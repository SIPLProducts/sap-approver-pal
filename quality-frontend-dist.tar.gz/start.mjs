#!/usr/bin/env node
/**
 * Launcher + HTTP server for the built app server (plain Node).
 * Usage (inside this dist/ folder):
 *   PORT=8080 HOST=0.0.0.0 node start.mjs
 * or with pm2:
 *   pm2 start ecosystem.config.cjs
 *
 * Runtime env vars live in dist/.env.runtime (KEY=value per line).
 */
import { createReadStream, existsSync, readFileSync, rmSync, statSync } from "node:fs";
import { createServer } from "node:http";
import { dirname, extname, join, normalize, resolve, sep } from "node:path";
import { Readable } from "node:stream";
import { fileURLToPath, pathToFileURL } from "node:url";



const here = dirname(fileURLToPath(import.meta.url));

const envFile = join(here, ".env.runtime");
if (existsSync(envFile)) {
  for (const line of readFileSync(envFile, "utf8").split(String.fromCharCode(10))) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq < 1) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = value;
  }
  console.log("[start] loaded env from .env.runtime");
} else {
  console.log("[start] no .env.runtime found — using the process environment as-is");
}

// Self-heal: a stray dist/node_modules (from an old wrangler-based install)
// serves no purpose now and only bloats the asset folder.
const strayModules = join(here, "node_modules");
if (existsSync(strayModules)) {
  rmSync(strayModules, { recursive: true, force: true });
  console.log("[start] removed stray dist/node_modules (not needed by the Node server)");
}

const entry = join(here, "server", "index.mjs");
if (!existsSync(entry)) {
  console.error(
    "[start] server/index.mjs not found next to start.mjs — incomplete dist/. " +
      "Rebuild with 'npm run build:selfhost' and copy the whole dist/ folder.",
  );
  process.exit(1);
}

const REQUIRED = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY"];
const missingRequired = REQUIRED.filter((key) => !process.env[key]);
if (missingRequired.length) {
  console.error(
    "[start] missing required value(s) in .env.runtime: " + missingRequired.join(", "),
  );
  process.exit(1);
}

const EXPECTED = [
  "SUPABASE_URL",
  "SUPABASE_ANON_KEY",
  "SUPABASE_PUBLISHABLE_KEY",
  "SUPABASE_SERVICE_ROLE_KEY",
  "SUPABASE_PROJECT_ID",
  "MIDDLEWARE_URL",
  "MIDDLEWARE_SHARED_SECRET",
  "MIDDLEWARE_TIMEOUT_MS",
];
const found = EXPECTED.filter((key) => !!process.env[key]);
const absent = EXPECTED.filter((key) => !process.env[key]);
console.log("[start] env present: " + (found.join(", ") || "(none)"));
if (absent.length) console.log("[start] env absent : " + absent.join(", "));

// Warn when the service-role slot actually holds an anon key: login can then
// read config but cannot create the backend session.
try {
  const part = String(process.env.SUPABASE_SERVICE_ROLE_KEY).split(".")[1];
  if (part) {
    const json = JSON.parse(Buffer.from(part, "base64url").toString("utf8"));
    if (json && json.role && json.role !== "service_role") {
      console.warn(
        "[start] warning: SUPABASE_SERVICE_ROLE_KEY holds a '" +
          json.role +
          "' key. Use SERVICE_ROLE_KEY from supabase/.env.",
      );
    }
  }
} catch {
  /* not a JWT-format key — nothing to check */
}

const port = Number(process.env.PORT ?? "8080");
const host = process.env.HOST ?? "0.0.0.0";
process.env.PORT = String(port);
process.env.HOST = host;
process.env.NITRO_PORT ??= String(port);
process.env.NITRO_HOST ??= String(port);
if (process.env.NODE_ENV === undefined) process.env.NODE_ENV = "production";

console.log("[start] loading " + entry);
const mod = await import(pathToFileURL(entry).href);
const handler = mod.default ?? mod;
if (typeof handler?.fetch !== "function") {
  console.error(
    "[start] server/index.mjs does not export a fetch handler — this dist/ is not a usable build.\n" +
      "[start] Rebuild with 'npm run build:selfhost' and copy the WHOLE folder across:\n" +
      "[start]   rsync -a --delete dist/ <server>:<path>/frontend/dist/",
  );
  process.exit(1);
}

// ---------------------------------------------------------------- static files
const MIME = {
  ".css": "text/css; charset=utf-8", ".gif": "image/gif", ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon", ".jpeg": "image/jpeg", ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8",
  ".map": "application/json; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".pdf": "application/pdf", ".png": "image/png", ".svg": "image/svg+xml",
  ".txt": "text/plain; charset=utf-8", ".webmanifest": "application/manifest+json",
  ".webp": "image/webp", ".woff": "font/woff", ".woff2": "font/woff2",
  ".xml": "application/xml; charset=utf-8",
};
const staticRoot = resolve(process.env.STATIC_ROOT ?? here);
const BLOCKED = ["server", ".env", "start.mjs", "ecosystem.config.cjs", "deploy-frontend.sh"];

function resolveStatic(pathname) {
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { return null; }
  if (decoded.includes("\0")) return null;
  const candidate = resolve(join(staticRoot, normalize(decoded)));
  if (candidate !== staticRoot && !candidate.startsWith(staticRoot + sep)) return null;
  const rel = candidate.slice(staticRoot.length + 1);
  if (BLOCKED.some((b) => rel === b || rel.startsWith(b))) return null;
  try {
    const info = statSync(candidate);
    if (!info.isFile()) return null;
    return { file: candidate, size: info.size };
  } catch { return null; }
}

// ------------------------------------------------------------- node <-> fetch
function toWebRequest(req) {
  const url = new URL(req.url ?? "/", "http://" + (req.headers.host ?? "127.0.0.1"));
  const headers = new Headers();
  for (const [key, value] of Object.entries(req.headers)) {
    if (value === undefined) continue;
    if (Array.isArray(value)) for (const item of value) headers.append(key, item);
    else headers.set(key, value);
  }
  const method = req.method ?? "GET";
  const hasBody = method !== "GET" && method !== "HEAD";
  return new Request(url, {
    method,
    headers,
    ...(hasBody ? { body: Readable.toWeb(req), duplex: "half" } : {}),
  });
}

async function sendWebResponse(res, response) {
  const headers = {};
  response.headers.forEach((value, key) => {
    if (key.toLowerCase() !== "set-cookie") headers[key] = value;
  });
  const cookies = response.headers.getSetCookie?.();
  if (cookies && cookies.length) headers["set-cookie"] = cookies;
  res.writeHead(response.status, headers);
  if (!response.body) { res.end(); return; }
  Readable.fromWeb(response.body).pipe(res);
}

const server = createServer((req, res) => {
  void (async () => {
    try {
      const { pathname } = new URL(req.url ?? "/", "http://" + (req.headers.host ?? "127.0.0.1"));
      if (req.method === "GET" || req.method === "HEAD") {
        const found = resolveStatic(pathname);
        if (found) {
          res.writeHead(200, {
            "content-type": MIME[extname(found.file).toLowerCase()] ?? "application/octet-stream",
            "content-length": String(found.size),
            "cache-control": pathname.startsWith("/assets/")
              ? "public, max-age=31536000, immutable"
              : "public, max-age=0, must-revalidate",
          });
          if (req.method === "HEAD") { res.end(); return; }
          createReadStream(found.file).pipe(res);
          return;
        }
      }
      // SSR + /_serverFn/* + /api/*
      const upstream = await handler.fetch(toWebRequest(req), process.env, undefined);
      // A 5xx produced *inside* the app (SSR render error) never reaches the catch
      // below, so log it here — otherwise pm2 logs stay silent while the browser
      // shows a blank page.
      if (upstream && upstream.status >= 500) {
        console.error("[server] " + req.method + " " + req.url + " -> HTTP " + upstream.status +
          " (rendered by the app; check the stack trace above/below)");
      }
      await sendWebResponse(res, upstream);
    } catch (error) {
      console.error("[server] request failed:", req.method, req.url, error);
      if (!res.headersSent) res.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
      res.end("Internal Server Error");
    }
  })();
});

server.on("error", (error) => {
  console.error("[start] cannot bind " + host + ":" + port + " —", error.message ?? error);
  process.exit(1);
});

// "listening" is printed only from the listen callback, so a log line can never
// claim the app is up while the port is actually closed.
server.listen(port, host, () => {
  console.log("[start] listening on http://" + host + ":" + port);
  console.log("[start] static root: " + staticRoot);
});

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
