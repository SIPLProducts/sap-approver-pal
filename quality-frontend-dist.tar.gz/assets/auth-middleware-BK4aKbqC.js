import{e}from"./index-FCLUiXKQ.js";const t=e({type:"function"});export{t as r};
