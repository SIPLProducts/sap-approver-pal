import{e}from"./index-CcHxqT8S.js";const t=e({type:"function"});export{t as r};
