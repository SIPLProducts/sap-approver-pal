globalThis.__nitro_main__ = import.meta.url;
import "./_libs/unenv.mjs";

import { H as HookableCore } from "./_libs/hookable.mjs";
import { d as defineLazyEventHandler, H as HTTPError, a as H3Core } from "./_libs/h3.mjs";
import { a as FastResponse } from "./_libs/srvx.mjs";


import "./_libs/react.mjs";
import "./_libs/rou3.mjs";





function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const assets = {
  "/favicon.png": {
    "type": "image/png",
    "etag": '"2065-0iuSYXCUQSAaRDaeCoHTnuIbULM"',
    "mtime": "2026-08-12T06:42:42.358Z",
    "size": 8293,
    "path": "../client/favicon.png"
  },
  "/sw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"520-qi3M9qfxV22PLmH3NQRZTAF6xxU"',
    "mtime": "2026-08-12T06:42:42.358Z",
    "size": 1312,
    "path": "../client/sw.js"
  },
  "/assets/_._lovable.oauth.consent-BTvXu2w8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1c5-pt2M5VtuaIJsm025EZcPKSQRDh8"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 453,
    "path": "../client/assets/_._lovable.oauth.consent-BTvXu2w8.js"
  },
  "/manifest.webmanifest": {
    "type": "application/manifest+json",
    "etag": '"167-HgpLF/4Nrau0RGrgQqtVVNbn1KY"',
    "mtime": "2026-08-12T06:42:42.358Z",
    "size": 359,
    "path": "../client/manifest.webmanifest"
  },
  "/assets/_._lovable.oauth.consent-DHcmEGEg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"65b-MYuoufcwIxhHFXLJv/7Y6nyKw6o"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 1627,
    "path": "../client/assets/_._lovable.oauth.consent-DHcmEGEg.js"
  },
  "/assets/activity-B6_tA35E.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f6-yNv6FFWAQJt/Yuf+tJM9wIBeabw"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 246,
    "path": "../client/assets/activity-B6_tA35E.js"
  },
  "/assets/admin.integrations-Ck-6pkB3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1a5e-d42Bd+arBmwUREjy998+IMACbCg"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 6750,
    "path": "../client/assets/admin.integrations-Ck-6pkB3.js"
  },
  "/assets/admin.sap-api._id-DLPYGxKe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5982-gk5eayFDkRCeghF5WAI9C5m/rh4"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 22914,
    "path": "../client/assets/admin.sap-api._id-DLPYGxKe.js"
  },
  "/assets/_authenticated-CC02iV1W.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"47a6-McY35E3H+MqV9t13yaSJcaXmmK4"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 18342,
    "path": "../client/assets/_authenticated-CC02iV1W.js"
  },
  "/assets/admin.sap-api.index-BbIm12Bd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3bd1-FTTnkDQI5IAOHH2PXXTF/dwlQ58"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 15313,
    "path": "../client/assets/admin.sap-api.index-BbIm12Bd.js"
  },
  "/assets/admin.strategies-1iQ0iD6e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7a4-xYDb5C4kEkuGCwuaA74+oL+Xl6A"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 1956,
    "path": "../client/assets/admin.strategies-1iQ0iD6e.js"
  },
  "/assets/admin.users-eg-rSReO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"97da-UrKdJrW2Uw9OUrlu2nJAwZDd4fI"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 38874,
    "path": "../client/assets/admin.users-eg-rSReO.js"
  },
  "/assets/alert-sh-H2Fxu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e0-XYyJTBmV3cxWrKaNid1Ze+8HsiI"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 992,
    "path": "../client/assets/alert-sh-H2Fxu.js"
  },
  "/assets/approval._id-sEn2RF7J.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ea2-ufGqh6qoVdiQnYkCnsCQmuG5UKI"',
    "mtime": "2026-08-12T06:42:34.501Z",
    "size": 7842,
    "path": "../client/assets/approval._id-sEn2RF7J.js"
  },
  "/assets/arrow-left--FEzZTw-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b1-gsT2/pD4zYpa96TASJeuKg/J4gM"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 177,
    "path": "../client/assets/arrow-left--FEzZTw-.js"
  },
  "/assets/auth-middleware-BK4aKbqC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"50-RSbzmMScK5yJrrRvG1YQWfWplGM"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 80,
    "path": "../client/assets/auth-middleware-BK4aKbqC.js"
  },
  "/assets/badge-CylCXewn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"313-aj7uhbDkHUrYb9TRll1WlEkh9Nk"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 787,
    "path": "../client/assets/badge-CylCXewn.js"
  },
  "/assets/bell-CKuOEVWI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"12e-ANVncQYCKhXn9yimaRG/cLEXZNQ"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 302,
    "path": "../client/assets/bell-CKuOEVWI.js"
  },
  "/assets/bmw-status-report.functions-DrV0KTG3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"110-BtgGqwrzodaB3aqM4OPLtIHwXJI"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 272,
    "path": "../client/assets/bmw-status-report.functions-DrV0KTG3.js"
  },
  "/assets/brand-logo-caYVrb37.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"178-NC8HGEtzChDfMlNrlvXTPHhJWbk"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 376,
    "path": "../client/assets/brand-logo-caYVrb37.js"
  },
  "/assets/button-BdlZu0m_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d85-zCfXLTD1XZeY91p965LTZGgC3rg"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 3461,
    "path": "../client/assets/button-BdlZu0m_.js"
  },
  "/assets/card-DcwkcHcd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e3-qg6Vtn4hAPgrogvefpNFpcq6icw"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 995,
    "path": "../client/assets/card-DcwkcHcd.js"
  },
  "/assets/check-qIk6bTyy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"83-cJfvecEDYdUkLpI1RShxG9yC1V8"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 131,
    "path": "../client/assets/check-qIk6bTyy.js"
  },
  "/assets/checkbox-BQy6SvsR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"fa9-SUyCKVo4YsGiyUMHyQ4BChR/1+E"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 4009,
    "path": "../client/assets/checkbox-BQy6SvsR.js"
  },
  "/assets/Combination-C48hQ6hq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5e59-urUIgPinEst23V9+GYjJGrP/y88"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 24153,
    "path": "../client/assets/Combination-C48hQ6hq.js"
  },
  "/assets/chevron-right-C5xvmKVF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8e-uq2Vzx00Y3MVBH1rfqSOSbqA6os"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 142,
    "path": "../client/assets/chevron-right-C5xvmKVF.js"
  },
  "/assets/circle-alert-Dpg7QVBD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"106-iCgDavXJ0f+rFXpnzYyhEHVgVUU"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 262,
    "path": "../client/assets/circle-alert-Dpg7QVBD.js"
  },
  "/assets/cloudscape-approval-table-DBQjFaZr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1968-PRgMjOJr5Ip24Ge5CPuiJERxhMU"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 6504,
    "path": "../client/assets/cloudscape-approval-table-DBQjFaZr.js"
  },
  "/assets/circle-check-mBWePZhe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b9-qabrM1M/7J2c2RtwRzupNwqryis"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 185,
    "path": "../client/assets/circle-check-mBWePZhe.js"
  },
  "/assets/command-Um2TNYV6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5237-s3CRo2V+MirUy5O6ihEr3p91wJQ"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 21047,
    "path": "../client/assets/command-Um2TNYV6.js"
  },
  "/assets/confirm-dialog-B5RzJApi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"15b1-G+KuFvPkbGN/J8Mg8+0W7x4o9nk"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 5553,
    "path": "../client/assets/confirm-dialog-B5RzJApi.js"
  },
  "/assets/createLucideIcon-9crj5PK0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4b2-Tfnc9BVHsePPR7Smc3xuNo8MTfs"',
    "mtime": "2026-08-12T06:42:34.501Z",
    "size": 1202,
    "path": "../client/assets/createLucideIcon-9crj5PK0.js"
  },
  "/assets/contract-approval.functions-NXsOpppd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"186-K836513NsBhfjoxFL3FABY1dDoA"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 390,
    "path": "../client/assets/contract-approval.functions-NXsOpppd.js"
  },
  "/assets/constants-MDQLjhgn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"840-Dzj42sRbcrda86oXAh9wim/QCT8"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 2112,
    "path": "../client/assets/constants-MDQLjhgn.js"
  },
  "/assets/createServerFn-Ud3h4Dxf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1216-afMZ311JPBu84KpsuHmaisEYbh0"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 4630,
    "path": "../client/assets/createServerFn-Ud3h4Dxf.js"
  },
  "/assets/customer-select-CB5LJIKG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1513-hG8Au9cjC5Y3BjebQbvoO00POSo"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 5395,
    "path": "../client/assets/customer-select-CB5LJIKG.js"
  },
  "/assets/dialog-hX5B8jYO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"81b-LzUj5TKQC7LM74E/SaHCq90WQ7s"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 2075,
    "path": "../client/assets/dialog-hX5B8jYO.js"
  },
  "/assets/email-config-BAKnt0jX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"24fa-NTeeiu5HSGiW/YctSkeqB0cmbAQ"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 9466,
    "path": "../client/assets/email-config-BAKnt0jX.js"
  },
  "/assets/dynamic-columns-ChX3M34h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"999-q+A4kKhjy1nefzfLE/hR+SaGnbE"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 2457,
    "path": "../client/assets/dynamic-columns-ChX3M34h.js"
  },
  "/assets/eye-BmBuQURW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"107-zNVrw/ACAHU+ZqsgAEOB2flu3r4"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 263,
    "path": "../client/assets/eye-BmBuQURW.js"
  },
  "/assets/eye-off-DmuwiowN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ba-FRbnIOXgpJ5WBhbwFpvMsrNmqfk"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 442,
    "path": "../client/assets/eye-off-DmuwiowN.js"
  },
  "/assets/empty-state-DzJ1qj9k.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"311-NI7JDGy6ojUSK4b8EGaLICMxikQ"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 785,
    "path": "../client/assets/empty-state-DzJ1qj9k.js"
  },
  "/assets/file-check-corner-NRhLWbqP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"147-2rZI4milPsuZEoj71mmwrVpIpV0"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 327,
    "path": "../client/assets/file-check-corner-NRhLWbqP.js"
  },
  "/assets/file-text-DGzc0H5h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18d-Yhot+hUoMyvlrXVdrKD3V2G9T/c"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 397,
    "path": "../client/assets/file-text-DGzc0H5h.js"
  },
  "/assets/format-C58jPiiU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4d7-zP9OjQgvkwcRPxpqqmzra4LF5GE"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 1239,
    "path": "../client/assets/format-C58jPiiU.js"
  },
  "/assets/inbox-Bu933Km5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"12a-p30Z/tR/0EKMIp9uD9nJhJ/zcfM"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 298,
    "path": "../client/assets/inbox-Bu933Km5.js"
  },
  "/assets/funnel-Fq4Jn58V.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"99e-u9WdBVsOlIu4mV8GemqYAUglv/s"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 2462,
    "path": "../client/assets/funnel-Fq4Jn58V.js"
  },
  "/assets/inbox._module-1qsT2Ybm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1c10-IvlGpaNBBoNbyeauTr1AkJLvS3A"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 7184,
    "path": "../client/assets/inbox._module-1qsT2Ybm.js"
  },
  "/assets/history-C5gPslwN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"858-eUng+IgwfDq4OJ6uTxNdJ7H2MaE"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 2136,
    "path": "../client/assets/history-C5gPslwN.js"
  },
  "/assets/history-rXM_8JVh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f9-j4otTu8d4WXON6qHjOmbTfDGeZM"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 249,
    "path": "../client/assets/history-rXM_8JVh.js"
  },
  "/assets/index-3NcoG0kJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4759-rpXTU//2s2AbUuozF377T8p+D1Q"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 18265,
    "path": "../client/assets/index-3NcoG0kJ.js"
  },
  "/assets/index-Bl4GKtGX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7f7-NO18NFIrfiA1LSAp95SmYqlRnPM"',
    "mtime": "2026-08-12T06:42:34.501Z",
    "size": 2039,
    "path": "../client/assets/index-Bl4GKtGX.js"
  },
  "/assets/index-C1kpxTz7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a8c-Jt9I1d/knbSpy9HbnaNBuY4C/OE"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 2700,
    "path": "../client/assets/index-C1kpxTz7.js"
  },
  "/assets/index-D-Aj3wsy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6963-PoYSRQHoJoNNmilIYVILiR6CRG4"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 26979,
    "path": "../client/assets/index-D-Aj3wsy.js"
  },
  "/assets/index-DMU1Tc1c.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"de7-R/zLqWfO1c8D3X1K1USNwZ4VsGs"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 3559,
    "path": "../client/assets/index-DMU1Tc1c.js"
  },
  "/assets/index-LHNt3CwB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2bb-FdPVTTp03mSjPnpcgLEqlvVfPpU"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 699,
    "path": "../client/assets/index-LHNt3CwB.js"
  },
  "/assets/input-BLBZiEAI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"24e-NknsMTYXPvtcvwcH3gv9TxKOxFQ"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 590,
    "path": "../client/assets/input-BLBZiEAI.js"
  },
  "/assets/kpi-tile-BvgKxHEX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"61d-6t0HhFd2MqjX+fAcl6od/6UeLgg"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 1565,
    "path": "../client/assets/kpi-tile-BvgKxHEX.js"
  },
  "/assets/label-B95Vr-g0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3d6-xOBMfMA9stw7Vt1t1zwZQ7dxm9w"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 982,
    "path": "../client/assets/label-B95Vr-g0.js"
  },
  "/assets/loader-circle-YsuScR2T.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"97-LplH9a4grjLE6Bb2htNizVAZDag"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 151,
    "path": "../client/assets/loader-circle-YsuScR2T.js"
  },
  "/assets/lock-B60z-rVk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14f-ksuCMnv41cJ62nx3GbiKW69781Y"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 335,
    "path": "../client/assets/lock-B60z-rVk.js"
  },
  "/assets/login-C_nUdT55.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1f1c-EWYuBw8whN4Kq0zMngdOei/SMGA"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 7964,
    "path": "../client/assets/login-C_nUdT55.js"
  },
  "/assets/mm.gate-pass-DgjL0R64.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2176-Z7zLUNjFXZQZvqEFYvFA9Meh9Qk"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 8566,
    "path": "../client/assets/mm.gate-pass-DgjL0R64.js"
  },
  "/assets/index-J2YU0p-x.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2dd-ac/DUl8xO9Qm+sPQmQtRBdJ5utY"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 733,
    "path": "../client/assets/index-J2YU0p-x.js"
  },
  "/assets/mm.material-reservation-CXQbHuw-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"234b-eR4aJRN9zKm32ULvem7RvrunAt8"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 9035,
    "path": "../client/assets/mm.material-reservation-CXQbHuw-.js"
  },
  "/assets/mm.migo-release-P7Qm0ULh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"249d-Lb9MfFGeL9IyPEpOQB4n9SDjwio"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 9373,
    "path": "../client/assets/mm.migo-release-P7Qm0ULh.js"
  },
  "/assets/mm.po-release-CA7HQ5tH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2cc1-XPsoj80qRh57Mj5Nxy3KlvJidEQ"',
    "mtime": "2026-08-12T06:42:34.501Z",
    "size": 11457,
    "path": "../client/assets/mm.po-release-CA7HQ5tH.js"
  },
  "/assets/mm.pr-release-57FdIdE2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2e73-OXG48pOA/Gx0zQreLY2KFJajM/I"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 11891,
    "path": "../client/assets/mm.pr-release-57FdIdE2.js"
  },
  "/assets/mm.znfa-release-UOnY250_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b53c-Esx1m9Ak9gFvLjfrBfojMz1VeL8"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 46396,
    "path": "../client/assets/mm.znfa-release-UOnY250_.js"
  },
  "/assets/notifications-K56-pV7I.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"90c-B/t42L5eppX+VpAQn1I3iSndLAY"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 2316,
    "path": "../client/assets/notifications-K56-pV7I.js"
  },
  "/assets/info-CD0GvhpV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d3-DFf3X/C0NGNXHEbi1CBDK8iO0Cc"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 211,
    "path": "../client/assets/info-CD0GvhpV.js"
  },
  "/assets/package-9uh_ADyb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"180-uCHt0Il939Eukh5PmPLSYjud1xk"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 384,
    "path": "../client/assets/package-9uh_ADyb.js"
  },
  "/assets/index-CHGBLnyp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2145-kyc8RWOEjkLwWfAxVVhwD/usX88"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 8517,
    "path": "../client/assets/index-CHGBLnyp.js"
  },
  "/assets/mm.gate-process-DPzvWmYT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"324b-meVnijRVEFi65JT4H5ehMNmz/aY"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 12875,
    "path": "../client/assets/mm.gate-process-DPzvWmYT.js"
  },
  "/assets/index-FCLUiXKQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a1c75-J6N2pGvLN0xWPYJIdhYJb0WPPr4"',
    "mtime": "2026-08-12T06:42:34.502Z",
    "size": 662645,
    "path": "../client/assets/index-FCLUiXKQ.js"
  },
  "/assets/page-header-BSSAyo33.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"36f-M8nxY64H4ZEmLKoTlNgcfLhET7Y"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 879,
    "path": "../client/assets/page-header-BSSAyo33.js"
  },
  "/assets/pencil-DpYtS-wB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"120-TSJrb5vb/dAWfNKqN5tQgGqEWbg"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 288,
    "path": "../client/assets/pencil-DpYtS-wB.js"
  },
  "/assets/plant-multi-select-CnQFHPwh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1141-yjhJ1IJqPSYZ1FeTgosfUGacEQo"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 4417,
    "path": "../client/assets/plant-multi-select-CnQFHPwh.js"
  },
  "/assets/plant-select-Dauzwgd_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1286-K1aIFgy9octdbb+MwhiAc3owj+Q"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 4742,
    "path": "../client/assets/plant-select-Dauzwgd_.js"
  },
  "/assets/price-approval.functions-2T1i_aIT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"205-3US3auDpIupsl15rxDpCv+G2bWE"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 517,
    "path": "../client/assets/price-approval.functions-2T1i_aIT.js"
  },
  "/assets/radio-group-BkLOoTe3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1087-HaN7FmMJh27tx7/UWAgQY7YnZ6g"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 4231,
    "path": "../client/assets/radio-group-BkLOoTe3.js"
  },
  "/assets/refresh-cw-C_vHLvO9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"29c-g+7746EeU8kdVMaKfuAxy+9kxhs"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 668,
    "path": "../client/assets/refresh-cw-C_vHLvO9.js"
  },
  "/assets/release-key-select-dZhpDNRW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"616-m4Oad9/SPfnhE9HL1HYDAftWAzE"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 1558,
    "path": "../client/assets/release-key-select-dZhpDNRW.js"
  },
  "/assets/rotate-ccw-DaLRSTba.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d4-AYtEwkVGjUpe7ZJzRptVavJaMeI"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 212,
    "path": "../client/assets/rotate-ccw-DaLRSTba.js"
  },
  "/assets/sales-order-approval.functions-B9tlB2q2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"190-Cs/i1ba01UzUKh/N48Ug9wXYdd8"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 400,
    "path": "../client/assets/sales-order-approval.functions-B9tlB2q2.js"
  },
  "/assets/sap-api.functions-BpCtWEmc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"471-FCwkxWIsB62ECDlKO/ynr6bhaIw"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 1137,
    "path": "../client/assets/sap-api.functions-BpCtWEmc.js"
  },
  "/assets/sap.functions-DWQMMfLC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"206-pX9A4GhHeUTmt2zZ0jhawjPMoIA"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 518,
    "path": "../client/assets/sap.functions-DWQMMfLC.js"
  },
  "/assets/save-Dk6a4caP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"153-MurVhM6GcufombbdJf//Uq/DOC0"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 339,
    "path": "../client/assets/save-Dk6a4caP.js"
  },
  "/assets/sc-so-approval.functions-C42CjEpa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"186-wrZqqkJ6MAHGqlCiKXVomW9WJMs"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 390,
    "path": "../client/assets/sc-so-approval.functions-C42CjEpa.js"
  },
  "/assets/sd.contract-B2Wk0uhE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2ca9-2TluY6jDfo124B7B4wPE0vzkkAw"',
    "mtime": "2026-08-12T06:42:34.502Z",
    "size": 11433,
    "path": "../client/assets/sd.contract-B2Wk0uhE.js"
  },
  "/assets/sd.bmw-status-CYFxrTKU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3725-I/1ajgpZVkI7eoGZSjc618aGFqQ"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 14117,
    "path": "../client/assets/sd.bmw-status-CYFxrTKU.js"
  },
  "/assets/sd.contract-reports-BUkr4ROK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1131-TtSV9lpGeBo0tXUQG7R3Q7xyMb8"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 4401,
    "path": "../client/assets/sd.contract-reports-BUkr4ROK.js"
  },
  "/assets/sd.price-CE2-gmRS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1f9f-e7GFulF5S+s/UI8r9SoNnesmnPE"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 8095,
    "path": "../client/assets/sd.price-CE2-gmRS.js"
  },
  "/assets/sd.price-reports-DLNtEF8S.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ffa-4r6wG0RNgZ0B7V/NjLhJlebu/g8"',
    "mtime": "2026-08-12T06:42:34.497Z",
    "size": 4090,
    "path": "../client/assets/sd.price-reports-DLNtEF8S.js"
  },
  "/assets/sd.sales-order-B7HTC5cH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2def-aAglLrA8inmURT8JT4s0/xzOlOI"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 11759,
    "path": "../client/assets/sd.sales-order-B7HTC5cH.js"
  },
  "/assets/sd.sales-order-reports-JHEvQxYn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"10e5-pQHMn0+sdgjLt1VNUlTts3wRxME"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 4325,
    "path": "../client/assets/sd.sales-order-reports-JHEvQxYn.js"
  },
  "/assets/sd.sc-so-3XxdbRsH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3008-kNUQCk8sa0jFxQ4qzZ1ukagUKs0"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 12296,
    "path": "../client/assets/sd.sc-so-3XxdbRsH.js"
  },
  "/assets/sd.sc-so-reports-ihn379dK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1399-+CdmO0hBV3MpyjkWKe0AuqU8Y3s"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 5017,
    "path": "../client/assets/sd.sc-so-reports-ihn379dK.js"
  },
  "/assets/sd.dashboard-BMJZ5t_J.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6ae92-YIsW3QtVNyHma1l45GEdGG6qRgk"',
    "mtime": "2026-08-12T06:42:34.502Z",
    "size": 437906,
    "path": "../client/assets/sd.dashboard-BMJZ5t_J.js"
  },
  "/assets/search-term-multi-select-BQoYwKSE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18ad-txXOTX4W8XIVVjyE0JPoy5P38uU"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 6317,
    "path": "../client/assets/search-term-multi-select-BQoYwKSE.js"
  },
  "/assets/search-xBRK3i95.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b5-tEAD7k7/Y9hYi1c7YBYCzVbhfhc"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 181,
    "path": "../client/assets/search-xBRK3i95.js"
  },
  "/assets/select-BbQzqb2p.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"593e-uisF3zd7ar2lqfJuXP+B1IagkZE"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 22846,
    "path": "../client/assets/select-BbQzqb2p.js"
  },
  "/assets/server-CZ0l8T0U.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"24c-9TzURdz6jaPsOQIMu7LO5dWFBFI"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 588,
    "path": "../client/assets/server-CZ0l8T0U.js"
  },
  "/assets/settings-9x5jRnUd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"13f4-zYIerOL2Ioe30wnHRmdXQUZj5p8"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 5108,
    "path": "../client/assets/settings-9x5jRnUd.js"
  },
  "/assets/shield-check-BUNgOqUd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"147-pt0YMrmMVeetL6vD96gInpFH9oQ"',
    "mtime": "2026-08-12T06:42:34.502Z",
    "size": 327,
    "path": "../client/assets/shield-check-BUNgOqUd.js"
  },
  "/assets/switch-0JUcwZYm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a1e-8Kt++FE0uJ/P/PHOARx0AL4L4HY"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 2590,
    "path": "../client/assets/switch-0JUcwZYm.js"
  },
  "/assets/table-BoN6n87V.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6b3-0YWZaw8nHDa8UsS6Ga3sAPis73E"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 1715,
    "path": "../client/assets/table-BoN6n87V.js"
  },
  "/assets/status-badge-BDh8EenV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"83b-Kqlyt0mDoOne/ZdxipM4uFAotX8"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 2107,
    "path": "../client/assets/status-badge-BDh8EenV.js"
  },
  "/assets/tabs-DKOwlYF6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"efc-YlCgPZyzar/zYgzJodDRPJxncKM"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 3836,
    "path": "../client/assets/tabs-DKOwlYF6.js"
  },
  "/assets/skeleton-C9QkHNnS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"cd-pmOmOXwnNx8YYmgwsBImQh/pN5I"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 205,
    "path": "../client/assets/skeleton-C9QkHNnS.js"
  },
  "/assets/textarea-CjNq2HRm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1e8-J3CTWeW5V9WJ6tSn9IYM/F24AoM"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 488,
    "path": "../client/assets/textarea-CjNq2HRm.js"
  },
  "/assets/triangle-alert-Cl0ZgDu0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"115-1ucV4c7w1wVxaK4vGPz+pNEGZB8"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 277,
    "path": "../client/assets/triangle-alert-Cl0ZgDu0.js"
  },
  "/assets/skeleton-rows-D4IEbkhM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e2-+avF3IorVFaJGKtlxD2DRMCnPiE"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 994,
    "path": "../client/assets/skeleton-rows-D4IEbkhM.js"
  },
  "/assets/use-active-context-HrDWIFRC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1410-eBTKvl6yqJHv2eRUhuQUtzQN4MM"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 5136,
    "path": "../client/assets/use-active-context-HrDWIFRC.js"
  },
  "/assets/truck-CMAUtG5p.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"268-Q/qV6+dZLkxxSbONjJ8mphuDBww"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 616,
    "path": "../client/assets/truck-CMAUtG5p.js"
  },
  "/assets/use-sap-profile-iFE8cLZ-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"36f-gyShZ35oPRLdRBJWu2ItoQDhuOY"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 879,
    "path": "../client/assets/use-sap-profile-iFE8cLZ-.js"
  },
  "/assets/use-auth-C-J3xig-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18d-trs5lQLgmjYOxIuqXfdfUKbdZ9o"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 397,
    "path": "../client/assets/use-auth-C-J3xig-.js"
  },
  "/assets/utils-BQHNewu7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"683d-MgixwZ5BLQV8sqtaj9G83JcgCSQ"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 26685,
    "path": "../client/assets/utils-BQHNewu7.js"
  },
  "/assets/useQuery-COKTYHYO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"226e-fzx6lCRKf0EZlJ749+sYwaBxA7E"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 8814,
    "path": "../client/assets/useQuery-COKTYHYO.js"
  },
  "/assets/use-permissions-BOmZIYT6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"309-cZCn8bvs1LgrjlZa/u4ykp3zwR4"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 777,
    "path": "../client/assets/use-permissions-BOmZIYT6.js"
  },
  "/assets/users-DIarig-3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"22d-3SUlBDruIjLCjd4IX0N9wtCM0Yc"',
    "mtime": "2026-08-12T06:42:34.499Z",
    "size": 557,
    "path": "../client/assets/users-DIarig-3.js"
  },
  "/assets/x-BzMwchnq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a6-O9ciTrQmO69w10rZthGJbn+2Df8"',
    "mtime": "2026-08-12T06:42:34.498Z",
    "size": 166,
    "path": "../client/assets/x-BzMwchnq.js"
  },
  "/assets/styles-CuqGuqZr.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"4a217-nY3MryUr6lNwc3RkshHHCPI7QlE"',
    "mtime": "2026-08-12T06:42:34.490Z",
    "size": 303639,
    "path": "../client/assets/styles-CuqGuqZr.css"
  }
};
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
const headers = ((m) => function headersRouteRule(event) {
  for (const [key, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key, value);
  }
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_j21Qvj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_j21Qvj };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function useNitroHooks() {
  const nitroApp = useNitroApp();
  const hooks = nitroApp.hooks;
  if (hooks) {
    return hooks;
  }
  return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function createHandler(hooks) {
  const nitroApp = useNitroApp();
  const nitroHooks = useNitroHooks();
  return {
    async fetch(request, env, context) {
      globalThis.__env__ = env;
      augmentReq(request, {
        env,
        context
      });
      const ctxExt = {};
      const url = new URL(request.url);
      if (hooks.fetch) {
        const res = await hooks.fetch(request, env, context, url, ctxExt);
        if (res) {
          return res;
        }
      }
      return await nitroApp.fetch(request);
    },
    scheduled(controller, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
        controller,
        env,
        context
      }) || Promise.resolve());
    },
    email(message, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:email", {
        message,
        event: message,
        env,
        context
      }) || Promise.resolve());
    },
    queue(batch, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
        batch,
        event: batch,
        env,
        context
      }) || Promise.resolve());
    },
    tail(traces, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
        traces,
        env,
        context
      }) || Promise.resolve());
    },
    trace(traces, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
        traces,
        env,
        context
      }) || Promise.resolve());
    }
  };
}
function augmentReq(cfReq, ctx) {
  const req = cfReq;
  req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
  req.runtime ??= { name: "cloudflare" };
  req.runtime.cloudflare = {
    ...req.runtime.cloudflare,
    ...ctx
  };
  req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
const cloudflareModule = createHandler({ fetch(cfRequest, env, context, url) {
  if (env.ASSETS && isPublicAssetURL(url.pathname)) {
    return env.ASSETS.fetch(cfRequest);
  }
} });
export {
  cloudflareModule as default
};
