globalThis.__nitro_main__ = import.meta.url;
import "./_libs/unenv.mjs";

import { H as HookableCore } from "./_libs/hookable.mjs";
import { d as defineLazyEventHandler, H as HTTPError, a as H3Core } from "./_libs/h3.mjs";
import { a as FastResponse } from "./_libs/srvx.mjs";


import "./_libs/react.mjs";
import "./_libs/rou3.mjs";





function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const assets = {
  "/sw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"520-qi3M9qfxV22PLmH3NQRZTAF6xxU"',
    "mtime": "2026-08-11T17:23:06.019Z",
    "size": 1312,
    "path": "../client/sw.js"
  },
  "/favicon.png": {
    "type": "image/png",
    "etag": '"2065-0iuSYXCUQSAaRDaeCoHTnuIbULM"',
    "mtime": "2026-08-11T17:23:06.019Z",
    "size": 8293,
    "path": "../client/favicon.png"
  },
  "/assets/_._lovable.oauth.consent-DCrOXSTk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1c5-mj0+eVzbcjk7orif6zrmtCbJN4I"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 453,
    "path": "../client/assets/_._lovable.oauth.consent-DCrOXSTk.js"
  },
  "/assets/_._lovable.oauth.consent-CHwAjQ5B.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"65b-zsJHP1/uDM4VG1M5nCLEnbi0OOg"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 1627,
    "path": "../client/assets/_._lovable.oauth.consent-CHwAjQ5B.js"
  },
  "/assets/activity-C7Q4cRTK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f6-xgJfmtJc3P+GvWo8ZkjMc2PKo+g"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 246,
    "path": "../client/assets/activity-C7Q4cRTK.js"
  },
  "/assets/Combination-2bG2pDLf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5e59-Nj3MZFMGRn4v/h0ohsr1hi6XC8c"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 24153,
    "path": "../client/assets/Combination-2bG2pDLf.js"
  },
  "/assets/_authenticated-B5pH02iO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"47a6-EqPe03gSa1SZzt3HZpL6d6jM2uE"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 18342,
    "path": "../client/assets/_authenticated-B5pH02iO.js"
  },
  "/assets/admin.sap-api._id-8FMn-9rg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5982-aK/yKjlCed3yxkRsa2OVyoT4Q40"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 22914,
    "path": "../client/assets/admin.sap-api._id-8FMn-9rg.js"
  },
  "/assets/admin.integrations-olq-FO7T.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1a5e-RlY0g7xGkx1sHdgK4B/EE+y0MP0"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 6750,
    "path": "../client/assets/admin.integrations-olq-FO7T.js"
  },
  "/assets/admin.sap-api.index-Ba3dYEk9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3bd1-+o8wEJPMwEo2DtGoLzVlN+OpOgY"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 15313,
    "path": "../client/assets/admin.sap-api.index-Ba3dYEk9.js"
  },
  "/assets/alert-BPoRT5l4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e0-pW93PxUZ1ftJQMyUZKkujIe8Xz4"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 992,
    "path": "../client/assets/alert-BPoRT5l4.js"
  },
  "/manifest.webmanifest": {
    "type": "application/manifest+json",
    "etag": '"167-HgpLF/4Nrau0RGrgQqtVVNbn1KY"',
    "mtime": "2026-08-11T17:23:06.020Z",
    "size": 359,
    "path": "../client/manifest.webmanifest"
  },
  "/assets/admin.strategies-DQwawjFg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7a4-h8OUImSV7sMvzpxIW+K358U2S8Q"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 1956,
    "path": "../client/assets/admin.strategies-DQwawjFg.js"
  },
  "/assets/admin.users-B7-3zu43.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"97da-oxuMz2TEQ7FStcnHMAY8GGs9yZU"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 38874,
    "path": "../client/assets/admin.users-B7-3zu43.js"
  },
  "/assets/arrow-left-CVlDSZwQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b1-OuPx+Ztf2KrcR/P67OWGJQOMiR0"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 177,
    "path": "../client/assets/arrow-left-CVlDSZwQ.js"
  },
  "/assets/approval._id-DqUBvGGu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ea2-gVQE86Sg3nmNFbjAo7b2YGSvcW0"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 7842,
    "path": "../client/assets/approval._id-DqUBvGGu.js"
  },
  "/assets/badge-BjPWJ5mJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"313-DX+YQ06jOPVpeFpASJyGCbQmdk8"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 787,
    "path": "../client/assets/badge-BjPWJ5mJ.js"
  },
  "/assets/brand-logo-nq_PjjML.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"178-tRCp8OZyyEGG4JEPtLDFmiq3wlI"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 376,
    "path": "../client/assets/brand-logo-nq_PjjML.js"
  },
  "/assets/auth-middleware-WszeL8DX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"50-5V8lFFf7gRrafxUVOKXidwbwvFs"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 80,
    "path": "../client/assets/auth-middleware-WszeL8DX.js"
  },
  "/assets/bell-DqjzOO8X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"12e-KPZ8ccFF5UVzfwcET76Cgh63b5Y"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 302,
    "path": "../client/assets/bell-DqjzOO8X.js"
  },
  "/assets/bmw-status-report.functions-Cdpq8LdO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"110-7lU8fsbbx0hEF0X4u38tuVY0Dm4"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 272,
    "path": "../client/assets/bmw-status-report.functions-Cdpq8LdO.js"
  },
  "/assets/card-Dl2W0e68.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e3-YWTYTldW2PrDS3xCiq8qrMGf6F8"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 995,
    "path": "../client/assets/card-Dl2W0e68.js"
  },
  "/assets/button-DuFcH-8z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d85-/T+tsxc2dL9g2WwEWu2HoQYXeGI"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 3461,
    "path": "../client/assets/button-DuFcH-8z.js"
  },
  "/assets/check-F32kDnLO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"83-bpExtKssnXQOIJFk24R1Jm9DWQc"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 131,
    "path": "../client/assets/check-F32kDnLO.js"
  },
  "/assets/checkbox-Cacr7CII.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"fa9-2y9imu2m5aWl5pBCCrjiSWHBUpY"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 4009,
    "path": "../client/assets/checkbox-Cacr7CII.js"
  },
  "/assets/circle-check-LTPc6G0N.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b9-Sntpl+ZWaqcqXoFJNygiqUVDPPk"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 185,
    "path": "../client/assets/circle-check-LTPc6G0N.js"
  },
  "/assets/confirm-dialog-D2PztHJQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"15b1-IS0BasmStWgr47EBERCO5ha6iPw"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 5553,
    "path": "../client/assets/confirm-dialog-D2PztHJQ.js"
  },
  "/assets/command-BFkZ1HTZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5237-wXnMSuUHE7vgQUfzNoF9GJ+8uPs"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 21047,
    "path": "../client/assets/command-BFkZ1HTZ.js"
  },
  "/assets/chevron-right-kaVQsulA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8e-/ftcGXQpJXQjp5OO2wRlCCRErJc"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 142,
    "path": "../client/assets/chevron-right-kaVQsulA.js"
  },
  "/assets/circle-alert-D4eXsPfU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"106-Fz110gbLSZxcf2hTYg4fS7xrjMA"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 262,
    "path": "../client/assets/circle-alert-D4eXsPfU.js"
  },
  "/assets/constants-Bkdyjkz3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"824-ii0EiAOnZZxBnVWl28WXLE1c6sI"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 2084,
    "path": "../client/assets/constants-Bkdyjkz3.js"
  },
  "/assets/cloudscape-approval-table-By1eds8I.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1968-sP7/JU++euOTr/1wpJKGL0UtpgY"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 6504,
    "path": "../client/assets/cloudscape-approval-table-By1eds8I.js"
  },
  "/assets/contract-approval.functions-CeHjH5Cl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"186-NktXhX5yLsML50KITyuZG+Pp13Q"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 390,
    "path": "../client/assets/contract-approval.functions-CeHjH5Cl.js"
  },
  "/assets/customer-select-BRT2fV1E.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1513-mbRMgRqRpBIldlV9BCE1cHnL7SA"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 5395,
    "path": "../client/assets/customer-select-BRT2fV1E.js"
  },
  "/assets/createLucideIcon-CqcclLPy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4b2-V6HopmrmuHE+Oj/carPJhWGtQek"',
    "mtime": "2026-08-11T17:22:57.594Z",
    "size": 1202,
    "path": "../client/assets/createLucideIcon-CqcclLPy.js"
  },
  "/assets/createServerFn-DWcl6fkj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1216-EpnwYI8UOXDVY+hct/UYz5pbwpk"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 4630,
    "path": "../client/assets/createServerFn-DWcl6fkj.js"
  },
  "/assets/dialog-B5zF04An.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"81b-gqNnBGcsY1v1DkPFa1P2OKt9Ui8"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 2075,
    "path": "../client/assets/dialog-B5zF04An.js"
  },
  "/assets/dynamic-columns-ChX3M34h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"999-q+A4kKhjy1nefzfLE/hR+SaGnbE"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 2457,
    "path": "../client/assets/dynamic-columns-ChX3M34h.js"
  },
  "/assets/email-config-CXilG6Hx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"24fa-gmW03rw0xyTdOToacofMcw6WABE"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 9466,
    "path": "../client/assets/email-config-CXilG6Hx.js"
  },
  "/assets/empty-state-J3hpA3px.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"311-O1MKYuX0vZ6wcmxOnUJOByWVXSE"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 785,
    "path": "../client/assets/empty-state-J3hpA3px.js"
  },
  "/assets/eye-B_PLSYxB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"107-vFSc0Ioxec2/P4YCpYQo2LwUinU"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 263,
    "path": "../client/assets/eye-B_PLSYxB.js"
  },
  "/assets/file-check-corner-CF55pw9L.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"147-5UTvi1aDmcyp9oxKe5Xf5OfzhUc"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 327,
    "path": "../client/assets/file-check-corner-CF55pw9L.js"
  },
  "/assets/file-text-C5q2QBUk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18d-L/PdUTlUElitYOn08OZ8apmONJk"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 397,
    "path": "../client/assets/file-text-C5q2QBUk.js"
  },
  "/assets/funnel-RajHu8uH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"99e-IYGLyURpg7lbwM6pOasqayuCMe0"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 2462,
    "path": "../client/assets/funnel-RajHu8uH.js"
  },
  "/assets/eye-off-Hjy6-blw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ba-TLA/ZdieCLB68JH0mLn19JmeXfc"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 442,
    "path": "../client/assets/eye-off-Hjy6-blw.js"
  },
  "/assets/history-7fC4_72A.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"858-PvpTgzJIJ1O4FFgrpzvMzOLcZME"',
    "mtime": "2026-08-11T17:22:57.586Z",
    "size": 2136,
    "path": "../client/assets/history-7fC4_72A.js"
  },
  "/assets/history-DIdBi0fy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f9-GivHRzSK/QIBe3mJUxcHofq0oQ8"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 249,
    "path": "../client/assets/history-DIdBi0fy.js"
  },
  "/assets/inbox-BZw0-lOM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"12a-G2xBDNgTbzpB8XeBL+lB3Fx3r/E"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 298,
    "path": "../client/assets/inbox-BZw0-lOM.js"
  },
  "/assets/inbox._module-CagcZigb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1c10-FOHi4Q1xeQlZBvROdxQgqV6xY5A"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 7184,
    "path": "../client/assets/inbox._module-CagcZigb.js"
  },
  "/assets/format-C58jPiiU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4d7-zP9OjQgvkwcRPxpqqmzra4LF5GE"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 1239,
    "path": "../client/assets/format-C58jPiiU.js"
  },
  "/assets/index--Fii5Mln.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a8c-AXvVEG8x7g02BQzZsUxeEi9zpQM"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 2700,
    "path": "../client/assets/index--Fii5Mln.js"
  },
  "/assets/index-BKCxXCtT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4759-W/ssDyp8TXW+m0ptmZ9e9GatVMk"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 18265,
    "path": "../client/assets/index-BKCxXCtT.js"
  },
  "/assets/index-BmZU3jBn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7f7-al1KaIxo5DJAIvZzEsAEQOMBh3A"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 2039,
    "path": "../client/assets/index-BmZU3jBn.js"
  },
  "/assets/index-CdzrC74o.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6963-xzHPkjCxOLVERkaC4QfpOwRFwQQ"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 26979,
    "path": "../client/assets/index-CdzrC74o.js"
  },
  "/assets/index-wT41R47g.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"de7-L+SWAfbLvcCigL78U3uqsdwtEdM"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 3559,
    "path": "../client/assets/index-wT41R47g.js"
  },
  "/assets/info-CRaqoWEo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d3-vy26hVXLfI5TFAjTgHwcGorhIyY"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 211,
    "path": "../client/assets/info-CRaqoWEo.js"
  },
  "/assets/input-IiBi2Jrz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"24e-DNe+cmiFPpPgp8CzwCrJNRWI8Ws"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 590,
    "path": "../client/assets/input-IiBi2Jrz.js"
  },
  "/assets/kpi-tile-BTLbhVdP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"61d-uyXssjv4gUH+YFl80I1CfxmF/BY"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 1565,
    "path": "../client/assets/kpi-tile-BTLbhVdP.js"
  },
  "/assets/label-BfOTkuOa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3d6-Niy9XJELDPkeWzzUiKHSc+XK60E"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 982,
    "path": "../client/assets/label-BfOTkuOa.js"
  },
  "/assets/loader-circle-C4LrqTBT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"97-iESLGhL1QkguNM6jxGG4NsEtRdw"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 151,
    "path": "../client/assets/loader-circle-C4LrqTBT.js"
  },
  "/assets/index-Cj2SiLII.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2145-vyfWcLC3AziMfIabLCU4g2aDng0"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 8517,
    "path": "../client/assets/index-Cj2SiLII.js"
  },
  "/assets/lock-mrQqD3yk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14f-J5H1dpLojkCZOcncZBS9MO41BMM"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 335,
    "path": "../client/assets/lock-mrQqD3yk.js"
  },
  "/assets/login-BttJhgek.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1f1c-4mnROaQltKM/4Bu49BEwbjFvkvI"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 7964,
    "path": "../client/assets/login-BttJhgek.js"
  },
  "/assets/mm.gate-process-CJhq1cCs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"324b-+11359x+fcd/pa1tZu4f8KevQV4"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 12875,
    "path": "../client/assets/mm.gate-process-CJhq1cCs.js"
  },
  "/assets/mm.gate-pass-Bvj9ADLA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2176-/zO5xh9+mk1Smh2emeOCQJAp4Cg"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 8566,
    "path": "../client/assets/mm.gate-pass-Bvj9ADLA.js"
  },
  "/assets/mm.material-reservation-BjcnNwaL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"234b-szYYmIruA3KG69oyWoBDawjOExY"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 9035,
    "path": "../client/assets/mm.material-reservation-BjcnNwaL.js"
  },
  "/assets/mm.migo-release-CCW-v1nb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"249d-CLcCyaJ6SdWDFvopo27TGUoJE1w"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 9373,
    "path": "../client/assets/mm.migo-release-CCW-v1nb.js"
  },
  "/assets/mm.pr-release-D5g9f5qP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2e73-84MqVutjttsOqprhUuFavYA0GJ8"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 11891,
    "path": "../client/assets/mm.pr-release-D5g9f5qP.js"
  },
  "/assets/mm.znfa-release-BK-pascQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b53c-aJ+3nma6Ct6tPAeva+6PDue00kY"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 46396,
    "path": "../client/assets/mm.znfa-release-BK-pascQ.js"
  },
  "/assets/notifications-D_rlDoE7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"90c-v5k8qdMdD2zFGgG2A8eA/6hOvec"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 2316,
    "path": "../client/assets/notifications-D_rlDoE7.js"
  },
  "/assets/mm.po-release-Sn-ONwuB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2cc1-iG+/ZIpe+bPZDE/ykTBErFlAAO8"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 11457,
    "path": "../client/assets/mm.po-release-Sn-ONwuB.js"
  },
  "/assets/package-BT6NQkuE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"180-dHnHQWjAHlZYFiPWeDdz72uELM0"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 384,
    "path": "../client/assets/package-BT6NQkuE.js"
  },
  "/assets/index-LHNt3CwB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2bb-FdPVTTp03mSjPnpcgLEqlvVfPpU"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 699,
    "path": "../client/assets/index-LHNt3CwB.js"
  },
  "/assets/index-D4YNpyJX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2dd-ApC0Vut4uVHJGOdUroi6fPw9xzg"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 733,
    "path": "../client/assets/index-D4YNpyJX.js"
  },
  "/assets/index-CcHxqT8S.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a1c75-lRGBf4q4tSdF/7tmTeFAHgdVIkA"',
    "mtime": "2026-08-11T17:22:57.598Z",
    "size": 662645,
    "path": "../client/assets/index-CcHxqT8S.js"
  },
  "/assets/page-header-Co6qqkns.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"36f-9kf9ZGLzZg64v5BRAb9iLFX5K5s"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 879,
    "path": "../client/assets/page-header-Co6qqkns.js"
  },
  "/assets/pencil-DKOPm8XX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"120-hwAtiwCDbOy4UZaui9QtexJ+++M"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 288,
    "path": "../client/assets/pencil-DKOPm8XX.js"
  },
  "/assets/plant-multi-select-CnkcSHwj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1141-RQZ0wNBGfbzjv22Sf+/ikjPBI1A"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 4417,
    "path": "../client/assets/plant-multi-select-CnkcSHwj.js"
  },
  "/assets/plant-select-Cc-wh1tB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1286-u1vJu4kzbaASg4mstSW5Pw8lquc"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 4742,
    "path": "../client/assets/plant-select-Cc-wh1tB.js"
  },
  "/assets/radio-group-BZhWqEvi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1087-hxZGmjSpslBJKsXZZrzR+wy2XTs"',
    "mtime": "2026-08-11T17:22:57.594Z",
    "size": 4231,
    "path": "../client/assets/radio-group-BZhWqEvi.js"
  },
  "/assets/refresh-cw-DBD6bhFh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"29c-D32KRvjUmXUQ0jVBye/g89m1N/s"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 668,
    "path": "../client/assets/refresh-cw-DBD6bhFh.js"
  },
  "/assets/release-key-select-DPjbOGrT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"616-ggOsoHwP14QoFf+UQXnsOEflB6g"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 1558,
    "path": "../client/assets/release-key-select-DPjbOGrT.js"
  },
  "/assets/rotate-ccw-DrZgWDJ3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d4-52LN2q7b1l+kRVxhcVC60/wrmNo"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 212,
    "path": "../client/assets/rotate-ccw-DrZgWDJ3.js"
  },
  "/assets/sales-order-approval.functions-DsQq4hsR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"190-KWj4h/z/La0/Ll+DCPHiPTAMsvA"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 400,
    "path": "../client/assets/sales-order-approval.functions-DsQq4hsR.js"
  },
  "/assets/sap-api.functions-BnOU1z7o.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"471-1C7HHXcxV9rEOjBMKdFCWlXk4iI"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 1137,
    "path": "../client/assets/sap-api.functions-BnOU1z7o.js"
  },
  "/assets/sap.functions-CFthjF-h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"206-Zo4Wk8LuPfYq33+i0bJaLN7N7nU"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 518,
    "path": "../client/assets/sap.functions-CFthjF-h.js"
  },
  "/assets/save-B5-D_35y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"153-KGEXgQNnlkepKHzs3lkcHuSWM80"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 339,
    "path": "../client/assets/save-B5-D_35y.js"
  },
  "/assets/sc-so-approval.functions-B6nhrjq_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"186-UfGsPjHIko6ijBXiJV+pkCr3XGY"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 390,
    "path": "../client/assets/sc-so-approval.functions-B6nhrjq_.js"
  },
  "/assets/sd.contract-QX2cxvLB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2ca9-IjmZcL/5f8nTGYNdC8js+QLAJQU"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 11433,
    "path": "../client/assets/sd.contract-QX2cxvLB.js"
  },
  "/assets/sd.bmw-status-DsLouGYK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3725-FNddiIclK7ez+F9s/GLd8Uv8+jA"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 14117,
    "path": "../client/assets/sd.bmw-status-DsLouGYK.js"
  },
  "/assets/sd.contract-reports-DIa_rBhR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1131-BodHQqb3WsmDqmGl0is4nGcmL60"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 4401,
    "path": "../client/assets/sd.contract-reports-DIa_rBhR.js"
  },
  "/assets/sd.price-HRormXUB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1f9f-A3nEJXlbS/j8TsoQxX0UxOSxt18"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 8095,
    "path": "../client/assets/sd.price-HRormXUB.js"
  },
  "/assets/price-approval.functions-CgdJKOCM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"205-iljSV7H51p9ZPUfF/nZh2p1Z8aA"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 517,
    "path": "../client/assets/price-approval.functions-CgdJKOCM.js"
  },
  "/assets/sd.price-reports-HvHQP1MJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ffa-p+zjvC2yG2176K0/2NrkYH12prg"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 4090,
    "path": "../client/assets/sd.price-reports-HvHQP1MJ.js"
  },
  "/assets/sd.dashboard-BvtvzA_T.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6ae92-3Y2FwkDABYGlR65vCT6ofhBIaMk"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 437906,
    "path": "../client/assets/sd.dashboard-BvtvzA_T.js"
  },
  "/assets/sd.sales-order-DrusyGLM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2def-Jjyt3RCFqamtWM853+A0p5IC424"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 11759,
    "path": "../client/assets/sd.sales-order-DrusyGLM.js"
  },
  "/assets/sd.sc-so-URg-tnXl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3008-1XCFe6EX5KH4HPQLDhTmS3vN+po"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 12296,
    "path": "../client/assets/sd.sc-so-URg-tnXl.js"
  },
  "/assets/sd.sales-order-reports-PMlN3hKZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"10e5-Ar32ye2kCek0vjioPdXlb04Ymw0"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 4325,
    "path": "../client/assets/sd.sales-order-reports-PMlN3hKZ.js"
  },
  "/assets/sd.sc-so-reports-Dm703oX_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1399-melvGI64pC5NMcSBVPcHqWB9qQE"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 5017,
    "path": "../client/assets/sd.sc-so-reports-Dm703oX_.js"
  },
  "/assets/search-C870tZRK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b5-qlrVMyXxPttf28lDNLp61JG0IL4"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 181,
    "path": "../client/assets/search-C870tZRK.js"
  },
  "/assets/search-term-multi-select-CUvx485o.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18ad-OmhVy3gpop9SkUL2IzdkXFOXCwM"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 6317,
    "path": "../client/assets/search-term-multi-select-CUvx485o.js"
  },
  "/assets/select-DjZxOibM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"593e-fBuGC9afE3aEbWxRLGfIAiXhxQw"',
    "mtime": "2026-08-11T17:22:57.594Z",
    "size": 22846,
    "path": "../client/assets/select-DjZxOibM.js"
  },
  "/assets/server-UDlDZvMN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"24c-tmoIYtD6QHGreNY7DowvFp4PeF8"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 588,
    "path": "../client/assets/server-UDlDZvMN.js"
  },
  "/assets/settings-B9dc1Yqd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"13f4-B0oUYj/SXyl+JdE1AlqcIdZUNKE"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 5108,
    "path": "../client/assets/settings-B9dc1Yqd.js"
  },
  "/assets/shield-check-BBI54nAF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"147-f8xG2P7Uv9B68oArJCoLR7rAVpw"',
    "mtime": "2026-08-11T17:22:57.591Z",
    "size": 327,
    "path": "../client/assets/shield-check-BBI54nAF.js"
  },
  "/assets/skeleton-DGCsm7ev.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"cd-NbHrWkTqDk644LwFf0bLu572nH4"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 205,
    "path": "../client/assets/skeleton-DGCsm7ev.js"
  },
  "/assets/skeleton-rows-BcHUCSmO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e2-xTRpdmg30ZhEiy/Oru4k/+XyusY"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 994,
    "path": "../client/assets/skeleton-rows-BcHUCSmO.js"
  },
  "/assets/status-badge-Dt1wREU_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"83b-1jJJJ577pDRdrxkDXaVgroleSbc"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 2107,
    "path": "../client/assets/status-badge-Dt1wREU_.js"
  },
  "/assets/styles-CuqGuqZr.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"4a217-nY3MryUr6lNwc3RkshHHCPI7QlE"',
    "mtime": "2026-08-11T17:22:57.583Z",
    "size": 303639,
    "path": "../client/assets/styles-CuqGuqZr.css"
  },
  "/assets/switch-i31DBxIC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a1e-Evhwwi5BA6NZCkwAUUkQgsJCmM8"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 2590,
    "path": "../client/assets/switch-i31DBxIC.js"
  },
  "/assets/table-CdVDtiOs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6b3-oM7B0j/ALHHu8Y/ePEFYyw+h3rA"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 1715,
    "path": "../client/assets/table-CdVDtiOs.js"
  },
  "/assets/tabs-DqAIXVs0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"efc-9cVQ8RJhQCUJzXru4QiQKHI6UEY"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 3836,
    "path": "../client/assets/tabs-DqAIXVs0.js"
  },
  "/assets/textarea-CF6OkeC0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1e8-A2jm0zMRN4uTG3tatzf9GVQ7Y0Q"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 488,
    "path": "../client/assets/textarea-CF6OkeC0.js"
  },
  "/assets/triangle-alert-Vpw9kj2Z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"115-HT9c0tvyZqHpGCIV0dLQXesyMGY"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 277,
    "path": "../client/assets/triangle-alert-Vpw9kj2Z.js"
  },
  "/assets/truck-Bqj_aE37.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"268-49zY9FQeijoftygAzfYhPWir/9o"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 616,
    "path": "../client/assets/truck-Bqj_aE37.js"
  },
  "/assets/use-active-context-CZADtPTq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1410-r0NFwvMfU/v4V5BlwN3vyhJuXvQ"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 5136,
    "path": "../client/assets/use-active-context-CZADtPTq.js"
  },
  "/assets/use-auth-CnialTzz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18d-vzZEEh5otsG+GYaURH4ToGsYOrA"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 397,
    "path": "../client/assets/use-auth-CnialTzz.js"
  },
  "/assets/use-permissions-Cjfhcph3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"309-ZfPQtvh/zkavYg5Cmu6VZWGeyz4"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 777,
    "path": "../client/assets/use-permissions-Cjfhcph3.js"
  },
  "/assets/useQuery-CRpgzi_5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"226e-yfklDnxjJ+IyikhVCmdyoZKYT6w"',
    "mtime": "2026-08-11T17:22:57.595Z",
    "size": 8814,
    "path": "../client/assets/useQuery-CRpgzi_5.js"
  },
  "/assets/use-sap-profile-D8_wKuLM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"36f-fQUZKilgwW29qMjjLBtW/zCURC8"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 879,
    "path": "../client/assets/use-sap-profile-D8_wKuLM.js"
  },
  "/assets/users-CentwQjv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"22d-AmEXmjbJpguQMJ+ODOuNmvDlLQ4"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 557,
    "path": "../client/assets/users-CentwQjv.js"
  },
  "/assets/utils-BQHNewu7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"683d-MgixwZ5BLQV8sqtaj9G83JcgCSQ"',
    "mtime": "2026-08-11T17:22:57.593Z",
    "size": 26685,
    "path": "../client/assets/utils-BQHNewu7.js"
  },
  "/assets/x-BMLOWbrF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a6-qn/shhImA/qCL1vLrr0AWi0hGyU"',
    "mtime": "2026-08-11T17:22:57.592Z",
    "size": 166,
    "path": "../client/assets/x-BMLOWbrF.js"
  }
};
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
const headers = ((m) => function headersRouteRule(event) {
  for (const [key, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key, value);
  }
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_j21Qvj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_j21Qvj };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function useNitroHooks() {
  const nitroApp = useNitroApp();
  const hooks = nitroApp.hooks;
  if (hooks) {
    return hooks;
  }
  return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function createHandler(hooks) {
  const nitroApp = useNitroApp();
  const nitroHooks = useNitroHooks();
  return {
    async fetch(request, env, context) {
      globalThis.__env__ = env;
      augmentReq(request, {
        env,
        context
      });
      const ctxExt = {};
      const url = new URL(request.url);
      if (hooks.fetch) {
        const res = await hooks.fetch(request, env, context, url, ctxExt);
        if (res) {
          return res;
        }
      }
      return await nitroApp.fetch(request);
    },
    scheduled(controller, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
        controller,
        env,
        context
      }) || Promise.resolve());
    },
    email(message, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:email", {
        message,
        event: message,
        env,
        context
      }) || Promise.resolve());
    },
    queue(batch, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
        batch,
        event: batch,
        env,
        context
      }) || Promise.resolve());
    },
    tail(traces, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
        traces,
        env,
        context
      }) || Promise.resolve());
    },
    trace(traces, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
        traces,
        env,
        context
      }) || Promise.resolve());
    }
  };
}
function augmentReq(cfReq, ctx) {
  const req = cfReq;
  req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
  req.runtime ??= { name: "cloudflare" };
  req.runtime.cloudflare = {
    ...req.runtime.cloudflare,
    ...ctx
  };
  req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
const cloudflareModule = createHandler({ fetch(cfRequest, env, context, url) {
  if (env.ASSETS && isPublicAssetURL(url.pathname)) {
    return env.ASSETS.fetch(cfRequest);
  }
} });
export {
  cloudflareModule as default
};
