import { j as jsxRuntimeExports } from "./_libs/react.mjs";
import { C as Card } from "./_ssr/card-DcbU6Qrh.mjs";

import "./_ssr/utils-H80jjgLf.mjs";
import "./_libs/clsx.mjs";
import "./_libs/tailwind-merge.mjs";
const SplitErrorComponent = ({
  error
}) => /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "min-h-screen grid place-items-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-6 max-w-md", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg font-semibold mb-2", children: "Authorization error" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: String(error?.message ?? error) })
] }) });
export {
  SplitErrorComponent as errorComponent
};
