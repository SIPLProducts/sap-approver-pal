import { j as jsxRuntimeExports, r as reactExports } from "./_libs/react.mjs";
import { d as useNavigate, u as useRouter, e as useRouterState, L as Link, O as Outlet } from "./_libs/tanstack__react-router.mjs";
import { s as supabase } from "./_ssr/client-CXnFcWf4.mjs";
import { u as useAuth } from "./_ssr/use-auth-CXN9VXh3.mjs";
import { u as useQueryClient, a as useQuery } from "./_libs/tanstack__react-query.mjs";
import { B as BrandLogo } from "./_ssr/brand-logo-CzKKMZ3Z.mjs";
import { B as Button } from "./_ssr/button-vZ1dO6Qq.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./_ssr/select-CZRUt5a6.mjs";
import { P as Popover, a as PopoverTrigger, b as PopoverContent, C as Command, c as CommandInput, d as CommandList, e as CommandEmpty, f as CommandGroup, g as CommandItem } from "./_ssr/command-i9zWGkU5.mjs";
import { C as Checkbox } from "./_ssr/checkbox-mmp_duDa.mjs";
import { t as toast } from "./_libs/sonner.mjs";
import { u as useServerFn } from "./_ssr/createSsrRpc-XOrxmi8L.mjs";
import { s as syncFromSAP } from "./_ssr/sap.functions-BddyAsKl.mjs";
import { f as fetchBmwStatusReport } from "./_ssr/bmw-status-report.functions-D6YGNvCd.mjs";
import { u as usePermissions } from "./_ssr/use-permissions-CVVfE7Yp.mjs";
import { A as ActiveContextProvider, u as useActiveContext } from "./_ssr/use-active-context-CMJTykFM.mjs";

import "./_libs/seroval.mjs";
import { b as ChartColumn, d as Tag, F as FileText, e as FileCheckCorner, f as ShoppingCart, g as ClipboardCheck, P as Package, T as Truck, H as History, U as Users, S as ShieldCheck, h as Server, i as Plug, M as Mail, j as Settings, k as ChevronDown, l as LogOut, m as PanelLeft, R as RefreshCcw, B as Bell, n as ChevronsUpDown } from "./_libs/lucide-react.mjs";

import "./_libs/tanstack__router-core.mjs";
import "./_libs/tanstack__history.mjs";
import "./_libs/cookie-es.mjs";
import "./_libs/seroval-plugins.mjs";


import "./_libs/react-dom.mjs";
import "./_libs/isbot.mjs";
import "./_libs/supabase__supabase-js.mjs";
import "./_libs/supabase__postgrest-js.mjs";
import "./_libs/supabase__realtime-js.mjs";
import "./_libs/unenv.mjs";


import "./_libs/supabase__phoenix.mjs";
import "./_libs/supabase__storage-js.mjs";
import "./_libs/iceberg-js.mjs";
import "./_libs/supabase__auth-js.mjs";
import "./_libs/tslib.mjs";
import "./_libs/supabase__functions-js.mjs";
import "./_libs/tanstack__query-core.mjs";
import "./_ssr/utils-H80jjgLf.mjs";
import "./_libs/clsx.mjs";
import "./_libs/tailwind-merge.mjs";
import "./_libs/radix-ui__react-slot.mjs";
import "./_libs/radix-ui__react-compose-refs.mjs";
import "./_libs/class-variance-authority.mjs";
import "./_libs/radix-ui__react-select.mjs";
import "./_libs/radix-ui__number.mjs";
import "./_libs/radix-ui__primitive.mjs";
import "./_libs/radix-ui__react-collection.mjs";
import "./_libs/radix-ui__react-context.mjs";
import "./_libs/radix-ui__react-direction.mjs";
import "./_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "./_libs/radix-ui__react-primitive.mjs";
import "./_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "./_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "./_libs/radix-ui__react-focus-guards.mjs";
import "./_libs/radix-ui__react-focus-scope.mjs";
import "./_libs/radix-ui__react-id.mjs";
import "./_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "./_libs/radix-ui__react-popper.mjs";
import "./_libs/floating-ui__react-dom.mjs";
import "./_libs/floating-ui__dom.mjs";
import "./_libs/floating-ui__core.mjs";
import "./_libs/floating-ui__utils.mjs";
import "./_libs/radix-ui__react-arrow.mjs";
import "./_libs/radix-ui__react-use-size.mjs";
import "./_libs/radix-ui__react-portal.mjs";
import "./_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "./_libs/radix-ui__react-use-previous.mjs";
import "./_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "./_libs/aria-hidden.mjs";
import "./_libs/react-remove-scroll.mjs";
import "./_libs/react-remove-scroll-bar.mjs";
import "./_libs/react-style-singleton.mjs";
import "./_libs/get-nonce.mjs";
import "./_libs/use-sidecar.mjs";
import "./_libs/use-callback-ref.mjs";
import "./_libs/radix-ui__react-popover.mjs";
import "./_libs/radix-ui__react-presence.mjs";
import "./_libs/cmdk.mjs";
import "./_libs/radix-ui__react-dialog.mjs";
import "./_libs/radix-ui__react-checkbox.mjs";
import "./_ssr/server-CeMw7B2X.mjs";
import "./_libs/h3-v2.mjs";
import "./_libs/rou3.mjs";
import "./_libs/srvx.mjs";




import "./_ssr/auth-middleware-BtdUo7VX.mjs";
import "./_libs/zod.mjs";
import "./_ssr/screen-keys-mn2QOK0m.mjs";
import "./_ssr/use-sap-profile-DRIQ-_33.mjs";
function AuthenticatedRoot() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ActiveContextProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AuthenticatedLayout, {}) });
}
function AuthenticatedLayout() {
  const {
    user,
    loading
  } = useAuth();
  const nav = useNavigate();
  const router = useRouter();
  const qc = useQueryClient();
  const pathname = useRouterState({
    select: (s) => s.location.pathname
  });
  const [open, setOpen] = reactExports.useState(false);
  const [collapsed, setCollapsed] = reactExports.useState(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem("app.sidebarCollapsed") === "1";
  });
  reactExports.useEffect(() => {
    try {
      window.localStorage.setItem("app.sidebarCollapsed", collapsed ? "1" : "0");
    } catch {
    }
  }, [collapsed]);
  const perms = usePermissions();
  const ctx = useActiveContext();
  const sdOpen = pathname.startsWith("/sd") || pathname.startsWith("/inbox/sd");
  const [sdExpanded, setSdExpanded] = reactExports.useState(sdOpen);
  reactExports.useEffect(() => {
    if (sdOpen) setSdExpanded(true);
  }, [sdOpen]);
  const mmOpen = pathname.startsWith("/mm") || pathname.startsWith("/inbox/mm");
  const [mmExpanded, setMmExpanded] = reactExports.useState(mmOpen);
  reactExports.useEffect(() => {
    if (mmOpen) setMmExpanded(true);
  }, [mmOpen]);
  reactExports.useEffect(() => {
    if (!loading && !user) nav({
      to: "/login"
    });
  }, [loading, user, nav]);
  const {
    data: profile
  } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      return data;
    }
  });
  const {
    data: unread = 0
  } = useQuery({
    queryKey: ["unread", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        count
      } = await supabase.from("notifications").select("id", {
        count: "exact",
        head: true
      }).eq("user_id", user.id).is("read_at", null);
      return count ?? 0;
    },
    refetchInterval: 3e4
  });
  reactExports.useEffect(() => {
    if (!user) return;
    const ch = supabase.channel("inbox-updates").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "notifications",
      filter: `user_id=eq.${user.id}`
    }, () => {
      qc.invalidateQueries({
        queryKey: ["unread", user.id]
      });
      qc.invalidateQueries({
        queryKey: ["inbox"]
      });
      qc.invalidateQueries({
        queryKey: ["notifications"]
      });
    }).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "approval_steps"
    }, () => {
      qc.invalidateQueries({
        queryKey: ["inbox"]
      });
    }).subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [user, qc]);
  const sync = useServerFn(syncFromSAP);
  const bmwFetch = useServerFn(fetchBmwStatusReport);
  const sortedPlants = reactExports.useMemo(() => [...ctx.activePlants].sort(), [ctx.activePlants]);
  const bmwFrom = sortedPlants[0] ?? "";
  const bmwTo = sortedPlants[sortedPlants.length - 1] ?? "";
  function prefetchSdDashboard() {
    if (!bmwFrom || !bmwTo) return;
    qc.prefetchQuery({
      queryKey: ["sd-dashboard-bmw", bmwFrom, bmwTo],
      staleTime: 5 * 6e4,
      queryFn: async () => {
        const res = await bmwFetch({
          data: {
            sales_org_from: bmwFrom,
            sales_org_to: bmwTo,
            customer_from: "",
            customer_to: "",
            contract_from: "",
            contract_to: "",
            mode: "sales"
          }
        });
        return res?.rows ?? [];
      }
    }).catch(() => {
    });
  }
  async function pullSap() {
    const t = toast.loading("Syncing from SAP…");
    try {
      const res = await sync();
      toast.success(`Synced — ${res.inserted} new document${res.inserted === 1 ? "" : "s"}`, {
        id: t
      });
      qc.invalidateQueries();
    } catch (e) {
      toast.error(e.message ?? "Sync failed", {
        id: t
      });
    }
  }
  async function logout() {
    const {
      setSapProfile
    } = await import("./_ssr/use-sap-profile-DRIQ-_33.mjs");
    setSapProfile(null);
    try {
      localStorage.removeItem("app.activePlants");
      localStorage.removeItem("app.activePlant");
      localStorage.removeItem("app.activeRole");
    } catch {
    }
    await supabase.auth.signOut();
    nav({
      to: "/login"
    });
  }
  if (loading || !user || perms.loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen grid place-items-center text-muted-foreground", children: "Loading…" });
  }
  const can = perms.can;
  const sdChildren = [{
    to: "/sd/dashboard",
    label: "SD Dashboard",
    icon: ChartColumn,
    screen: "approvals.inbox.sd"
  }, {
    to: "/sd/price",
    label: "Price Approvals",
    icon: Tag,
    screen: "approvals.inbox.sd"
  }, {
    to: "/sd/contract",
    label: "Contract Approvals",
    icon: FileText,
    screen: "approvals.inbox.sd"
  }, {
    to: "/sd/sc-so",
    label: "Service Cert & SO",
    icon: FileCheckCorner,
    screen: "approvals.inbox.sd"
  }, {
    to: "/sd/sales-order",
    label: "Sales Order Approvals",
    icon: ShoppingCart,
    screen: "approvals.inbox.sd"
  }, {
    to: "/sd/bmw-status",
    label: "BMW Status Report",
    icon: ChartColumn,
    screen: "approvals.inbox.sd"
  }].filter((it) => can(it.screen));
  const mmChildren = [{
    to: "/mm/dashboard",
    label: "MM Dashboard",
    icon: ChartColumn,
    screen: "approvals.inbox.mm"
  }, {
    to: "/mm/pr-release",
    label: "PR Release",
    icon: ClipboardCheck,
    screen: "approvals.inbox.mm"
  }, {
    to: "/mm/po-release",
    label: "PO Release",
    icon: ClipboardCheck,
    screen: "approvals.inbox.mm"
  }, {
    to: "/mm/material-reservation",
    label: "Material Reservation",
    icon: Package,
    screen: "approvals.inbox.mm"
  }, {
    to: "/mm/gate-process",
    label: "ZNFA Rating",
    icon: ClipboardCheck,
    screen: "approvals.inbox.mm"
  }, {
    to: "/mm/gate-pass",
    label: "Gate Pass",
    icon: Truck,
    screen: "approvals.inbox.mm"
  }, {
    to: "/mm/migo-release",
    label: "MIGO Release",
    icon: ClipboardCheck,
    screen: "approvals.inbox.mm"
  }, {
    to: "/mm/znfa-release",
    label: "ZNFA Release",
    icon: ClipboardCheck,
    screen: "approvals.inbox.mm"
  }].filter((it) => can(it.screen));
  const showMm = mmChildren.length > 0;
  const showSd = sdChildren.length > 0;
  const manage_items = [{
    to: "/history",
    label: "History",
    icon: History,
    screen: "approvals.history"
  }, {
    to: "/admin/users",
    label: "Users & Roles",
    icon: Users,
    screen: "admin.users"
  }, {
    to: "/admin/strategies",
    label: "Release Strategies",
    icon: ShieldCheck,
    screen: "admin.strategies"
  }, {
    to: "/admin/sap-api",
    label: "SAP API Settings",
    icon: Server,
    screen: "sap.api_settings"
  }, {
    to: "/admin/integrations",
    label: "Integrations",
    icon: Plug,
    screen: "sap.integrations"
  }, {
    to: "/email-config",
    label: "Email Configuration",
    icon: Mail,
    screen: "settings.email_config"
  }, {
    to: "/settings",
    label: "Settings",
    icon: Settings,
    screen: null
  }].filter((it) => it.screen === null || can(it.screen));
  const roleSelectValue = ctx.activeRole ? `${ctx.activeRole.kind}:${ctx.activeRole.value}` : "";
  function onRoleChange(v) {
    const idx = v.indexOf(":");
    if (idx < 0) return;
    const value = v.slice(idx + 1);
    const found = ctx.roles.find((r) => r.value === value);
    if (!found) return;
    ctx.setActiveRole({
      kind: "sap",
      value: found.value,
      label: found.label
    });
    qc.invalidateQueries();
    router.invalidate();
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-screen overflow-hidden bg-background flex", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: `fixed lg:sticky lg:top-0 lg:h-screen z-40 inset-y-0 left-0 ${collapsed ? "w-16" : "w-64"} bg-sidebar text-sidebar-foreground flex flex-col transition-all ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `px-4 py-4 flex items-center gap-3 border-b border-sidebar-border ${collapsed ? "justify-center px-2" : ""}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-lg bg-white px-2 py-1.5 shadow-card flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BrandLogo, { className: "h-7" }) }),
        !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display font-semibold leading-tight text-[13px] tracking-tight", children: "Re Sustainability" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] uppercase tracking-[0.18em] text-sidebar-foreground/55", children: "Executive Approvals" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "flex-1 px-3 py-4 space-y-0.5 overflow-y-auto", children: [
        !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-sidebar-foreground/40", children: "Workspaces" }),
        showMm && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => {
            if (collapsed) setCollapsed(false);
            setMmExpanded(true);
            setOpen(false);
            nav({
              to: "/mm/dashboard"
            });
          }, title: "MM Approvals", className: `relative w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${mmOpen ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"} ${collapsed ? "justify-center" : ""}`, children: [
            mmOpen && !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-r bg-sidebar-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { className: "h-4 w-4 shrink-0" }),
            !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1 text-left truncate", children: "MM Approvals" }),
            !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { role: "button", tabIndex: 0, onClick: (e) => {
              e.stopPropagation();
              setMmExpanded((v) => !v);
            }, onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                setMmExpanded((v) => !v);
              }
            }, className: "p-0.5 -mr-1 rounded hover:bg-sidebar-accent/60", "aria-label": mmExpanded ? "Collapse" : "Expand", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: `h-3.5 w-3.5 transition-transform ${mmExpanded ? "rotate-0" : "-rotate-90"}` }) })
          ] }),
          mmExpanded && !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ml-5 pl-3 border-l border-sidebar-border/70 space-y-0.5 mt-0.5 mb-1", children: mmChildren.map((it) => {
            const active = pathname.startsWith(it.to) || it.to === "/mm/dashboard" && pathname.startsWith("/inbox/mm");
            const Icon = it.icon;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: it.to, onClick: () => setOpen(false), className: `flex items-center gap-2 px-3 py-1.5 rounded-md text-[12px] transition-colors ${active ? "bg-sidebar-primary/15 text-sidebar-primary-foreground/95 font-medium" : "text-sidebar-foreground/65 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-3.5 w-3.5 shrink-0" }),
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: it.label })
            ] }, it.to);
          }) })
        ] }),
        showSd && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onMouseEnter: prefetchSdDashboard, onFocus: prefetchSdDashboard, onClick: () => {
            if (collapsed) setCollapsed(false);
            setSdExpanded(true);
            setOpen(false);
            nav({
              to: "/sd/dashboard"
            });
          }, title: "SD Approvals", className: `relative w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${sdOpen ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"} ${collapsed ? "justify-center" : ""}`, children: [
            sdOpen && !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-r bg-sidebar-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Truck, { className: "h-4 w-4 shrink-0" }),
            !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1 text-left truncate", children: "SD Approvals" }),
            !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { role: "button", tabIndex: 0, onClick: (e) => {
              e.stopPropagation();
              setSdExpanded((v) => !v);
            }, onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                setSdExpanded((v) => !v);
              }
            }, className: "p-0.5 -mr-1 rounded hover:bg-sidebar-accent/60", "aria-label": sdExpanded ? "Collapse" : "Expand", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: `h-3.5 w-3.5 transition-transform ${sdExpanded ? "rotate-0" : "-rotate-90"}` }) })
          ] }),
          sdExpanded && !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ml-5 pl-3 border-l border-sidebar-border/70 space-y-0.5 mt-0.5 mb-1", children: sdChildren.map((it) => {
            const active = pathname.startsWith(it.to);
            const Icon = it.icon;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: it.to, onClick: () => setOpen(false), className: `flex items-center gap-2 px-3 py-1.5 rounded-md text-[12px] transition-colors ${active ? "bg-sidebar-primary/15 text-sidebar-primary-foreground/95 font-medium" : "text-sidebar-foreground/65 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-3.5 w-3.5 shrink-0" }),
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: it.label })
            ] }, it.to);
          }) })
        ] }),
        manage_items.length > 0 && !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 pt-5 pb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-sidebar-foreground/40", children: "Manage" }),
        manage_items.map((it) => {
          const active = pathname.startsWith(it.to);
          const Icon = it.icon;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: it.to, onClick: () => setOpen(false), title: it.label, className: `relative flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${active ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"} ${collapsed ? "justify-center" : ""}`, children: [
            active && !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-r bg-sidebar-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4 shrink-0" }),
            " ",
            !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: it.label })
          ] }, it.to);
        })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 border-t border-sidebar-border space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-3 px-2 py-1.5 rounded-md bg-sidebar-accent/40 ${collapsed ? "justify-center" : ""}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 shrink-0 rounded-full bg-gradient-primary text-primary-foreground grid place-items-center text-xs font-semibold", children: (profile?.full_name || user.email || "?").charAt(0).toUpperCase() }),
          !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[12px] font-medium truncate text-sidebar-foreground", children: profile?.full_name || user.email }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-sidebar-foreground/55 truncate", children: perms.activeRoleLabel ?? "No active role" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: logout, variant: "ghost", size: "sm", title: "Sign out", className: `w-full text-sidebar-foreground/75 hover:text-sidebar-accent-foreground hover:bg-sidebar-accent ${collapsed ? "justify-center px-0" : "justify-start"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: `h-4 w-4 ${collapsed ? "" : "mr-2"}` }),
          " ",
          !collapsed && "Sign out"
        ] })
      ] })
    ] }),
    open && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-30", onClick: () => setOpen(false) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 flex flex-col h-screen overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "h-[60px] border-b bg-card/80 backdrop-blur-md flex items-center gap-3 px-4 lg:px-6 sticky top-0 z-20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "lg:hidden text-muted-foreground p-2 -ml-2 rounded-md hover:bg-accent", onClick: () => setOpen(true), "aria-label": "Open menu", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-lg leading-none", children: "☰" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "hidden lg:inline-flex text-muted-foreground p-2 -ml-2 rounded-md hover:bg-accent", onClick: () => setCollapsed((v) => !v), "aria-label": collapsed ? "Expand sidebar" : "Collapse sidebar", title: collapsed ? "Expand sidebar" : "Collapse sidebar", children: /* @__PURE__ */ jsxRuntimeExports.jsx(PanelLeft, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:hidden flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BrandLogo, { className: "h-7" }) }),
        ctx.plants.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(TopBarPlantSelect, { plants: ctx.plants, value: ctx.activePlants, onChange: (next) => {
          ctx.setActivePlants(next);
          qc.invalidateQueries();
          router.invalidate();
        } }),
        ctx.roles.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: roleSelectValue, onValueChange: onRoleChange, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "h-9 w-[160px] text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Select role" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ctx.roles.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: `${r.kind}:${r.value}`, children: r.label }, `${r.kind}:${r.value}`)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden xl:flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground ml-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1.5 w-1.5 rounded-full bg-success animate-pulse" }),
          "Live · SAP synced"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", onClick: pullSap, className: "h-9", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCcw, { className: "h-3.5 w-3.5 mr-2" }),
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Sync SAP" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/notifications", className: "relative h-9 w-9 grid place-items-center rounded-md hover:bg-accent", "aria-label": "Notifications", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "h-4 w-4" }),
          unread > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-1 right-1 h-4 min-w-4 px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold grid place-items-center tabular-nums", children: unread })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1 overflow-y-auto p-4 lg:p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[1600px] w-full mx-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) }) })
    ] })
  ] });
}
function TopBarPlantSelect({
  plants,
  value,
  onChange
}) {
  const [open, setOpen] = reactExports.useState(false);
  const selected = reactExports.useMemo(() => new Set(value), [value]);
  const allCodes = reactExports.useMemo(() => plants.map((p) => p.code), [plants]);
  const label = reactExports.useMemo(() => {
    if (value.length === 0) return "Select plants";
    if (value.length === plants.length) return `All plants (${plants.length})`;
    if (value.length === 1) {
      const p = plants.find((x) => x.code === value[0]);
      return p ? `Plant ${p.code}${p.name ? ` — ${p.name}` : ""}` : `Plant ${value[0]}`;
    }
    return `${value.length} plants`;
  }, [value, plants]);
  function toggle(code) {
    if (selected.has(code)) onChange(value.filter((v) => v !== code));
    else onChange([...value, code]);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", role: "combobox", "aria-expanded": open, className: "h-9 w-[180px] justify-between gap-2 px-3 text-sm font-normal", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate text-left", children: label }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronsUpDown, { className: "h-3.5 w-3.5 shrink-0 opacity-50" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverContent, { className: "z-[1000] w-[260px] p-0", align: "start", sideOffset: 6, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Command, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CommandInput, { placeholder: "Search plant…", className: "h-9" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandList, { className: "max-h-[50vh]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CommandEmpty, { children: "No plant found." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandGroup, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandItem, { value: "__select_all__", onSelect: () => {
            if (value.length === allCodes.length) return;
            onChange(allCodes);
          }, className: "font-medium border-b rounded-none", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: value.length === allCodes.length, tabIndex: -1, className: "pointer-events-none mr-2" }),
            "Select all (",
            allCodes.length,
            ")"
          ] }),
          plants.map((p) => {
            const isSel = selected.has(p.code);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandItem, { value: `${p.code} ${p.name ?? ""}`, onSelect: () => {
              if (isSel && value.length === 1) return;
              toggle(p.code);
            }, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: isSel, tabIndex: -1, className: "pointer-events-none mr-2" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: p.code }),
              p.name && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 text-muted-foreground truncate", children: [
                "— ",
                p.name
              ] })
            ] }, p.code);
          })
        ] })
      ] })
    ] }) })
  ] });
}
export {
  AuthenticatedRoot as component
};
