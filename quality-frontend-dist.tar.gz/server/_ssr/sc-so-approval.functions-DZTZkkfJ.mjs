import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, D as enumType, C as arrayType, z as stringType, A as unionType, B as numberType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
function pick(o, k) {
  if (!o || typeof o !== "object") return null;
  const hit = Object.keys(o).find((x) => x.toLowerCase() === k.toLowerCase());
  return hit ? o[hit] ?? null : null;
}
function mapRow(raw) {
  const adv = pick(raw, "ADV_DOC_NUM");
  return {
    select: pick(raw, "SELECT"),
    company_code: pick(raw, "COMPANY_CODE"),
    sales_org: pick(raw, "SALES_ORG"),
    customer: pick(raw, "CUSTOMER"),
    customer_name: pick(raw, "CUSTOMER_NAME"),
    year: pick(raw, "YEAR"),
    contract_no: pick(raw, "CONTRACT_NO"),
    contract_item: pick(raw, "CONTRACT_ITEM"),
    contract_ref_no: pick(raw, "CONTRACT_REF_NO"),
    contract_ref_date: pick(raw, "CONTRACT_REF_DATE"),
    con_creation_date: pick(raw, "CON_CREATION_DATE"),
    contract_start_date: pick(raw, "CONTRACT_START_DATE"),
    contract_end_date: pick(raw, "CONTRACT_END_DATE"),
    down_pay_req_amount: pick(raw, "DOWN_PAY_REQ_AMOUNT"),
    adv_doc_zeile: adv && typeof adv === "object" ? pick(adv, "ZEILE") : null,
    adv_doc_ebelp: adv && typeof adv === "object" ? pick(adv, "EBELP") : null,
    adv_amount: pick(raw, "ADV_AMOUNT"),
    profit_center: pick(raw, "PROFIT_CENTER"),
    clearing_document: pick(raw, "CLEARING_DOCUMENT"),
    customer_group: pick(raw, "CUSTOMER_GROUP"),
    customer_price_group: pick(raw, "CUSTOMER_PRICE_GROUP"),
    service_valid_from: pick(raw, "SERVICE_VALID_FROM"),
    service_valid_to: pick(raw, "SERVICE_VALID_TO"),
    service_start_date: pick(raw, "SERVICE_START_DATE"),
    registration_date: pick(raw, "REGISTRATION_DATE"),
    cus_agr_from: pick(raw, "CUS_AGR_FROM"),
    cus_agr_to: pick(raw, "CUS_AGR_TO"),
    active_inactive: pick(raw, "ACTIVE_INACTIVE"),
    no_of_beds_to_be_inv: pick(raw, "NO_OF_BEDS_TO_BE_INV"),
    fixed_rate: pick(raw, "FIXED_RATE"),
    per_bed_rate: pick(raw, "PER_BED_RATE"),
    excess_qty_rate: pick(raw, "EXCESS_QTY_RATE"),
    upper_slab_qty: pick(raw, "UPPER_SLAB_QTY"),
    code_land_qty: pick(raw, "CODE_LAND_QTY"),
    total_balance: pick(raw, "TOTAL_BALANCE"),
    ph_reason_code: pick(raw, "PH_REASON_CODE"),
    release_code_1: pick(raw, "RELEASE_CODE1"),
    approval_status: pick(raw, "APPROVAL_STATUS"),
    reason: pick(raw, "REASON")
  };
}
const fetchScSoApprovals_createServerFn_handler = createServerRpc({
  id: "3e5039af411053f11aa69184274229697e6ca84d3d854e210edc988671b7c565",
  name: "fetchScSoApprovals",
  filename: "src/lib/sd/sc-so-approval.functions.ts"
}, (opts) => fetchScSoApprovals.__executeServer(opts));
const fetchScSoApprovals = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().trim().min(1).max(40)).min(1, "At least one plant required"),
  user_id: stringType().trim().max(40).optional(),
  customer_from: stringType().trim().max(40).optional(),
  customer_to: stringType().trim().max(40).optional(),
  search_terms: arrayType(stringType().trim().min(1).max(40)).max(100).optional(),
  status: enumType(["pending", "accepted", "rejected", "all"]).default("pending"),
  approval_type: enumType(["service", "sales", "all"]).default("service")
}).parse(d)).handler(fetchScSoApprovals_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const CONFIG_NAME = "Sevice_Certificate_Fetch";
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: prof
  }, {
    data: userIdField
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("profiles").select("sap_user_id").eq("id", context.userId).maybeSingle(), supabaseAdmin.from("sap_api_request_fields").select("default_value").eq("config_id", cfg.id).eq("field_name", "USER_ID").maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const custFrom = (data.customer_from ?? "").trim();
  const custTo = (data.customer_to ?? "").trim() || custFrom;
  const searchTerms = (data.search_terms ?? []).map((s2) => s2.trim()).filter(Boolean);
  const resolvedUserId = data.user_id && data.user_id.trim() || prof?.sap_user_id && prof.sap_user_id.trim() || userIdField?.default_value || "";
  const isAllStatus = data.status === "all";
  const isAllType = data.approval_type === "all";
  const inputs = {
    PLANT: data.plants.map((p) => ({
      plant: p
    })),
    CUSTOMER_FROM: custFrom,
    CUSTOMER_TO: custTo,
    SEARCH_TERMS: searchTerms.map((s2) => ({
      search_term: s2
    })),
    SORTL: searchTerms[0] ?? "",
    USER_ID: resolvedUserId,
    R_PEND: isAllStatus || data.status === "pending" ? "X" : "",
    R_ACCP: isAllStatus || data.status === "accepted" ? "X" : "",
    R_REJ: isAllStatus || data.status === "rejected" ? "X" : "",
    service: isAllType || data.approval_type === "service" ? "X" : "",
    Sales: isAllType || data.approval_type === "sales" ? "X" : ""
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/service_certificate/Fetch`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      inputs
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url.trim();
    headers["Content-Type"] = "application/json";
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
    bodyOut = JSON.stringify(inputs);
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  console.log("[scso-fetch] target=", target, "method=", method, "proxied=", proxied);
  console.log("[scso-fetch] payload=", JSON.stringify(inputs));
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `scso-fetch network: ${errMsg}`
    });
    console.log("[scso-fetch] network-error=", errMsg, "latency_ms=", latency_ms2);
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `Could not reach SAP. ${errMsg}.`,
      payload: inputs,
      debug: {
        target,
        method,
        proxied,
        request_payload: inputs,
        response_status: 0,
        response_body_preview: errMsg,
        latency_ms: latency_ms2
      }
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  console.log("[scso-fetch] status=", res.status, "latency_ms=", latency_ms, "body=", text.slice(0, 1e3));
  const debug = {
    target,
    method,
    proxied,
    request_payload: inputs,
    response_status: res.status,
    response_body_preview: text.slice(0, 2e3),
    latency_ms
  };
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `scso-fetch: ${message} ${text.slice(0, 500)}`
    });
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`,
      payload: inputs,
      debug
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`,
      payload: inputs,
      debug
    };
  }
  const sapJson = proxied ? json?.data ?? json : json;
  if (sapJson && typeof sapJson === "object" && sapJson.__parse_error) {
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `SAP returned unparseable JSON: ${sapJson.__parse_error}. Preview: ${String(sapJson.__raw_preview ?? "").slice(0, 200)}`,
      payload: inputs,
      debug
    };
  }
  const arr = Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : Array.isArray(sapJson) ? sapJson : [];
  const rows = arr.map(mapRow);
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `scso-fetch: ${message}`
  });
  return {
    rows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    count: rows.length,
    error: null,
    payload: inputs,
    debug
  };
});
const DECISION_CONFIG_NAME = "Service_Certificate_Approve_Reject";
function s(v) {
  return v == null ? "" : String(v);
}
function padCustomer(v) {
  const x = s(v).trim();
  return x && /^\d+$/.test(x) ? x.padStart(10, "0") : x;
}
function numOrEmpty(v) {
  if (v == null || v === "") return "";
  const n = Number(v);
  return isFinite(n) ? n : "";
}
const ScSoRowSchema = objectType({
  select: stringType().nullable().optional(),
  company_code: stringType().nullable().optional(),
  sales_org: stringType().nullable().optional(),
  customer: stringType().nullable().optional(),
  customer_name: stringType().nullable().optional(),
  year: unionType([stringType(), numberType()]).nullable().optional(),
  contract_no: stringType().nullable().optional(),
  contract_item: unionType([stringType(), numberType()]).nullable().optional(),
  contract_ref_no: stringType().nullable().optional(),
  contract_ref_date: stringType().nullable().optional(),
  con_creation_date: stringType().nullable().optional(),
  contract_start_date: stringType().nullable().optional(),
  contract_end_date: stringType().nullable().optional(),
  down_pay_req_amount: unionType([stringType(), numberType()]).nullable().optional(),
  adv_doc_zeile: unionType([stringType(), numberType()]).nullable().optional(),
  adv_doc_ebelp: unionType([stringType(), numberType()]).nullable().optional(),
  adv_amount: unionType([stringType(), numberType()]).nullable().optional(),
  profit_center: stringType().nullable().optional(),
  clearing_document: stringType().nullable().optional(),
  customer_group: stringType().nullable().optional(),
  customer_price_group: stringType().nullable().optional(),
  service_valid_from: stringType().nullable().optional(),
  service_valid_to: stringType().nullable().optional(),
  service_start_date: stringType().nullable().optional(),
  registration_date: stringType().nullable().optional(),
  cus_agr_from: stringType().nullable().optional(),
  cus_agr_to: stringType().nullable().optional(),
  active_inactive: stringType().nullable().optional(),
  no_of_beds_to_be_inv: unionType([stringType(), numberType()]).nullable().optional(),
  fixed_rate: unionType([stringType(), numberType()]).nullable().optional(),
  per_bed_rate: unionType([stringType(), numberType()]).nullable().optional(),
  excess_qty_rate: unionType([stringType(), numberType()]).nullable().optional(),
  upper_slab_qty: unionType([stringType(), numberType()]).nullable().optional(),
  code_land_qty: unionType([stringType(), numberType()]).nullable().optional(),
  total_balance: unionType([stringType(), numberType()]).nullable().optional(),
  ph_reason_code: stringType().nullable().optional(),
  release_code_1: stringType().nullable().optional(),
  approval_status: stringType().nullable().optional(),
  reason: stringType().nullable().optional()
});
function toSapScSoRow(r) {
  return {
    SELECT: "X",
    COMPANY_CODE: s(r.company_code),
    SALES_ORG: s(r.sales_org),
    CUSTOMER: padCustomer(r.customer),
    CUSTOMER_NAME: s(r.customer_name),
    YEAR: numOrEmpty(r.year),
    CONTRACT_NO: s(r.contract_no),
    CONTRACT_ITEM: numOrEmpty(r.contract_item),
    CONTRACT_REF_NO: s(r.contract_ref_no),
    CONTRACT_REF_DATE: s(r.contract_ref_date),
    CON_CREATION_DATE: s(r.con_creation_date),
    CONTRACT_START_DATE: s(r.contract_start_date),
    CONTRACT_END_DATE: s(r.contract_end_date),
    DOWN_PAY_REQ_AMOUNT: numOrEmpty(r.down_pay_req_amount),
    ADV_DOC_NUM: {
      ZEILE: numOrEmpty(r.adv_doc_zeile),
      EBELP: numOrEmpty(r.adv_doc_ebelp)
    },
    ADV_AMOUNT: numOrEmpty(r.adv_amount),
    PROFIT_CENTER: s(r.profit_center),
    CLEARING_DOCUMENT: s(r.clearing_document),
    CUSTOMER_GROUP: s(r.customer_group),
    CUSTOMER_PRICE_GROUP: s(r.customer_price_group),
    SERVICE_VALID_FROM: s(r.service_valid_from),
    SERVICE_VALID_TO: s(r.service_valid_to),
    SERVICE_START_DATE: s(r.service_start_date),
    REGISTRATION_DATE: s(r.registration_date),
    CUS_AGR_FROM: s(r.cus_agr_from),
    CUS_AGR_TO: s(r.cus_agr_to),
    ACTIVE_INACTIVE: s(r.active_inactive),
    NO_OF_BEDS_TO_BE_INV: numOrEmpty(r.no_of_beds_to_be_inv),
    FIXED_RATE: numOrEmpty(r.fixed_rate),
    PER_BED_RATE: numOrEmpty(r.per_bed_rate),
    EXCESS_QTY_RATE: numOrEmpty(r.excess_qty_rate),
    UPPER_SLAB_QTY: numOrEmpty(r.upper_slab_qty),
    CODE_LAND_QTY: numOrEmpty(r.code_land_qty),
    TOTAL_BALANCE: numOrEmpty(r.total_balance),
    PH_REASON_CODE: s(r.ph_reason_code),
    RELEASE_CODE1: s(r.release_code_1),
    APPROVAL_STATUS: s(r.approval_status),
    REASON: s(r.reason)
  };
}
const submitScSoDecision_createServerFn_handler = createServerRpc({
  id: "99437d5650fafa19bc7e2c0d37d4bde1888acbb74149c270908943eced65be69",
  name: "submitScSoDecision",
  filename: "src/lib/sd/sc-so-approval.functions.ts"
}, (opts) => submitScSoDecision.__executeServer(opts));
const submitScSoDecision = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["accepted", "rejected"]),
  user_id: stringType().trim().max(40).optional(),
  approval_type: enumType(["service", "sales"]).default("service"),
  rows: arrayType(ScSoRowSchema).min(1, "Select at least one row")
}).parse(d)).handler(submitScSoDecision_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", DECISION_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${DECISION_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${DECISION_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: prof
  }, {
    data: userIdField
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("profiles").select("sap_user_id").eq("id", context.userId).maybeSingle(), supabaseAdmin.from("sap_api_request_fields").select("default_value").eq("config_id", cfg.id).eq("field_name", "USER_ID").maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const resolvedUserId = data.user_id && data.user_id.trim() || prof?.sap_user_id && prof.sap_user_id.trim() || userIdField?.default_value || "NEOBMWCONS";
  const sapPayload = {
    APPROV: data.action === "accepted" ? "X" : "",
    REJ: data.action === "rejected" ? "X" : "",
    USER_ID: resolvedUserId,
    DATA: data.rows.map(toSapScSoRow)
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/service_certificate/Service_Certificate_Approve_Reject`;
    method = "POST";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      inputs: sapPayload
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url.trim();
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
    bodyOut = JSON.stringify(sapPayload);
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const redacted = (h) => {
    const o = {};
    for (const [k, v] of Object.entries(h)) {
      if (/^(authorization|x-shared-secret)$/i.test(k)) o[k] = "***redacted***";
      else o[k] = v;
    }
    return o;
  };
  const t0 = Date.now();
  console.log("[submitScSoDecision] target=", target, "method=", method, "proxied=", proxied, "payload=", sapPayload);
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
    if (proxied && res.status === 404) {
      const peek = await res.clone().text().catch(() => "");
      if (/Cannot\s+(POST|PUT)/i.test(peek)) {
        const fallback = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
        res = await fetch(fallback, {
          method: "POST",
          headers,
          body: JSON.stringify({
            configId: cfg.id,
            inputs: sapPayload
          })
        });
        target = fallback;
      }
    }
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    console.error("[submitScSoDecision] network error", errMsg);
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `scso-decision ${data.action}: network ${errMsg}`
    });
    return {
      ok: false,
      action: data.action,
      count: data.rows.length,
      error: `Could not reach SAP: ${errMsg}`,
      sap_response: null,
      debug: {
        target,
        method,
        proxied,
        request_headers: redacted(headers),
        request_payload: sapPayload,
        response_status: null,
        response_body_preview: "",
        latency_ms: latency_ms2
      }
    };
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  console.log("[submitScSoDecision] status=", res.status, "latency_ms=", latency_ms, "body=", text.slice(0, 1e3));
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = {
      raw: text
    };
  }
  if (!res.ok) {
    let upstream = "";
    try {
      if (json?.error) upstream = String(json.error);
      else if (json?.data) upstream = typeof json.data === "string" ? json.data : JSON.stringify(json.data);
    } catch {
    }
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `scso-decision ${data.action}: ${res.status} ${text.slice(0, 500)}`
    });
    return {
      ok: false,
      action: data.action,
      count: data.rows.length,
      error: `SAP returned ${res.status} ${res.statusText}: ${upstream || text.slice(0, 300) || "(empty body)"}`,
      sap_response: json,
      debug: {
        target,
        method,
        proxied,
        request_headers: redacted(headers),
        request_payload: sapPayload,
        response_status: res.status,
        response_body_preview: text.slice(0, 4e3),
        latency_ms
      }
    };
  }
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: data.rows.length,
    message: `scso-decision ${data.action}: ${res.status}`
  });
  return {
    ok: true,
    action: data.action,
    count: data.rows.length,
    error: null,
    sap_response: json,
    debug: {
      target,
      method,
      proxied,
      request_headers: redacted(headers),
      request_payload: sapPayload,
      response_status: res.status,
      response_body_preview: text.slice(0, 4e3),
      latency_ms
    }
  };
});
export {
  fetchScSoApprovals_createServerFn_handler,
  submitScSoDecision_createServerFn_handler
};
