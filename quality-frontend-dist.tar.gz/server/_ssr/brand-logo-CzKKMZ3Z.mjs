import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
const url = "/__l5e/assets-v1/c870cd9a-5c10-4c0a-8190-7238cda87da3/re-sustainability-logo.jpg";
const logo = {
  url
};
function BrandLogo({ className, compact = false, alt = "Resustainability" }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "img",
    {
      src: logo.url,
      alt,
      draggable: false,
      className: cn(
        "select-none object-contain",
        compact ? "h-8 w-8" : "h-9 w-auto",
        className
      )
    }
  );
}
export {
  BrandLogo as B
};
