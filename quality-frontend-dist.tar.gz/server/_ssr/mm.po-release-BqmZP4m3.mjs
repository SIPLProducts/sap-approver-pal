import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BhFPQiYt.mjs";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, e as DialogFooter } from "./dialog--up_DbYf.mjs";
import { P as PlantSelect } from "./plant-select-DVNSwFX1.mjs";
import { R as ReleaseKeySelect } from "./release-key-select-EHp_3AUB.mjs";
import { u as useActiveContext, r as releaseKeysFor } from "./use-active-context-CMJTykFM.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";
import { a as SkeletonRows } from "./skeleton-rows-C2wJYLiJ.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";

import "../_libs/seroval.mjs";
import { aa as Funnel, a3 as LoaderCircle, ab as RotateCcw, q as Search } from "../_libs/lucide-react.mjs";
import { a as objectType, C as arrayType, z as stringType } from "../_libs/zod.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "./command-i9zWGkU5.mjs";
import "../_libs/radix-ui__react-popover.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/cmdk.mjs";
import "./sap.functions-BddyAsKl.mjs";
import "./select-CZRUt5a6.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./client-CXnFcWf4.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "./screen-keys-mn2QOK0m.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/radix-ui__react-alert-dialog.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "../_libs/tailwind-merge.mjs";
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  relgroup: stringType().trim().min(1, "Release Group is required").max(10),
  relcode: stringType().trim().min(1, "Release Code is required").max(10),
  plants: arrayType(stringType().trim().min(1)).min(1, "At least one plant is required")
}).parse(d)).handler(createSsrRpc("cbf5aefc482f7a31847fd5286ecb4dce5e98caf7ca607189c5fa428c35006db5"));
const poActionInput = objectType({
  relgroup: stringType().trim().min(1).max(10),
  relcode: stringType().trim().min(1).max(10),
  items: arrayType(objectType({
    EBELN: stringType().trim().min(1),
    EBELP: stringType().trim().default(""),
    REMARKS: stringType().optional().default("")
  })).min(1)
});
const releasePoItems = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => poActionInput.parse(d)).handler(createSsrRpc("8d5655541850e5c45ac9b1924025c12a3db2078072827ad9f3467aa7b30c68a6"));
const rejectPoItems = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => poActionInput.parse(d)).handler(createSsrRpc("fcc316c5f4e14fd42cdb8e9dac52f02d2be76ef2509026ada47ac8702d0d7509"));
const fetchPoGet = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  relgroup: stringType().trim().min(1, "Release Group is required").max(10),
  relcode: stringType().trim().min(1, "Release Code is required").max(10),
  plants: arrayType(stringType().trim().min(1)).min(1, "At least one plant is required")
}).parse(d)).handler(createSsrRpc("2268d63a82c03e043889eab91ed815ce2b8ac40adedbaf16cbade97047f7b6fa"));
const COLUMN_LABELS = {
  EBELN: "Purchase Order Number",
  EBELP: "PO Item",
  BATXT: "Document Type",
  PLANT_NAME: "Plant",
  VENDOR_NAME: "Vendor Name",
  RLWRT: "Net Value",
  WAERS: "Currency",
  BUKRS: "Company Code",
  BSTYP: "PO Category",
  BSART: "Document Type",
  LIFNR: "Vendor",
  LIFNR_NAME: "Vendor Name",
  EKORG: "Purchasing Organization",
  EKGRP: "Purchasing Group",
  BEDAT: "PO Date",
  ERNAM: "Created By",
  MATERIAL: "Material Number",
  MATKL: "Material Group",
  TXZ01: "Short Text",
  WERKS: "Plant",
  PLANT: "Plant",
  LGORT: "Storage Location",
  MENGE: "Quantity",
  MEINS: "Unit",
  NETPR: "Net Price",
  NETWR: "Net Value",
  PEINH: "Price Unit",
  EEIND: "Delivery Date",
  REMARKS: "Remarks"
};
const NUMERIC_COLUMNS = /* @__PURE__ */ new Set(["RLWRT", "NETPR", "NETWR", "MENGE"]);
function rowKey(r, idx) {
  const ebeln = r.EBELN ?? "";
  const ebelp = r.EBELP ?? "";
  return `${ebeln}-${ebelp}-${idx}`;
}
function PoReleasePage() {
  const {
    plants: assignedPlants,
    activePlants
  } = useActiveContext();
  const [plants, setPlants] = reactExports.useState(activePlants.slice(0, 1));
  const [releaseGroup, setReleaseGroup] = reactExports.useState("");
  const [releaseCode, setReleaseCode] = reactExports.useState("");
  const poKeys = reactExports.useMemo(() => releaseKeysFor(assignedPlants, "po", plants), [assignedPlants, plants]);
  const [rows, setRows] = reactExports.useState([]);
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const [remarks, setRemarks] = reactExports.useState({});
  const [search, setSearch] = reactExports.useState("");
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const [responseDialog, setResponseDialog] = reactExports.useState(null);
  reactExports.useEffect(() => {
    setPlants((prev) => {
      if (activePlants.length === 0) return [];
      const allowed = new Set(activePlants);
      const kept = prev.filter((c) => allowed.has(c)).slice(0, 1);
      return kept.length === 0 ? activePlants.slice(0, 1) : kept;
    });
  }, [activePlants.join(",")]);
  const fetchFn = useServerFn(fetchPoGet);
  const mutation = useMutation({
    mutationFn: (input) => fetchFn({
      data: input
    }),
    onSuccess: (res) => {
      if (res.error) {
        toast.error(res.error);
        setRows([]);
        setSelected(/* @__PURE__ */ new Set());
        setRemarks({});
        return;
      }
      setRows(res.data);
      setSelected(/* @__PURE__ */ new Set());
      setRemarks({});
      toast.success(`Loaded ${res.data.length} row(s).`);
    },
    onError: (e) => {
      toast.error(e?.message ?? "Failed to fetch PO Release data.");
    }
  });
  function execute() {
    if (plants.length === 0) {
      toast.error("Select a plant.");
      return;
    }
    if (!releaseGroup.trim() || !releaseCode.trim()) {
      toast.error("Release Group and Release Code are required.");
      return;
    }
    mutation.mutate({
      relgroup: releaseGroup.trim(),
      relcode: releaseCode.trim(),
      plants
    });
  }
  function reset() {
    setPlants(activePlants.slice(0, 1));
    setReleaseGroup("");
    setReleaseCode("");
    setRows([]);
    setSelected(/* @__PURE__ */ new Set());
    setRemarks({});
  }
  const filteredRows = reactExports.useMemo(() => {
    const q = search.trim().toLowerCase();
    const withIdx = rows.map((r, i) => ({
      r,
      i
    }));
    if (!q) return withIdx;
    return withIdx.filter(({
      r
    }) => Object.values(r).some((v) => String(v ?? "").toLowerCase().includes(q)));
  }, [rows, search]);
  const allKeys = reactExports.useMemo(() => filteredRows.map(({
    r,
    i
  }) => rowKey(r, i)), [filteredRows]);
  const allSelected = allKeys.length > 0 && allKeys.every((k) => selected.has(k));
  const someSelected = selected.size > 0 && !allSelected;
  const columns = reactExports.useMemo(() => {
    const keys = [];
    const seen = /* @__PURE__ */ new Set();
    for (const r of rows) {
      for (const k of Object.keys(r)) {
        if (!seen.has(k)) {
          seen.add(k);
          keys.push(k);
        }
      }
    }
    if (!seen.has("REMARKS")) keys.push("REMARKS");
    return keys;
  }, [rows]);
  function toggleAll(checked) {
    setSelected(checked ? new Set(allKeys) : /* @__PURE__ */ new Set());
  }
  function toggleRow(k, checked) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(k);
      else next.delete(k);
      return next;
    });
  }
  const releaseFn = useServerFn(releasePoItems);
  const releaseMutation = useMutation({
    mutationFn: (input) => releaseFn({
      data: input
    }),
    onSuccess: (res) => {
      const releasedKeys = /* @__PURE__ */ new Set();
      const seenPo = /* @__PURE__ */ new Set();
      const dialogItems = [];
      for (const r of res.results) {
        if (r.ok) releasedKeys.add(`${r.ebeln}-${r.ebelp}`);
        if (!seenPo.has(r.ebeln)) {
          seenPo.add(r.ebeln);
          dialogItems.push({
            ebeln: r.ebeln,
            message: r.MSGTXT ?? r.msgtxt ?? r.error ?? (r.ok ? "Released" : "Failed"),
            ok: r.ok,
            response: r.response
          });
        }
      }
      setResponseDialog({
        open: true,
        title: "PO Release Response",
        results: dialogItems
      });
      if (releasedKeys.size > 0) {
        setRows((prev) => prev.filter((r) => !releasedKeys.has(`${String(r.EBELN ?? "")}-${String(r.EBELP ?? "")}`)));
        setSelected(/* @__PURE__ */ new Set());
        setRemarks({});
      }
      if (plants.length > 0 && releaseGroup.trim() && releaseCode.trim()) {
        mutation.mutate({
          relgroup: releaseGroup.trim(),
          relcode: releaseCode.trim(),
          plants
        });
      }
    },
    onError: (e) => {
      toast.error(e?.message ?? "Release failed.");
    }
  });
  function onRelease() {
    if (selected.size === 0) return;
    if (!releaseGroup.trim() || !releaseCode.trim()) {
      toast.error("Release Group and Release Code are required.");
      return;
    }
    const items = rows.map((r, i) => ({
      r,
      k: rowKey(r, i)
    })).filter(({
      k
    }) => selected.has(k)).map(({
      r,
      k
    }) => ({
      EBELN: String(r.EBELN ?? ""),
      EBELP: String(r.EBELP ?? ""),
      REMARKS: remarks[k] ?? (r.REMARKS == null ? "" : String(r.REMARKS))
    })).filter((it) => it.EBELN);
    if (items.length === 0) return;
    void (async () => {
      if (!await confirm({
        title: `Release ${items.length} selected item(s)?`,
        description: "This posts the release to SAP and cannot be undone.",
        confirmLabel: "Release",
        destructive: false
      })) return;
      releaseMutation.mutate({
        relgroup: releaseGroup.trim(),
        relcode: releaseCode.trim(),
        items
      });
    })();
  }
  const rejectFn = useServerFn(rejectPoItems);
  const rejectMutation = useMutation({
    mutationFn: (input) => rejectFn({
      data: input
    }),
    onSuccess: (res) => {
      const rejectedKeys = /* @__PURE__ */ new Set();
      const seenPo = /* @__PURE__ */ new Set();
      const dialogItems = [];
      for (const r of res.results) {
        if (r.ok) rejectedKeys.add(`${r.ebeln}-${r.ebelp}`);
        if (!seenPo.has(r.ebeln)) {
          seenPo.add(r.ebeln);
          dialogItems.push({
            ebeln: r.ebeln,
            message: r.MSGTXT ?? r.msgtxt ?? r.error ?? (r.ok ? "Rejected" : "Failed"),
            ok: r.ok,
            response: r.response
          });
        }
      }
      setResponseDialog({
        open: true,
        title: "PO Reject Response",
        results: dialogItems
      });
      if (rejectedKeys.size > 0) {
        setRows((prev) => prev.filter((r) => !rejectedKeys.has(`${String(r.EBELN ?? "")}-${String(r.EBELP ?? "")}`)));
        setSelected(/* @__PURE__ */ new Set());
        setRemarks({});
      }
      if (plants.length > 0 && releaseGroup.trim() && releaseCode.trim()) {
        mutation.mutate({
          relgroup: releaseGroup.trim(),
          relcode: releaseCode.trim(),
          plants
        });
      }
    },
    onError: (e) => {
      toast.error(e?.message ?? "Reject failed.");
    }
  });
  function onReject() {
    if (selected.size === 0) return;
    if (!releaseGroup.trim() || !releaseCode.trim()) {
      toast.error("Release Group and Release Code are required.");
      return;
    }
    const items = rows.map((r, i) => ({
      r,
      k: rowKey(r, i)
    })).filter(({
      k
    }) => selected.has(k)).map(({
      r,
      k
    }) => ({
      EBELN: String(r.EBELN ?? ""),
      EBELP: String(r.EBELP ?? ""),
      REMARKS: remarks[k] ?? (r.REMARKS == null ? "" : String(r.REMARKS))
    })).filter((it) => it.EBELN);
    if (items.length === 0) return;
    void (async () => {
      if (!await confirm({
        title: `Reject ${items.length} selected item(s)?`,
        description: "This posts the rejection to SAP and cannot be undone.",
        confirmLabel: "Reject"
      })) return;
      rejectMutation.mutate({
        relgroup: releaseGroup.trim(),
        relcode: releaseCode.trim(),
        items
      });
    })();
  }
  const showResults = mutation.isSuccess || rows.length > 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "MM Approvals", title: "PO Release", subtitle: "Release or reject pending purchase orders." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-[280px_240px_240px_1fr_auto] items-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs", children: [
            "Plant ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(PlantSelect, { value: plants[0] ?? "", onChange: (v) => setPlants(v ? [v] : []), source: "user-plant" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ReleaseKeySelect, { keys: poKeys, group: releaseGroup, code: releaseCode, onGroupChange: setReleaseGroup, onCodeChange: setReleaseCode, disabled: mutation.isPending }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: mutation.isPending, children: [
            mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Execute"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, disabled: mutation.isPending, children: "Reset" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "destructive", size: "sm", onClick: onReject, disabled: selected.size === 0 || rejectMutation.isPending, children: [
        rejectMutation.isPending && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }),
        "Reject"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "success", size: "sm", onClick: onRelease, disabled: selected.size === 0 || releaseMutation.isPending, children: [
        releaseMutation.isPending && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }),
        "Release"
      ] })
    ] }),
    mutation.isPending && !showResults && /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { columns: 6 }),
    showResults && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-semibold text-muted-foreground", children: [
          "RESULTS · ",
          filteredRows.length,
          search.trim() ? ` / ${rows.length}` : "",
          " row(s) · ",
          selected.size,
          " selected"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Search results...", className: "h-9 text-sm pl-8" })
        ] })
      ] }),
      rows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { title: "No data available", description: "Run the selection above to load PO release items." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto border rounded-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "w-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: allSelected ? true : someSelected ? "indeterminate" : false, onCheckedChange: (v) => toggleAll(v === true), "aria-label": "Select all" }) }),
          columns.map((key) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: cn("whitespace-nowrap text-xs", NUMERIC_COLUMNS.has(key) && "text-right"), children: COLUMN_LABELS[key] ?? key }, key))
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: filteredRows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: columns.length + 1, className: "text-center text-sm text-muted-foreground py-6", children: "No results match your search." }) }) : filteredRows.map(({
          r,
          i
        }) => {
          const k = rowKey(r, i);
          const checked = selected.has(k);
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { "data-state": checked ? "selected" : void 0, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked, onCheckedChange: (v) => toggleRow(k, v === true), "aria-label": `Select row ${i + 1}` }) }),
            columns.map((key) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: cn("whitespace-nowrap text-xs", NUMERIC_COLUMNS.has(key) && "text-right tabular-nums"), children: key === "REMARKS" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: remarks[k] ?? (r.REMARKS == null ? "" : String(r.REMARKS)), onChange: (e) => setRemarks((prev) => ({
              ...prev,
              [k]: e.target.value
            })), placeholder: "Remarks", className: "h-8 text-xs min-w-[180px]" }) : r[key] === null || r[key] === void 0 || r[key] === "" ? "-" : String(r[key]) }, key))
          ] }, k);
        }) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: !!responseDialog?.open, onOpenChange: (open) => setResponseDialog((prev) => prev ? {
      ...prev,
      open
    } : prev), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: responseDialog?.title ?? "PO Response" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-h-[60vh] overflow-y-auto space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto border rounded-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "PO Number" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Message" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: responseDialog?.results.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs font-medium whitespace-nowrap align-top", children: r.ebeln }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: cn("text-xs", r.ok ? "text-success" : "text-destructive"), children: r.message || "-" })
          ] }, r.ebeln)) })
        ] }) }),
        responseDialog?.results.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("details", { className: "border rounded-md", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("summary", { className: "cursor-pointer px-3 py-2 text-xs font-semibold text-muted-foreground", children: [
            "Raw response — PO ",
            r.ebeln
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { className: "text-xs font-mono bg-muted/50 p-3 overflow-x-auto whitespace-pre", children: JSON.stringify(r.response ?? {
            message: r.message
          }, null, 2) })
        ] }, `raw-${r.ebeln}`))
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: () => setResponseDialog((prev) => prev ? {
        ...prev,
        open: false
      } : prev), children: "Close" }) })
    ] }) }),
    confirmDialog
  ] });
}
export {
  PoReleasePage as component
};
