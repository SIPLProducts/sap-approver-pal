import process from "node:process";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { sapEnabled, fetchOpenApprovals } from "./sap-client.server-CglbxEth.mjs";
import { s as sendPushToUser } from "./push.server-Co_uxbPF.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import "../_libs/web-push.mjs";
import { a as objectType, z as stringType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./client.server-D5ro3rAQ.mjs";


import "../_libs/asn1.js.mjs";
import "../_libs/bn.js.mjs";
import "../_libs/inherits.mjs";
import "../_libs/safer-buffer.mjs";
import "../_libs/minimalistic-assert.mjs";
import "../_libs/jws.mjs";

import "../_libs/safe-buffer.mjs";
import "../_libs/jwa.mjs";
import "../_libs/ecdsa-sig-formatter.mjs";
import "../_libs/buffer-equal-constant-time.mjs";
import "../_libs/http_ece.mjs";
import "../_libs/https-proxy-agent.mjs";



import "../_libs/debug.mjs";
import "../_libs/ms.mjs";
import "../_libs/supports-color.mjs";

import "../_libs/has-flag.mjs";
import "../_libs/agent-base.mjs";
async function assertAdmin(userId) {
  const {
    assertAnyScreen
  } = await import("./assert-screen-DK8QvcMQ.mjs");
  await assertAnyScreen(userId, ["sap.integrations"]);
}
const getIntegrationStatus_createServerFn_handler = createServerRpc({
  id: "bbdcf3c2fb277f21c95d0d963ec1660f6cae78764ce1a89329e8d988171f28aa",
  name: "getIntegrationStatus",
  filename: "src/lib/admin/integrations.functions.ts"
}, (opts) => getIntegrationStatus.__executeServer(opts));
const getIntegrationStatus = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getIntegrationStatus_createServerFn_handler, async ({
  context
}) => {
  await assertAdmin(context.userId);
  const has = (k) => Boolean(process.env[k] && process.env[k].length > 0);
  return {
    sap: {
      configured: has("SAP_BASE_URL") && has("SAP_USER") && has("SAP_PASSWORD"),
      liveMode: sapEnabled(),
      baseUrlSet: has("SAP_BASE_URL"),
      userSet: has("SAP_USER"),
      passwordSet: has("SAP_PASSWORD"),
      useRealFlag: process.env.SAP_USE_REAL ?? "false"
    },
    push: {
      publicKeySet: has("VAPID_PUBLIC_KEY"),
      privateKeySet: has("VAPID_PRIVATE_KEY"),
      subjectSet: has("VAPID_SUBJECT"),
      publicKey: process.env.VAPID_PUBLIC_KEY ?? ""
      // public by design
    },
    cron: {
      secretSet: has("CRON_SECRET")
    }
  };
});
const testSapConnection_createServerFn_handler = createServerRpc({
  id: "979cda470c83d4637138c99f1a5980ef2e5bee56765ee8687dcbaf09c095f9ff",
  name: "testSapConnection",
  filename: "src/lib/admin/integrations.functions.ts"
}, (opts) => testSapConnection.__executeServer(opts));
const testSapConnection = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(testSapConnection_createServerFn_handler, async ({
  context
}) => {
  await assertAdmin(context.userId);
  if (!process.env.SAP_BASE_URL || !process.env.SAP_USER || !process.env.SAP_PASSWORD) {
    return {
      ok: false,
      message: "SAP credentials not configured"
    };
  }
  try {
    const items = await fetchOpenApprovals();
    return {
      ok: true,
      message: `Connected. Pulled ${items.length} open document(s).`
    };
  } catch (e) {
    return {
      ok: false,
      message: e.message
    };
  }
});
const sendTestPush_createServerFn_handler = createServerRpc({
  id: "b17c43c371ad3e0b19c6dc99564e6f0b89482e742639c04a3b9da2eb0e849e83",
  name: "sendTestPush",
  filename: "src/lib/admin/integrations.functions.ts"
}, (opts) => sendTestPush.__executeServer(opts));
const sendTestPush = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => objectType({
  userId: stringType().uuid().optional()
}).parse(input)).handler(sendTestPush_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const target = data.userId ?? context.userId;
  const res = await sendPushToUser(target, {
    title: "Test push from Resustainability Approvals",
    body: "If you can read this, web push is working end-to-end.",
    url: "/inbox",
    tag: "test-push"
  });
  return res;
});
export {
  getIntegrationStatus_createServerFn_handler,
  sendTestPush_createServerFn_handler,
  testSapConnection_createServerFn_handler
};
