import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { a as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn } from "./createSsrRpc-Bx8XQbeC.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, e as DialogFooter } from "./dialog--up_DbYf.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";
import { S as StatusBadge } from "./status-badge-CHGzK-xV.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { C as CloudscapeApprovalTable } from "./cloudscape-approval-table-B3gA6T4g.mjs";
import { b as buildDynamicColumns } from "./dynamic-columns-C64XiqUr.mjs";
import { P as PlantMultiSelect } from "./plant-multi-select-ZAM7hHZh.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { f as fetchPriceApprovals, s as submitPriceDecision, g as getMySapUserId } from "./price-approval.functions-D1l7f9uf.mjs";

import "../_libs/seroval.mjs";
import { aa as Funnel, a3 as LoaderCircle, ab as RotateCcw, F as FileText, x as TriangleAlert, y as CircleX, C as CircleCheck } from "../_libs/lucide-react.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./server-6SfJ9jtE.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/class-variance-authority.mjs";
import "./input-C0QjszdI.mjs";
import "./checkbox-mmp_duDa.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "./empty-state-DA5qeMhN.mjs";
import "./skeleton-rows-C2wJYLiJ.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./format-D-HjDoz6.mjs";
import "./table-BhFPQiYt.mjs";
import "./command-i9zWGkU5.mjs";
import "../_libs/radix-ui__react-popover.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/cmdk.mjs";
import "./plant-select-BIpZq3f7.mjs";
import "./auth-middleware-Drtg4FDX.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./sap.functions-oOi__-nP.mjs";
import "../_libs/zod.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./client-CXnFcWf4.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "./screen-keys-mn2QOK0m.mjs";
function rowKey(r, i) {
  return [r.key_combination, r.condition_type, r.customer, r.material, r.plant, i].map((x) => x ?? "").join("|");
}
function PricePage() {
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const fetchFn = useServerFn(fetchPriceApprovals);
  const userIdFn = useServerFn(getMySapUserId);
  const decisionFn = useServerFn(submitPriceDecision);
  const navigate = useNavigate();
  const {
    data: userIdData
  } = useQuery({
    queryKey: ["sd-price", "sap-user-id"],
    queryFn: () => userIdFn()
  });
  const {
    activePlants
  } = useActiveContext();
  const [plants, setPlants] = reactExports.useState(activePlants);
  const [userId, setUserId] = reactExports.useState("");
  reactExports.useEffect(() => {
    setPlants((prev) => {
      if (activePlants.length === 0) return [];
      const allowed = new Set(activePlants);
      const kept = prev.filter((c) => allowed.has(c));
      return kept.length === 0 ? activePlants : kept;
    });
  }, [activePlants.join(",")]);
  reactExports.useEffect(() => {
    if (userIdData?.sap_user_id && !userId) setUserId(userIdData.sap_user_id);
  }, [userIdData?.sap_user_id]);
  const [rows, setRows] = reactExports.useState([]);
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const [lastFetchedAt, setLastFetchedAt] = reactExports.useState(null);
  const [resultOpen, setResultOpen] = reactExports.useState(false);
  const [resultData, setResultData] = reactExports.useState({
    action: "accepted",
    messages: [],
    total: 0
  });
  const mutation = useMutation({
    mutationFn: async (vars) => {
      const v = await fetchFn({
        data: {
          plants: vars.plants,
          user_id: vars.user_id || void 0
        }
      });
      const rows2 = Array.isArray(v?.rows) ? v.rows : [];
      return {
        rows: rows2,
        count: rows2.length,
        error: v?.error ?? null,
        fetched_at: v?.fetched_at ?? (/* @__PURE__ */ new Date()).toISOString()
      };
    },
    onSuccess: (res) => {
      setRows(res.rows);
      setSelected(/* @__PURE__ */ new Set());
      setLastFetchedAt(res.fetched_at);
      if (res.error) {
        toast.error(res.error);
      } else {
        toast.success(`Loaded ${res.count} record${res.count === 1 ? "" : "s"} from SAP`);
      }
    },
    onError: (e) => toast.error(e.message ?? "Failed to fetch from SAP")
  });
  function execute() {
    if (plants.length === 0) {
      toast.error("Select at least one plant");
      return;
    }
    mutation.mutate({
      plants,
      user_id: userId.trim()
    });
  }
  function reset() {
    setPlants([]);
    setUserId(userIdData?.sap_user_id ?? "");
    setRows([]);
    setSelected(/* @__PURE__ */ new Set());
    setLastFetchedAt(null);
  }
  const indexed = reactExports.useMemo(() => rows.map((r, i) => ({
    r,
    k: rowKey(r, i)
  })), [rows]);
  const decisionMutation = useMutation({
    mutationFn: (vars) => {
      console.log("[price-decision] sending", vars);
      return decisionFn({
        data: vars
      });
    },
    onSuccess: (res, vars) => {
      console.log("[price-decision] response", res);
      setSelected(/* @__PURE__ */ new Set());
      const sap = res?.sap_response ?? {};
      const inner = sap?.data ?? sap;
      const rawMsgs = inner?.MESSAGE ?? inner?.message ?? inner?.Messages ?? sap?.MESSAGE ?? [];
      const msgs = Array.isArray(rawMsgs) ? rawMsgs : rawMsgs ? [rawMsgs] : [];
      setResultData({
        action: vars.action,
        messages: msgs,
        total: vars.rows.length
      });
      setResultOpen(true);
    },
    onError: (e) => {
      console.error("[price-decision] failed", e);
      toast.error(e.message ?? "SAP submission failed");
    }
  });
  async function decide(action) {
    if (selected.size === 0 || decisionMutation.isPending) return;
    const selectedRows = indexed.filter(({
      k
    }) => selected.has(k)).map(({
      r
    }) => r);
    const ok = await confirm({
      title: `${action === "accepted" ? "Approve" : "Reject"} ${selectedRows.length} selected item(s)?`,
      description: "This submits the decision to SAP and cannot be undone.",
      confirmLabel: action === "accepted" ? "Approve" : "Reject",
      destructive: action !== "accepted"
    });
    if (!ok) return;
    decisionMutation.mutate({
      action,
      rows: selectedRows,
      user_id: userId.trim()
    });
  }
  const canAct = selected.size > 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "SD Approvals", title: "Price Approvals", subtitle: "Review and action pending price condition approval requests routed from SAP." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-[240px_1fr_auto] items-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs", children: [
            "Plant ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(PlantMultiSelect, { value: plants, onChange: setPlants })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: plants.length === 0 || mutation.isPending, children: [
            mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Execute"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", onClick: () => navigate({
            to: "/sd/price-reports"
          }), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Reports"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Reset" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CloudscapeApprovalTable, { title: "Price Approvals", countLabel: `(${rows.length})`, rows, rowKey, loading: mutation.isPending, showSelect: true, selectedKeys: selected, onSelectionChange: setSelected, onAccept: () => decide("accepted"), onReject: () => decide("rejected"), acceptDisabled: !canAct || decisionMutation.isPending, rejectDisabled: !canAct || decisionMutation.isPending, acceptLoading: decisionMutation.isPending && decisionMutation.variables?.action === "accepted", rejectLoading: decisionMutation.isPending && decisionMutation.variables?.action === "rejected", emptyMessage: rows.length === 0 ? "Enter a Plant and click Execute to load price approvals from SAP." : "No records.", columns: buildDynamicColumns(rows, {
      exclude: ["release_code1", "release_code_1", "approval_status"]
    }) }),
    confirmDialog,
    /* @__PURE__ */ jsxRuntimeExports.jsx(ResultDialog, { open: resultOpen, onOpenChange: setResultOpen, action: resultData.action, messages: resultData.messages, total: resultData.total })
  ] });
}
function ResultDialog({
  open,
  onOpenChange,
  action,
  messages,
  total
}) {
  const types = messages.map((m) => String(m?.TYPE ?? "").toUpperCase());
  const hasError = types.some((t) => t === "E" || t === "A");
  const hasWarn = types.some((t) => t === "W");
  types.filter((t) => t === "S").length;
  const tone = hasError ? "error" : hasWarn ? "warning" : "success";
  const banner = {
    success: {
      bg: "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-5 w-5 text-emerald-600" }),
      title: action === "accepted" ? "Approved successfully" : "Rejected successfully"
    },
    error: {
      bg: "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-5 w-5 text-red-600" }),
      title: "Completed with errors"
    },
    warning: {
      bg: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-5 w-5 text-amber-600" }),
      title: "Completed with warnings"
    }
  }[tone];
  function badge(type) {
    const t = String(type ?? "").toUpperCase();
    if (t === "S") return /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: "success", label: "Success" });
    if (t === "E" || t === "A") return /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: "error", label: "Error" });
    if (t === "W") return /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: "warning", label: "Warning" });
    return /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: "neutral", label: "Info" });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open, onOpenChange, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "SAP Response" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-start gap-3 rounded-lg border p-3 ${banner.bg}`, children: [
      banner.icon,
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-sm", children: banner.title }) })
    ] }),
    messages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-muted-foreground mt-2", children: "SAP Response Details" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[55vh] overflow-auto space-y-2 pr-1", children: messages.map((m, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3 rounded-md border bg-card p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium leading-snug", children: m?.MESSAGE || "—" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-muted-foreground mt-1 font-mono", children: [
            "Customer: ",
            m?.CUSTOMER?.trim() ? m.CUSTOMER : "—"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0", children: badge(m?.TYPE) })
      ] }, i)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => onOpenChange(false), children: "Close" }) })
  ] }) });
}
export {
  PricePage as component
};
