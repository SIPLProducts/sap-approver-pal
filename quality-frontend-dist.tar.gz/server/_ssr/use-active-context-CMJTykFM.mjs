import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { useSapProfile } from "./use-sap-profile-DRIQ-_33.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { u as useAuth } from "./use-auth-CXN9VXh3.mjs";
import { ALL_SCREENS } from "./screen-keys-mn2QOK0m.mjs";
function useIsBuiltInAdmin() {
  const { user, loading: authLoading } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["builtin-admin", user?.id ?? null],
    enabled: !!user?.id,
    staleTime: 6e4,
    queryFn: async () => {
      const { data: data2, error } = await supabase.rpc("has_role", {
        _user_id: user.id,
        _role: "Admin"
      });
      if (error) return false;
      return !!data2;
    }
  });
  return {
    loading: authLoading || !!user && isLoading,
    isAdmin: !!data
  };
}
const Ctx = reactExports.createContext(null);
const PLANTS_KEY = "app.activePlants";
const LEGACY_PLANT_KEY = "app.activePlant";
const ROLE_KEY = "app.activeRole";
function readStoredRole() {
  try {
    const raw = localStorage.getItem(ROLE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed?.kind === "sap" && typeof parsed.value === "string") {
      return { kind: "sap", value: parsed.value, label: parsed.label ?? parsed.value };
    }
    return null;
  } catch {
    return null;
  }
}
function readStoredPlants() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(PLANTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.filter((v) => typeof v === "string");
    }
    const legacy = localStorage.getItem(LEGACY_PLANT_KEY);
    if (legacy) return [legacy];
  } catch {
  }
  return [];
}
function writeStoredPlants(codes) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(PLANTS_KEY, JSON.stringify(codes));
    localStorage.removeItem(LEGACY_PLANT_KEY);
  } catch {
  }
}
function writeStoredRole(role) {
  if (typeof window === "undefined") return;
  if (role) localStorage.setItem(ROLE_KEY, JSON.stringify(role));
  else localStorage.removeItem(ROLE_KEY);
}
function normRole(value) {
  return value.trim().toUpperCase();
}
function plantFromProfile(p) {
  return {
    code: p.code,
    name: p.name,
    prKeys: p.prKeys,
    poKeys: p.poKeys,
    nfaKeys: p.nfaKeys,
    sesKeys: p.sesKeys
  };
}
function releaseKeysFor(plants, kind, plantCodes) {
  const wanted = new Set(plantCodes);
  const field = kind === "pr" ? "prKeys" : kind === "po" ? "poKeys" : kind === "nfa" ? "nfaKeys" : "sesKeys";
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const p of plants) {
    if (wanted.size > 0 && !wanted.has(p.code)) continue;
    for (const k of p[field] ?? []) {
      const dedupe = `${k.relGroup}\0${k.releaseCode}`;
      if (seen.has(dedupe)) continue;
      seen.add(dedupe);
      out.push(k);
    }
  }
  return out;
}
function buildBuiltInAdminProfile() {
  return {
    user: "builtin-admin",
    plants: [
      {
        code: "ALL",
        name: "All Plants",
        roles: [
          {
            role: "ADMIN",
            label: "Administrator",
            activities: ALL_SCREENS.map((s) => s.activity)
          }
        ]
      }
    ]
  };
}
function sameSet(a, b) {
  if (a.length !== b.length) return false;
  const s = new Set(a);
  for (const x of b) if (!s.has(x)) return false;
  return true;
}
function ActiveContextProvider({ children }) {
  const sapProfile = useSapProfile();
  const { isAdmin: builtInAdmin } = useIsBuiltInAdmin();
  const profile = reactExports.useMemo(() => {
    if (sapProfile) return sapProfile;
    if (builtInAdmin) return buildBuiltInAdminProfile();
    return null;
  }, [sapProfile, builtInAdmin]);
  const plants = reactExports.useMemo(
    () => (profile?.plants ?? []).map(plantFromProfile).sort((a, b) => a.code.localeCompare(b.code)),
    [profile]
  );
  const [activePlants, setActivePlantsState] = reactExports.useState([]);
  const [activeRole, setActiveRoleState] = reactExports.useState(null);
  const [hydrated, setHydrated] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (typeof window === "undefined") return;
    setActivePlantsState(readStoredPlants());
    setActiveRoleState(readStoredRole());
    setHydrated(true);
  }, []);
  reactExports.useEffect(() => {
    if (!hydrated) return;
    const assignedCodes = plants.map((p) => p.code);
    if (assignedCodes.length === 0) {
      if (activePlants.length > 0) {
        setActivePlantsState([]);
        writeStoredPlants([]);
      }
      return;
    }
    const allowed = new Set(assignedCodes);
    const pruned = activePlants.filter((c) => allowed.has(c));
    const next = pruned.length === 0 ? assignedCodes : pruned;
    if (!sameSet(next, activePlants)) {
      setActivePlantsState(next);
    }
    writeStoredPlants(next);
  }, [hydrated, plants, activePlants]);
  const activePlant = activePlants[0] ?? null;
  const roles = reactExports.useMemo(() => {
    if (!profile || !activePlant) return [];
    const plant = profile.plants.find((p) => p.code === activePlant);
    return (plant?.roles ?? []).map((r) => ({
      kind: "sap",
      value: r.role,
      label: r.label ?? r.role,
      activities: r.activities
    }));
  }, [profile, activePlant]);
  reactExports.useEffect(() => {
    if (!hydrated) return;
    if (roles.length === 0) {
      if (activeRole) {
        setActiveRoleState(null);
        writeStoredRole(null);
      }
      return;
    }
    const found = activeRole ? roles.find((r) => normRole(r.value) === normRole(activeRole.value)) : void 0;
    if (!found) {
      const r0 = roles[0];
      const next = { kind: "sap", value: r0.value, label: r0.label };
      setActiveRoleState(next);
      writeStoredRole(next);
    } else if (activeRole?.kind !== "sap" || activeRole.label !== found.label) {
      const next = { kind: "sap", value: found.value, label: found.label };
      setActiveRoleState(next);
      writeStoredRole(next);
    } else {
      writeStoredRole(activeRole);
    }
  }, [hydrated, roles, activeRole]);
  const activeActivities = reactExports.useMemo(() => {
    if (!activeRole) return [];
    return roles.find((r) => normRole(r.value) === normRole(activeRole.value))?.activities ?? [];
  }, [roles, activeRole]);
  const setActivePlants = (codes) => {
    setActivePlantsState(codes);
    writeStoredPlants(codes);
  };
  const setActivePlant = (code) => {
    const next = code ? [code] : [];
    setActivePlantsState(next);
    writeStoredPlants(next);
  };
  const setActiveRole = (role) => {
    setActiveRoleState(role);
    writeStoredRole(role);
  };
  const value = {
    loading: !hydrated,
    plants,
    roles,
    activePlants,
    activePlant,
    activeRole,
    activeActivities,
    setActivePlants,
    setActivePlant,
    setActiveRole
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Ctx.Provider, { value, children });
}
function useActiveContext() {
  const v = reactExports.useContext(Ctx);
  if (!v) {
    return {
      loading: false,
      plants: [],
      roles: [],
      activePlants: [],
      activePlant: null,
      activeRole: null,
      activeActivities: [],
      setActivePlants: () => {
      },
      setActivePlant: () => {
      },
      setActiveRole: () => {
      }
    };
  }
  return v;
}
export {
  ActiveContextProvider as A,
  releaseKeysFor as r,
  useActiveContext as u
};
