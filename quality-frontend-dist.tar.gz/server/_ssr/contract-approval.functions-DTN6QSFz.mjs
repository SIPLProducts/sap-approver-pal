import { c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { a as objectType, D as enumType, C as arrayType, z as stringType, A as unionType, B as numberType } from "../_libs/zod.mjs";
const fetchContractApprovals = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().trim().min(1).max(40)).min(1, "At least one plant required"),
  user_id: stringType().trim().max(40).optional(),
  customer_from: stringType().trim().max(40).optional(),
  customer_to: stringType().trim().max(40).optional(),
  search_terms: arrayType(stringType().trim().min(1).max(40)).max(100).optional(),
  status: enumType(["pending", "accepted", "rejected", "all"]).default("pending")
}).parse(d)).handler(createSsrRpc("552e7f71419724c8f34d7591326f8dc39cc8389335f8d699243dd51a8c639edc"));
const ContractRowSchema = objectType({
  select: stringType().nullable().optional(),
  company_code: stringType().nullable().optional(),
  sales_org: stringType().nullable().optional(),
  customer: stringType().nullable().optional(),
  customer_name: stringType().nullable().optional(),
  year: stringType().nullable().optional(),
  contract_no: stringType().nullable().optional(),
  contract_item: unionType([stringType(), numberType()]).nullable().optional(),
  con_creation_date: stringType().nullable().optional(),
  dis_chanel: stringType().nullable().optional(),
  division: stringType().nullable().optional(),
  material: stringType().nullable().optional(),
  qty: unionType([stringType(), numberType()]).nullable().optional(),
  customer_group: stringType().nullable().optional(),
  customer_price_group: stringType().nullable().optional(),
  net_value: unionType([stringType(), numberType()]).nullable().optional(),
  tax_value: unionType([stringType(), numberType()]).nullable().optional(),
  total: unionType([stringType(), numberType()]).nullable().optional(),
  agreement_from: stringType().nullable().optional(),
  agreement_to: stringType().nullable().optional(),
  service_valid_from: stringType().nullable().optional(),
  service_valid_to: stringType().nullable().optional(),
  service_start_date: stringType().nullable().optional(),
  registration_date: stringType().nullable().optional(),
  upper_slab: unionType([stringType(), numberType()]).nullable().optional(),
  no_of_beds_to_be_inv: unionType([stringType(), numberType()]).nullable().optional(),
  fixed_rate: unionType([stringType(), numberType()]).nullable().optional(),
  per_bed_rate: unionType([stringType(), numberType()]).nullable().optional(),
  excess_qty_rate: unionType([stringType(), numberType()]).nullable().optional(),
  reason: stringType().nullable().optional(),
  rel_1: stringType().nullable().optional(),
  status_1: stringType().nullable().optional(),
  rel_2: stringType().nullable().optional(),
  status_2: stringType().nullable().optional()
});
const submitContractDecision = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["accepted", "rejected"]),
  user_id: stringType().trim().max(40).optional(),
  rows: arrayType(ContractRowSchema).min(1, "Select at least one row")
}).parse(d)).handler(createSsrRpc("5a3e059341648c570e01a7c2304832c66a4635abc790b8f7cb815989e10a98b1"));
export {
  fetchContractApprovals as f,
  submitContractDecision as s
};
