import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-Bm5Y9dpM.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, z as stringType, C as arrayType, E as recordType, I as anyType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "MIGO_Fetch_API";
const fetchMigo_createServerFn_handler = createServerRpc({
  id: "59f3c7297cbfe93895378718402fe3f3855263f438f9d563f3840eac0a345303",
  name: "fetchMigo",
  filename: "src/lib/mm/migo-release.functions.ts"
}, (opts) => fetchMigo.__executeServer(opts));
const fetchMigo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  mat_doc_number: stringType().trim().min(1, "Material Document Number is required").max(40),
  mat_doc_year: stringType().trim().min(4, "Material Document Year is required").max(4)
}).parse(d)).handler(fetchMigo_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const matDocNo = data.mat_doc_number.trim();
  const matDocYear = data.mat_doc_year.trim();
  const inputs = {
    mblnr: matDocNo,
    mjahr: matDocYear
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    headers["Content-Type"] = "application/json";
    bodyOut = JSON.stringify(inputs);
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `migo-fetch network: ${errMsg}`
    });
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      error: `Could not reach SAP. ${errMsg}.`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `migo-fetch: ${message} ${text.slice(0, 500)}`
    });
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  const rawHeader = sapJson?.HEADER ?? sapJson?.header ?? null;
  const header = Array.isArray(rawHeader) ? rawHeader[0] && typeof rawHeader[0] === "object" ? {
    ...rawHeader[0]
  } : null : rawHeader && typeof rawHeader === "object" ? {
    ...rawHeader
  } : null;
  const dataArr = Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : [];
  const rows = dataArr.map((r) => r && typeof r === "object" ? {
    ...r
  } : {});
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `migo-fetch: ${message}`
  });
  return {
    header,
    data: rows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    error: null
  };
});
const CHECK_CONFIG_NAME = "MIGO_Check_API";
const checkMigo_createServerFn_handler = createServerRpc({
  id: "d4a2658f012824e0283a64a9941a225550d9e5ecb5892127e2dab11cec725689",
  name: "checkMigo",
  filename: "src/lib/mm/migo-release.functions.ts"
}, (opts) => checkMigo.__executeServer(opts));
const checkMigo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  mat_doc_number: stringType().trim().min(1, "Material Document Number is required").max(40),
  mat_doc_year: stringType().trim().min(4, "Material Document Year is required").max(4)
}).parse(d)).handler(checkMigo_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CHECK_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CHECK_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CHECK_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const inputs = {
    mblnr: data.mat_doc_number.trim(),
    mjahr: data.mat_doc_year.trim(),
    Check: "X"
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    headers["Content-Type"] = "application/json";
    bodyOut = JSON.stringify(inputs);
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `migo-check network: ${errMsg}`
    });
    return {
      fields: null,
      raw: [],
      error: `Could not reach SAP. ${errMsg}.`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `migo-check: ${message} ${text.slice(0, 500)}`
    });
    return {
      fields: null,
      raw: [],
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      fields: null,
      raw: [],
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  const arr = Array.isArray(sapJson) ? sapJson : Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : [];
  const first = arr.length > 0 && arr[0] && typeof arr[0] === "object" ? {
    ...arr[0]
  } : null;
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: arr.length,
    message: `migo-check: ${message}`
  });
  return {
    fields: first,
    raw: arr,
    error: null
  };
});
const SAVE_CONFIG_NAME = "MIGO_Save_API";
const saveMigo_createServerFn_handler = createServerRpc({
  id: "285b595eefb3611f049270b2cc24cb22a5dc30c1f91cb3e6db4d80b51def5f7e",
  name: "saveMigo",
  filename: "src/lib/mm/migo-release.functions.ts"
}, (opts) => saveMigo.__executeServer(opts));
const saveMigo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  header: recordType(stringType(), anyType()),
  data: arrayType(recordType(stringType(), anyType())).min(1, "At least one row is required")
}).parse(d)).handler(saveMigo_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", SAVE_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${SAVE_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${SAVE_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const payload = {
    ...data.header,
    DATA: data.data
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs: payload
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    headers["Content-Type"] = "application/json";
    bodyOut = JSON.stringify(payload);
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `migo-save network: ${errMsg}`
    });
    return {
      ok: false,
      message: `Could not reach SAP: ${errMsg}`,
      documentNumber: null
    };
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `migo-save: invalid JSON ${text.slice(0, 300)}`
    });
    return {
      ok: false,
      message: `Invalid JSON from SAP: ${text.slice(0, 200)}`,
      documentNumber: null
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  if (Array.isArray(sapJson?.MESSAGES) && sapJson.MESSAGES.length > 0) {
    const msg = sapJson.MESSAGES.map((m) => String(m?.MESSAGE ?? "").trim()).filter(Boolean).join("; ") || "SAP returned an error";
    const anyError = sapJson.MESSAGES.some((m) => String(m?.TYPE ?? "").toUpperCase() === "E" || String(m?.TYPE ?? "").toUpperCase() === "A");
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: anyError ? "error" : "ok",
      latency_ms,
      message: `migo-save: ${msg}`
    });
    return {
      ok: !anyError,
      message: msg,
      documentNumber: sapJson?.DOCUMENT_NUMBER ?? null
    };
  }
  const type = String(sapJson?.TYPE ?? "").toUpperCase();
  const message = String(sapJson?.MESSAGE ?? "").trim();
  const ok = res.ok && (type === "S" || type === "I" || type === "");
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: ok ? "ok" : "error",
    latency_ms,
    message: `migo-save: ${type || "?"} ${message || text.slice(0, 200)}`
  });
  return {
    ok,
    message: message || (ok ? "Saved successfully" : `SAP returned ${res.status}`),
    documentNumber: sapJson?.DOCUMENT_NUMBER ?? null
  };
});
const POST_CONFIG_NAME = "MIGO_POST_API";
const postMigo_createServerFn_handler = createServerRpc({
  id: "e694e6efe281439e5d97d7a9962a1f0cb36ddbfe1781c18d75c0e00ab6e80181",
  name: "postMigo",
  filename: "src/lib/mm/migo-release.functions.ts"
}, (opts) => postMigo.__executeServer(opts));
const postMigo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  header: recordType(stringType(), anyType()),
  data: arrayType(recordType(stringType(), anyType())).min(1, "At least one row is required"),
  custom: recordType(stringType(), anyType()).nullish()
}).parse(d)).handler(postMigo_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", POST_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${POST_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${POST_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const {
    buildMigoPostPayload
  } = await import("./migo-payload-DK-8U11M.mjs");
  const payload = buildMigoPostPayload(data.header, data.data, data.custom ?? null);
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs: payload
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    headers["Content-Type"] = "application/json";
    bodyOut = JSON.stringify(payload);
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `migo-post network: ${errMsg}`
    });
    return {
      ok: false,
      type: "E",
      message: `Could not reach SAP: ${errMsg}`,
      mat_doc: "",
      doc_year: 0,
      raw: null
    };
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `migo-post: invalid JSON ${text.slice(0, 300)}`
    });
    return {
      ok: false,
      type: "E",
      message: `Invalid JSON from SAP: ${text.slice(0, 200)}`,
      mat_doc: "",
      doc_year: 0,
      raw: text
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  const rawResp = Array.isArray(sapJson) ? sapJson[0] ?? {} : sapJson;
  const type = String(rawResp?.TYPE ?? rawResp?.type ?? "").toUpperCase();
  const message = String(rawResp?.MESSAGE ?? rawResp?.message ?? "").trim();
  const matDoc = String(rawResp?.MAT_DOC ?? rawResp?.mat_doc ?? "");
  const docYear = Number(rawResp?.DOC_YEAR ?? rawResp?.doc_year ?? 0);
  const ok = res.ok && type === "S";
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: ok ? "ok" : "error",
    latency_ms,
    message: `migo-post: ${type || "?"} ${message || text.slice(0, 200)}`
  });
  return {
    ok,
    type: type || "",
    message: message || (ok ? "Posted successfully" : `SAP returned ${res.status}`),
    mat_doc: matDoc,
    doc_year: docYear,
    raw: rawResp
  };
});
export {
  checkMigo_createServerFn_handler,
  fetchMigo_createServerFn_handler,
  postMigo_createServerFn_handler,
  saveMigo_createServerFn_handler
};
