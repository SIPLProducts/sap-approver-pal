const MIGO_HEADER_KEYS = [
  "DOC_DATE",
  "PSTNG_DATE",
  "DELIV_NOTE",
  "VENDOR_NAME",
  "HEADER_TEXT",
  "POST",
  "GAT_NO",
  "GAT_DATE",
  "GIR_NO",
  "GIR_DATE",
  "VEHICLE_NO",
  "INVOICE_NO",
  "TRANSPORT_NO",
  "ZINSP",
  "ZNSP",
  "ZMTSNR"
];
const MIGO_CUSTOM_KEYS = [
  "GAT_NO",
  "GAT_DATE",
  "GIR_NO",
  "GIR_DATE",
  "VEHICLE_NO",
  "INVOICE_NO",
  "TRANSPORT_NO",
  "ZINSP",
  "ZNSP",
  "ZMTSNR"
];
const MIGO_ITEM_KEYS = [
  "MAT_DOC",
  "DOC_YEAR",
  "MATDOC_ITM",
  "MATERIAL",
  "WARRANTY",
  "OK",
  "PLANT",
  "DESCRIPTION",
  "STGE_LOC",
  "BATCH",
  "MOVE_TYPE",
  "STCK_TYPE",
  "SPEC_STOCK",
  "VENDOR",
  "VENDOR_NAME",
  "CUSTOMER",
  "SALES_ORD",
  "S_ORD_ITEM",
  "SCHED_LINE",
  "ENTRY_QNT",
  "ENTRY_UOM",
  "PO_PR_QNT",
  "ORDERPR_UN",
  "PO_NUMBER",
  "PO_ITEM",
  "ITEM_TEXT",
  "PROFIT_CTR",
  "CURRENCY",
  "REF_DOC_YR",
  "REF_DOC",
  "REF_DOC_IT",
  "CMMT_ITEM_LONG",
  "LINE_ID"
];
const MIGO_NUMERIC_ITEM_KEYS = /* @__PURE__ */ new Set([
  "DOC_YEAR",
  "MATDOC_ITM",
  "S_ORD_ITEM",
  "SCHED_LINE",
  "ENTRY_QNT",
  "PO_PR_QNT",
  "PO_ITEM",
  "REF_DOC_YR",
  "REF_DOC_IT",
  "LINE_ID"
]);
function pick(src, key) {
  if (!src) return void 0;
  if (key in src) return src[key];
  const norm = (s) => s.replace(/[\s_]/g, "").toUpperCase();
  const want = norm(key);
  for (const k of Object.keys(src)) {
    if (norm(k) === want) return src[k];
  }
  return void 0;
}
function asString(v) {
  if (v === null || v === void 0) return "";
  return String(v);
}
function asNumber(v) {
  if (v === null || v === void 0 || v === "") return 0;
  const n = Number(String(v).replace(/,/g, "").trim());
  return Number.isFinite(n) ? n : 0;
}
function buildMigoHeader(header, custom) {
  const out = {};
  for (const key of MIGO_HEADER_KEYS) {
    if (key === "POST") {
      out.POST = "X";
      continue;
    }
    if (MIGO_CUSTOM_KEYS.includes(key)) {
      const fromCustom = pick(custom, key);
      out[key] = asString(fromCustom !== void 0 && fromCustom !== null ? fromCustom : pick(header, key));
      continue;
    }
    out[key] = asString(pick(header, key));
  }
  return out;
}
function buildMigoItem(row) {
  const out = {};
  for (const key of MIGO_ITEM_KEYS) {
    const v = pick(row, key);
    out[key] = MIGO_NUMERIC_ITEM_KEYS.has(key) ? asNumber(v) : asString(v);
  }
  return out;
}
function buildMigoPostPayload(header, rows, custom) {
  return {
    HEADER: buildMigoHeader(header, custom),
    DATA: rows.map(buildMigoItem)
  };
}
export {
  MIGO_CUSTOM_KEYS,
  MIGO_HEADER_KEYS,
  MIGO_ITEM_KEYS,
  buildMigoHeader,
  buildMigoItem,
  buildMigoPostPayload
};
