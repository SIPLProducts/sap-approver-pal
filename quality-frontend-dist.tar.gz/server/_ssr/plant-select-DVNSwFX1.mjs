import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { P as Popover, a as PopoverTrigger, b as PopoverContent, C as Command, c as CommandInput, d as CommandList, e as CommandEmpty, f as CommandGroup, g as CommandItem } from "./command-i9zWGkU5.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { r as runSapApi } from "./sap.functions-BddyAsKl.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { a3 as LoaderCircle, n as ChevronsUpDown, o as Check } from "../_libs/lucide-react.mjs";
const getPlantConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("b0a132193613dcd4e649fa2c7b1cc40833c087b5b24e6fcf84d8d10d6309d2d7"));
const getUserPlantConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("394e0fd740d1810d557877758ff7cf86db4c2946e74acdb78de987ea35382048"));
function extractPlantOptions(resp, field) {
  const r = resp;
  let rows = [];
  if (Array.isArray(r)) rows = r;
  else if (r && typeof r === "object") {
    const candidates = [r.DATA, r.data?.DATA, r.data, r.ITEMS, r.items, r.RESULTS, r.results, r.PLANT_LIST];
    rows = candidates.find((c) => Array.isArray(c)) ?? [];
    if (!rows.length) {
      for (const v of Object.values(r)) {
        if (Array.isArray(v)) {
          rows = v;
          break;
        }
      }
    }
  }
  const codeKeys = [field, "VKORG", "WERKS", "PLANT", "Plant", "Werks", "Vkorg", "plant", "werks", "vkorg"];
  const textKeys = ["VTEXT", "Vtext", "vtext", "NAME1", "Name1", "name1", "DESCRIPTION", "Description", "description", "TEXT", "Text", "text"];
  const map = /* @__PURE__ */ new Map();
  for (const row of rows) {
    if (row == null) continue;
    if (typeof row === "string" || typeof row === "number") {
      const c = String(row).trim();
      if (c && !map.has(c)) map.set(c, "");
      continue;
    }
    let code = "";
    for (const k of codeKeys) {
      const v = row?.[k];
      if (v != null && String(v).trim()) {
        code = String(v).trim();
        break;
      }
    }
    if (!code) continue;
    let text = "";
    for (const k of textKeys) {
      const v = row?.[k];
      if (v != null && String(v).trim()) {
        text = String(v).trim();
        break;
      }
    }
    if (!map.has(code) || text && !map.get(code)) map.set(code, text);
  }
  return Array.from(map.entries()).map(([code, text]) => ({ code, text })).sort((a, b) => a.code.localeCompare(b.code));
}
function PlantSelect({
  value,
  onChange,
  placeholder = "Select plant…",
  disabled,
  className,
  restrictToActive = true,
  source = "default"
}) {
  const [open, setOpen] = reactExports.useState(false);
  const getDefaultCfg = useServerFn(getPlantConfig);
  const getUserCfg = useServerFn(getUserPlantConfig);
  const runApi = useServerFn(runSapApi);
  const { activePlants } = useActiveContext();
  const cfgQuery = useQuery({
    queryKey: ["sap-plant-config", source],
    queryFn: async () => source === "user-plant" ? await getUserCfg() : await getDefaultCfg(),
    staleTime: 10 * 60 * 1e3
  });
  const configId = cfgQuery.data?.configId ?? null;
  const plantField = cfgQuery.data?.plantField ?? (source === "user-plant" ? "WERKS" : "VKORG");
  const plantsQuery = useQuery({
    queryKey: ["sap-plants", configId],
    enabled: !!configId,
    staleTime: 5 * 60 * 1e3,
    queryFn: async () => {
      const resp = await runApi({ data: { configId, inputs: {} } });
      return extractPlantOptions(resp?.data ?? resp, plantField);
    }
  });
  const allowedSet = reactExports.useMemo(
    () => restrictToActive && activePlants.length > 0 ? new Set(activePlants) : null,
    [restrictToActive, activePlants]
  );
  const plants = reactExports.useMemo(() => {
    const list = plantsQuery.data ?? [];
    return allowedSet ? list.filter((p) => allowedSet.has(p.code)) : list;
  }, [plantsQuery.data, allowedSet]);
  const selectedOption = reactExports.useMemo(
    () => plants.find((p) => p.code === value),
    [plants, value]
  );
  reactExports.useEffect(() => {
    if (!allowedSet) return;
    if (value && !allowedSet.has(value)) onChange("");
  }, [allowedSet]);
  const triggerLabel = value ? selectedOption && selectedOption.text ? `${selectedOption.code} - ${selectedOption.text}` : value : "";
  if (!cfgQuery.isLoading && !configId) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Input,
      {
        value,
        onChange: (e) => onChange(e.target.value),
        placeholder: "e.g. 3801",
        className: cn("h-9 font-mono", className),
        disabled
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "outline",
        role: "combobox",
        "aria-expanded": open,
        disabled: disabled || cfgQuery.isLoading,
        className: cn(
          "h-9 w-full justify-between",
          !value && "text-muted-foreground font-sans",
          className
        ),
        children: [
          cfgQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2 font-sans", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Loading…"
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate text-left", children: triggerLabel || placeholder }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronsUpDown, { className: "ml-2 h-3.5 w-3.5 shrink-0 opacity-50" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PopoverContent,
      {
        className: "z-[1000] w-[320px] p-0 max-h-[60vh]",
        align: "start",
        side: "bottom",
        sideOffset: 6,
        avoidCollisions: false,
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Command, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CommandInput, { placeholder: "Search plant…", className: "h-9" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CommandList, { className: "max-h-[calc(60vh-3rem)]", children: plantsQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 py-6 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Fetching plants…"
          ] }) : plantsQuery.isError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-4 text-xs text-destructive space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: "Failed to load plants." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] opacity-80 break-words", children: plantsQuery.error?.message ?? "Unknown error" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "underline", onClick: () => plantsQuery.refetch(), children: "Retry" })
          ] }) : plants.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-xs text-muted-foreground", children: "No plants returned. Check SAP API Settings." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CommandEmpty, { children: "No plant found." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CommandGroup, { children: plants.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              CommandItem,
              {
                value: `${p.code} ${p.text}`,
                onSelect: () => {
                  onChange(p.code === value ? "" : p.code);
                  setOpen(false);
                },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Check,
                    {
                      className: cn(
                        "mr-2 h-3.5 w-3.5",
                        value === p.code ? "opacity-100" : "opacity-0"
                      )
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: p.code }),
                  p.text && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 text-muted-foreground truncate", children: [
                    "— ",
                    p.text
                  ] })
                ]
              },
              p.code
            )) })
          ] }) })
        ] })
      }
    )
  ] });
}
export {
  PlantSelect as P,
  getUserPlantConfig as a,
  extractPlantOptions as e,
  getPlantConfig as g
};
