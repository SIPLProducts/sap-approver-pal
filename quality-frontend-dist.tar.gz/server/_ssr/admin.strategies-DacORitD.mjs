import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { B as Badge } from "./badge-DyfXZgLs.mjs";
import { D as DOC_TYPE_LABELS } from "./constants-BH6qBFMC.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { a as SkeletonRows } from "./skeleton-rows-C2wJYLiJ.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { N as GitBranch } from "../_libs/lucide-react.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "./skeleton-C5WX2eNf.mjs";
function Strategies() {
  const {
    data: rows = [],
    isLoading
  } = useQuery({
    queryKey: ["strategies"],
    queryFn: async () => (await supabase.from("approval_strategies").select("*").order("doc_type")).data ?? []
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Admin", title: "Release Strategies", subtitle: "Approval chains for each SAP transaction. Editable per BU / value band." }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { rows: 5, columns: 3 }) : rows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(GitBranch, { className: "h-5 w-5" }), title: "No strategies configured", description: "Release strategies will appear here once configured." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3", children: rows.map((s) => {
      const meta = DOC_TYPE_LABELS[s.doc_type];
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: meta?.label ?? s.doc_type }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
            "T-code: ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: meta?.tcode }),
            " • Module: ",
            meta?.module,
            " ",
            s.business_unit ? `• BU: ${s.business_unit}` : ""
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1", children: (s.roles_in_order ?? []).map((r, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "outline", children: [
          i + 1,
          ". ",
          r
        ] }, i)) })
      ] }) }, s.id);
    }) })
  ] });
}
export {
  Strategies as component
};
