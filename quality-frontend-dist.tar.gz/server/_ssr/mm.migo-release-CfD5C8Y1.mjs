import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { C as CloudscapeApprovalTable } from "./cloudscape-approval-table-B3gA6T4g.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-CZRUt5a6.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, e as DialogFooter } from "./dialog--up_DbYf.mjs";

import "../_libs/seroval.mjs";
import { aa as Funnel, a3 as LoaderCircle, ab as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as objectType, z as stringType, E as recordType, I as anyType, C as arrayType } from "../_libs/zod.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "./empty-state-DA5qeMhN.mjs";
import "./skeleton-rows-C2wJYLiJ.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./format-D-HjDoz6.mjs";
import "./table-BhFPQiYt.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
const fetchMigo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  mat_doc_number: stringType().trim().min(1, "Material Document Number is required").max(40),
  mat_doc_year: stringType().trim().min(4, "Material Document Year is required").max(4)
}).parse(d)).handler(createSsrRpc("59f3c7297cbfe93895378718402fe3f3855263f438f9d563f3840eac0a345303"));
const checkMigo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  mat_doc_number: stringType().trim().min(1, "Material Document Number is required").max(40),
  mat_doc_year: stringType().trim().min(4, "Material Document Year is required").max(4)
}).parse(d)).handler(createSsrRpc("d4a2658f012824e0283a64a9941a225550d9e5ecb5892127e2dab11cec725689"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  header: recordType(stringType(), anyType()),
  data: arrayType(recordType(stringType(), anyType())).min(1, "At least one row is required")
}).parse(d)).handler(createSsrRpc("285b595eefb3611f049270b2cc24cb22a5dc30c1f91cb3e6db4d80b51def5f7e"));
const postMigo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  header: recordType(stringType(), anyType()),
  data: arrayType(recordType(stringType(), anyType())).min(1, "At least one row is required"),
  custom: recordType(stringType(), anyType()).nullish()
}).parse(d)).handler(createSsrRpc("e694e6efe281439e5d97d7a9962a1f0cb36ddbfe1781c18d75c0e00ab6e80181"));
const STCK_TYPE_OPTIONS = [{
  value: "1",
  label: "1 Unrestricted"
}, {
  value: "2",
  label: "2 Quality Inspection"
}, {
  value: "3",
  label: "3 Blocked"
}];
function isStckTypeKey(k) {
  const u = k.toUpperCase();
  return u === "STCK_TYPE" || u === "STCKTYPE";
}
function rowKey(r, i) {
  return [r.MAT_DOC, r.DOC_YEAR, r.MATDOC_ITM, r.MATERIAL, r.LINE_ID, i].map((x) => x ?? "").join("|");
}
function toStr(v) {
  if (v == null) return "";
  return String(v);
}
function isCheckboxKey(k) {
  const u = k.toUpperCase();
  return u === "WARRANTY" || u === "OK";
}
function isEditableTextKey(k) {
  const u = k.toUpperCase();
  return u === "STGE_LOC" || u === "STGELOC" || u === "LGORT";
}
function isLineIdKey(k) {
  const u = k.toUpperCase();
  return u === "LINE_ID" || u === "LINEID";
}
function MigoReleasePage() {
  const fetchFn = useServerFn(fetchMigo);
  const checkFn = useServerFn(checkMigo);
  const [matDocNo, setMatDocNo] = reactExports.useState("");
  const [matDocYear, setMatDocYear] = reactExports.useState("");
  const [header, setHeader] = reactExports.useState(null);
  const [rows, setRows] = reactExports.useState([]);
  const [edits, setEdits] = reactExports.useState(/* @__PURE__ */ new Map());
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const [customFields, setCustomFields] = reactExports.useState(null);
  const hasResults = header !== null || rows.length > 0;
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const [resultDialog, setResultDialog] = reactExports.useState(null);
  const mutation = useMutation({
    mutationFn: async (vars) => {
      const v = await fetchFn({
        data: vars
      });
      const data = Array.isArray(v?.data) ? v.data : [];
      return {
        header: v?.header ?? null,
        data,
        count: data.length,
        error: v?.error ?? null
      };
    },
    onSuccess: (res) => {
      setHeader(res.header);
      setRows(res.data);
      const seeded = /* @__PURE__ */ new Map();
      res.data.forEach((r, i) => {
        seeded.set(rowKey(r, i), {
          ...r
        });
      });
      setEdits(seeded);
      setCustomFields(null);
      if (res.error) toast.error(res.error);
      else toast.success(`Loaded ${res.count} record${res.count === 1 ? "" : "s"} from SAP`);
    },
    onError: (e) => toast.error(e.message ?? "Failed to fetch from SAP")
  });
  const postFn = useServerFn(postMigo);
  const postMutation = useMutation({
    mutationFn: async (vars) => {
      const v = await postFn({
        data: vars
      });
      return v;
    },
    onSuccess: (res) => {
      const parts = [res.message];
      if (res.mat_doc) parts.push(`Material Document: ${res.mat_doc}`);
      if (res.doc_year) parts.push(`Document Year: ${res.doc_year}`);
      setResultDialog({
        open: true,
        ok: res.ok,
        title: res.ok ? "Success" : "Failed",
        lines: parts
      });
      if (res.ok) {
        toast.success(res.message || "Posted successfully");
        setMatDocNo("");
        setMatDocYear("");
        setHeader(null);
        setRows([]);
        setEdits(/* @__PURE__ */ new Map());
        setSelected(/* @__PURE__ */ new Set());
        setCustomFields(null);
      } else {
        toast.error(res.message || "Post failed");
      }
    },
    onError: (e) => toast.error(e.message ?? "Failed to post")
  });
  function onPost() {
    if (selected.size === 0) {
      toast.error("Select at least one row");
      return;
    }
    const items = rows.map((r, i) => ({
      r,
      i,
      k: rowKey(r, i)
    })).filter(({
      k
    }) => selected.has(k)).map(({
      r,
      k
    }) => ({
      ...r,
      ...edits.get(k) ?? {}
    }));
    void (async () => {
      if (!await confirm({
        title: `Post ${items.length} selected item(s)?`,
        description: "This posts the goods movement to SAP and cannot be undone.",
        confirmLabel: "Post",
        destructive: false
      })) return;
      postMutation.mutate({
        header: {
          ...header ?? {}
        },
        data: items,
        custom: customFields ?? null
      });
    })();
  }
  function execute() {
    if (!matDocNo.trim()) {
      toast.error("Material Document Number is required");
      return;
    }
    mutation.mutate({
      mat_doc_number: matDocNo.trim(),
      mat_doc_year: matDocYear.trim()
    });
  }
  function reset() {
    setMatDocNo("");
    setMatDocYear("");
    setHeader(null);
    setRows([]);
    setEdits(/* @__PURE__ */ new Map());
    setSelected(/* @__PURE__ */ new Set());
    setCustomFields(null);
  }
  const checkMutation = useMutation({
    mutationFn: async (vars) => {
      const v = await checkFn({
        data: vars
      });
      return v;
    },
    onSuccess: (res) => {
      if (res.error) {
        toast.error(res.error);
        return;
      }
      setCustomFields(res.fields ?? {});
      toast.success("Check completed");
    },
    onError: (e) => toast.error(e.message ?? "Check failed")
  });
  function check() {
    if (!matDocNo.trim()) {
      toast.error("Material Document Number is required");
      return;
    }
    checkMutation.mutate({
      mat_doc_number: matDocNo.trim(),
      mat_doc_year: matDocYear.trim()
    });
  }
  function updateCell(k, field, value) {
    setEdits((prev) => {
      const next = new Map(prev);
      const cur = next.get(k) ?? {};
      next.set(k, {
        ...cur,
        [field]: value
      });
      return next;
    });
  }
  const columns = reactExports.useMemo(() => {
    const dataKeys = [];
    for (const r of rows) {
      for (const k of Object.keys(r)) {
        if (!dataKeys.includes(k)) dataKeys.push(k);
      }
    }
    const lineIdKeys = dataKeys.filter(isLineIdKey);
    const materialKey = dataKeys.find((k) => k.toUpperCase() === "MATERIAL");
    const entryQtyKey = dataKeys.find((k) => k.toUpperCase() === "ENTRY_QNT");
    const priorityKeys = [...lineIdKeys, ...materialKey ? [materialKey] : [], ...entryQtyKey ? [entryQtyKey] : []];
    const otherKeys = dataKeys.filter((k) => !priorityKeys.includes(k));
    const orderedKeys = [...priorityKeys, ...otherKeys];
    const numericHint = /(QTY|QUANTITY|AMOUNT|VALUE|PRICE|STOCK|NETWR|RLWRT|QNT)/i;
    return orderedKeys.map((key) => {
      if (isCheckboxKey(key)) {
        return {
          id: key,
          header: key.replace(/_/g, " "),
          minWidth: 100,
          cell: (item) => {
            const idx = rows.indexOf(item);
            const k = rowKey(item, idx);
            const cur = edits.get(k) ?? item;
            const checked = String(cur?.[key] ?? "").toUpperCase() === "X";
            return /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked, onCheckedChange: (v) => updateCell(k, key, v === true ? "X" : "") });
          }
        };
      }
      if (isEditableTextKey(key)) {
        return {
          id: key,
          header: key.replace(/_/g, " "),
          minWidth: 140,
          cell: (item) => {
            const idx = rows.indexOf(item);
            const k = rowKey(item, idx);
            const cur = edits.get(k) ?? item;
            return /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: toStr(cur?.[key]), onChange: (e) => updateCell(k, key, e.target.value), className: "h-8 text-xs" });
          }
        };
      }
      if (isStckTypeKey(key)) {
        return {
          id: key,
          header: key.replace(/_/g, " "),
          minWidth: 200,
          cell: (item) => {
            const idx = rows.indexOf(item);
            const k = rowKey(item, idx);
            const cur = edits.get(k) ?? item;
            const val = toStr(cur?.[key]);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: val, onValueChange: (v) => updateCell(k, key, v), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Select" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: STCK_TYPE_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.value, children: o.label }, o.value)) })
            ] });
          }
        };
      }
      return {
        id: key,
        header: key.replace(/_/g, " "),
        minWidth: 120,
        align: numericHint.test(key) ? "right" : void 0,
        cell: (item) => {
          const v = item[key];
          if (v == null || v === "") return "—";
          return String(v);
        }
      };
    });
  }, [rows, edits]);
  const headerFields = reactExports.useMemo(() => Object.keys(header ?? {}), [header]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "MM Approvals", title: "MIGO Release", subtitle: "Review, check and post goods movement documents." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-[240px_180px_auto] items-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Material Document Number" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: matDocNo, onChange: (e) => setMatDocNo(e.target.value), placeholder: "Material document number", className: "h-9 text-sm" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Material Document Year" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: matDocYear, onChange: (e) => setMatDocYear(e.target.value.replace(/\D/g, "").slice(0, 4)), placeholder: "YYYY", inputMode: "numeric", maxLength: 4, className: "h-9 text-sm" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: mutation.isPending, children: [
            mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Get Details"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: check, disabled: !hasResults || checkMutation.isPending, children: [
            checkMutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : null,
            "Check"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Reset" })
        ] })
      ] })
    ] }),
    hasResults && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      headerFields.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
          " HEADER"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 md:grid-cols-2 lg:grid-cols-4", children: headerFields.map((k) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: k.replace(/_/g, " ") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: toStr(header?.[k]), readOnly: true, className: "h-9 text-sm bg-muted/40" })
        ] }, k)) })
      ] }),
      customFields && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
          " CUSTOM FIELDS"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 md:grid-cols-2 lg:grid-cols-4", children: ["GAT_NO", "GAT_DATE", "GIR_NO", "GIR_DATE", "VEHICLE_NO", "INVOICE_NO", "TRANSPORT_NO", "ZINSP", "ZNSP", "ZMTSNR"].map((k) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: k.replace(/_/g, " ") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: toStr(customFields?.[k]), readOnly: true, className: "h-9 text-sm bg-muted/40" })
        ] }, k)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "success", disabled: selected.size === 0 || postMutation.isPending, onClick: onPost, children: [
        postMutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : null,
        "Post"
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CloudscapeApprovalTable, { title: "MIGO Items", countLabel: `(${rows.length})`, rows, rowKey, loading: mutation.isPending, emptyMessage: "No line items.", showSelect: true, selectedKeys: selected, onSelectionChange: setSelected, columns })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: !!resultDialog?.open, onOpenChange: (open) => setResultDialog((prev) => prev ? {
      ...prev,
      open
    } : prev), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { className: resultDialog?.ok ? "text-success" : "text-destructive", children: resultDialog?.title }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1 text-sm", children: resultDialog?.lines.map((line, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: line }, i)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: () => setResultDialog((prev) => prev ? {
        ...prev,
        open: false
      } : prev), children: "Close" }) })
    ] }) }),
    confirmDialog
  ] });
}
export {
  MigoReleasePage as component
};
