import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn } from "./createSsrRpc-XOrxmi8L.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { C as CloudscapeApprovalTable } from "./cloudscape-approval-table-B3gA6T4g.mjs";
import { b as buildDynamicColumns } from "./dynamic-columns-C64XiqUr.mjs";
import { P as PlantMultiSelect } from "./plant-multi-select-BpKoT4A-.mjs";
import { C as CustomerSelect } from "./customer-select-CCM4PbU4.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { f as fetchSalesOrderApprovals } from "./sales-order-approval.functions-IoRIGx-4.mjs";

import "../_libs/seroval.mjs";
import { a4 as ArrowLeft, aa as Funnel, a3 as LoaderCircle, ab as RotateCcw } from "../_libs/lucide-react.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./server-CeMw7B2X.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "./input-C0QjszdI.mjs";
import "./checkbox-mmp_duDa.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "./empty-state-DA5qeMhN.mjs";
import "./skeleton-rows-C2wJYLiJ.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./format-D-HjDoz6.mjs";
import "./table-BhFPQiYt.mjs";
import "./command-i9zWGkU5.mjs";
import "../_libs/radix-ui__react-popover.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "./plant-select-DVNSwFX1.mjs";
import "./auth-middleware-BtdUo7VX.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./sap.functions-BddyAsKl.mjs";
import "../_libs/zod.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./client-CXnFcWf4.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "./screen-keys-mn2QOK0m.mjs";
function rowKey(r, i) {
  return [r.sales_document_no, r.sales_item_no, r.customer, r.material, i].map((x) => x ?? "").join("|");
}
function SalesOrderReportsPage() {
  const navigate = useNavigate();
  const fetchFn = useServerFn(fetchSalesOrderApprovals);
  const {
    activePlants: __aps
  } = useActiveContext();
  const [plants, setPlants] = reactExports.useState(__aps);
  reactExports.useEffect(() => {
    setPlants((prev) => {
      if (__aps.length === 0) return [];
      const allowed = new Set(__aps);
      const kept = prev.filter((c) => allowed.has(c));
      return kept.length === 0 ? __aps : kept;
    });
  }, [__aps.join(",")]);
  const [userId, setUserId] = reactExports.useState("");
  const [customerFrom, setCustomerFrom] = reactExports.useState("");
  const [rows, setRows] = reactExports.useState([]);
  const mutation = useMutation({
    mutationFn: async (vars) => {
      const v = await fetchFn({
        data: {
          ...vars,
          status: "pending"
        }
      });
      const rows2 = Array.isArray(v?.rows) ? v.rows : [];
      return {
        rows: rows2,
        count: rows2.length,
        error: v?.error ?? null
      };
    },
    onSuccess: (res) => {
      setRows(res.rows);
      if (res.error) toast.error(res.error);
      else toast.success(`Loaded ${res.count} record${res.count === 1 ? "" : "s"} from SAP`);
    },
    onError: (e) => toast.error(e.message ?? "Failed to fetch from SAP")
  });
  function execute() {
    if (plants.length === 0) return toast.error("Select at least one plant");
    mutation.mutate({
      plants,
      user_id: userId.trim(),
      customer_from: customerFrom.trim(),
      customer_to: customerFrom.trim()
    });
  }
  function reset() {
    setPlants([]);
    setUserId("");
    setCustomerFrom("");
    setRows([]);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "SD Reports", title: "Sales Order Approval Reports", subtitle: "Read-only view of pending sales order approval records for reporting and export.", actions: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", size: "icon", onClick: () => navigate({
      to: "/sd/sales-order"
    }), "aria-label": "Back to Sales Order Approvals", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-3 lg:grid-cols-5 items-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs", children: [
            "Plant ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(PlantMultiSelect, { value: plants, onChange: setPlants })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Customer" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CustomerSelect, { value: customerFrom, onChange: setCustomerFrom, plants, onEnter: execute })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: plants.length === 0 || mutation.isPending, children: [
            mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Execute"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Reset" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CloudscapeApprovalTable, { title: "Sales Order Approval Reports", countLabel: `(${rows.length})`, rows, rowKey, loading: mutation.isPending, emptyMessage: rows.length === 0 ? "Enter Plant and click Execute to load sales order approval reports from SAP." : "No records.", columns: buildDynamicColumns(rows, {
      alwaysInclude: ["rel_1", "status_1", "rel_2", "status_2"],
      headerLabels: {
        rel_1: "Release Code 1",
        status_1: "Status 1",
        rel_2: "Release Code 2",
        status_2: "Status 2"
      }
    }) })
  ] });
}
export {
  SalesOrderReportsPage as component
};
