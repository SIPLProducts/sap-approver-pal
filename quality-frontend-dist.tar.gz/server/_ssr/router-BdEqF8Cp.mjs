import process from "node:process";
import { Buffer } from "node:buffer";
import { b as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider, u as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { c as createRouter, a as createRootRouteWithContext, u as useRouter, L as Link, O as Outlet, H as HeadContent, S as Scripts, b as createFileRoute, l as lazyRouteComponent } from "../_libs/tanstack__react-router.mjs";
import { v as redirect, H as notFound } from "../_libs/tanstack__router-core.mjs";
import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { T as Toaster$1 } from "../_libs/sonner.mjs";
import { c as createTanStackInvokeToolHandler, a as createTanStackOAuthProtectedResourceMetadataHandler, b as createTanStackListToolsHandler, d as createTanStackMcpHandler, e as defineTool, f as defineMcp, g as auth } from "../_libs/lovable.dev__mcp-js.mjs";
import { c as createClient } from "../_libs/supabase__supabase-js.mjs";
import { z as zodValidator, f as fallback } from "../_libs/tanstack__zod-adapter.mjs";
import { supabaseAdmin } from "./client.server-D5ro3rAQ.mjs";
import { sapEnabled, fetchOpenApprovals } from "./sap-client.server-CglbxEth.mjs";
import { s as sendPushToUser } from "./push.server-Co_uxbPF.mjs";
import { timingSafeEqual } from "node:crypto";
import { a as objectType, z as stringType, B as numberType, D as enumType, A as unionType } from "../_libs/zod.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/tanstack__history.mjs";

import "../_libs/isbot.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/seroval-plugins.mjs";

import "../_libs/jose.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/web-push.mjs";

import "../_libs/asn1.js.mjs";
import "../_libs/bn.js.mjs";
import "../_libs/inherits.mjs";
import "../_libs/safer-buffer.mjs";
import "../_libs/minimalistic-assert.mjs";
import "../_libs/jws.mjs";

import "../_libs/safe-buffer.mjs";
import "../_libs/jwa.mjs";
import "../_libs/ecdsa-sig-formatter.mjs";
import "../_libs/buffer-equal-constant-time.mjs";
import "../_libs/http_ece.mjs";

import "../_libs/https-proxy-agent.mjs";



import "../_libs/debug.mjs";
import "../_libs/ms.mjs";
import "../_libs/supports-color.mjs";

import "../_libs/has-flag.mjs";
import "../_libs/agent-base.mjs";

const appCss = "/assets/styles-CuqGuqZr.css";
const Toaster = ({ ...props }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Toaster$1,
    {
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
        }
      },
      ...props
    }
  );
};
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Page not found." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90", children: "Go home" })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold text-foreground", children: "Something went wrong" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: error.message }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => {
      router2.invalidate();
      reset();
    }, className: "mt-6 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90", children: "Try again" })
  ] }) });
}
const Route$F = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#d4202a" },
      { title: "Resustainability – SAP Approvals" },
      { name: "description", content: "Role-based SAP MM & SD approvals with real-time notifications for Resustainability." },
      { property: "og:title", content: "Resustainability – SAP Approvals" },
      { name: "twitter:title", content: "Resustainability – SAP Approvals" },
      { property: "og:description", content: "Role-based SAP MM & SD approvals with real-time notifications for Resustainability." },
      { name: "twitter:description", content: "Role-based SAP MM & SD approvals with real-time notifications for Resustainability." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/lMuNufL1WVQqWEBzmwb74CIjyID3/social-images/social-1781682742591-RESL_Logo.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/lMuNufL1WVQqWEBzmwb74CIjyID3/social-images/social-1781682742591-RESL_Logo.webp" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" }
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "icon", type: "image/png", href: "/favicon.png" }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function AuthSync() {
  const router2 = useRouter();
  const qc = useQueryClient();
  reactExports.useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      if (event === "SIGNED_OUT") {
        qc.cancelQueries();
        qc.clear();
        router2.invalidate();
        return;
      }
      router2.invalidate();
      qc.invalidateQueries();
    });
    return () => subscription.unsubscribe();
  }, [router2, qc]);
  return null;
}
function RootComponent() {
  const { queryClient } = Route$F.useRouteContext();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(QueryClientProvider, { client: queryClient, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(AuthSync, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Toaster, { richColors: true, position: "top-right" })
  ] });
}
const $$splitComponentImporter$v = () => import("./index-DKTmgHj4.mjs");
const Route$E = createFileRoute("/")({
  beforeLoad: async () => {
    const {
      redirect: redirect2
    } = await import("../_libs/tanstack__react-router.mjs").then(function(n) {
      return n.i;
    });
    const {
      data
    } = await supabase.auth.getSession();
    if (data.session) throw redirect2({
      to: "/inbox"
    });
    throw redirect2({
      to: "/login"
    });
  },
  component: lazyRouteComponent($$splitComponentImporter$v, "component")
});
const $$splitComponentImporter$u = () => import("../_authenticated-BkfF6B6s.mjs");
const Route$D = createFileRoute("/_authenticated")({
  component: lazyRouteComponent($$splitComponentImporter$u, "component")
});
const $$splitComponentImporter$t = () => import("./login-C1FnCNbo.mjs");
const Route$C = createFileRoute("/login")({
  component: lazyRouteComponent($$splitComponentImporter$t, "component")
});
const whoamiTool = defineTool({
  name: "whoami",
  title: "Who am I",
  description: "Return the signed-in user's id and email for this app.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: (_input, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const info = { user_id: ctx.getUserId(), email: ctx.getUserEmail() ?? null };
    return {
      content: [{ type: "text", text: JSON.stringify(info) }],
      structuredContent: info
    };
  }
});
function supabaseForUser(ctx) {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_PUBLISHABLE_KEY, {
    global: { headers: { Authorization: `Bearer ${ctx.getToken()}` } },
    auth: { persistSession: false, autoRefreshToken: false }
  });
}
const listApprovalsTool = defineTool({
  name: "list_approvals",
  title: "List my approvals",
  description: "List approval documents visible to the signed-in user, subject to the app's row-level security. Supports optional status/module filters and a result limit.",
  inputSchema: {
    status: stringType().optional().describe("Optional status filter (e.g. 'open', 'approved', 'rejected')."),
    module: enumType(["MM", "SD"]).optional().describe("Optional module filter."),
    limit: numberType().int().min(1).max(100).optional().describe("Max rows to return (default 25).")
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ status, module, limit }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const sb = supabaseForUser(ctx);
    let q = sb.from("approval_documents").select("*").limit(limit ?? 25);
    if (status) q = q.eq("status", status);
    if (module) q = q.eq("module", module);
    const { data, error } = await q;
    if (error) {
      return { content: [{ type: "text", text: error.message }], isError: true };
    }
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { rows: data ?? [] }
    };
  }
});
const projectRef = "lagvqxstbpriwsxpzcld";
const mcp = defineMcp({
  name: "resustainability-approvals-mcp",
  title: "Resustainability Approvals",
  version: "0.1.0",
  instructions: "Tools for the Resustainability SAP Approvals app. Use `whoami` to confirm connectivity and identity. Use `list_approvals` to list approval documents visible to the signed-in user (RLS-scoped).",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated"
  }),
  tools: [whoamiTool, listApprovalsTool]
});
const Route$B = createFileRoute("/mcp")({
  server: {
    handlers: {
      ANY: createTanStackMcpHandler(mcp, { resourcePath: "/mcp", metadataPath: "/.well-known/oauth-protected-resource", trustForwardedHost: true })
    }
  }
});
const Route$A = createFileRoute("/.mcp/list-tools")({
  server: {
    handlers: {
      // ANY: TanStack returns SPA HTML for methods not in `handlers`; the SDK 405s instead.
      ANY: createTanStackListToolsHandler(mcp, { resourcePath: "/mcp", metadataPath: "/.well-known/oauth-protected-resource", trustForwardedHost: true })
    }
  }
});
const Route$z = createFileRoute("/.well-known/oauth-protected-resource")({
  server: {
    handlers: {
      ANY: createTanStackOAuthProtectedResourceMetadataHandler(mcp, { resourcePath: "/mcp", metadataPath: "/.well-known/oauth-protected-resource", trustForwardedHost: true })
    }
  }
});
const $$splitComponentImporter$s = () => import("./email-config-CePGxK7-.mjs");
const Route$y = createFileRoute("/_authenticated/email-config")({
  head: () => ({
    meta: [{
      title: "Email Configuration — Resustainability Approvals"
    }, {
      name: "description",
      content: "Manage the No-Reply SMTP sender for outbound emails."
    }, {
      property: "og:title",
      content: "Email Configuration"
    }, {
      property: "og:description",
      content: "Manage the No-Reply SMTP sender for outbound emails."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$s, "component")
});
const $$splitComponentImporter$r = () => import("./history-BJaetkNm.mjs");
const Route$x = createFileRoute("/_authenticated/history")({
  component: lazyRouteComponent($$splitComponentImporter$r, "component")
});
const $$splitComponentImporter$q = () => import("./notifications-DTyqExrp.mjs");
const Route$w = createFileRoute("/_authenticated/notifications")({
  component: lazyRouteComponent($$splitComponentImporter$q, "component")
});
const $$splitComponentImporter$p = () => import("./settings-BoSRzBEH.mjs");
const Route$v = createFileRoute("/_authenticated/settings")({
  component: lazyRouteComponent($$splitComponentImporter$p, "component")
});
const oauth = () => supabase.auth.oauth;
const $$splitErrorComponentImporter = () => import("../_._lovable.oauth.consent-vOi0OSgD.mjs");
const $$splitComponentImporter$o = () => import("../_._lovable.oauth.consent-BoP_ZISg.mjs");
const Route$u = createFileRoute("/.lovable/oauth/consent")({
  // Browser-only: session lives in localStorage.
  ssr: false,
  validateSearch: (s) => ({
    authorization_id: typeof s.authorization_id === "string" ? s.authorization_id : ""
  }),
  beforeLoad: async ({
    search,
    location
  }) => {
    if (!search.authorization_id) throw new Error("Missing authorization_id");
    const {
      data
    } = await supabase.auth.getSession();
    const next = location.pathname + location.searchStr;
    if (!data.session) throw redirect({
      to: "/login",
      search: {
        next
      }
    });
  },
  loader: async ({
    location
  }) => {
    const authorizationId = new URLSearchParams(location.search).get("authorization_id");
    const {
      data,
      error
    } = await oauth().getAuthorizationDetails(authorizationId);
    if (error) throw error;
    const immediate = data?.redirect_url ?? data?.redirect_to;
    if (immediate && !data?.client) throw redirect({
      href: immediate
    });
    return data;
  },
  component: lazyRouteComponent($$splitComponentImporter$o, "component"),
  errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent")
});
const Route$t = createFileRoute("/.mcp/invoke-tool/$tool")({
  server: {
    handlers: {
      // ANY: TanStack returns SPA HTML for methods not in `handlers`; the SDK 405s instead.
      ANY: createTanStackInvokeToolHandler(mcp, { resourcePath: "/mcp", metadataPath: "/.well-known/oauth-protected-resource", trustForwardedHost: true })
    }
  }
});
const $$splitComponentImporter$n = () => import("./admin.integrations-DPfrQnnC.mjs");
const Route$s = createFileRoute("/_authenticated/admin/integrations")({
  component: lazyRouteComponent($$splitComponentImporter$n, "component")
});
const $$splitComponentImporter$m = () => import("./admin.strategies-DacORitD.mjs");
const Route$r = createFileRoute("/_authenticated/admin/strategies")({
  component: lazyRouteComponent($$splitComponentImporter$m, "component")
});
const $$splitComponentImporter$l = () => import("./admin.users-m6xMaxqn.mjs");
const Route$q = createFileRoute("/_authenticated/admin/users")({
  component: lazyRouteComponent($$splitComponentImporter$l, "component")
});
const $$splitComponentImporter$k = () => import("./approval._id-CkXDA1xu.mjs");
const Route$p = createFileRoute("/_authenticated/approval/$id")({
  component: lazyRouteComponent($$splitComponentImporter$k, "component")
});
const Route$o = createFileRoute("/_authenticated/inbox/")({
  beforeLoad: () => {
    throw redirect({ to: "/inbox/$module", params: { module: "mm" } });
  }
});
const $$splitComponentImporter$j = () => import("./inbox._module-XyUO1DGE.mjs");
const Route$n = createFileRoute("/_authenticated/inbox/$module")({
  beforeLoad: ({
    params
  }) => {
    const m = params.module.toUpperCase();
    if (m !== "MM" && m !== "SD") throw notFound();
  },
  component: lazyRouteComponent($$splitComponentImporter$j, "component")
});
const Route$m = createFileRoute("/_authenticated/mm/dashboard")({
  beforeLoad: () => {
    throw redirect({ to: "/inbox/$module", params: { module: "mm" } });
  }
});
const $$splitComponentImporter$i = () => import("./mm.gate-pass-BmK8oZiT.mjs");
const Route$l = createFileRoute("/_authenticated/mm/gate-pass")({
  component: lazyRouteComponent($$splitComponentImporter$i, "component")
});
const $$splitComponentImporter$h = () => import("./mm.gate-process-BphvzQcR.mjs");
const Route$k = createFileRoute("/_authenticated/mm/gate-process")({
  component: lazyRouteComponent($$splitComponentImporter$h, "component")
});
const $$splitComponentImporter$g = () => import("./mm.material-reservation-DSSR5kfL.mjs");
const Route$j = createFileRoute("/_authenticated/mm/material-reservation")({
  component: lazyRouteComponent($$splitComponentImporter$g, "component")
});
const $$splitComponentImporter$f = () => import("./mm.migo-release-CfD5C8Y1.mjs");
const Route$i = createFileRoute("/_authenticated/mm/migo-release")({
  component: lazyRouteComponent($$splitComponentImporter$f, "component")
});
const $$splitComponentImporter$e = () => import("./mm.po-release-Bv8tpEuZ.mjs");
const Route$h = createFileRoute("/_authenticated/mm/po-release")({
  component: lazyRouteComponent($$splitComponentImporter$e, "component")
});
const $$splitComponentImporter$d = () => import("./mm.pr-release-B7RJ8pOA.mjs");
const Route$g = createFileRoute("/_authenticated/mm/pr-release")({
  component: lazyRouteComponent($$splitComponentImporter$d, "component")
});
const $$splitComponentImporter$c = () => import("./mm.znfa-release-C7-uNO_o.mjs");
const Route$f = createFileRoute("/_authenticated/mm/znfa-release")({
  component: lazyRouteComponent($$splitComponentImporter$c, "component")
});
const $$splitComponentImporter$b = () => import("./sd.bmw-status-C65jE4P_.mjs");
const Route$e = createFileRoute("/_authenticated/sd/bmw-status")({
  component: lazyRouteComponent($$splitComponentImporter$b, "component")
});
const $$splitComponentImporter$a = () => import("./sd.contract-DcekRFoV.mjs");
const Route$d = createFileRoute("/_authenticated/sd/contract")({
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./sd.contract-reports-zmCm0ECr.mjs");
const Route$c = createFileRoute("/_authenticated/sd/contract-reports")({
  head: () => ({
    meta: [{
      title: "Contract Approval Reports"
    }, {
      name: "description",
      content: "Read-only report of SAP contract approval records."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./sd.dashboard-CD-O687Q.mjs");
const Route$b = createFileRoute("/_authenticated/sd/dashboard")({
  component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
const $$splitComponentImporter$7 = () => import("./sd.price-CSWWiwAe.mjs");
const Route$a = createFileRoute("/_authenticated/sd/price")({
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./sd.price-reports-UuzWSe38.mjs");
const Route$9 = createFileRoute("/_authenticated/sd/price-reports")({
  head: () => ({
    meta: [{
      title: "Price Approval Reports"
    }, {
      name: "description",
      content: "Read-only report of SAP price approval records."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./sd.sales-order-CTK9EXoF.mjs");
const searchSchema$1 = objectType({
  status: fallback(enumType(["pending", "accepted", "rejected"]), "pending").default("pending")
});
const Route$8 = createFileRoute("/_authenticated/sd/sales-order")({
  validateSearch: zodValidator(searchSchema$1),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./sd.sales-order-reports-CnZTVcix.mjs");
const Route$7 = createFileRoute("/_authenticated/sd/sales-order-reports")({
  head: () => ({
    meta: [{
      title: "Sales Order Approval Reports"
    }, {
      name: "description",
      content: "Read-only report of SAP sales order approval records."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./sd.sc-so-BgYVi4Xb.mjs");
const searchSchema = objectType({
  status: fallback(enumType(["pending", "accepted", "rejected"]), "pending").default("pending")
});
const Route$6 = createFileRoute("/_authenticated/sd/sc-so")({
  validateSearch: zodValidator(searchSchema),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./sd.sc-so-reports-DXvlLdzm.mjs");
const Route$5 = createFileRoute("/_authenticated/sd/sc-so-reports")({
  head: () => ({
    meta: [{
      title: "Service Certificate & SO Approval Reports"
    }, {
      name: "description",
      content: "Read-only report of SAP service certificate & SO approval records."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./admin.sap-api.index-BPCqoFbJ.mjs");
const Route$4 = createFileRoute("/_authenticated/admin/sap-api/")({
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./admin.sap-api._id-D3SA_GyP.mjs");
const Route$3 = createFileRoute("/_authenticated/admin/sap-api/$id")({
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const CORS$2 = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, x-cron-secret"
};
const Route$2 = createFileRoute("/api/public/hooks/sap-sync")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS$2 }),
      POST: async ({ request }) => {
        const secret = process.env.CRON_SECRET;
        const header = request.headers.get("x-cron-secret");
        if (!secret || header !== secret) {
          return new Response("Unauthorized", { status: 401, headers: CORS$2 });
        }
        if (!sapEnabled()) {
          return Response.json(
            { ok: true, skipped: "SAP_USE_REAL=false" },
            { headers: CORS$2 }
          );
        }
        const items = await fetchOpenApprovals();
        const { data: roleRows } = await supabaseAdmin.from("user_roles").select("user_id, role");
        const roleMap = /* @__PURE__ */ new Map();
        for (const r of roleRows ?? []) {
          const list = roleMap.get(r.role) ?? [];
          list.push(r.user_id);
          roleMap.set(r.role, list);
        }
        let inserted = 0;
        for (const it of items) {
          const { data: existing } = await supabaseAdmin.from("approval_documents").select("id").eq("doc_type", it.doc_type).eq("sap_doc_no", it.sap_doc_no).maybeSingle();
          if (existing) continue;
          const { data: doc } = await supabaseAdmin.from("approval_documents").insert({
            module: it.module,
            doc_type: it.doc_type,
            sap_t_code: it.sap_t_code,
            sap_doc_no: it.sap_doc_no,
            title: it.title,
            description: it.description ?? null,
            plant: it.plant ?? null,
            business_unit: it.business_unit ?? null,
            company_code: it.company_code ?? null,
            vendor_name: it.vendor_name ?? null,
            customer_name: it.customer_name ?? null,
            requester_name: it.requester_name,
            requester_sap_id: it.requester_sap_id ?? null,
            total_value: it.total_value,
            currency: it.currency || "INR",
            document_date: it.document_date,
            current_step_seq: 1,
            status: "pending",
            sap_payload: { source: "SAP_CRON", t_code: it.sap_t_code }
          }).select().single();
          if (!doc) continue;
          inserted++;
          if (it.lines?.length) {
            await supabaseAdmin.from("approval_line_items").insert(
              it.lines.map((l) => ({ ...l, document_id: doc.id }))
            );
          }
          const steps = it.steps.map((s, idx) => ({
            document_id: doc.id,
            seq: s.seq,
            role: s.role,
            assigned_user: (roleMap.get(s.role) ?? [])[0] ?? null,
            status: idx === 0 ? "pending" : "waiting"
          }));
          await supabaseAdmin.from("approval_steps").insert(steps);
          const firstAssignee = steps[0]?.assigned_user;
          if (firstAssignee) {
            await supabaseAdmin.from("notifications").insert({
              user_id: firstAssignee,
              document_id: doc.id,
              title: `New approval: ${doc.sap_doc_no}`,
              body: `${doc.title} — ₹${Number(doc.total_value).toLocaleString("en-IN")}`,
              kind: "assignment"
            });
            await sendPushToUser(firstAssignee, {
              title: `New approval: ${doc.sap_doc_no}`,
              body: doc.title,
              url: `/approval/${doc.id}`,
              tag: `doc-${doc.id}`
            });
          }
        }
        return Response.json(
          { ok: true, inserted, pulled: items.length },
          { headers: CORS$2 }
        );
      }
    }
  }
});
const CORS$1 = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, x-shared-secret"
};
function checkSecret$1(req) {
  const expected = process.env.MIDDLEWARE_SHARED_SECRET;
  const got = req.headers.get("x-shared-secret");
  if (!expected || !got) return false;
  const a = Buffer.from(expected);
  const b = Buffer.from(got);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}
const Body$1 = unionType([
  objectType({ configId: stringType().uuid() }),
  objectType({ name: stringType().min(1).max(120) })
]);
const Route$1 = createFileRoute("/api/public/middleware/config")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS$1 }),
      POST: async ({ request }) => {
        if (!checkSecret$1(request)) {
          return Response.json(
            { ok: false, error: "Invalid or missing x-shared-secret" },
            { status: 401, headers: CORS$1 }
          );
        }
        let parsed;
        try {
          parsed = Body$1.parse(await request.json());
        } catch (e) {
          return Response.json(
            { ok: false, error: e?.message ?? "Invalid body" },
            { status: 400, headers: CORS$1 }
          );
        }
        const { supabaseAdmin: supabaseAdmin2 } = await import("./client.server-D5ro3rAQ.mjs");
        const lookupKey = "configId" in parsed ? parsed.configId : parsed.name;
        const lookupCol = "configId" in parsed ? "id" : "name";
        const { data: cfg, error } = await supabaseAdmin2.from("sap_api_configs").select("*").eq(lookupCol, lookupKey).maybeSingle();
        if (error) {
          return Response.json(
            { ok: false, error: `Load config failed: ${error.message}` },
            { status: 500, headers: CORS$1 }
          );
        }
        if (!cfg) {
          return Response.json(
            { ok: false, error: `Config not found: ${lookupKey}` },
            { status: 404, headers: CORS$1 }
          );
        }
        if (!cfg.is_active) {
          return Response.json(
            { ok: false, error: `Config is inactive: ${lookupKey}` },
            { status: 409, headers: CORS$1 }
          );
        }
        const [credsRes, reqFieldsRes, resFieldsRes, globalRes, globalSecretRes] = await Promise.all([
          supabaseAdmin2.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(),
          supabaseAdmin2.from("sap_api_request_fields").select("*").eq("config_id", cfg.id).order("sort_order"),
          supabaseAdmin2.from("sap_api_response_fields").select("*").eq("config_id", cfg.id).order("sort_order"),
          supabaseAdmin2.from("sap_global_settings").select("sap_base_url, sap_username").eq("id", "default").maybeSingle(),
          supabaseAdmin2.from("sap_global_secrets").select("sap_password").eq("id", "default").maybeSingle()
        ]);
        const creds = credsRes.data;
        const { resolveSapUrl } = await import("./url-Cdjg0c3W.mjs");
        let resolvedUrl = null;
        try {
          resolvedUrl = resolveSapUrl(cfg.endpoint_url, globalRes.data?.sap_base_url ?? null);
        } catch (e) {
          return Response.json(
            { ok: false, error: e.message },
            { status: 422, headers: CORS$1 }
          );
        }
        const nonEmpty = (v) => typeof v === "string" && v.trim() !== "" ? v : null;
        const username = nonEmpty(globalRes.data?.sap_username);
        const password = nonEmpty(globalSecretRes.data?.sap_password);
        const resolved = {
          id: cfg.id,
          name: cfg.name,
          module: cfg.module,
          endpoint_url: resolvedUrl,
          http_method: cfg.http_method,
          auth_type: cfg.auth_type,
          is_active: cfg.is_active,
          updated_at: cfg.updated_at,
          credentials: {
            username,
            password,
            extra_headers: creds?.extra_headers ?? {}
          },
          requestFields: reqFieldsRes.data ?? [],
          responseFields: resFieldsRes.data ?? []
        };
        return Response.json({ ok: true, config: resolved }, { headers: CORS$1 });
      }
    }
  }
});
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, x-shared-secret"
};
function checkSecret(req) {
  const expected = process.env.MIDDLEWARE_SHARED_SECRET;
  const got = req.headers.get("x-shared-secret");
  if (!expected || !got) return false;
  const a = Buffer.from(expected);
  const b = Buffer.from(got);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}
const Body = objectType({
  configId: stringType().uuid(),
  status: enumType(["ok", "error"]),
  latency_ms: numberType().int().nonnegative().optional(),
  message: stringType().max(2e3).optional()
});
const Route = createFileRoute("/api/public/middleware/log")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }) => {
        if (!checkSecret(request)) {
          return Response.json(
            { ok: false, error: "Invalid or missing x-shared-secret" },
            { status: 401, headers: CORS }
          );
        }
        let parsed;
        try {
          parsed = Body.parse(await request.json());
        } catch (e) {
          return Response.json(
            { ok: false, error: e?.message ?? "Invalid body" },
            { status: 400, headers: CORS }
          );
        }
        const { supabaseAdmin: supabaseAdmin2 } = await import("./client.server-D5ro3rAQ.mjs");
        const { error } = await supabaseAdmin2.from("sap_api_sync_log").insert({
          config_id: parsed.configId,
          status: parsed.status,
          latency_ms: parsed.latency_ms ?? null,
          message: parsed.message ?? null
        });
        if (error) {
          return Response.json(
            { ok: false, error: error.message },
            { status: 500, headers: CORS }
          );
        }
        return Response.json({ ok: true }, { headers: CORS });
      }
    }
  }
});
const IndexRoute = Route$E.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$F
});
const AuthenticatedRoute = Route$D.update({
  id: "/_authenticated",
  getParentRoute: () => Route$F
});
const LoginRoute = Route$C.update({
  id: "/login",
  path: "/login",
  getParentRoute: () => Route$F
});
const McpRoute = Route$B.update({
  id: "/mcp",
  path: "/mcp",
  getParentRoute: () => Route$F
});
const Char91DotmcpChar93ListToolsRoute = Route$A.update({
  id: "/.mcp/list-tools",
  path: "/.mcp/list-tools",
  getParentRoute: () => Route$F
});
const Char91DotwellKnownChar93OauthProtectedResourceRoute = Route$z.update({
  id: "/.well-known/oauth-protected-resource",
  path: "/.well-known/oauth-protected-resource",
  getParentRoute: () => Route$F
});
const AuthenticatedEmailConfigRoute = Route$y.update({
  id: "/email-config",
  path: "/email-config",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedHistoryRoute = Route$x.update({
  id: "/history",
  path: "/history",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedNotificationsRoute = Route$w.update({
  id: "/notifications",
  path: "/notifications",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSettingsRoute = Route$v.update({
  id: "/settings",
  path: "/settings",
  getParentRoute: () => AuthenticatedRoute
});
const DotlovableOauthConsentRoute = Route$u.update({
  id: "/.lovable/oauth/consent",
  path: "/.lovable/oauth/consent",
  getParentRoute: () => Route$F
});
const Char91DotmcpChar93InvokeToolToolRoute = Route$t.update({
  id: "/.mcp/invoke-tool/$tool",
  path: "/.mcp/invoke-tool/$tool",
  getParentRoute: () => Route$F
});
const AuthenticatedAdminIntegrationsRoute = Route$s.update({
  id: "/admin/integrations",
  path: "/admin/integrations",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedAdminStrategiesRoute = Route$r.update({
  id: "/admin/strategies",
  path: "/admin/strategies",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedAdminUsersRoute = Route$q.update({
  id: "/admin/users",
  path: "/admin/users",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedApprovalIdRoute = Route$p.update({
  id: "/approval/$id",
  path: "/approval/$id",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedInboxIndexRoute = Route$o.update({
  id: "/inbox/",
  path: "/inbox/",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedInboxModuleRoute = Route$n.update({
  id: "/inbox/$module",
  path: "/inbox/$module",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMmDashboardRoute = Route$m.update({
  id: "/mm/dashboard",
  path: "/mm/dashboard",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMmGatePassRoute = Route$l.update({
  id: "/mm/gate-pass",
  path: "/mm/gate-pass",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMmGateProcessRoute = Route$k.update({
  id: "/mm/gate-process",
  path: "/mm/gate-process",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMmMaterialReservationRoute = Route$j.update({
  id: "/mm/material-reservation",
  path: "/mm/material-reservation",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMmMigoReleaseRoute = Route$i.update({
  id: "/mm/migo-release",
  path: "/mm/migo-release",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMmPoReleaseRoute = Route$h.update({
  id: "/mm/po-release",
  path: "/mm/po-release",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMmPrReleaseRoute = Route$g.update({
  id: "/mm/pr-release",
  path: "/mm/pr-release",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMmZnfaReleaseRoute = Route$f.update({
  id: "/mm/znfa-release",
  path: "/mm/znfa-release",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdBmwStatusRoute = Route$e.update({
  id: "/sd/bmw-status",
  path: "/sd/bmw-status",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdContractRoute = Route$d.update({
  id: "/sd/contract",
  path: "/sd/contract",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdContractReportsRoute = Route$c.update({
  id: "/sd/contract-reports",
  path: "/sd/contract-reports",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdDashboardRoute = Route$b.update({
  id: "/sd/dashboard",
  path: "/sd/dashboard",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdPriceRoute = Route$a.update({
  id: "/sd/price",
  path: "/sd/price",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdPriceReportsRoute = Route$9.update({
  id: "/sd/price-reports",
  path: "/sd/price-reports",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdSalesOrderRoute = Route$8.update({
  id: "/sd/sales-order",
  path: "/sd/sales-order",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdSalesOrderReportsRoute = Route$7.update({
  id: "/sd/sales-order-reports",
  path: "/sd/sales-order-reports",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdScSoRoute = Route$6.update({
  id: "/sd/sc-so",
  path: "/sd/sc-so",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedSdScSoReportsRoute = Route$5.update({
  id: "/sd/sc-so-reports",
  path: "/sd/sc-so-reports",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedAdminSapApiIndexRoute = Route$4.update({
  id: "/admin/sap-api/",
  path: "/admin/sap-api/",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedAdminSapApiIdRoute = Route$3.update({
  id: "/admin/sap-api/$id",
  path: "/admin/sap-api/$id",
  getParentRoute: () => AuthenticatedRoute
});
const ApiPublicHooksSapSyncRoute = Route$2.update({
  id: "/api/public/hooks/sap-sync",
  path: "/api/public/hooks/sap-sync",
  getParentRoute: () => Route$F
});
const ApiPublicMiddlewareConfigRoute = Route$1.update({
  id: "/api/public/middleware/config",
  path: "/api/public/middleware/config",
  getParentRoute: () => Route$F
});
const ApiPublicMiddlewareLogRoute = Route.update({
  id: "/api/public/middleware/log",
  path: "/api/public/middleware/log",
  getParentRoute: () => Route$F
});
const AuthenticatedRouteChildren = {
  AuthenticatedEmailConfigRoute,
  AuthenticatedHistoryRoute,
  AuthenticatedNotificationsRoute,
  AuthenticatedSettingsRoute,
  AuthenticatedAdminIntegrationsRoute,
  AuthenticatedAdminStrategiesRoute,
  AuthenticatedAdminUsersRoute,
  AuthenticatedApprovalIdRoute,
  AuthenticatedInboxModuleRoute,
  AuthenticatedMmDashboardRoute,
  AuthenticatedMmGatePassRoute,
  AuthenticatedMmGateProcessRoute,
  AuthenticatedMmMaterialReservationRoute,
  AuthenticatedMmMigoReleaseRoute,
  AuthenticatedMmPoReleaseRoute,
  AuthenticatedMmPrReleaseRoute,
  AuthenticatedMmZnfaReleaseRoute,
  AuthenticatedSdBmwStatusRoute,
  AuthenticatedSdContractRoute,
  AuthenticatedSdContractReportsRoute,
  AuthenticatedSdDashboardRoute,
  AuthenticatedSdPriceRoute,
  AuthenticatedSdPriceReportsRoute,
  AuthenticatedSdSalesOrderRoute,
  AuthenticatedSdSalesOrderReportsRoute,
  AuthenticatedSdScSoRoute,
  AuthenticatedSdScSoReportsRoute,
  AuthenticatedInboxIndexRoute,
  AuthenticatedAdminSapApiIdRoute,
  AuthenticatedAdminSapApiIndexRoute
};
const AuthenticatedRouteWithChildren = AuthenticatedRoute._addFileChildren(
  AuthenticatedRouteChildren
);
const rootRouteChildren = {
  IndexRoute,
  AuthenticatedRoute: AuthenticatedRouteWithChildren,
  LoginRoute,
  McpRoute,
  Char91DotmcpChar93ListToolsRoute,
  Char91DotwellKnownChar93OauthProtectedResourceRoute,
  DotlovableOauthConsentRoute,
  Char91DotmcpChar93InvokeToolToolRoute,
  ApiPublicHooksSapSyncRoute,
  ApiPublicMiddlewareConfigRoute,
  ApiPublicMiddlewareLogRoute
};
const routeTree = Route$F._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreload: "intent",
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Route$u as R,
  Route$p as a,
  Route$n as b,
  Route$8 as c,
  Route$6 as d,
  Route$3 as e,
  oauth as o,
  router as r
};
