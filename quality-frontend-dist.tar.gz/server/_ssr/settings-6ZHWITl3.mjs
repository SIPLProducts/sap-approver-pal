import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useQueryClient, a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { u as useAuth } from "./use-auth-CXN9VXh3.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { B as Badge } from "./badge-DyfXZgLs.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";

import "../_libs/seroval.mjs";
import { G as BellOff, B as Bell } from "../_libs/lucide-react.mjs";
import { a as objectType, z as stringType } from "../_libs/zod.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
const getVapidPublicKey = createServerFn({
  method: "GET"
}).handler(createSsrRpc("3b65599ef4be62ae58ca53057726d74d6b12362a7b2a9d484b24502f2314e944"));
const SubInput = objectType({
  endpoint: stringType().url().max(2e3),
  p256dh: stringType().min(1).max(500),
  auth: stringType().min(1).max(500),
  device_label: stringType().max(120).optional()
});
const subscribePush = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => SubInput.parse(input)).handler(createSsrRpc("6de3a7c2061580c60ac513b1a1b3fff95d728e2816e2ad6b9ec872e0c95dc780"));
const unsubscribePush = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => objectType({
  endpoint: stringType().url()
}).parse(input)).handler(createSsrRpc("59fe8778a670f746039c968d8a3b8f17d0fe359eef7504227b8b658e55daef74"));
function urlBase64ToUint8Array(base64) {
  const padding = "=".repeat((4 - base64.length % 4) % 4);
  const b64 = (base64 + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(b64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}
function isPreviewOrIframe() {
  try {
    if (window.self !== window.top) return true;
  } catch {
    return true;
  }
  const host = window.location.hostname;
  return host.includes("id-preview--") || host.includes("lovableproject.com");
}
function usePush() {
  const [supported, setSupported] = reactExports.useState(false);
  const [enabled, setEnabled] = reactExports.useState(false);
  const [busy, setBusy] = reactExports.useState(false);
  const getKey = useServerFn(getVapidPublicKey);
  const subFn = useServerFn(subscribePush);
  const unsubFn = useServerFn(unsubscribePush);
  reactExports.useEffect(() => {
    const ok = "serviceWorker" in navigator && "PushManager" in window && !isPreviewOrIframe();
    setSupported(ok);
    if (!ok) return;
    navigator.serviceWorker.getRegistration().then(async (reg) => {
      if (!reg) return;
      const sub = await reg.pushManager.getSubscription();
      setEnabled(!!sub);
    });
  }, []);
  const enable = reactExports.useCallback(async () => {
    if (!supported) return;
    setBusy(true);
    try {
      const perm = await Notification.requestPermission();
      if (perm !== "granted") return;
      const reg = await navigator.serviceWorker.getRegistration() ?? await navigator.serviceWorker.register("/sw.js");
      await navigator.serviceWorker.ready;
      const { publicKey } = await getKey();
      if (!publicKey) throw new Error("Server VAPID key not configured");
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey)
      });
      const json = sub.toJSON();
      await subFn({
        data: {
          endpoint: json.endpoint,
          p256dh: json.keys.p256dh,
          auth: json.keys.auth,
          device_label: navigator.userAgent.slice(0, 100)
        }
      });
      setEnabled(true);
    } finally {
      setBusy(false);
    }
  }, [supported, getKey, subFn]);
  const disable = reactExports.useCallback(async () => {
    setBusy(true);
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      const sub = await reg?.pushManager.getSubscription();
      if (sub) {
        await unsubFn({ data: { endpoint: sub.endpoint } });
        await sub.unsubscribe();
      }
      setEnabled(false);
    } finally {
      setBusy(false);
    }
  }, [unsubFn]);
  return { supported, enabled, busy, enable, disable };
}
function SettingsPage() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const push = usePush();
  const {
    data: p
  } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()).data
  });
  const [form, setForm] = reactExports.useState({
    full_name: "",
    sap_user_id: "",
    designation: "",
    plant: "",
    business_unit: "",
    company_code: "",
    phone: ""
  });
  if (p && !form.full_name && p.full_name) {
    setForm({
      full_name: p.full_name ?? "",
      sap_user_id: p.sap_user_id ?? "",
      designation: p.designation ?? "",
      plant: p.plant ?? "",
      business_unit: p.business_unit ?? "",
      company_code: p.company_code ?? "",
      phone: p.phone ?? ""
    });
  }
  async function save() {
    const {
      error
    } = await supabase.from("profiles").update(form).eq("id", user.id);
    if (error) toast.error(error.message);
    else {
      toast.success("Profile updated");
      qc.invalidateQueries({
        queryKey: ["profile", user.id]
      });
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack max-w-2xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Account", title: "Settings", subtitle: "Your SAP profile, contact details, and notification channels." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "p-6 space-y-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-semibold", children: "Browser & PWA push" }),
          push.enabled && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", children: "Enabled" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground mt-1", children: [
          "Real-time push alerts for new approvals, even when the app is closed.",
          !push.supported && " Not available in this preview — open the published app on a supported browser."
        ] })
      ] }),
      push.enabled ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", disabled: push.busy, onClick: push.disable, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-4 h-4 mr-2" }),
        " Disable"
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { disabled: !push.supported || push.busy, onClick: push.enable, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-4 h-4 mr-2" }),
        " Enable push"
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-6 space-y-4", children: [
      [["full_name", "Full name"], ["sap_user_id", "SAP user ID"], ["designation", "Designation"], ["plant", "Plant code"], ["business_unit", "Business unit (IWM / BMW / Recycling / ISS)"], ["company_code", "Company code"], ["phone", "Phone (for SMS)"]].map(([k, label]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: k, children: label }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: k, value: form[k], onChange: (e) => setForm({
          ...form,
          [k]: e.target.value
        }) })
      ] }, k)),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: save, children: "Save changes" })
    ] })
  ] });
}
export {
  SettingsPage as component
};
