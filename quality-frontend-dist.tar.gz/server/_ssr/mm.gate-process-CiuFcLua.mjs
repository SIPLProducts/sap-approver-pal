import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BhFPQiYt.mjs";
import { C as CloudscapeApprovalTable } from "./cloudscape-approval-table-B3gA6T4g.mjs";
import { b as buildDynamicColumns } from "./dynamic-columns-C64XiqUr.mjs";
import { g as getMySapUserId } from "./price-approval.functions-whaYOtr3.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-CZRUt5a6.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";

import "../_libs/seroval.mjs";
import { aa as Funnel, a3 as LoaderCircle, ab as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as objectType, z as stringType, C as arrayType, D as enumType } from "../_libs/zod.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "./checkbox-mmp_duDa.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "./empty-state-DA5qeMhN.mjs";
import "./skeleton-rows-C2wJYLiJ.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./format-D-HjDoz6.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
const fetchGateProcess = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1, "User ID is required").max(60)
}).parse(d)).handler(createSsrRpc("8b22a2bac26ac45e115549d786afca8169ef130a0e45b27810d52d8634d20ad6"));
const createZnfa = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["RATE", "CHANGE", "DISPLAY", "ATTACHMENTS"]),
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  data: arrayType(objectType({
    CHECK: stringType().default("X"),
    BANFN: stringType().default(""),
    ANFNR: stringType().default(""),
    TITLE: stringType().default(""),
    NAME1: stringType().default(""),
    TER_SUB_ID: stringType().default("")
  })).min(1, "Select at least one row")
}).parse(d)).handler(createSsrRpc("7f11d1eb14f584129ea3cea0ca62d2cd9d7787b257af355bc9cf9c9e4b30b5df"));
const ItemSchema = objectType({
  SR_NO: stringType().default(""),
  MATERIAL: stringType().default(""),
  DESCRIPTION: stringType().default(""),
  TENDER_SPEC: stringType().default(""),
  UOM: stringType().default(""),
  VENDOR_NAME: stringType().default(""),
  REMARKS: stringType().default("")
});
const RatingSchema = objectType({
  VENDOR: stringType().default(""),
  RATE: stringType().default("")
});
const saveZnfa = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["RATE", "CHANGE"]),
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  pr_number: stringType().default(""),
  pr_date: stringType().default(""),
  ter_sub_id: stringType().default(""),
  items: arrayType(ItemSchema).default([]),
  ratings: arrayType(RatingSchema).default([])
}).parse(d)).handler(createSsrRpc("4b73b96d3bd0c464cff9d5eae0134f55b00ae74b9b007add95ba0b9b9e068235"));
createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("9d2f17f213753145b1de92ac86025762818464db5226935e5f9876fce3f44459"));
const RATING_OPTIONS = ["T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "T10", "NQ"];
function rowKey(r, i) {
  return [r.pr_number, r.rfq_number, r.ter_sub_id, i].map((x) => x ?? "").join("|");
}
function toStr(v) {
  if (v == null) return "";
  return String(v);
}
function GateProcessPage() {
  const fetchFn = useServerFn(fetchGateProcess);
  const userIdFn = useServerFn(getMySapUserId);
  const createFn = useServerFn(createZnfa);
  const saveFn = useServerFn(saveZnfa);
  const {
    data: userIdData
  } = useQuery({
    queryKey: ["mm-gate-process", "sap-user-id"],
    queryFn: () => userIdFn()
  });
  const [userId, setUserId] = reactExports.useState("");
  const [rows, setRows] = reactExports.useState([]);
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const [output, setOutput] = reactExports.useState(null);
  const [header, setHeader] = reactExports.useState({
    PR_NUMBER: "",
    PR_DATE: "",
    TER_SUB_ID: ""
  });
  const [items, setItems] = reactExports.useState({});
  const [ratings, setRatings] = reactExports.useState({});
  const [lastAction, setLastAction] = reactExports.useState(null);
  const outputRef = reactExports.useRef(null);
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const isEditable = lastAction === "RATE" || lastAction === "CHANGE";
  const ratingOptions = RATING_OPTIONS;
  const outputTitle = reactExports.useMemo(() => {
    switch (lastAction) {
      case "RATE":
        return "Rating Result";
      case "CHANGE":
        return "Change Result";
      case "DISPLAY":
        return "Display Result";
      case "ATTACHMENTS":
        return "Attachments Result";
      default:
        return "Output";
    }
  }, [lastAction]);
  reactExports.useEffect(() => {
    if (userIdData?.sap_user_id && !userId) setUserId(userIdData.sap_user_id);
  }, [userIdData?.sap_user_id]);
  const mutation = useMutation({
    mutationFn: async (vars) => {
      const v = await fetchFn({
        data: {
          user_id: vars.user_id
        }
      });
      const rows2 = Array.isArray(v?.rows) ? v.rows : [];
      return {
        rows: rows2,
        count: rows2.length,
        error: v?.error ?? null,
        fetched_at: v?.fetched_at ?? (/* @__PURE__ */ new Date()).toISOString()
      };
    },
    onSuccess: (res) => {
      setRows(res.rows);
      setSelected(/* @__PURE__ */ new Set());
      setOutput(null);
      setHeader({
        PR_NUMBER: "",
        PR_DATE: "",
        TER_SUB_ID: ""
      });
      setItems({});
      setRatings({});
      setLastAction(null);
      if (res.error) {
        toast.error(res.error);
      } else {
        toast.success(`Loaded ${res.count} record${res.count === 1 ? "" : "s"} from SAP`);
      }
    },
    onError: (e) => toast.error(e.message ?? "Failed to fetch from SAP")
  });
  const createMutation = useMutation({
    mutationFn: async (vars) => {
      const payloadData = vars.data.map((r) => ({
        CHECK: "X",
        BANFN: toStr(r.pr_number),
        ANFNR: toStr(r.rfq_number),
        TITLE: toStr(r.rfq_title),
        NAME1: toStr(r.vendor_name),
        TER_SUB_ID: toStr(r.ter_sub_id)
      }));
      const v = await createFn({
        data: {
          action: vars.action,
          user_id: vars.user_id,
          data: payloadData
        }
      });
      return {
        output: v?.output ?? null,
        error: v?.error ?? null
      };
    },
    onSuccess: (res, vars) => {
      if (res.error) {
        toast.error(res.error);
      } else {
        setLastAction(vars.action);
        setOutput(res.output);
        setHeader({
          PR_NUMBER: toStr(res.output?.PR_NUMBER),
          PR_DATE: toStr(res.output?.PR_DATE),
          TER_SUB_ID: toStr(res.output?.TER_SUB_ID)
        });
        const itemsArr = Array.isArray(res.output?.ITEMS) ? res.output.ITEMS : [];
        const itemsInit = {};
        itemsArr.forEach((it, i) => {
          itemsInit[i] = {
            SR_NO: toStr(it.SR_NO),
            MATERIAL: toStr(it.MATERIAL),
            DESCRIPTION: toStr(it.DESCRIPTION),
            TENDER_SPEC: toStr(it.TENDER_SPEC),
            UOM: toStr(it.UOM),
            VENDOR_NAME: toStr(it.VENDOR_NAME),
            REMARKS: toStr(it.REMARKS)
          };
        });
        setItems(itemsInit);
        const ratingsArr = Array.isArray(res.output?.RATINGS) ? res.output.RATINGS : [];
        const ratingsInit = {};
        ratingsArr.forEach((rt, i) => {
          ratingsInit[i] = {
            VENDOR: toStr(rt.VENDOR),
            RATE: toStr(rt.RATE)
          };
        });
        setRatings(ratingsInit);
        toast.success("Request submitted successfully");
        requestAnimationFrame(() => {
          outputRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "start"
          });
        });
      }
    },
    onError: (e) => toast.error(e.message ?? "Failed to submit")
  });
  const saveMutation = useMutation({
    mutationFn: async (vars) => {
      const v = await saveFn({
        data: vars
      });
      return v;
    },
    onSuccess: (res) => {
      if (res.ok) {
        if (res.ter_sub_id) setHeader((p) => ({
          ...p,
          TER_SUB_ID: res.ter_sub_id
        }));
        toast.success(res.message ?? "Saved successfully");
      } else {
        toast.error(res.error ?? "Save failed");
      }
    },
    onError: (e) => toast.error(e.message ?? "Failed to save")
  });
  function handleSave() {
    if (lastAction !== "RATE" && lastAction !== "CHANGE") return;
    if (!userId.trim()) {
      toast.error("User ID is required");
      return;
    }
    void doSave();
  }
  async function doSave() {
    if (lastAction !== "RATE" && lastAction !== "CHANGE") return;
    const itemsArr = Array.isArray(output?.ITEMS) ? output.ITEMS.map((it, idx) => {
      const f = items[idx];
      return {
        SR_NO: f?.SR_NO ?? toStr(it.SR_NO),
        MATERIAL: f?.MATERIAL ?? toStr(it.MATERIAL),
        DESCRIPTION: f?.DESCRIPTION ?? toStr(it.DESCRIPTION),
        TENDER_SPEC: f?.TENDER_SPEC ?? toStr(it.TENDER_SPEC),
        UOM: f?.UOM ?? toStr(it.UOM),
        VENDOR_NAME: f?.VENDOR_NAME ?? toStr(it.VENDOR_NAME),
        REMARKS: f?.REMARKS ?? toStr(it.REMARKS)
      };
    }) : [];
    const ratingsArr = Array.isArray(output?.RATINGS) ? output.RATINGS.map((rt, idx) => {
      const f = ratings[idx];
      return {
        VENDOR: f?.VENDOR ?? toStr(rt.VENDOR),
        RATE: f?.RATE ?? toStr(rt.RATE)
      };
    }) : [];
    if (!await confirm({
      title: "Save changes?",
      description: "This posts the update to SAP and cannot be undone.",
      confirmLabel: "Save",
      destructive: false
    })) return;
    saveMutation.mutate({
      action: lastAction,
      user_id: userId.trim(),
      pr_number: header.PR_NUMBER,
      pr_date: header.PR_DATE,
      ter_sub_id: header.TER_SUB_ID,
      items: itemsArr,
      ratings: ratingsArr
    });
  }
  function execute() {
    if (!userId.trim()) {
      toast.error("User ID is required");
      return;
    }
    mutation.mutate({
      user_id: userId.trim()
    });
  }
  function reset() {
    setUserId(userIdData?.sap_user_id ?? "");
    setRows([]);
    setSelected(/* @__PURE__ */ new Set());
    setOutput(null);
    setHeader({
      PR_NUMBER: "",
      PR_DATE: "",
      TER_SUB_ID: ""
    });
    setItems({});
    setRatings({});
    setLastAction(null);
  }
  function handleAction(action) {
    if (!userId.trim()) {
      toast.error("User ID is required");
      return;
    }
    const selectedRows = rows.filter((r, i) => selected.has(rowKey(r, i)));
    if (selectedRows.length === 0) {
      toast.error("Select at least one row");
      return;
    }
    createMutation.mutate({
      action,
      user_id: userId.trim(),
      data: selectedRows
    });
  }
  const hasResults = rows.length > 0 || output !== null;
  const actionButtons = [{
    label: "Rating",
    action: "RATE",
    variant: "default"
  }, {
    label: "Change",
    action: "CHANGE",
    variant: "secondary"
  }, {
    label: "Display",
    action: "DISPLAY",
    variant: "outline"
  }, {
    label: "Attachments",
    action: "ATTACHMENTS",
    variant: "success"
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "MM Approvals", title: "ZNFA Rating", subtitle: "Rate, change and review ZNFA tender records." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-[240px_1fr_auto] items-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs", children: [
            "User ID ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: userId, onChange: (e) => setUserId(e.target.value), readOnly: true, className: "h-9 text-sm bg-muted/40" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: !userId.trim() || mutation.isPending, children: [
            mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Execute"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Reset" })
        ] })
      ] })
    ] }),
    hasResults && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CloudscapeApprovalTable, { title: "ZNFA Rating", countLabel: `(${rows.length})`, rows, rowKey, loading: mutation.isPending, showSelect: true, selectedKeys: selected, onSelectionChange: setSelected, emptyMessage: rows.length === 0 ? "Click Execute to load ZNFA Rating records from SAP." : "No records.", columns: buildDynamicColumns(rows), headerExtras: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: actionButtons.map(({
        label,
        action,
        variant
      }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant, disabled: selected.size === 0 || createMutation.isPending, onClick: () => handleAction(action), children: [
        createMutation.isPending && createMutation.variables?.action === action ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : null,
        label
      ] }, action)) }) }),
      output && isEditable && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "success", onClick: handleSave, disabled: saveMutation.isPending, children: [
        saveMutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : null,
        "Save"
      ] }) }),
      output && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { ref: outputRef, className: "p-4 space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
          " ",
          outputTitle
        ] }),
        lastAction === "ATTACHMENTS" ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { className: "bg-muted/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Created By" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Created On" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: Array.isArray(output.ATTACHMENTS) && output.ATTACHMENTS.length > 0 ? output.ATTACHMENTS.map((att, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: toStr(att.NAME) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: toStr(att.CREATED_BY) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: toStr(att.CREATED_ON) })
          ] }, idx)) : /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 3, className: "text-center text-xs text-muted-foreground py-4", children: "No attachments." }) }) })
        ] }) }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "PR Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: header.PR_NUMBER, onChange: (e) => setHeader((p) => ({
                ...p,
                PR_NUMBER: e.target.value
              })), readOnly: !isEditable, className: `h-9 text-sm ${isEditable ? "" : "bg-muted/40"}` })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "PR Date" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: header.PR_DATE, onChange: (e) => setHeader((p) => ({
                ...p,
                PR_DATE: e.target.value
              })), readOnly: !isEditable, className: `h-9 text-sm ${isEditable ? "" : "bg-muted/40"}` })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "TER SUB ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: header.TER_SUB_ID, onChange: (e) => setHeader((p) => ({
                ...p,
                TER_SUB_ID: e.target.value
              })), readOnly: !isEditable, className: `h-9 text-sm ${isEditable ? "" : "bg-muted/40"}` })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide", children: "Items" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { className: "bg-muted/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Sr. No" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Material" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Description" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Tender Spec" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "UoM" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Vendor Name" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Remarks" })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: Array.isArray(output.ITEMS) && output.ITEMS.length > 0 ? output.ITEMS.map((item, idx) => {
                const it = items[idx] ?? {
                  SR_NO: toStr(item.SR_NO),
                  MATERIAL: toStr(item.MATERIAL),
                  DESCRIPTION: toStr(item.DESCRIPTION),
                  TENDER_SPEC: toStr(item.TENDER_SPEC),
                  UOM: toStr(item.UOM),
                  VENDOR_NAME: toStr(item.VENDOR_NAME),
                  REMARKS: toStr(item.REMARKS)
                };
                const setField = (k, val) => setItems((prev) => ({
                  ...prev,
                  [idx]: {
                    ...it,
                    ...prev[idx],
                    [k]: val
                  }
                }));
                const renderCell = (k, editable, placeholder) => editable ? /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: it[k], onChange: (e) => setField(k, e.target.value), className: "h-8 text-xs", placeholder }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: it[k] || "—" });
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderCell("SR_NO", isEditable) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderCell("MATERIAL", isEditable) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderCell("DESCRIPTION", isEditable) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderCell("TENDER_SPEC", isEditable) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderCell("UOM", isEditable) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderCell("VENDOR_NAME", isEditable) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderCell("REMARKS", isEditable, "Enter remarks") })
                ] }, idx);
              }) : /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 7, className: "text-center text-xs text-muted-foreground py-4", children: "No items." }) }) })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide", children: "Ratings" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { className: "bg-muted/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Vendor" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-xs", children: "Rate" })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: Array.isArray(output.RATINGS) && output.RATINGS.length > 0 ? output.RATINGS.map((rating, idx) => {
                const rt = ratings[idx] ?? {
                  VENDOR: toStr(rating.VENDOR),
                  RATE: toStr(rating.RATE)
                };
                const setField = (k, val) => setRatings((prev) => ({
                  ...prev,
                  [idx]: {
                    ...rt,
                    ...prev[idx],
                    [k]: val
                  }
                }));
                const renderCell = (k) => isEditable ? /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: rt[k], onChange: (e) => setField(k, e.target.value), className: "h-8 text-xs" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: rt[k] || "—" });
                const renderRateCell = () => {
                  if (!isEditable) return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: rt.RATE || "—" });
                  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: rt.RATE || void 0, onValueChange: (v) => setField("RATE", v), children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Select rate" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ratingOptions.map((opt) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: opt, className: "text-xs", children: opt }, opt)) })
                  ] });
                };
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderCell("VENDOR") }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-xs", children: renderRateCell() })
                ] }, idx);
              }) : /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 2, className: "text-center text-xs text-muted-foreground py-4", children: "No ratings." }) }) })
            ] }) })
          ] })
        ] })
      ] })
    ] }),
    confirmDialog
  ] });
}
export {
  GateProcessPage as component
};
