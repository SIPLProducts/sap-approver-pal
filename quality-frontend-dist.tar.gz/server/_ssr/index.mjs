import process from "node:process";
let lastCapturedError;
const TTL_MS = 5e3;
function record(error) {
  lastCapturedError = { error, at: Date.now() };
}
if (typeof globalThis.addEventListener === "function") {
  globalThis.addEventListener("error", (event) => record(event.error ?? event));
  globalThis.addEventListener(
    "unhandledrejection",
    (event) => record(event.reason)
  );
}
function consumeLastCapturedError() {
  if (!lastCapturedError) return void 0;
  if (Date.now() - lastCapturedError.at > TTL_MS) {
    lastCapturedError = void 0;
    return void 0;
  }
  const { error } = lastCapturedError;
  lastCapturedError = void 0;
  return error;
}
function renderErrorPage() {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>This page didn't load</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      body { font: 15px/1.5 system-ui, -apple-system, sans-serif; background: #fafafa; color: #111; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 1.5rem; }
      .card { max-width: 28rem; width: 100%; text-align: center; padding: 2rem; }
      h1 { font-size: 1.25rem; margin: 0 0 0.5rem; }
      p { color: #4b5563; margin: 0 0 1.5rem; }
      .actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
      a, button { padding: 0.5rem 1rem; border-radius: 0.375rem; font: inherit; cursor: pointer; text-decoration: none; border: 1px solid transparent; }
      .primary { background: #111; color: #fff; }
      .secondary { background: #fff; color: #111; border-color: #d1d5db; }
    </style>
  </head>
  <body>
    <div class="card">
      <h1>This page didn't load</h1>
      <p>Something went wrong on our end. You can try refreshing or head back home.</p>
      <div class="actions">
        <button class="primary" onclick="location.reload()">Try again</button>
        <a class="secondary" href="/">Go home</a>
      </div>
    </div>
  </body>
</html>`;
}
let cached;
async function loadShell() {
  try {
    const [fs, path, url] = await Promise.all([
      import("node:fs/promises"),
      import("node:path"),
      import("node:url")
    ]);
    const here = path.dirname(url.fileURLToPath(import.meta.url));
    const candidates = [
      path.join(here, "ssr-fallback.html"),
      path.join(here, "server", "ssr-fallback.html"),
      path.join(process.cwd(), "server", "ssr-fallback.html"),
      path.join(process.cwd(), "ssr-fallback.html")
    ];
    for (const candidate of candidates) {
      try {
        const html = await fs.readFile(candidate, "utf8");
        if (html.trim()) return html;
      } catch {
      }
    }
  } catch {
  }
  return null;
}
async function getSsrFallbackShell() {
  if (cached === void 0) cached = await loadShell();
  return cached;
}
function wantsHtmlDocument(request) {
  if (request.method !== "GET" && request.method !== "HEAD") return false;
  const accept = request.headers.get("accept") ?? "";
  if (!accept.includes("text/html")) return false;
  const path = new URL(request.url).pathname;
  return !path.startsWith("/api/") && !path.startsWith("/_serverFn/");
}
let serverEntryPromise;
async function getServerEntry() {
  if (!serverEntryPromise) {
    serverEntryPromise = import("./server-6SfJ9jtE.mjs").then((n) => n.s).then(
      (m) => m.default ?? m
    );
  }
  return serverEntryPromise;
}
function logSsrError(error, where) {
  const err = error instanceof Error ? error : void 0;
  const name = err?.name ?? typeof error;
  const message = err?.message ?? String(error);
  console.error(`[ssr] ${where}: ${name}: ${message}`);
  if (err?.stack) console.error(err.stack);
  if (err?.cause) console.error(`[ssr] cause: ${String(err.cause?.message ?? err.cause)}`);
}
async function fallbackResponse(request) {
  if (wantsHtmlDocument(request)) {
    const shell = await getSsrFallbackShell();
    if (shell) {
      console.error("[ssr] serving the client-boot shell instead (the page renders in the browser)");
      return new Response(shell, {
        status: 200,
        headers: {
          "content-type": "text/html; charset=utf-8",
          "cache-control": "no-store",
          "x-ssr-fallback": "client-boot"
        }
      });
    }
    console.error("[ssr] no server/ssr-fallback.html in this bundle — showing the static error page");
  }
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" }
  });
}
function isCatastrophicSsrErrorBody(body, responseStatus) {
  let payload;
  try {
    payload = JSON.parse(body);
  } catch {
    return false;
  }
  if (!payload || Array.isArray(payload) || typeof payload !== "object") {
    return false;
  }
  const fields = payload;
  const expectedKeys = /* @__PURE__ */ new Set(["message", "status", "unhandled"]);
  if (!Object.keys(fields).every((key) => expectedKeys.has(key))) {
    return false;
  }
  return fields.unhandled === true && fields.message === "HTTPError" && (fields.status === void 0 || fields.status === responseStatus);
}
async function normalizeCatastrophicSsrResponse(request, response) {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;
  const body = await response.clone().text();
  if (!isCatastrophicSsrErrorBody(body, response.status)) {
    return response;
  }
  logSsrError(
    consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`),
    `render ${new URL(request.url).pathname}`
  );
  return fallbackResponse(request);
}
const server = {
  async fetch(request, env, ctx) {
    try {
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      return await normalizeCatastrophicSsrResponse(request, response);
    } catch (error) {
      logSsrError(error, `fetch ${new URL(request.url).pathname}`);
      return fallbackResponse(request);
    }
  }
};
export {
  server as default,
  logSsrError,
  renderErrorPage as r
};
