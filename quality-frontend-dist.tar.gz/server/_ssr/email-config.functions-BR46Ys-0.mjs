import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { assertScreen } from "./assert-screen-DK8QvcMQ.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { D as enumType, a as objectType, z as stringType, C as arrayType, G as literalType, B as numberType, y as booleanType } from "../_libs/zod.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./screen-keys-mn2QOK0m.mjs";
const encryptionSchema = enumType(["none", "ssl", "tls", "starttls"]);
const configSchema = objectType({
  enabled: booleanType(),
  host: stringType().trim().max(200).nullable().optional().default(null),
  port: numberType().int().min(1).max(65535).nullable().optional().default(null),
  encryption: encryptionSchema.default("tls"),
  username: stringType().trim().max(200).nullable().optional().default(null),
  from_email: stringType().trim().email().max(200).nullable().or(literalType("")).optional(),
  from_name: stringType().trim().max(200).nullable().optional().default(null),
  cc_recipients: arrayType(stringType().trim().email().max(200)).max(50).default([]),
  app_password: stringType().max(500).optional()
  // empty/undefined = keep existing
});
const SCREEN_KEY = "settings.email_config";
const getNoReplyEmailConfig_createServerFn_handler = createServerRpc({
  id: "3bb6f4f62712d6fe529a483b782014c5e5a9ee261c9f21644b66f7ea45cd0728",
  name: "getNoReplyEmailConfig",
  filename: "src/lib/admin/email-config.functions.ts"
}, (opts) => getNoReplyEmailConfig.__executeServer(opts));
const getNoReplyEmailConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getNoReplyEmailConfig_createServerFn_handler, async ({
  context
}) => {
  await assertScreen(context.userId, SCREEN_KEY);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const [{
    data: cfg
  }, {
    data: sec
  }] = await Promise.all([supabaseAdmin.from("email_no_reply_config").select("*").eq("id", "default").maybeSingle(), supabaseAdmin.from("email_no_reply_secrets").select("app_password").eq("id", "default").maybeSingle()]);
  return {
    enabled: cfg?.enabled ?? true,
    host: cfg?.host ?? null,
    port: cfg?.port ?? null,
    encryption: cfg?.encryption ?? "tls",
    username: cfg?.username ?? null,
    from_email: cfg?.from_email ?? null,
    from_name: cfg?.from_name ?? null,
    cc_recipients: cfg?.cc_recipients ?? [],
    hasPassword: Boolean(sec?.app_password && String(sec.app_password).length > 0),
    updated_at: cfg?.updated_at ?? null
  };
});
const saveNoReplyEmailConfig_createServerFn_handler = createServerRpc({
  id: "24c9b8c545ac80eace6b3e6fc3038857c795f0f1c7ed5f5ced2c5d9a8e02811e",
  name: "saveNoReplyEmailConfig",
  filename: "src/lib/admin/email-config.functions.ts"
}, (opts) => saveNoReplyEmailConfig.__executeServer(opts));
const saveNoReplyEmailConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => configSchema.parse(d)).handler(saveNoReplyEmailConfig_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertScreen(context.userId, SCREEN_KEY);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const fromEmail = data.from_email ? data.from_email : null;
  const {
    error: cfgErr
  } = await supabaseAdmin.from("email_no_reply_config").upsert({
    id: "default",
    enabled: data.enabled,
    host: data.host ?? null,
    port: data.port ?? null,
    encryption: data.encryption,
    username: data.username ?? null,
    from_email: fromEmail,
    from_name: data.from_name ?? null,
    cc_recipients: data.cc_recipients ?? [],
    updated_by: context.userId,
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  });
  if (cfgErr) throw new Error(cfgErr.message);
  if (typeof data.app_password === "string" && data.app_password.length > 0) {
    const {
      error: secErr
    } = await supabaseAdmin.from("email_no_reply_secrets").upsert({
      id: "default",
      app_password: data.app_password,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    if (secErr) throw new Error(secErr.message);
  }
  return {
    ok: true
  };
});
const sendNoReplyTestEmail_createServerFn_handler = createServerRpc({
  id: "27cdea68d5651b3c710b32a7cce10b3e2072834255ac838bce2a9dc9826bbecb",
  name: "sendNoReplyTestEmail",
  filename: "src/lib/admin/email-config.functions.ts"
}, (opts) => sendNoReplyTestEmail.__executeServer(opts));
const sendNoReplyTestEmail = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  to: stringType().trim().email().max(200)
}).parse(d)).handler(sendNoReplyTestEmail_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertScreen(context.userId, SCREEN_KEY);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const [{
    data: cfg
  }, {
    data: sec
  }] = await Promise.all([supabaseAdmin.from("email_no_reply_config").select("*").eq("id", "default").maybeSingle(), supabaseAdmin.from("email_no_reply_secrets").select("app_password").eq("id", "default").maybeSingle()]);
  if (!cfg?.enabled) throw new Error("No-Reply sending is disabled");
  if (!cfg?.host || !cfg?.port || !cfg?.from_email) {
    throw new Error("SMTP host, port, and From email are required");
  }
  if (!sec?.app_password) throw new Error("SMTP app password is not set");
  const nodemailer = (await import("../_libs/nodemailer.mjs").then(function(n) {
    return n.n;
  })).default;
  const enc = cfg.encryption ?? "tls";
  const transport = nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    secure: enc === "ssl",
    requireTLS: enc === "starttls" || enc === "tls",
    auth: cfg.username ? {
      user: cfg.username,
      pass: sec.app_password
    } : void 0
  });
  const info = await transport.sendMail({
    from: cfg.from_name ? `${cfg.from_name} <${cfg.from_email}>` : cfg.from_email,
    to: data.to,
    cc: cfg.cc_recipients ?? [],
    subject: "Test email from Re Sustainability Approvals",
    text: "This is a test message confirming your No-Reply SMTP configuration works."
  });
  return {
    ok: true,
    messageId: info.messageId
  };
});
export {
  getNoReplyEmailConfig_createServerFn_handler,
  saveNoReplyEmailConfig_createServerFn_handler,
  sendNoReplyTestEmail_createServerFn_handler
};
