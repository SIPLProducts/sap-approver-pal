import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { C as CloudscapeApprovalTable } from "./cloudscape-approval-table-B3gA6T4g.mjs";
import { g as getMySapUserId } from "./price-approval.functions-whaYOtr3.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";

import "../_libs/seroval.mjs";
import { aa as Funnel, a3 as LoaderCircle, ab as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as objectType, y as booleanType, z as stringType, C as arrayType, A as unionType, B as numberType } from "../_libs/zod.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "./empty-state-DA5qeMhN.mjs";
import "./skeleton-rows-C2wJYLiJ.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./format-D-HjDoz6.mjs";
import "./table-BhFPQiYt.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
const fetchMaterialReservation = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  document_number: stringType().trim().max(40).optional().default(""),
  hod_approve: booleanType().optional().default(false)
}).parse(d)).handler(createSsrRpc("01d2f77dc8711dbe6b11028bdfdf11124329d9b4ce59e347b0fbc83246dd038d"));
const saveItemSchema = objectType({
  SNO: unionType([stringType(), numberType()]).optional(),
  GOODS_RECEPIENT: stringType().optional().default(""),
  MATERIAL: stringType().optional().default(""),
  MATERIAL_DESCRIPTION: stringType().optional().default(""),
  UOM: stringType().optional().default(""),
  ORDER_NUMBER: stringType().optional().default(""),
  COST_CENTER: stringType().optional().default(""),
  REQUESTED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  APPROVED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  ISSUED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  STORAGE_LOCATION: stringType().optional().default(""),
  TOTAL_STOCK: unionType([stringType(), numberType()]).optional().default(0),
  COST_CENT_DESC: stringType().optional().default(""),
  HOD_APRROVAL: stringType().optional().default(""),
  HOD_REJECTION: stringType().optional().default(""),
  REMARKS: stringType().optional().default("")
}).passthrough();
const saveMaterialReservation = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  header: objectType({
    DOCUMENT_NUMBER: stringType().optional().default(""),
    HOD_APPROVE: stringType().optional().default(""),
    DOCUMENT_DATE: stringType().optional().default(""),
    MOVEMENT_TYPE: stringType().optional().default(""),
    PLANT: stringType().optional().default(""),
    MATERIAL_TYPE: stringType().optional().default("")
  }).passthrough(),
  data: arrayType(saveItemSchema).min(1, "At least one row is required")
}).parse(d)).handler(createSsrRpc("b8722dff6c5541251aa1deb4f7802a20a268cb1f7141e0b4382a7dc299e56ecb"));
function rowKey(r, i) {
  return [r.DOCUMENT_NUMBER, r.SNO, r.MATERIAL, i].map((x) => x ?? "").join("|");
}
function toStr(v) {
  if (v == null) return "";
  return String(v);
}
const HEADER_FIELDS = [{
  key: "DOCUMENT_NUMBER",
  label: "Document Number"
}, {
  key: "DOCUMENT_DATE",
  label: "Document Date"
}, {
  key: "MOVEMENT_TYPE",
  label: "Movement Type"
}, {
  key: "PLANT",
  label: "Plant"
}, {
  key: "MATERIAL_TYPE",
  label: "Material Type"
}];
const DATA_COLUMNS = [{
  key: "SNO",
  header: "S.No",
  minWidth: 70
}, {
  key: "GOODS_RECEPIENT",
  header: "Goods Recipient",
  minWidth: 140
}, {
  key: "MATERIAL",
  header: "Material",
  minWidth: 120
}, {
  key: "MATERIAL_DESCRIPTION",
  header: "Material Description",
  minWidth: 220
}, {
  key: "UOM",
  header: "UoM",
  minWidth: 80
}, {
  key: "ORDER_NUMBER",
  header: "Order Number",
  minWidth: 120
}, {
  key: "COST_CENTER",
  header: "Cost Center",
  minWidth: 130
}, {
  key: "REQUESTED_QUANTITY",
  header: "Requested Qty",
  align: "right",
  minWidth: 130
}, {
  key: "APPROVED_QUANTITY",
  header: "Approved Qty",
  align: "right",
  minWidth: 130
}, {
  key: "ISSUED_QUANTITY",
  header: "Issued Qty",
  align: "right",
  minWidth: 120
}, {
  key: "STORAGE_LOCATION",
  header: "Storage Location",
  minWidth: 140
}, {
  key: "TOTAL_STOCK",
  header: "Total Stock",
  align: "right",
  minWidth: 120
}, {
  key: "COST_CENT_DESC",
  header: "Cost Center Desc",
  minWidth: 180
}];
function MaterialReservationPage() {
  const fetchFn = useServerFn(fetchMaterialReservation);
  const userIdFn = useServerFn(getMySapUserId);
  const {
    data: userIdData
  } = useQuery({
    queryKey: ["mm-material-reservation", "sap-user-id"],
    queryFn: () => userIdFn()
  });
  const [userId, setUserId] = reactExports.useState("");
  const [docNumber, setDocNumber] = reactExports.useState("");
  const [hodApprove, setHodApprove] = reactExports.useState(false);
  const [header, setHeader] = reactExports.useState(null);
  const [rows, setRows] = reactExports.useState([]);
  const [rowStates, setRowStates] = reactExports.useState(/* @__PURE__ */ new Map());
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const hasResults = header !== null || rows.length > 0;
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  reactExports.useEffect(() => {
    if (userIdData?.sap_user_id && !userId) setUserId(userIdData.sap_user_id);
  }, [userIdData?.sap_user_id]);
  const mutation = useMutation({
    mutationFn: async (vars) => {
      const v = await fetchFn({
        data: vars
      });
      const data = Array.isArray(v?.data) ? v.data : [];
      return {
        header: v?.header ?? null,
        data,
        count: data.length,
        error: v?.error ?? null
      };
    },
    onSuccess: (res) => {
      setHeader(res.header);
      setRows(res.data);
      const seeded = /* @__PURE__ */ new Map();
      res.data.forEach((r, i) => {
        seeded.set(rowKey(r, i), {
          hodApproval: String(r.HOD_APRROVAL ?? r.HOD_APPROVAL ?? "").toUpperCase() === "X",
          hodRejection: String(r.HOD_REJECTION ?? "").toUpperCase() === "X",
          remarks: toStr(r.REMARKS),
          approvedQty: toStr(r.APPROVED_QUANTITY ?? "")
        });
      });
      setRowStates(seeded);
      if (res.error) toast.error(res.error);
      else toast.success(`Loaded ${res.count} record${res.count === 1 ? "" : "s"} from SAP`);
    },
    onError: (e) => toast.error(e.message ?? "Failed to fetch from SAP")
  });
  const saveFn = useServerFn(saveMaterialReservation);
  const saveMutation = useMutation({
    mutationFn: async (vars) => {
      const v = await saveFn({
        data: vars
      });
      return v;
    },
    onSuccess: (res) => {
      if (res.ok) toast.success(res.message || "Saved successfully");
      else toast.error(res.message || "Save failed");
      if (res.ok) {
        mutation.mutate({
          user_id: userId.trim(),
          document_number: docNumber.trim(),
          hod_approve: hodApprove
        });
        setSelected(/* @__PURE__ */ new Set());
      }
    },
    onError: (e) => toast.error(e.message ?? "Failed to save")
  });
  function onSave() {
    if (!userId.trim()) {
      toast.error("User ID is required");
      return;
    }
    if (selected.size === 0) {
      toast.error("Select at least one row");
      return;
    }
    void doSave();
  }
  async function doSave() {
    const items = rows.map((r, i) => ({
      r,
      i,
      k: rowKey(r, i)
    })).filter(({
      k
    }) => selected.has(k)).map(({
      r,
      i,
      k
    }) => {
      const st = rowStates.get(k) ?? {
        hodApproval: false,
        hodRejection: false,
        remarks: "",
        approvedQty: ""
      };
      return {
        SNO: String(r.SNO ?? i + 1),
        GOODS_RECEPIENT: toStr(r.GOODS_RECEPIENT),
        MATERIAL: toStr(r.MATERIAL),
        MATERIAL_DESCRIPTION: toStr(r.MATERIAL_DESCRIPTION),
        UOM: toStr(r.UOM),
        ORDER_NUMBER: toStr(r.ORDER_NUMBER),
        COST_CENTER: toStr(r.COST_CENTER),
        REQUESTED_QUANTITY: Number(r.REQUESTED_QUANTITY ?? 0) || 0,
        APPROVED_QUANTITY: Number(st.approvedQty !== "" ? st.approvedQty : r.APPROVED_QUANTITY ?? 0) || 0,
        ISSUED_QUANTITY: Number(r.ISSUED_QUANTITY ?? 0) || 0,
        STORAGE_LOCATION: toStr(r.STORAGE_LOCATION),
        TOTAL_STOCK: Number(r.TOTAL_STOCK ?? 0) || 0,
        COST_CENT_DESC: toStr(r.COST_CENT_DESC),
        HOD_APRROVAL: st.hodApproval ? "X" : "",
        HOD_REJECTION: st.hodRejection ? "X" : "",
        REMARKS: st.remarks ?? ""
      };
    });
    const payload = {
      user_id: userId.trim(),
      header: {
        DOCUMENT_NUMBER: toStr(header?.DOCUMENT_NUMBER),
        HOD_APPROVE: hodApprove ? "X" : "",
        DOCUMENT_DATE: toStr(header?.DOCUMENT_DATE),
        MOVEMENT_TYPE: toStr(header?.MOVEMENT_TYPE),
        PLANT: toStr(header?.PLANT),
        MATERIAL_TYPE: toStr(header?.MATERIAL_TYPE)
      },
      data: items
    };
    if (!await confirm({
      title: `Save ${items.length} selected item(s)?`,
      description: "This posts the update to SAP and cannot be undone.",
      confirmLabel: "Save",
      destructive: false
    })) return;
    saveMutation.mutate(payload);
  }
  function execute() {
    if (!userId.trim()) {
      toast.error("User ID is required");
      return;
    }
    mutation.mutate({
      user_id: userId.trim(),
      document_number: docNumber.trim(),
      hod_approve: hodApprove
    });
  }
  function reset() {
    setUserId(userIdData?.sap_user_id ?? "");
    setDocNumber("");
    setHodApprove(false);
    setHeader(null);
    setRows([]);
    setRowStates(/* @__PURE__ */ new Map());
    setSelected(/* @__PURE__ */ new Set());
  }
  function updateRow(k, patch) {
    setRowStates((prev) => {
      const next = new Map(prev);
      const cur = next.get(k) ?? {
        hodApproval: false,
        hodRejection: false,
        remarks: "",
        approvedQty: ""
      };
      next.set(k, {
        ...cur,
        ...patch
      });
      return next;
    });
  }
  const columns = reactExports.useMemo(() => {
    const base = DATA_COLUMNS.map((c) => ({
      id: c.key,
      header: c.header,
      minWidth: c.minWidth,
      align: c.align,
      cell: (item) => {
        if (c.key === "APPROVED_QUANTITY") {
          const idx = rows.indexOf(item);
          const k = rowKey(item, idx);
          const st = rowStates.get(k);
          return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
            width: 110
          }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: st?.approvedQty ?? "", onChange: (e) => updateRow(k, {
            approvedQty: e.target.value
          }), className: "h-8 text-sm text-right" }) });
        }
        const v = item[c.key];
        if (v == null || v === "") return "—";
        return String(v);
      }
    }));
    base.push({
      id: "HOD_APPROVAL",
      header: "HOD Approval",
      minWidth: 110,
      cell: (item) => {
        const idx = rows.indexOf(item);
        const k = rowKey(item, idx);
        const st = rowStates.get(k);
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: st?.hodApproval ?? false, onCheckedChange: (v) => updateRow(k, {
          hodApproval: v === true
        }) });
      }
    });
    base.push({
      id: "HOD_REJECTION",
      header: "HOD Rejection",
      minWidth: 110,
      cell: (item) => {
        const idx = rows.indexOf(item);
        const k = rowKey(item, idx);
        const st = rowStates.get(k);
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: st?.hodRejection ?? false, onCheckedChange: (v) => updateRow(k, {
          hodRejection: v === true
        }) });
      }
    });
    base.push({
      id: "REMARKS",
      header: "Remarks",
      minWidth: 200,
      cell: (item) => {
        const idx = rows.indexOf(item);
        const k = rowKey(item, idx);
        const st = rowStates.get(k);
        return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
          width: 200
        }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: st?.remarks ?? "", onChange: (e) => updateRow(k, {
          remarks: e.target.value
        }), placeholder: "Enter remarks", className: "h-8 text-sm" }) });
      }
    });
    return base;
  }, [rowStates, rows]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "MM Approvals", title: "Material Reservation", subtitle: "Review and approve material reservation requests." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-[240px_200px_1fr_auto] items-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Document Number" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: docNumber, onChange: (e) => setDocNumber(e.target.value), placeholder: "Document number", className: "h-9 text-sm" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "HOD Approve" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-9 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: hodApprove, onCheckedChange: (v) => setHodApprove(v === true) }),
            "HOD Approve"
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: !userId.trim() || mutation.isPending, children: [
            mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Execute"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Reset" })
        ] })
      ] })
    ] }),
    hasResults && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
          " HEADER"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 md:grid-cols-2 lg:grid-cols-5", children: HEADER_FIELDS.map((f) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: f.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: toStr(header?.[f.key]), readOnly: true, className: "h-9 text-sm bg-muted/40" })
        ] }, f.key)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", disabled: selected.size === 0 || saveMutation.isPending, onClick: onSave, children: [
        saveMutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : null,
        "Save"
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CloudscapeApprovalTable, { title: "Material Reservation Items", countLabel: `(${rows.length})`, rows, rowKey, loading: mutation.isPending, emptyMessage: "No line items.", showSelect: true, selectedKeys: selected, onSelectionChange: setSelected, columns })
    ] }),
    confirmDialog
  ] });
}
export {
  MaterialReservationPage as component
};
