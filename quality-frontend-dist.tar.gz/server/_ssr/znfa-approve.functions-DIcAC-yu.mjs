import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, y as booleanType, z as stringType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const APPROVE_CONFIG_NAME = "ZNFA_APPROVE_API";
const REJECT_CONFIG_NAME = "ZNFA_REJECT_API";
const CLARIFY_CONFIG_NAME = "ZNFA_Clarification_API";
const DIS_CLARIFY_CONFIG_NAME = "ZNFA_DISPLAY_CLARIFY_API";
function fail(error, sapMessage = null) {
  return {
    ok: false,
    sapMessage,
    number: null,
    error,
    lines: []
  };
}
function extractSapMsg(text) {
  if (!text || !text.trim()) return null;
  try {
    const parsed = JSON.parse(text);
    const payload = Array.isArray(parsed) ? parsed[0] : parsed;
    const msg = payload?.MSG ?? payload?.data?.MSG ?? payload?.message ?? payload?.error;
    return typeof msg === "string" && msg.trim() ? msg.trim() : null;
  } catch {
    const match = text.match(/"MSG"\s*:\s*"([^"]*)"/i);
    return match?.[1] ? match[1] : null;
  }
}
const approveZnfa_createServerFn_handler = createServerRpc({
  id: "5618c2277fc49fa5461e378768e88786ab968ac4962130d80c22e0ff956350e7",
  name: "approveZnfa",
  filename: "src/lib/mm/znfa-approve.functions.ts"
}, (opts) => approveZnfa.__executeServer(opts));
const approveZnfa = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  znfaNum: stringType().trim().min(1, "NFA number is required").max(60),
  user: stringType().trim().min(1, "SAP user id is required").max(30),
  relCode: stringType().trim().min(1, "Release Code is required").max(10),
  reject: booleanType().default(false),
  reason: stringType().trim().max(500).default(""),
  clarify: booleanType().default(false),
  clarifyText: stringType().max(5e3).default(""),
  disClarify: booleanType().default(false)
}).parse(d)).handler(approveZnfa_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const configName = data.disClarify ? DIS_CLARIFY_CONFIG_NAME : data.clarify ? CLARIFY_CONFIG_NAME : data.reject ? REJECT_CONFIG_NAME : APPROVE_CONFIG_NAME;
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", configName).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${configName}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${configName}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const inputs = {
    ZNFA_NUM: data.znfaNum.trim(),
    USER: data.user.trim(),
    REL_CODE: data.relCode.trim(),
    NFA_REL: data.reject || data.clarify || data.disClarify ? "" : "X",
    REJECT: data.reject ? "X" : "",
    REJ_DEL_REASON: data.reject ? data.reason : "",
    DELETE: ""
  };
  if (data.disClarify) {
    inputs.CLARIFY = "";
    inputs.DIS_CLARIFY = "X";
    inputs.TEXT_CLARIFY = [];
  } else if (data.clarify) {
    inputs.CLARIFY = "X";
    inputs.DIS_CLARIFY = "";
    inputs.TEXT_CLARIFY = data.clarifyText.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0).map((l) => ({
      LINE: l
    }));
  }
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs,
      raw: true
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    method = cfg.http_method ?? "POST";
    bodyOut = JSON.stringify(inputs);
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const logTag = data.disClarify ? "znfa-dis-clarify" : data.clarify ? "znfa-clarify" : data.reject ? "znfa-reject" : "znfa-approve-action";
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: Date.now() - t0,
      message: `${logTag} network: ${errMsg}`
    });
    return fail(`Could not reach SAP. ${errMsg}.`);
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  const httpMsg = `${res.status} ${res.statusText}`;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `${logTag}: ${httpMsg} ${text.slice(0, 500)}`
    });
    return fail(null, extractSapMsg(text) ?? "SAP returned an error");
  }
  let json;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    return fail(null, extractSapMsg(text) ?? "Invalid response from SAP");
  }
  const sapJsonRaw = proxied ? json?.data ?? json : json;
  const sapJson = Array.isArray(sapJsonRaw) ? sapJsonRaw[0] : sapJsonRaw;
  const lines = Array.isArray(sapJsonRaw) ? sapJsonRaw.filter((r) => r && typeof r === "object" && "LINE" in r).map((r) => String(r.LINE ?? "")) : [];
  const status = String(sapJson?.STATUS ?? "").toUpperCase();
  const msg = typeof sapJson?.MSG === "string" ? sapJson.MSG.trim() : "";
  const number = sapJson?.NUMBER != null ? String(sapJson.NUMBER) : null;
  if (status === "FALSE") {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `${logTag}: SAP said "${msg || status}"`
    });
    return fail(null, msg || "SAP rejected the request.");
  }
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: lines.length || 1,
    message: `${logTag}: ${httpMsg}`
  });
  return {
    ok: true,
    sapMessage: msg || null,
    number,
    error: null,
    lines
  };
});
export {
  approveZnfa_createServerFn_handler
};
