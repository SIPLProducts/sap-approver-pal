import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, z as stringType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "ZNFA_DISPLAY_GET_API";
function empty(error, sapMessage = null) {
  return {
    znfa: null,
    rfqs: [],
    prDet: [],
    rfqDet: [],
    relMatx: [],
    recommend: [],
    attach: [],
    nfaTexts: [],
    error,
    sapMessage,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function extractSapMsg(text) {
  if (!text || !text.trim()) return null;
  try {
    const parsed = JSON.parse(text);
    const msg = parsed?.MSG ?? parsed?.data?.MSG ?? parsed?.message ?? parsed?.error;
    return typeof msg === "string" && msg.trim() ? msg.trim() : null;
  } catch {
    const match = text.match(/"MSG"\s*:\s*"([^"]*)"/i);
    return match?.[1] ? match[1] : null;
  }
}
function arr(v) {
  return Array.isArray(v) ? v.filter((r) => r && typeof r === "object") : [];
}
const fetchZnfaDisplay_createServerFn_handler = createServerRpc({
  id: "f0a6262092bad707ee5aed03cda207d75025e3652f20b17dcdb7736ff13edb70",
  name: "fetchZnfaDisplay",
  filename: "src/lib/mm/znfa-display.functions.ts"
}, (opts) => fetchZnfaDisplay.__executeServer(opts));
const fetchZnfaDisplay = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  znfaNum: stringType().trim().min(1, "Main NFA Number is required").max(60)
}).parse(d)).handler(fetchZnfaDisplay_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const inputs = {
    TYPE_NFA: "",
    ZRFQS: [{
      RFQ: ""
    }],
    GET: "",
    REL_CODE: "",
    ZNFA_NUM: data.znfaNum.trim(),
    PRINT: ""
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs,
      raw: true
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    method = cfg.http_method ?? "POST";
    bodyOut = JSON.stringify(inputs);
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: Date.now() - t0,
      message: `znfa-display network: ${errMsg}`
    });
    return empty(`Could not reach SAP. ${errMsg}.`);
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `znfa-display: ${message} ${text.slice(0, 500)}`
    });
    return empty(null, extractSapMsg(text) ?? "SAP returned an error");
  }
  let json;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    return empty(null, extractSapMsg(text) ?? "Invalid response from SAP");
  }
  const sapJson = proxied ? json?.data ?? json : json;
  const payload = Array.isArray(sapJson) ? sapJson[0] : sapJson;
  const status = String(payload?.STATUS ?? payload?.status ?? "").toUpperCase();
  const rawMsg = payload?.MSG ?? payload?.msg;
  const msg = typeof rawMsg === "string" ? rawMsg.trim() : "";
  const znfa = payload?.ZNFA && typeof payload.ZNFA === "object" ? payload.ZNFA : null;
  if (!znfa) {
    if (status === "FALSE") {
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: "error",
        latency_ms,
        message: `znfa-display: SAP said "${msg || status}"`
      });
      return empty(null, msg || null);
    }
    if (msg) {
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: "error",
        latency_ms,
        message: `znfa-display: SAP said "${msg}"`
      });
      return empty(null, msg);
    }
    return empty(null, extractSapMsg(text) ?? "Unexpected response from SAP");
  }
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: arr(payload?.PR_DET).length,
    message: `znfa-display: ${message}`
  });
  return {
    znfa,
    rfqs: arr(payload?.ZRFQS),
    prDet: arr(payload?.PR_DET),
    rfqDet: arr(payload?.RFQ_DET),
    relMatx: arr(payload?.REL_MATX),
    recommend: arr(payload?.RECOMMEND),
    attach: arr(payload?.ATTACH),
    nfaTexts: arr(payload?.NFA_TEXTS),
    error: null,
    sapMessage: null,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString()
  };
});
export {
  fetchZnfaDisplay_createServerFn_handler
};
