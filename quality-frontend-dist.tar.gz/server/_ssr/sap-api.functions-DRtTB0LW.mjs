import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, y as booleanType, z as stringType, D as enumType, B as numberType, C as arrayType, E as recordType } from "../_libs/zod.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
async function assertAdmin(userId) {
  const {
    assertAnyScreen
  } = await import("./assert-screen-DK8QvcMQ.mjs");
  await assertAnyScreen(userId, ["sap.api_settings"]);
}
const ConfigSchema = objectType({
  id: stringType().uuid().optional(),
  name: stringType().min(1).max(120),
  description: stringType().max(500).optional().nullable(),
  module: enumType(["MM", "SD", "COMMON"]).default("COMMON"),
  endpoint_url: stringType().min(1).max(500).refine((v) => /^https?:\/\//i.test(v) || v.startsWith("/"), "Endpoint must be a full http(s):// URL or a path starting with /"),
  http_method: enumType(["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"]).default("GET"),
  auth_type: enumType(["basic", "oauth", "none", "proxy"]).default("basic"),
  middleware_url: stringType().max(500).optional().nullable(),
  proxy_secret_ref: stringType().max(120).optional().nullable(),
  api_type: enumType(["sync", "fetch"]).default("fetch"),
  auto_sync_enabled: booleanType().default(false),
  schedule_cron: stringType().max(120).optional().nullable(),
  is_active: booleanType().default(true)
});
const listSapConfigs_createServerFn_handler = createServerRpc({
  id: "4a963cfb9ad4b493470da421ecbbd1d1ce6f75bfbd35e417647e7e337aac5db8",
  name: "listSapConfigs",
  filename: "src/lib/admin/sap-api.functions.ts"
}, (opts) => listSapConfigs.__executeServer(opts));
const listSapConfigs = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listSapConfigs_createServerFn_handler, async ({
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data,
    error
  } = await supabaseAdmin.from("sap_api_configs").select("*").order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return {
    configs: data ?? []
  };
});
const getSapConfig_createServerFn_handler = createServerRpc({
  id: "02c8eedddaf533f75bcc544a284380d5e7983a11c1d91facd0494ed671a74c07",
  name: "getSapConfig",
  filename: "src/lib/admin/sap-api.functions.ts"
}, (opts) => getSapConfig.__executeServer(opts));
const getSapConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  id: stringType().uuid()
}).parse(d)).handler(getSapConfig_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const [{
    data: cfg
  }, {
    data: req
  }, {
    data: res
  }, {
    data: creds
  }] = await Promise.all([supabaseAdmin.from("sap_api_configs").select("*").eq("id", data.id).maybeSingle(), supabaseAdmin.from("sap_api_request_fields").select("*").eq("config_id", data.id).order("sort_order"), supabaseAdmin.from("sap_api_response_fields").select("*").eq("config_id", data.id).order("sort_order"), supabaseAdmin.from("sap_api_credentials").select("config_id, username, extra_headers, updated_at").eq("config_id", data.id).maybeSingle()]);
  if (!cfg) throw new Error("Not found");
  return {
    config: cfg,
    requestFields: req ?? [],
    responseFields: res ?? [],
    credentials: creds ? {
      ...creds,
      password_set: true
    } : {
      config_id: data.id,
      username: null,
      extra_headers: {},
      password_set: false
    }
  };
});
const upsertSapConfig_createServerFn_handler = createServerRpc({
  id: "f1b044041e32d8e13bced15291cc18536b714141bcd7ae2c66472494e1d787cb",
  name: "upsertSapConfig",
  filename: "src/lib/admin/sap-api.functions.ts"
}, (opts) => upsertSapConfig.__executeServer(opts));
const upsertSapConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ConfigSchema.parse(d)).handler(upsertSapConfig_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  if (data.auth_type === "proxy" && (!data.middleware_url || !data.proxy_secret_ref)) {
    throw new Error("Proxy mode requires middleware_url and proxy_secret_ref (MIDDLEWARE_SHARED_SECRET).");
  }
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const payload = {
    ...data,
    created_by: context.userId
  };
  const {
    data: row,
    error
  } = data.id ? await supabaseAdmin.from("sap_api_configs").update(payload).eq("id", data.id).select().single() : await supabaseAdmin.from("sap_api_configs").insert(payload).select().single();
  if (error) throw new Error(error.message);
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: data.id ? "sap_config.update" : "sap_config.create",
    target_table: "sap_api_configs",
    target_id: row.id,
    payload: data
  });
  return {
    config: row
  };
});
const deleteSapConfig_createServerFn_handler = createServerRpc({
  id: "bc43286c9bc8ef202be0cbe6c2c78dbc9e1ff49a7c74c0c3d45d9125f06aeea8",
  name: "deleteSapConfig",
  filename: "src/lib/admin/sap-api.functions.ts"
}, (opts) => deleteSapConfig.__executeServer(opts));
const deleteSapConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  id: stringType().uuid()
}).parse(d)).handler(deleteSapConfig_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    error
  } = await supabaseAdmin.from("sap_api_configs").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "sap_config.delete",
    target_table: "sap_api_configs",
    target_id: data.id
  });
  return {
    ok: true
  };
});
const FieldRowSchema = objectType({
  field_name: stringType().min(1).max(120),
  source: enumType(["static", "column", "expr", "secret"]).default("static"),
  default_value: stringType().max(500).optional().nullable(),
  required: booleanType().default(false),
  sort_order: numberType().int().default(0)
});
const replaceRequestFields_createServerFn_handler = createServerRpc({
  id: "5f3fd7ee53cea81019769c8cfdc7b1fcff9760e35417000b46c0b38ce885b54c",
  name: "replaceRequestFields",
  filename: "src/lib/admin/sap-api.functions.ts"
}, (opts) => replaceRequestFields.__executeServer(opts));
const replaceRequestFields = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  config_id: stringType().uuid(),
  fields: arrayType(FieldRowSchema).max(200)
}).parse(d)).handler(replaceRequestFields_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  await supabaseAdmin.from("sap_api_request_fields").delete().eq("config_id", data.config_id);
  if (data.fields.length) {
    const {
      error
    } = await supabaseAdmin.from("sap_api_request_fields").insert(data.fields.map((f, i) => ({
      ...f,
      config_id: data.config_id,
      sort_order: f.sort_order ?? i
    })));
    if (error) throw new Error(error.message);
  }
  return {
    ok: true,
    count: data.fields.length
  };
});
const ResponseRowSchema = objectType({
  field_name: stringType().min(1).max(120),
  target_table: stringType().max(120).optional().nullable(),
  target_column: stringType().max(120).optional().nullable(),
  transform_expr: stringType().max(500).optional().nullable(),
  sort_order: numberType().int().default(0)
});
const replaceResponseFields_createServerFn_handler = createServerRpc({
  id: "90741a15444ee0f5a9109fff5ae772a9b7e9c2b6c6d4ea1502b2a81267508eb5",
  name: "replaceResponseFields",
  filename: "src/lib/admin/sap-api.functions.ts"
}, (opts) => replaceResponseFields.__executeServer(opts));
const replaceResponseFields = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  config_id: stringType().uuid(),
  fields: arrayType(ResponseRowSchema).max(200)
}).parse(d)).handler(replaceResponseFields_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  await supabaseAdmin.from("sap_api_response_fields").delete().eq("config_id", data.config_id);
  if (data.fields.length) {
    const {
      error
    } = await supabaseAdmin.from("sap_api_response_fields").insert(data.fields.map((f, i) => ({
      ...f,
      config_id: data.config_id,
      sort_order: f.sort_order ?? i
    })));
    if (error) throw new Error(error.message);
  }
  return {
    ok: true,
    count: data.fields.length
  };
});
const upsertCredentials_createServerFn_handler = createServerRpc({
  id: "4deca62d6cda48679a364b7cc9d2dfda967aef43bbc8911ec5608ba336f9e038",
  name: "upsertCredentials",
  filename: "src/lib/admin/sap-api.functions.ts"
}, (opts) => upsertCredentials.__executeServer(opts));
const upsertCredentials = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  config_id: stringType().uuid(),
  username: stringType().max(200).optional().nullable(),
  password: stringType().max(500).optional().nullable(),
  extra_headers: recordType(stringType(), stringType()).optional()
}).parse(d)).handler(upsertCredentials_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const update = {
    config_id: data.config_id,
    username: data.username ?? null,
    extra_headers: data.extra_headers ?? {},
    ...data.password ? {
      password_encrypted: data.password
    } : {}
  };
  const {
    error
  } = await supabaseAdmin.from("sap_api_credentials").upsert(update);
  if (error) throw new Error(error.message);
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "sap_credentials.update",
    target_table: "sap_api_credentials",
    target_id: data.config_id,
    payload: {
      username: data.username,
      password_changed: !!data.password
    }
  });
  return {
    ok: true
  };
});
const testSapConnection_createServerFn_handler = createServerRpc({
  id: "1b4d251d4de26af9621ab12d16e20a97d56bf17f97f7438beeb8bd3288a0368d",
  name: "testSapConnection",
  filename: "src/lib/admin/sap-api.functions.ts"
}, (opts) => testSapConnection.__executeServer(opts));
const testSapConnection = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  id: stringType().uuid()
}).parse(d)).handler(testSapConnection_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("id", data.id).maybeSingle();
  if (!cfg) throw new Error("Config not found");
  const {
    data: creds
  } = await supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", data.id).maybeSingle();
  const {
    data: global
  } = await supabaseAdmin.from("sap_global_settings").select("sap_base_url, sap_username").eq("id", "default").maybeSingle();
  const {
    data: globalSecret
  } = await supabaseAdmin.from("sap_global_secrets").select("sap_password").eq("id", "default").maybeSingle();
  const {
    resolveSapUrl
  } = await import("./url-Cdjg0c3W.mjs");
  let target = resolveSapUrl(cfg.endpoint_url, global?.sap_base_url ?? null);
  let method = "HEAD";
  let body;
  const headers = {
    Accept: "application/json"
  };
  if (cfg.auth_type === "proxy") {
    const {
      data: g
    } = await supabaseAdmin.from("sap_global_settings").select("middleware_url").eq("id", "default").maybeSingle();
    const {
      data: gs
    } = await supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle();
    if (!g?.middleware_url) throw new Error("Global Node.js Middleware URL is not configured. Set it in SAP API Settings → Middleware Configuration.");
    target = `${g.middleware_url.replace(/\/$/, "")}/sap/test`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    if (gs?.proxy_secret) headers["x-shared-secret"] = gs.proxy_secret;
    body = JSON.stringify({
      configId: data.id
    });
  } else {
    const user = global?.sap_username ?? null;
    const pass = globalSecret?.sap_password ?? null;
    if (cfg.auth_type === "basic" && user && pass) {
      headers.Authorization = "Basic " + Buffer.from(`${user}:${pass}`).toString("base64");
    }
    for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) headers[k] = v;
  }
  const t0 = Date.now();
  let ok = false, status = 0, message = "";
  try {
    const res = await fetch(target, {
      method,
      headers,
      body
    });
    status = res.status;
    ok = res.ok;
    message = `${res.status} ${res.statusText}`;
  } catch (e) {
    message = e.message;
  }
  const latency_ms = Date.now() - t0;
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: data.id,
    status: ok ? "ok" : "error",
    latency_ms,
    message: `test: ${message}`
  });
  return {
    ok,
    status,
    latency_ms,
    message
  };
});
export {
  deleteSapConfig_createServerFn_handler,
  getSapConfig_createServerFn_handler,
  listSapConfigs_createServerFn_handler,
  replaceRequestFields_createServerFn_handler,
  replaceResponseFields_createServerFn_handler,
  testSapConnection_createServerFn_handler,
  upsertCredentials_createServerFn_handler,
  upsertSapConfig_createServerFn_handler
};
