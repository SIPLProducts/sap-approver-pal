import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn } from "./createSsrRpc-Bx8XQbeC.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { P as Popover, a as PopoverTrigger, b as PopoverContent, C as Command, c as CommandInput, d as CommandList, e as CommandEmpty, f as CommandGroup, g as CommandItem } from "./command-i9zWGkU5.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { g as getPlantConfig, a as getUserPlantConfig, e as extractPlantOptions } from "./plant-select-BIpZq3f7.mjs";
import { r as runSapApi } from "./sap.functions-oOi__-nP.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { a3 as LoaderCircle, n as ChevronsUpDown } from "../_libs/lucide-react.mjs";
function PlantMultiSelect({
  value,
  onChange,
  placeholder = "Select plants…",
  disabled,
  className,
  restrictToActive = true,
  source = "default"
}) {
  const [open, setOpen] = reactExports.useState(false);
  const getDefaultCfg = useServerFn(getPlantConfig);
  const getUserCfg = useServerFn(getUserPlantConfig);
  const runApi = useServerFn(runSapApi);
  const { activePlants } = useActiveContext();
  const cfgQuery = useQuery({
    queryKey: ["sap-plant-config", source],
    queryFn: async () => source === "user-plant" ? await getUserCfg() : await getDefaultCfg(),
    staleTime: 10 * 60 * 1e3
  });
  const configId = cfgQuery.data?.configId ?? null;
  const plantField = cfgQuery.data?.plantField ?? (source === "user-plant" ? "WERKS" : "VKORG");
  const plantsQuery = useQuery({
    queryKey: ["sap-plants", configId],
    enabled: !!configId,
    staleTime: 5 * 60 * 1e3,
    queryFn: async () => {
      const resp = await runApi({ data: { configId, inputs: {} } });
      return extractPlantOptions(resp?.data ?? resp, plantField);
    }
  });
  const allowedSet = reactExports.useMemo(
    () => restrictToActive && activePlants.length > 0 ? new Set(activePlants) : null,
    [restrictToActive, activePlants]
  );
  const plants = reactExports.useMemo(() => {
    const list = plantsQuery.data ?? [];
    if (!allowedSet) return list;
    const filtered = list.filter((p) => allowedSet.has(p.code));
    const present = new Set(filtered.map((p) => p.code));
    const extra = Array.from(allowedSet).filter((c) => !present.has(c)).map((code) => ({ code, text: "" }));
    return [...filtered, ...extra].sort((a, b) => a.code.localeCompare(b.code));
  }, [plantsQuery.data, allowedSet]);
  const selected = reactExports.useMemo(() => new Set(value), [value]);
  reactExports.useEffect(() => {
    if (!allowedSet) return;
    const pruned = value.filter((c) => allowedSet.has(c));
    if (pruned.length !== value.length) onChange(pruned);
  }, [allowedSet]);
  function toggle(code) {
    if (selected.has(code)) onChange(value.filter((v) => v !== code));
    else onChange([...value, code]);
  }
  if (!cfgQuery.isLoading && !configId) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Input,
      {
        value: value.join(", "),
        onChange: (e) => onChange(
          e.target.value.split(",").map((s) => s.trim()).filter(Boolean)
        ),
        placeholder: "e.g. 3801, 3802",
        className: cn("h-9 font-mono", className),
        disabled
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "outline",
        role: "combobox",
        "aria-expanded": open,
        disabled: disabled || cfgQuery.isLoading,
        className: cn(
          "h-9 w-full justify-between gap-2 px-3 font-mono",
          value.length === 0 && "text-muted-foreground font-sans",
          className
        ),
        children: [
          cfgQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2 font-sans", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Loading…"
          ] }) : value.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1 text-left truncate", children: placeholder }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "flex-1 min-w-0 overflow-x-auto whitespace-nowrap text-left [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
              onWheel: (e) => {
                if (e.deltaY !== 0) {
                  e.currentTarget.scrollLeft += e.deltaY;
                }
              },
              children: value.join(", ")
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronsUpDown, { className: "h-3.5 w-3.5 shrink-0 opacity-50" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PopoverContent,
      {
        className: "z-[1000] w-[320px] p-0 max-h-[60vh] overflow-hidden",
        align: "start",
        side: "bottom",
        sideOffset: 6,
        avoidCollisions: false,
        onWheel: (e) => e.stopPropagation(),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Command, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CommandInput, { placeholder: "Search plant…", className: "h-9" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CommandList, { className: "max-h-[calc(60vh-3rem)]", children: plantsQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 py-6 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Fetching plants…"
          ] }) : plantsQuery.isError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-4 text-xs text-destructive space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: "Failed to load plants." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] opacity-80 break-words", children: plantsQuery.error?.message ?? "Unknown error" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "underline", onClick: () => plantsQuery.refetch(), children: "Retry" })
          ] }) : plants.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-xs text-muted-foreground", children: "No plants returned by Get_Plant. Check SAP API Settings." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CommandEmpty, { children: "No plant found." }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandGroup, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                CommandItem,
                {
                  value: "__select_all__",
                  onSelect: () => {
                    if (value.length === plants.length) onChange([]);
                    else onChange(plants.map((p) => p.code));
                  },
                  className: "font-medium border-b rounded-none",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      Checkbox,
                      {
                        checked: value.length === plants.length,
                        tabIndex: -1,
                        className: "pointer-events-none mr-2"
                      }
                    ),
                    value.length === plants.length ? `Clear all (${plants.length})` : `Select all (${plants.length})`
                  ]
                }
              ),
              plants.map((p) => {
                const isSel = selected.has(p.code);
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  CommandItem,
                  {
                    value: `${p.code} ${p.text}`,
                    onSelect: () => toggle(p.code),
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        Checkbox,
                        {
                          checked: isSel,
                          tabIndex: -1,
                          className: "pointer-events-none mr-2"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: p.code }),
                      p.text && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 text-muted-foreground truncate", children: [
                        "— ",
                        p.text
                      ] })
                    ]
                  },
                  p.code
                );
              })
            ] })
          ] }) })
        ] })
      }
    )
  ] });
}
export {
  PlantMultiSelect as P
};
