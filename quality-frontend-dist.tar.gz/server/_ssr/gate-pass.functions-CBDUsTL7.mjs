import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-Bm5Y9dpM.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, y as booleanType, z as stringType, A as unionType, B as numberType, C as arrayType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "Gate_Pass_Fetch_API";
const fetchGatePass_createServerFn_handler = createServerRpc({
  id: "979f43fae68437941ded0e262c04aecc2048a75d5147e33c0a862ab14ec6957b",
  name: "fetchGatePass",
  filename: "src/lib/mm/gate-pass.functions.ts"
}, (opts) => fetchGatePass.__executeServer(opts));
const fetchGatePass = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  gate_pass_number: stringType().trim().max(40).optional().default(""),
  hod_approval: booleanType().optional().default(false),
  store_approval: booleanType().optional().default(false),
  scm_head: booleanType().optional().default(false),
  plant_head: booleanType().optional().default(false),
  return_receipt: booleanType().optional().default(false)
}).parse(d)).handler(fetchGatePass_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const userId = data.user_id.trim();
  const inputs = {
    GATEPASS_NUMBER: (data.gate_pass_number ?? "").trim(),
    HOD_APPROVAL: data.hod_approval ? "X" : "",
    STORE_APPROVAL: data.store_approval ? "X" : "",
    SCM_HEAD: data.scm_head ? "X" : "",
    PLANT_HEAD: data.plant_head ? "X" : "",
    RETURN_RECEIPT: data.return_receipt ? "X" : "",
    USER_ID: userId
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "GET";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs
    });
    proxied = true;
  } else {
    const qs = new URLSearchParams(inputs).toString();
    const join = cfg.endpoint_url.includes("?") ? "&" : "?";
    target = `${cfg.endpoint_url}${join}${qs}`;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `gate-pass network: ${errMsg}`
    });
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      user_id: userId,
      error: `Could not reach SAP at ${cfg.endpoint_url.split("?")[0]}. ${errMsg}.`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `gate-pass: ${message} ${text.slice(0, 500)}`
    });
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      user_id: userId,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      user_id: userId,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  const headerArr = Array.isArray(sapJson?.HEADER) ? sapJson.HEADER : Array.isArray(sapJson?.header) ? sapJson.header : [];
  const dataArr = Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : Array.isArray(sapJson) ? sapJson : [];
  const header = headerArr.length > 0 && headerArr[0] && typeof headerArr[0] === "object" ? {
    ...headerArr[0]
  } : null;
  const rows = dataArr.map((r) => r && typeof r === "object" ? {
    ...r
  } : {});
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `gate-pass: ${message}`
  });
  return {
    header,
    data: rows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    user_id: userId,
    error: null
  };
});
const SAVE_CONFIG_NAME = "Gate_Pass_Save_API";
const gpSaveRowSchema = objectType({
  MATERIAL: stringType().optional().default(""),
  DESCRIPTION: stringType().optional().default(""),
  MEINS: stringType().optional().default(""),
  QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  VALUE: unionType([stringType(), numberType()]).optional().default(0),
  EXPECTED_DATE_OF_RETURN: stringType().optional().default(""),
  USER_REMARKS: stringType().optional().default(""),
  HOD_APPROVAL: stringType().optional().default(""),
  HOD_REJECTION: stringType().optional().default(""),
  HOD_REMARKS: stringType().optional().default(""),
  ISSUED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  STORE_APPROVAL: stringType().optional().default(""),
  JUSTIFICATION: stringType().optional().default(""),
  SCM_HEAD: stringType().optional().default(""),
  PH_APPROVAL: stringType().optional().default(""),
  PH_REJECTION: stringType().optional().default(""),
  RETURN_STATUS: stringType().optional().default(""),
  REMARKS: stringType().optional().default(""),
  RETURNED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0)
}).passthrough();
function toNum(v) {
  if (v == null || v === "") return 0;
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}
const saveGatePass_createServerFn_handler = createServerRpc({
  id: "bfd48e87678e43e6e840b81605f9ccd3edda183570bf46342ce06e81faa3cf57",
  name: "saveGatePass",
  filename: "src/lib/mm/gate-pass.functions.ts"
}, (opts) => saveGatePass.__executeServer(opts));
const saveGatePass = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  header: objectType({
    GATEPASS_NUMBER: unionType([stringType(), numberType()]).optional().default(""),
    GATE_PASS_TYPE: stringType().optional().default(""),
    GATEPASS_DATE: stringType().optional().default(""),
    PLANT: stringType().optional().default(""),
    VEHICLE_NO: stringType().optional().default(""),
    VENDOR: stringType().optional().default(""),
    VENDOR_NAME: stringType().optional().default(""),
    PURPOSE: stringType().optional().default("")
  }).passthrough(),
  data: arrayType(gpSaveRowSchema).min(1, "At least one row is required")
}).parse(d)).handler(saveGatePass_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", SAVE_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${SAVE_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${SAVE_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const h = data.header;
  const gpNumRaw = h.GATEPASS_NUMBER;
  const gpNumNumeric = typeof gpNumRaw === "number" ? gpNumRaw : typeof gpNumRaw === "string" && gpNumRaw.trim() !== "" && !Number.isNaN(Number(gpNumRaw)) ? Number(gpNumRaw) : gpNumRaw ?? "";
  const payload = {
    GATEPASS_NUMBER: gpNumNumeric,
    GATE_PASS_TYPE: h.GATE_PASS_TYPE ?? h.GATEPASS_TYPE ?? "",
    GATEPASS_DATE: h.GATEPASS_DATE ?? "",
    PLANT: h.PLANT ?? "",
    VEHICLE_NO: h.VEHICLE_NO ?? "",
    VENDOR: h.VENDOR ?? "",
    VENDOR_NAME: h.VENDOR_NAME ?? "",
    PURPOSE: h.PURPOSE ?? "",
    DATA: data.data.map((r) => ({
      MATERIAL: r.MATERIAL ?? "",
      DESCRIPTION: r.DESCRIPTION ?? "",
      MEINS: r.MEINS ?? "",
      QUANTITY: toNum(r.QUANTITY),
      VALUE: toNum(r.VALUE),
      EXPECTED_DATE_OF_RETURN: r.EXPECTED_DATE_OF_RETURN ?? "",
      USER_REMARKS: r.USER_REMARKS ?? "",
      HOD_APPROVAL: r.HOD_APPROVAL ?? "",
      HOD_REJECTION: r.HOD_REJECTION ?? "",
      HOD_REMARKS: r.HOD_REMARKS ?? "",
      ISSUED_QUANTITY: toNum(r.ISSUED_QUANTITY),
      STORE_APPROVAL: r.STORE_APPROVAL ?? "",
      JUSTIFICATION: r.JUSTIFICATION ?? "",
      SCM_HEAD: r.SCM_HEAD ?? "",
      PH_APPROVAL: r.PH_APPROVAL ?? "",
      PH_REJECTION: r.PH_REJECTION ?? "",
      RETURN_STATUS: r.RETURN_STATUS ?? "",
      REMARKS: r.REMARKS ?? "",
      RETURNED_QUANTITY: toNum(r.RETURNED_QUANTITY)
    }))
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs: payload
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    headers["Content-Type"] = "application/json";
    bodyOut = JSON.stringify(payload);
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `gate-pass-save network: ${errMsg}`
    });
    return {
      ok: false,
      message: `Could not reach SAP: ${errMsg}`,
      document_number: null,
      error: errMsg
    };
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `gate-pass-save: invalid JSON ${text.slice(0, 300)}`
    });
    return {
      ok: false,
      message: `Invalid JSON from SAP: ${text.slice(0, 200)}`,
      document_number: null,
      error: "invalid_json"
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  if (Array.isArray(sapJson?.MESSAGES) && sapJson.MESSAGES.length > 0) {
    const msg = sapJson.MESSAGES.map((m) => String(m?.MESSAGE ?? "").trim()).filter(Boolean).join("; ") || "SAP returned an error";
    const anyError = sapJson.MESSAGES.some((m) => {
      const t = String(m?.TYPE ?? "").toUpperCase();
      return t === "E" || t === "A";
    });
    const ok2 = res.ok && !anyError;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: ok2 ? "ok" : "error",
      latency_ms,
      message: `gate-pass-save: ${msg}`
    });
    const docMatch = msg.match(/Document\s*No\s*:?\s*(\S+)/i);
    return {
      ok: ok2,
      message: msg,
      document_number: sapJson?.DOCUMENT_NUMBER ?? docMatch?.[1] ?? null,
      error: ok2 ? null : msg
    };
  }
  const type = String(sapJson?.TYPE ?? "").toUpperCase();
  const message = String(sapJson?.MESSAGE ?? "").trim();
  const ok = res.ok && (type === "S" || type === "I" || type === "");
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: ok ? "ok" : "error",
    latency_ms,
    message: `gate-pass-save: ${type || "?"} ${message || text.slice(0, 200)}`
  });
  return {
    ok,
    message: message || (ok ? "Saved successfully" : `SAP returned ${res.status}`),
    document_number: sapJson?.DOCUMENT_NUMBER ?? null,
    error: ok ? null : message || `SAP returned ${res.status}`
  };
});
export {
  fetchGatePass_createServerFn_handler,
  saveGatePass_createServerFn_handler
};
