import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as Skeleton } from "./skeleton-C5WX2eNf.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
function SkeletonRows({ rows = 6, columns = 4, className }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: cn("w-full space-y-2", className), "aria-busy": "true", "aria-live": "polite", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-3 pb-2 border-b", children: Array.from({ length: columns }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 flex-1" }, i)) }),
    Array.from({ length: rows }).map((_, r) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-3 py-2", children: Array.from({ length: columns }).map((_2, c) => /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 flex-1" }, c)) }, r))
  ] });
}
function SkeletonCards({ count = 4, className }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: cn(
        "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4",
        className
      ),
      "aria-busy": "true",
      "aria-live": "polite",
      children: Array.from({ length: count }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border bg-card p-5 shadow-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-24" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "mt-4 h-8 w-32" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "mt-3 h-3 w-20" })
      ] }, i))
    }
  );
}
export {
  SkeletonCards as S,
  SkeletonRows as a
};
