import { activityToScreenKey } from "./screen-keys-mn2QOK0m.mjs";
async function isBuiltInAdmin(supabaseAdmin, userId) {
  const { data } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId).eq("role", "Admin").maybeSingle();
  return !!data;
}
async function assertScreen(userId, screenKey) {
  const { supabaseAdmin } = await import("./client.server-D5ro3rAQ.mjs");
  if (await isBuiltInAdmin(supabaseAdmin, userId)) return;
  const { data: profile } = await supabaseAdmin.from("profiles").select("sap_profile").eq("id", userId).maybeSingle();
  const sap = profile?.sap_profile ?? null;
  if (sap?.plants?.length) {
    for (const p of sap.plants) {
      for (const r of p.roles ?? []) {
        for (const act of r.activities ?? []) {
          if (activityToScreenKey(act) === screenKey) return;
        }
      }
    }
  }
  if (!sap?.plants?.length) {
    throw new Error(
      "Your SAP permissions are not loaded on the server. Please sign out and sign in again to refresh."
    );
  }
  throw new Error("Not authorized for this screen");
}
async function assertAnyScreen(userId, screenKeys) {
  const { supabaseAdmin } = await import("./client.server-D5ro3rAQ.mjs");
  if (await isBuiltInAdmin(supabaseAdmin, userId)) return;
  const { data: profile } = await supabaseAdmin.from("profiles").select("sap_profile").eq("id", userId).maybeSingle();
  const sap = profile?.sap_profile ?? null;
  const wanted = new Set(screenKeys);
  if (sap?.plants?.length) {
    for (const p of sap.plants) {
      for (const r of p.roles ?? []) {
        for (const act of r.activities ?? []) {
          const key = activityToScreenKey(act);
          if (key && wanted.has(key)) return;
        }
      }
    }
  }
  if (!sap?.plants?.length) {
    throw new Error(
      "Your SAP permissions are not loaded on the server. Please sign out and sign in again to refresh."
    );
  }
  throw new Error("Not authorized for this screen");
}
export {
  assertAnyScreen,
  assertScreen
};
