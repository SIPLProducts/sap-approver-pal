import { c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { a as objectType, E as recordType, z as stringType, H as unknownType, D as enumType } from "../_libs/zod.mjs";
const syncFromSAP = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("e588a3a42a79643703e8fc58b19550c2e037b2e8f676047ac729abc367bacc7e"));
const ActionInput = objectType({
  documentId: stringType().uuid(),
  action: enumType(["approve", "reject", "send_back"]),
  comments: stringType().max(2e3).optional()
});
const decideStep = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => ActionInput.parse(input)).handler(createSsrRpc("2168ff80ec4bfb5ab4f8ec9cac835108649eedc4efba3a710d6090bee795b1bc"));
const RunSapInput = objectType({
  configId: stringType().uuid(),
  inputs: recordType(stringType(), unknownType()).optional().default({})
});
const runSapApi = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => RunSapInput.parse(d)).handler(createSsrRpc("15429faf95fe4dfe7a1118d539cb815e469213051e804670c84f9a95063282d0"));
export {
  decideStep as d,
  runSapApi as r,
  syncFromSAP as s
};
