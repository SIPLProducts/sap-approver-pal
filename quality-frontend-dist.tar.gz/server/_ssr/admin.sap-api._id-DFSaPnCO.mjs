import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQueryClient, a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn } from "./createSsrRpc-XOrxmi8L.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { T as Textarea } from "./textarea-DSyJ1nlY.mjs";
import { S as Switch } from "./switch-CQ4rbtn8.mjs";
import { B as Badge } from "./badge-DyfXZgLs.mjs";
import { T as Tabs, a as TabsList, b as TabsTrigger, c as TabsContent } from "./tabs-D_u1EXWn.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-CZRUt5a6.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BhFPQiYt.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { t as testSapConnection, u as upsertSapConfig, r as replaceRequestFields, a as replaceResponseFields, b as upsertCredentials, g as getSapConfig } from "./sap-api.functions-CX1PogxP.mjs";
import { D as Dialog, f as DialogTrigger, a as DialogContent, b as DialogHeader, c as DialogTitle, d as DialogDescription, e as DialogFooter } from "./dialog--up_DbYf.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { S as StatusBadge } from "./status-badge-CHGzK-xV.mjs";
import { S as SkeletonCards } from "./skeleton-rows-C2wJYLiJ.mjs";
import { f as formatDateTime } from "./format-D-HjDoz6.mjs";
import { e as Route$3 } from "./router-dzu71i9y.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/web-push.mjs";

import { a3 as LoaderCircle, am as Activity, a4 as ArrowLeft, v as Save, V as Plus, at as GripVertical, a1 as Trash2, au as Sparkles, av as FileBraces, aw as Upload } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./server-CeMw7B2X.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";






import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-tabs.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "./auth-middleware-BtdUo7VX.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/zod.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./client-CXnFcWf4.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "./client.server-D5ro3rAQ.mjs";
import "./sap-client.server-CglbxEth.mjs";
import "./push.server-Co_uxbPF.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";

import "../_libs/asn1.js.mjs";
import "../_libs/bn.js.mjs";
import "../_libs/inherits.mjs";
import "../_libs/safer-buffer.mjs";
import "../_libs/minimalistic-assert.mjs";
import "../_libs/jws.mjs";

import "../_libs/safe-buffer.mjs";
import "../_libs/jwa.mjs";
import "../_libs/ecdsa-sig-formatter.mjs";
import "../_libs/buffer-equal-constant-time.mjs";
import "../_libs/http_ece.mjs";
import "../_libs/https-proxy-agent.mjs";



import "../_libs/debug.mjs";
import "../_libs/ms.mjs";
import "../_libs/supports-color.mjs";

import "../_libs/has-flag.mjs";
import "../_libs/agent-base.mjs";
const MAX_FIELDS = 500;
const MAX_DEPTH = 8;
const MAX_PAYLOAD_BYTES = 1e6;
const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?$/;
function inferType(v) {
  if (v === null) return "null";
  if (Array.isArray(v)) return "array";
  if (typeof v === "string") return ISO_DATE_RE.test(v) ? "date" : "string";
  if (typeof v === "number") return "number";
  if (typeof v === "boolean") return "boolean";
  return "string";
}
function flattenPayload(input) {
  const out = [];
  function walk(value, path, depth) {
    if (out.length >= MAX_FIELDS || depth > MAX_DEPTH) return;
    if (value !== null && typeof value === "object" && !Array.isArray(value)) {
      const entries = Object.entries(value);
      if (entries.length === 0 && path) {
        out.push({ path, sampleValue: {}, inferredType: "string" });
        return;
      }
      for (const [k, v] of entries) {
        if (out.length >= MAX_FIELDS) break;
        walk(v, path ? `${path}.${k}` : k, depth + 1);
      }
      return;
    }
    if (Array.isArray(value)) {
      if (value.length === 0) {
        if (path) out.push({ path: `${path}[]`, sampleValue: [], inferredType: "array" });
        return;
      }
      const first = value[0];
      if (first !== null && typeof first === "object") {
        walk(first, `${path}[]`, depth + 1);
      } else {
        out.push({ path: `${path}[]`, sampleValue: first, inferredType: inferType(first) });
      }
      return;
    }
    if (path) out.push({ path, sampleValue: value, inferredType: inferType(value) });
  }
  walk(input, "", 0);
  return out;
}
function sanitizeLooseJson(text) {
  let s = text;
  s = s.replace(/\/\*[\s\S]*?\*\//g, "");
  s = s.replace(/(^|[^:"])\/\/[^\n\r]*/g, "$1");
  s = s.replace(/:(\s*)(,|\}|\])/g, ": null$1$2");
  s = s.replace(/,(\s*[}\]])/g, "$1");
  return s;
}
function parsePayloadText(text) {
  if (text.length > MAX_PAYLOAD_BYTES) {
    return { ok: false, error: `Payload exceeds ${Math.round(MAX_PAYLOAD_BYTES / 1e3)} KB limit` };
  }
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch (e) {
    const originalError = e.message;
    try {
      return { ok: true, value: JSON.parse(sanitizeLooseJson(text)) };
    } catch {
      return { ok: false, error: originalError };
    }
  }
}
function leafColumn(path) {
  const leaf = path.split(/[.[]/).filter(Boolean).pop() ?? path;
  return leaf.replace(/\]$/, "").replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/[^a-zA-Z0-9]+/g, "_").replace(/^_+|_+$/g, "").toLowerCase();
}
function toReqRows(fields, startIndex = 0) {
  return fields.map((f, i) => ({
    field_name: f.path,
    source: "static",
    default_value: f.sampleValue === null || f.sampleValue === void 0 ? "" : String(f.sampleValue),
    required: false,
    sort_order: startIndex + i
  }));
}
function toResRows(fields, startIndex = 0) {
  return fields.map((f, i) => ({
    field_name: f.path,
    target_table: "",
    target_column: leafColumn(f.path),
    transform_expr: "",
    sort_order: startIndex + i
  }));
}
function mergeRows(existing, incoming, mode) {
  if (mode === "replace") return incoming.map((r, i) => ({ ...r, sort_order: i }));
  const seen = new Set(existing.map((r) => r.field_name));
  const additions = incoming.filter((r) => !seen.has(r.field_name));
  return [...existing, ...additions].map((r, i) => ({ ...r, sort_order: i }));
}
function PayloadImportDialog(props) {
  const { mode } = props;
  const [open, setOpen] = reactExports.useState(false);
  const [text, setText] = reactExports.useState("");
  const [fields, setFields] = reactExports.useState([]);
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const [merge, setMerge] = reactExports.useState("replace");
  const fileRef = reactExports.useRef(null);
  function reset() {
    setText("");
    setFields([]);
    setSelected(/* @__PURE__ */ new Set());
    setMerge("replace");
  }
  function detect(raw) {
    const parsed = parsePayloadText(raw);
    if (!parsed.ok) {
      toast.error(parsed.error);
      return;
    }
    const detected = flattenPayload(parsed.value);
    if (detected.length === 0) {
      toast.error("No fields detected in payload");
      return;
    }
    setFields(detected);
    setSelected(new Set(detected.map((f) => f.path)));
    toast.success(`Detected ${detected.length} field${detected.length === 1 ? "" : "s"}`);
  }
  async function onFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > MAX_PAYLOAD_BYTES) {
      toast.error("File too large (max 1 MB)");
      return;
    }
    const raw = await f.text();
    setText(raw);
    detect(raw);
    if (fileRef.current) fileRef.current.value = "";
  }
  function apply() {
    const chosen = fields.filter((f) => selected.has(f.path));
    if (chosen.length === 0) {
      toast.error("Select at least one field");
      return;
    }
    if (mode === "request") props.onApply(toReqRows(chosen), merge);
    else props.onApply(toResRows(chosen), merge);
    toast.success(`Imported ${chosen.length} field${chosen.length === 1 ? "" : "s"}`);
    setOpen(false);
    reset();
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Dialog, { open, onOpenChange: (v) => {
    setOpen(v);
    if (!v) reset();
  }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTrigger, { asChild: true, children: props.trigger ?? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4 mr-1" }),
      " Import payload"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileBraces, { className: "h-5 w-5" }),
          " Import ",
          mode,
          " payload"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogDescription, { children: [
          "Upload or paste a sample JSON payload. Detected fields will be added to the ",
          mode,
          " mapping table."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { ref: fileRef, type: "file", accept: ".json,application/json,.txt,text/plain", className: "hidden", onChange: onFile }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: () => fileRef.current?.click(), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4 mr-1" }),
            " Upload .json"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: () => detect(text), disabled: !text.trim(), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4 mr-1" }),
            " Detect fields"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground ml-auto", children: "Max 1 MB · JSON only" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Paste JSON" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Textarea,
            {
              rows: 6,
              value: text,
              onChange: (e) => setText(e.target.value),
              placeholder: '{ "doc_no": "4500000001", "items": [{ "material": "MAT-1", "qty": 10 }] }',
              className: "font-mono text-xs"
            }
          )
        ] }),
        fields.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Detected fields" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "secondary", children: [
                selected.size,
                "/",
                fields.length
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", onClick: () => setSelected(new Set(fields.map((f) => f.path))), children: "All" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", onClick: () => setSelected(/* @__PURE__ */ new Set()), children: "None" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border max-h-64 overflow-y-auto", children: fields.map((f) => {
            const checked = selected.has(f.path);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 px-3 py-1.5 text-xs border-b last:border-b-0 hover:bg-muted/40 cursor-pointer", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Checkbox,
                {
                  checked,
                  onCheckedChange: (v) => {
                    const next = new Set(selected);
                    if (v) next.add(f.path);
                    else next.delete(f.path);
                    setSelected(next);
                  }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono truncate flex-1", children: f.path }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "text-[10px]", children: f.inferredType }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground truncate max-w-[180px]", children: f.sampleValue === null ? "null" : typeof f.sampleValue === "object" ? "…" : String(f.sampleValue) })
            ] }, f.path);
          }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Merge mode" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: merge, onValueChange: (v) => setMerge(v), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "h-8 w-64", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "replace", children: "Replace existing rows" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "append", children: "Append new fields only" })
              ] })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: () => setOpen(false), children: "Cancel" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: apply, disabled: fields.length === 0, children: "Apply to table" })
      ] })
    ] })
  ] });
}
function SapApiEditPage() {
  const {
    id
  } = Route$3.useParams();
  const qc = useQueryClient();
  const getFn = useServerFn(getSapConfig);
  const saveFn = useServerFn(upsertSapConfig);
  const saveReqFn = useServerFn(replaceRequestFields);
  const saveResFn = useServerFn(replaceResponseFields);
  const saveCredsFn = useServerFn(upsertCredentials);
  const testFn = useServerFn(testSapConnection);
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["sap-config", id],
    queryFn: () => getFn({
      data: {
        id
      }
    })
  });
  const [cfg, setCfg] = reactExports.useState(null);
  const [reqRows, setReqRows] = reactExports.useState([]);
  const [resRows, setResRows] = reactExports.useState([]);
  const [creds, setCreds] = reactExports.useState({
    username: "",
    password: "",
    extra_headers: "{}",
    passwordSet: false
  });
  const [testResult, setTestResult] = reactExports.useState(null);
  const [busy, setBusy] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (data) {
      setCfg(data.config);
      setReqRows(data.requestFields.map((r) => ({
        ...r
      })));
      setResRows(data.responseFields.map((r) => ({
        ...r
      })));
      setCreds({
        username: data.credentials.username ?? "",
        password: "",
        extra_headers: JSON.stringify(data.credentials.extra_headers ?? {}, null, 2),
        passwordSet: data.credentials.password_set
      });
    }
  }, [data]);
  if (isLoading || !cfg) return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "page-shell page-stack", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonCards, { count: 2 }) });
  async function saveDetails() {
    setBusy(true);
    try {
      await saveFn({
        data: {
          id: cfg.id,
          name: cfg.name,
          description: cfg.description,
          module: cfg.module,
          endpoint_url: cfg.endpoint_url,
          http_method: cfg.http_method,
          auth_type: cfg.auth_type,
          middleware_url: cfg.middleware_url,
          proxy_secret_ref: cfg.proxy_secret_ref,
          api_type: cfg.api_type,
          auto_sync_enabled: cfg.auto_sync_enabled,
          schedule_cron: cfg.schedule_cron,
          is_active: cfg.is_active
        }
      });
      toast.success("Saved");
      qc.invalidateQueries({
        queryKey: ["sap-config", id]
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function saveRequest() {
    setBusy(true);
    try {
      await saveReqFn({
        data: {
          config_id: id,
          fields: reqRows.map((r, i) => ({
            ...r,
            sort_order: i
          }))
        }
      });
      toast.success("Request fields saved");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function saveResponse() {
    setBusy(true);
    try {
      await saveResFn({
        data: {
          config_id: id,
          fields: resRows.map((r, i) => ({
            ...r,
            sort_order: i
          }))
        }
      });
      toast.success("Response fields saved");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function saveCredentials() {
    setBusy(true);
    let headers = {};
    try {
      headers = JSON.parse(creds.extra_headers || "{}");
    } catch {
      setBusy(false);
      return toast.error("Extra headers must be valid JSON");
    }
    try {
      await saveCredsFn({
        data: {
          config_id: id,
          username: creds.username.trim() || void 0,
          password: creds.password || void 0,
          extra_headers: headers
        }
      });
      toast.success("Credentials saved");
      setCreds({
        ...creds,
        password: "",
        passwordSet: !!creds.password || creds.passwordSet
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function runTest() {
    setBusy(true);
    setTestResult(null);
    try {
      const r = await testFn({
        data: {
          id
        }
      });
      setTestResult(r);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Admin · SAP API Settings", title: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/admin/sap-api", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "sm", "aria-label": "Back to SAP API list", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4 mr-1" }),
        " Back"
      ] }) }),
      cfg.name
    ] }), meta: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", children: cfg.module }), actions: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: runTest, disabled: busy, variant: "outline", children: [
      busy ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 mr-1 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className: "h-4 w-4 mr-1" }),
      " Test connection"
    ] }) }),
    testResult && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-3 flex items-center gap-2 text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: testResult.ok ? "success" : "error", label: testResult.message }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground ml-auto tabular-nums", children: [
        testResult.latency_ms,
        " ms"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { defaultValue: "details", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid grid-cols-3 sm:grid-cols-6 w-full", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "details", children: "Details" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "request", children: "Request" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "response", children: "Response" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "credentials", children: "Credentials" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "scheduler", children: "Scheduler" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "connectivity", children: "Connectivity" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "details", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: cfg.name, onChange: (e) => setCfg({
              ...cfg,
              name: e.target.value
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Module" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: cfg.module, onValueChange: (v) => setCfg({
              ...cfg,
              module: v
            }), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "MM", children: "MM" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "SD", children: "SD" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "COMMON", children: "Common" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Description" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: cfg.description ?? "", onChange: (e) => setCfg({
              ...cfg,
              description: e.target.value
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Endpoint Path or URL" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: cfg.endpoint_url, onChange: (e) => setCfg({
              ...cfg,
              endpoint_url: e.target.value
            }), placeholder: "/sd_approval_mng/zvk11_app/vk11_app?sap-client=300" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-muted-foreground mt-1", children: [
              "Use a relative path (starting with ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "/" }),
              ") to inherit the SAP Base URL from ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "SAP API Settings → SAP Connection" }),
              ". A full ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "http(s)://…" }),
              " URL is also accepted."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "HTTP method" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: cfg.http_method, onValueChange: (v) => setCfg({
              ...cfg,
              http_method: v
            }), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"].map((m) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: m, children: m }, m)) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Auth type" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: cfg.auth_type, onValueChange: (v) => setCfg({
              ...cfg,
              auth_type: v
            }), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ["basic", "oauth", "none", "proxy"].map((m) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: m, children: m }, m)) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "API type" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: cfg.api_type, onValueChange: (v) => setCfg({
              ...cfg,
              api_type: v
            }), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "sync", children: "sync (store locally)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "fetch", children: "fetch (live pass-through)" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-end gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: cfg.is_active, onCheckedChange: (v) => setCfg({
              ...cfg,
              is_active: v
            }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Active" })
          ] }),
          cfg.auth_type === "proxy" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2 rounded-md border bg-muted/40 p-3 text-xs text-muted-foreground", children: [
            "Middleware URL and Proxy Secret are managed globally. Set them in ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/admin/sap-api", className: "underline font-medium", children: "SAP API Settings → Middleware Configuration" }),
            "."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: saveDetails, disabled: busy, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-2" }),
          " Save details"
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "request", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Configure how request payload fields are built." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(PayloadImportDialog, { mode: "request", onApply: (rows, merge) => setReqRows(mergeRows(reqRows, rows, merge)) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: () => setReqRows([...reqRows, {
              field_name: "",
              source: "static",
              default_value: "",
              required: false,
              sort_order: reqRows.length
            }]), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-1" }),
              " Add row"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: saveRequest, disabled: busy, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-1" }),
              " Save"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "w-8" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Field" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Source" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Default" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Required" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, {})
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TableBody, { children: [
            reqRows.map((r, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(GripVertical, { className: "h-4 w-4" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: r.field_name, onChange: (e) => {
                const c = [...reqRows];
                c[i].field_name = e.target.value;
                setReqRows(c);
              } }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: r.source, onValueChange: (v) => {
                const c = [...reqRows];
                c[i].source = v;
                setReqRows(c);
              }, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "w-28", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ["static", "column", "expr", "secret"].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: s, children: s }, s)) })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: r.default_value ?? "", onChange: (e) => {
                const c = [...reqRows];
                c[i].default_value = e.target.value;
                setReqRows(c);
              } }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: r.required, onCheckedChange: (v) => {
                const c = [...reqRows];
                c[i].required = v;
                setReqRows(c);
              } }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", className: "text-destructive", onClick: () => setReqRows(reqRows.filter((_, j) => j !== i)), "aria-label": `Remove request field ${r.field_name || i + 1}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
            ] }, i)),
            reqRows.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 6, className: "text-center text-muted-foreground py-6", children: "No request fields." }) })
          ] })
        ] }) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "response", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Map response fields to local table columns for sync." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(PayloadImportDialog, { mode: "response", onApply: (rows, merge) => setResRows(mergeRows(resRows, rows, merge)) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: () => setResRows([...resRows, {
              field_name: "",
              target_table: "",
              target_column: "",
              transform_expr: "",
              sort_order: resRows.length
            }]), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-1" }),
              " Add row"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: saveResponse, disabled: busy, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-1" }),
              " Save"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "SAP field" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Target table" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Target column" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Transform" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, {})
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TableBody, { children: [
            resRows.map((r, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: r.field_name, onChange: (e) => {
                const c = [...resRows];
                c[i].field_name = e.target.value;
                setResRows(c);
              } }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: r.target_table ?? "", onChange: (e) => {
                const c = [...resRows];
                c[i].target_table = e.target.value;
                setResRows(c);
              } }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: r.target_column ?? "", onChange: (e) => {
                const c = [...resRows];
                c[i].target_column = e.target.value;
                setResRows(c);
              } }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: r.transform_expr ?? "", onChange: (e) => {
                const c = [...resRows];
                c[i].transform_expr = e.target.value;
                setResRows(c);
              }, placeholder: "e.g. toUpper($)" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", className: "text-destructive", onClick: () => setResRows(resRows.filter((_, j) => j !== i)), "aria-label": `Remove response field ${r.field_name || i + 1}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
            ] }, i)),
            resRows.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 5, className: "text-center text-muted-foreground py-6", children: "No response mappings." }) })
          ] })
        ] }) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "credentials", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Username" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: creds.username, onChange: (e) => setCreds({
              ...creds,
              username: e.target.value
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { children: [
              "Password ",
              creds.passwordSet && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", className: "ml-2 text-[10px]", children: "set" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "password", value: creds.password, onChange: (e) => setCreds({
              ...creds,
              password: e.target.value
            }), placeholder: creds.passwordSet ? "•••••••• (leave blank to keep)" : "Enter password" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Extra headers (JSON)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { rows: 6, value: creds.extra_headers, onChange: (e) => setCreds({
              ...creds,
              extra_headers: e.target.value
            }), className: "font-mono text-xs" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Credentials are stored in a service-role-only table and are never returned to the client. v1 stores values as-provided; Vault encryption is a follow-up." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: saveCredentials, disabled: busy, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-2" }),
          " Save credentials"
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "scheduler", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: cfg.auto_sync_enabled, onCheckedChange: (v) => setCfg({
            ...cfg,
            auto_sync_enabled: v
          }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Auto sync enabled" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Cron expression" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: cfg.schedule_cron ?? "", onChange: (e) => setCfg({
            ...cfg,
            schedule_cron: e.target.value
          }), placeholder: "*/5 * * * *" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-2 gap-3 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "Last synced: ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("b", { className: "tabular-nums", children: formatDateTime(cfg.last_synced_at) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "Next sync: ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("b", { className: "tabular-nums", children: formatDateTime(cfg.next_sync_at) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: saveDetails, disabled: busy, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-2" }),
          " Save scheduler"
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "connectivity", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-3 text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: "Direct vs Proxy" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-muted-foreground mt-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "Direct" }),
            ": server functions call the SAP endpoint directly using the configured auth.",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "Proxy" }),
            ": server functions call your self-hosted middleware over a private network; middleware then reaches SAP."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: "Self-hosted middleware checklist" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ol", { className: "list-decimal pl-5 space-y-1 text-muted-foreground mt-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
              "Configure ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "middleware/.env" }),
              " with ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "MIDDLEWARE_SHARED_SECRET" }),
              ", ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "SAP_BP_API_URL" }),
              ", ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "SAP_BP_USERNAME" }),
              ", ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "SAP_BP_PASSWORD" }),
              "."
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
              "Run ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "node server.js" }),
              " on port 3002."
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Expose with ngrok or a reverse proxy." }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
              "Paste the URL into ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("i", { children: "Middleware URL" }),
              " and the secret name into ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("i", { children: "Proxy secret name" }),
              " on the Details tab."
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Add the secret value in Backend → Secrets under the same name." }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
              "Click ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "Test connection" }),
              " above."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: runTest, disabled: busy, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className: "h-4 w-4 mr-2" }),
          " Test SAP connection"
        ] })
      ] }) })
    ] })
  ] });
}
export {
  SapApiEditPage as component
};
