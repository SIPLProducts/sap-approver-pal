import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, z as stringType, C as arrayType, D as enumType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const FETCH_CONFIG_NAME = "ZNFA_Fetch_API";
const CREATE_CONFIG_NAME = "ZNFA_Create_API";
const SAVE_CONFIG_NAME = "ZNFA_SAVE_API";
function pick(o, k) {
  if (!o || typeof o !== "object") return null;
  const hit = Object.keys(o).find((x) => x.toLowerCase() === k.toLowerCase());
  return hit ? o[hit] ?? null : null;
}
function mapRow(raw) {
  return {
    check: pick(raw, "CHECK"),
    pr_number: pick(raw, "PR_NUMBER"),
    rfq_number: pick(raw, "RFQ_NUMBER"),
    rfq_title: pick(raw, "RFQ_TITLE"),
    vendor_name: pick(raw, "VENDOR_NAME"),
    ter_sub_id: pick(raw, "TER_SUB_ID")
  };
}
const fetchGateProcess_createServerFn_handler = createServerRpc({
  id: "8b22a2bac26ac45e115549d786afca8169ef130a0e45b27810d52d8634d20ad6",
  name: "fetchGateProcess",
  filename: "src/lib/mm/gate-process.functions.ts"
}, (opts) => fetchGateProcess.__executeServer(opts));
const fetchGateProcess = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1, "User ID is required").max(60)
}).parse(d)).handler(fetchGateProcess_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", FETCH_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${FETCH_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${FETCH_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const userId = data.user_id.trim();
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "GET";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs: {
        USER_ID: userId
      }
    });
    proxied = true;
  } else {
    const join = cfg.endpoint_url.includes("?") ? "&" : "?";
    target = `${cfg.endpoint_url}${join}USER_ID=${encodeURIComponent(userId)}`;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `gate-fetch network: ${errMsg}`
    });
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      user_id: userId,
      error: `Could not reach SAP at ${cfg.endpoint_url.split("?")[0]}. ${errMsg}. The endpoint may be on a private network not accessible from this server.`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `gate-fetch: ${message} ${text.slice(0, 500)}`
    });
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      user_id: userId,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      user_id: userId,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? {} : json;
  const arr = Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : Array.isArray(sapJson) ? sapJson : [];
  const rows = arr.map(mapRow);
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `gate-fetch: ${message}`
  });
  return {
    rows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    count: rows.length,
    user_id: userId,
    error: null
  };
});
const createZnfa_createServerFn_handler = createServerRpc({
  id: "7f11d1eb14f584129ea3cea0ca62d2cd9d7787b257af355bc9cf9c9e4b30b5df",
  name: "createZnfa",
  filename: "src/lib/mm/gate-process.functions.ts"
}, (opts) => createZnfa.__executeServer(opts));
const createZnfa = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["RATE", "CHANGE", "DISPLAY", "ATTACHMENTS"]),
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  data: arrayType(objectType({
    CHECK: stringType().default("X"),
    BANFN: stringType().default(""),
    ANFNR: stringType().default(""),
    TITLE: stringType().default(""),
    NAME1: stringType().default(""),
    TER_SUB_ID: stringType().default("")
  })).min(1, "Select at least one row")
}).parse(d)).handler(createZnfa_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CREATE_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CREATE_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CREATE_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const userId = data.user_id.trim();
  const action = data.action;
  const payload = {
    RATE: action === "RATE" ? "X" : "",
    CHANGE: action === "CHANGE" ? "X" : "",
    DISPLAY: action === "DISPLAY" ? "X" : "",
    ATTACHMENTS: action === "ATTACHMENTS" ? "X" : "",
    USER_ID: userId,
    DATA: data.data
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/+$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs: payload,
      raw: true
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
    bodyOut = JSON.stringify(payload);
    headers["Content-Type"] = "application/json";
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `znfa-create network: ${errMsg}`
    });
    return {
      output: null,
      error: `Could not reach SAP at ${cfg.endpoint_url.split("?")[0]}. ${errMsg}. The endpoint may be on a private network not accessible from this server.`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  console.log("[znfa-create] proxied=", proxied, "useProxy=", useProxy, "target=", target.split("?")[0]);
  console.log("[znfa-create] res.status=", res.status, "res.ok=", res.ok, "text.len=", text.length);
  console.log("[znfa-create] text.preview=", text.slice(0, 500));
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `znfa-create: ${message} ${text.slice(0, 500)}`
    });
    return {
      output: null,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `znfa-create: invalid JSON ${text.slice(0, 500)}`
    });
    return {
      output: null,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? {} : json;
  console.log("[znfa-create] json.keys=", Object.keys(json ?? {}), "sapJson.keys=", Object.keys(sapJson ?? {}));
  const outputRoot = sapJson?.OUTPUT ?? sapJson?.output ?? sapJson ?? {};
  console.log("[znfa-create] outputRoot.keys=", Object.keys(outputRoot ?? {}));
  const itemsRaw = Array.isArray(outputRoot?.ITEMS) ? outputRoot.ITEMS : Array.isArray(outputRoot?.items) ? outputRoot.items : [];
  const ratingsRaw = Array.isArray(outputRoot?.RATINGS) ? outputRoot.RATINGS : Array.isArray(outputRoot?.ratings) ? outputRoot.ratings : [];
  const attachmentsRaw = action === "ATTACHMENTS" && Array.isArray(outputRoot) ? outputRoot : [];
  const output = {
    PR_NUMBER: pick(outputRoot, "PR_NUMBER"),
    PR_DATE: pick(outputRoot, "PR_DATE"),
    TER_SUB_ID: pick(outputRoot, "TER_SUB_ID"),
    ITEMS: itemsRaw.map((it) => ({
      SR_NO: pick(it, "SR_NO"),
      MATERIAL: pick(it, "MATERIAL"),
      DESCRIPTION: pick(it, "DESCRIPTION"),
      TENDER_SPEC: pick(it, "TENDER_SPEC"),
      UOM: pick(it, "UOM"),
      VENDOR_NAME: pick(it, "VENDOR_NAME"),
      REMARKS: pick(it, "REMARKS")
    })),
    RATINGS: ratingsRaw.map((r) => ({
      VENDOR: pick(r, "VENDOR"),
      RATE: pick(r, "RATE")
    })),
    ATTACHMENTS: attachmentsRaw.map((a) => ({
      NAME: pick(a, "NAME"),
      CREATED_BY: pick(a, "CREATED_BY"),
      CREATED_ON: pick(a, "CREATED_ON")
    }))
  };
  console.log("[znfa-create] output.ITEMS.len=", output.ITEMS?.length, "output.RATINGS.len=", output.RATINGS?.length, "output.ATTACHMENTS.len=", output.ATTACHMENTS?.length, "PR_NUMBER=", output.PR_NUMBER);
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: (output.ITEMS?.length ?? 0) + (output.RATINGS?.length ?? 0) + (output.ATTACHMENTS?.length ?? 0),
    message: `znfa-create: ${action} ${message}`
  });
  return {
    output,
    error: null
  };
});
const ItemSchema = objectType({
  SR_NO: stringType().default(""),
  MATERIAL: stringType().default(""),
  DESCRIPTION: stringType().default(""),
  TENDER_SPEC: stringType().default(""),
  UOM: stringType().default(""),
  VENDOR_NAME: stringType().default(""),
  REMARKS: stringType().default("")
});
const RatingSchema = objectType({
  VENDOR: stringType().default(""),
  RATE: stringType().default("")
});
const saveZnfa_createServerFn_handler = createServerRpc({
  id: "4b73b96d3bd0c464cff9d5eae0134f55b00ae74b9b007add95ba0b9b9e068235",
  name: "saveZnfa",
  filename: "src/lib/mm/gate-process.functions.ts"
}, (opts) => saveZnfa.__executeServer(opts));
const saveZnfa = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["RATE", "CHANGE"]),
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  pr_number: stringType().default(""),
  pr_date: stringType().default(""),
  ter_sub_id: stringType().default(""),
  items: arrayType(ItemSchema).default([]),
  ratings: arrayType(RatingSchema).default([])
}).parse(d)).handler(saveZnfa_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", SAVE_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${SAVE_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${SAVE_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const userId = data.user_id.trim();
  const payload = {
    PR_NUMBER: data.pr_number,
    PR_DATE: data.pr_date,
    TER_SUB_ID: data.ter_sub_id,
    USER_ID: userId,
    RATE: data.action === "RATE" ? "X" : "",
    CHANGE: data.action === "CHANGE" ? "X" : "",
    SAVE: "X",
    ITEMS: data.items,
    RATINGS: data.ratings
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/+$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs: payload,
      raw: true
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
    bodyOut = JSON.stringify(payload);
    headers["Content-Type"] = "application/json";
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg2 = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `znfa-save network: ${errMsg2}`
    });
    return {
      ok: false,
      ter_sub_id: null,
      message: null,
      error: `Could not reach SAP. ${errMsg2}`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `znfa-save: ${message} ${text.slice(0, 500)}`
    });
    return {
      ok: false,
      ter_sub_id: null,
      message: null,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      ok: false,
      ter_sub_id: null,
      message: null,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? json : json;
  const first = Array.isArray(sapJson) ? sapJson[0] : sapJson;
  const type = pick(first, "TYPE");
  const isSuccess = typeof type === "string" && type.toUpperCase() === "S";
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: isSuccess ? "ok" : "error",
    latency_ms,
    message: `znfa-save: ${message} ${text.slice(0, 300)}`
  });
  if (isSuccess) {
    return {
      ok: true,
      ter_sub_id: pick(first, "TER_SUB_ID") ?? null,
      message: pick(first, "MESSAGE") ?? "Saved successfully",
      error: null
    };
  }
  const errMsg = pick(first, "MSG") || pick(first, "MESSAGE") || "Save failed";
  return {
    ok: false,
    ter_sub_id: null,
    message: null,
    error: errMsg
  };
});
const RATING_F4_CONFIG_NAME = "ZNFA_RATINGS_F4s_API";
const fetchZnfaRatingF4_createServerFn_handler = createServerRpc({
  id: "9d2f17f213753145b1de92ac86025762818464db5226935e5f9876fce3f44459",
  name: "fetchZnfaRatingF4",
  filename: "src/lib/mm/gate-process.functions.ts"
}, (opts) => fetchZnfaRatingF4.__executeServer(opts));
const fetchZnfaRatingF4 = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(fetchZnfaRatingF4_createServerFn_handler, async () => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", RATING_F4_CONFIG_NAME).maybeSingle();
  if (!cfg) return {
    options: [],
    error: `SAP API config "${RATING_F4_CONFIG_NAME}" not found.`
  };
  if (!cfg.is_active) return {
    options: [],
    error: `SAP API config "${RATING_F4_CONFIG_NAME}" is disabled.`
  };
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "GET";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) return {
      options: [],
      error: "Proxy mode is on but no middleware URL is configured."
    };
    target = `${middlewareUrl.replace(/\/+$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs: {},
      raw: true
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    return {
      options: [],
      error: `Could not reach SAP: ${e.message}`
    };
  }
  const text = await res.text().catch(() => "");
  if (!res.ok) return {
    options: [],
    error: `SAP returned ${res.status}: ${text.slice(0, 200)}`
  };
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      options: [],
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? json : json;
  const arr = Array.isArray(sapJson) ? sapJson : Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : [];
  const set = /* @__PURE__ */ new Set();
  const options = [];
  for (const row of arr) {
    if (!row || typeof row !== "object") continue;
    const vals = Object.values(row);
    const v = vals.length > 0 ? vals[0] : null;
    if (v == null) continue;
    const s = String(v).trim();
    if (!s || set.has(s)) continue;
    set.add(s);
    options.push(s);
  }
  return {
    options,
    error: null
  };
});
export {
  createZnfa_createServerFn_handler,
  fetchGateProcess_createServerFn_handler,
  fetchZnfaRatingF4_createServerFn_handler,
  saveZnfa_createServerFn_handler
};
