import { c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { a as objectType, z as stringType, y as booleanType, D as enumType, C as arrayType, E as recordType, B as numberType } from "../_libs/zod.mjs";
const ConfigSchema = objectType({
  id: stringType().uuid().optional(),
  name: stringType().min(1).max(120),
  description: stringType().max(500).optional().nullable(),
  module: enumType(["MM", "SD", "COMMON"]).default("COMMON"),
  endpoint_url: stringType().min(1).max(500).refine((v) => /^https?:\/\//i.test(v) || v.startsWith("/"), "Endpoint must be a full http(s):// URL or a path starting with /"),
  http_method: enumType(["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"]).default("GET"),
  auth_type: enumType(["basic", "oauth", "none", "proxy"]).default("basic"),
  middleware_url: stringType().max(500).optional().nullable(),
  proxy_secret_ref: stringType().max(120).optional().nullable(),
  api_type: enumType(["sync", "fetch"]).default("fetch"),
  auto_sync_enabled: booleanType().default(false),
  schedule_cron: stringType().max(120).optional().nullable(),
  is_active: booleanType().default(true)
});
const listSapConfigs = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("4a963cfb9ad4b493470da421ecbbd1d1ce6f75bfbd35e417647e7e337aac5db8"));
const getSapConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  id: stringType().uuid()
}).parse(d)).handler(createSsrRpc("02c8eedddaf533f75bcc544a284380d5e7983a11c1d91facd0494ed671a74c07"));
const upsertSapConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ConfigSchema.parse(d)).handler(createSsrRpc("f1b044041e32d8e13bced15291cc18536b714141bcd7ae2c66472494e1d787cb"));
const deleteSapConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  id: stringType().uuid()
}).parse(d)).handler(createSsrRpc("bc43286c9bc8ef202be0cbe6c2c78dbc9e1ff49a7c74c0c3d45d9125f06aeea8"));
const FieldRowSchema = objectType({
  field_name: stringType().min(1).max(120),
  source: enumType(["static", "column", "expr", "secret"]).default("static"),
  default_value: stringType().max(500).optional().nullable(),
  required: booleanType().default(false),
  sort_order: numberType().int().default(0)
});
const replaceRequestFields = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  config_id: stringType().uuid(),
  fields: arrayType(FieldRowSchema).max(200)
}).parse(d)).handler(createSsrRpc("5f3fd7ee53cea81019769c8cfdc7b1fcff9760e35417000b46c0b38ce885b54c"));
const ResponseRowSchema = objectType({
  field_name: stringType().min(1).max(120),
  target_table: stringType().max(120).optional().nullable(),
  target_column: stringType().max(120).optional().nullable(),
  transform_expr: stringType().max(500).optional().nullable(),
  sort_order: numberType().int().default(0)
});
const replaceResponseFields = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  config_id: stringType().uuid(),
  fields: arrayType(ResponseRowSchema).max(200)
}).parse(d)).handler(createSsrRpc("90741a15444ee0f5a9109fff5ae772a9b7e9c2b6c6d4ea1502b2a81267508eb5"));
const upsertCredentials = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  config_id: stringType().uuid(),
  username: stringType().max(200).optional().nullable(),
  password: stringType().max(500).optional().nullable(),
  extra_headers: recordType(stringType(), stringType()).optional()
}).parse(d)).handler(createSsrRpc("4deca62d6cda48679a364b7cc9d2dfda967aef43bbc8911ec5608ba336f9e038"));
const testSapConnection = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  id: stringType().uuid()
}).parse(d)).handler(createSsrRpc("1b4d251d4de26af9621ab12d16e20a97d56bf17f97f7438beeb8bd3288a0368d"));
export {
  replaceResponseFields as a,
  upsertCredentials as b,
  deleteSapConfig as d,
  getSapConfig as g,
  listSapConfigs as l,
  replaceRequestFields as r,
  testSapConnection as t,
  upsertSapConfig as u
};
