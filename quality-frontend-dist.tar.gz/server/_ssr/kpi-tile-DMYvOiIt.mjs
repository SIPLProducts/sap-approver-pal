import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
const accentBar = {
  gold: "bg-gradient-gold",
  primary: "bg-gradient-primary",
  info: "bg-info",
  success: "bg-success",
  warning: "bg-warning",
  destructive: "bg-destructive"
};
function KpiTile({ label, value, delta, sub, icon, accent = "primary", lead = false, className }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: cn(
        "group relative overflow-hidden rounded-xl border bg-card p-4 sm:p-5 shadow-card transition-shadow hover:shadow-elegant",
        lead && "ring-1 ring-gold/40",
        className
      ),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("absolute inset-x-0 top-0 h-[3px]", accentBar[accent]) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground", children: label }),
          icon && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground/70", children: icon })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex items-baseline gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-3xl sm:text-[34px] font-semibold tracking-tight tabular-nums leading-none", children: value }),
          delta && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: cn(
                "text-[11px] font-medium tabular-nums",
                delta.trend === "up" && "text-success",
                delta.trend === "down" && "text-destructive",
                delta.trend === "flat" && "text-muted-foreground"
              ),
              children: [
                delta.trend === "up" ? "▲" : delta.trend === "down" ? "▼" : "—",
                " ",
                delta.value
              ]
            }
          )
        ] }),
        sub && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 text-[11px] text-muted-foreground", children: sub })
      ]
    }
  );
}
export {
  KpiTile as K
};
