import process from "node:process";
import { Buffer } from "node:buffer";
function basicAuth() {
  const u = process.env.SAP_USER;
  const p = process.env.SAP_PASSWORD;
  if (!u || !p) throw new Error("SAP credentials not configured");
  return "Basic " + Buffer.from(`${u}:${p}`).toString("base64");
}
function sapEnabled() {
  return process.env.SAP_USE_REAL === "true" && !!process.env.SAP_BASE_URL;
}
async function sapFetch(path, opts = {}) {
  const base = process.env.SAP_BASE_URL.replace(/\/$/, "");
  const headers = {
    Authorization: basicAuth(),
    Accept: "application/json"
  };
  if (opts.method === "POST") {
    headers["Content-Type"] = "application/json";
    headers["x-csrf-token"] = opts.csrfToken ?? "fetch";
  }
  const res = await fetch(`${base}${path}`, {
    method: opts.method ?? "GET",
    headers,
    body: opts.body ? JSON.stringify(opts.body) : void 0
  });
  return res;
}
async function fetchCsrfToken() {
  const base = process.env.SAP_BASE_URL.replace(/\/$/, "");
  const res = await fetch(`${base}/api/csrf`, {
    method: "GET",
    headers: { Authorization: basicAuth(), "x-csrf-token": "fetch" }
  });
  return res.headers.get("x-csrf-token") ?? "";
}
async function fetchOpenApprovals(docType, sinceIso) {
  const qs = new URLSearchParams();
  const res = await sapFetch(`/api/approvals?${qs.toString()}`);
  if (!res.ok) {
    console.error("SAP fetchOpenApprovals failed", res.status, await res.text().catch(() => ""));
    return [];
  }
  const json = await res.json();
  return json.items ?? [];
}
async function postDecision(input) {
  const csrf = await fetchCsrfToken();
  const res = await sapFetch(`/api/approvals/${encodeURIComponent(input.sapDocNo)}/decision`, {
    method: "POST",
    csrfToken: csrf,
    body: {
      action: input.action,
      comments: input.comments ?? "",
      role: input.role,
      step_seq: input.stepSeq,
      actor_sap_id: ""
    }
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`SAP decision rejected: ${res.status} ${text}`);
  }
  return res.json().catch(() => ({}));
}
async function invokeViaMiddleware(configId, inputs = {}) {
  const { supabaseAdmin } = await import("./client.server-D5ro3rAQ.mjs");
  const [{ data: g }, { data: gs }] = await Promise.all([
    supabaseAdmin.from("sap_global_settings").select("middleware_url").eq("id", "default").maybeSingle(),
    supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()
  ]);
  if (!g?.middleware_url) {
    throw new Error("Node.js Middleware URL is not configured. Set it in SAP API Settings → Middleware Configuration.");
  }
  const url = `${g.middleware_url.replace(/\/$/, "")}/sap/invoke`;
  const headers = { "Content-Type": "application/json" };
  if (gs?.proxy_secret) headers["x-shared-secret"] = gs.proxy_secret;
  const t0 = Date.now();
  try {
    const res = await fetch(url, { method: "POST", headers, body: JSON.stringify({ configId, inputs }) });
    const body = await res.json().catch(() => ({}));
    if (res.status === 401) {
      const middlewareErr = typeof body.error === "string" ? body.error : "Invalid or missing x-shared-secret";
      return {
        ok: false,
        status: 401,
        latency_ms: Date.now() - t0,
        data: body.data ?? null,
        error: gs?.proxy_secret ? `Proxy Secret mismatch — middleware rejected the shared secret (${middlewareErr}). Re-enter the Proxy Secret in SAP API Settings → Middleware Configuration so it matches MIDDLEWARE_SHARED_SECRET on the middleware host.` : `Proxy Secret is not configured in the app. Set it in SAP API Settings → Middleware Configuration (must match MIDDLEWARE_SHARED_SECRET on the middleware host).`
      };
    }
    return {
      ok: !!body.ok,
      status: typeof body.status === "number" ? body.status : res.status,
      latency_ms: typeof body.latency_ms === "number" ? body.latency_ms : Date.now() - t0,
      data: body.data ?? null,
      error: typeof body.error === "string" ? body.error : void 0
    };
  } catch (e) {
    return { ok: false, status: 0, latency_ms: Date.now() - t0, data: null, error: e.message };
  }
}
export {
  fetchCsrfToken,
  fetchOpenApprovals,
  invokeViaMiddleware,
  postDecision,
  sapEnabled
};
