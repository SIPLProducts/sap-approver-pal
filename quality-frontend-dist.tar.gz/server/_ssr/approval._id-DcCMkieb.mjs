import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQueryClient, a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { B as Badge } from "./badge-DyfXZgLs.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { T as Textarea } from "./textarea-DSyJ1nlY.mjs";
import { S as Skeleton } from "./skeleton-C5WX2eNf.mjs";
import { a as SkeletonRows } from "./skeleton-rows-C2wJYLiJ.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { S as StatusBadge } from "./status-badge-CHGzK-xV.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";
import { a as formatCurrency, b as formatDate, c as formatQuantity, f as formatDateTime } from "./format-D-HjDoz6.mjs";
import { D as DOC_TYPE_LABELS, R as ROLE_LABELS } from "./constants-BH6qBFMC.mjs";
import { u as useServerFn } from "./createSsrRpc-XOrxmi8L.mjs";
import { d as decideStep } from "./sap.functions-BddyAsKl.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as useAuth } from "./use-auth-CXN9VXh3.mjs";
import { a as Route$p } from "./router-dzu71i9y.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/web-push.mjs";

import { a4 as ArrowLeft, a5 as FileQuestionMark, C as CircleCheck, y as CircleX, w as CornerUpLeft, z as Clock, o as Check } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";

import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "./server-CeMw7B2X.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "./auth-middleware-BtdUo7VX.mjs";
import "../_libs/zod.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "./client.server-D5ro3rAQ.mjs";
import "./sap-client.server-CglbxEth.mjs";
import "./push.server-Co_uxbPF.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";

import "../_libs/asn1.js.mjs";
import "../_libs/bn.js.mjs";
import "../_libs/inherits.mjs";
import "../_libs/safer-buffer.mjs";
import "../_libs/minimalistic-assert.mjs";
import "../_libs/jws.mjs";

import "../_libs/safe-buffer.mjs";
import "../_libs/jwa.mjs";
import "../_libs/ecdsa-sig-formatter.mjs";
import "../_libs/buffer-equal-constant-time.mjs";
import "../_libs/http_ece.mjs";
import "../_libs/https-proxy-agent.mjs";



import "../_libs/debug.mjs";
import "../_libs/ms.mjs";
import "../_libs/supports-color.mjs";

import "../_libs/has-flag.mjs";
import "../_libs/agent-base.mjs";
function ApprovalDetail() {
  const {
    id
  } = Route$p.useParams();
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const nav = useNavigate();
  const decide = useServerFn(decideStep);
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const [comments, setComments] = reactExports.useState("");
  const [busy, setBusy] = reactExports.useState(null);
  const {
    data: doc,
    isLoading: docLoading,
    isError: docError
  } = useQuery({
    queryKey: ["doc", id],
    queryFn: async () => (await supabase.from("approval_documents").select("*").eq("id", id).maybeSingle()).data
  });
  const {
    data: steps = []
  } = useQuery({
    queryKey: ["steps", id],
    queryFn: async () => (await supabase.from("approval_steps").select("*").eq("document_id", id).order("seq")).data ?? []
  });
  const {
    data: lines = []
  } = useQuery({
    queryKey: ["lines", id],
    queryFn: async () => (await supabase.from("approval_line_items").select("*").eq("document_id", id).order("line_no")).data ?? []
  });
  if (docLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack max-w-5xl mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-64" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-6 space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-40" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-7 w-80" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-56" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "p-5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { rows: 5, columns: 6 }) })
    ] });
  }
  if (docError || !doc) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "page-shell page-stack max-w-3xl mx-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(FileQuestionMark, { className: "h-5 w-5", "aria-hidden": true }), title: "Approval not found", description: "This document may have been withdrawn, already actioned, or you no longer have access to it.", action: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/inbox", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4 mr-1" }),
      " Back to inbox"
    ] }) }) }) });
  }
  const currentStep = steps.find((s) => s.seq === doc.current_step_seq);
  const canAct = !!currentStep && currentStep.assigned_user === user?.id && currentStep.status === "pending" && doc.status === "pending";
  const meta = DOC_TYPE_LABELS[doc.doc_type];
  async function act(action) {
    if ((action === "reject" || action === "send_back") && !comments.trim()) {
      toast.error("Please add a comment");
      return;
    }
    const label = action === "approve" ? "Approve" : action === "reject" ? "Reject" : "Send back";
    if (action !== "approve") {
      const ok = await confirm({
        title: `${label} this document?`,
        description: action === "reject" ? "Rejecting closes this approval and notifies the requester. This cannot be undone." : "The document goes back to the previous step for rework.",
        confirmLabel: label,
        destructive: action === "reject"
      });
      if (!ok) return;
    }
    setBusy(action);
    try {
      await decide({
        data: {
          documentId: id,
          action,
          comments: comments.trim() || void 0
        }
      });
      toast.success(`${action === "approve" ? "Approved" : action === "reject" ? "Rejected" : "Sent back"}`);
      qc.invalidateQueries();
      nav({
        to: "/inbox"
      });
    } catch (e) {
      toast.error(e.message ?? "Action failed");
    } finally {
      setBusy(null);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack max-w-5xl mx-auto", children: [
    confirmDialog,
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/inbox", className: "inline-flex items-center text-sm text-muted-foreground hover:text-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4 mr-1" }),
      " Back to inbox"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: `${doc.module} · ${meta?.tcode ?? doc.sap_doc_no}`, title: doc.title, subtitle: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "SAP Doc ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: doc.sap_doc_no }),
      " · Raised by ",
      doc.requester_name,
      " ",
      "(",
      doc.requester_sap_id,
      ") on ",
      formatDate(doc.document_date)
    ] }), meta: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "outline", children: [
        doc.plant,
        " / ",
        doc.business_unit
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: doc.status })
    ] }), actions: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-semibold tabular-nums", children: formatCurrency(doc.total_value) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground", children: "Total value" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-5 lg:grid-cols-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "card-pad lg:col-span-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-semibold mb-3", children: "Line items" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "table-scroll", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "data-table text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "#" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Material" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Description" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "num", children: "Qty" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "num", children: "Rate" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "num", children: "Amount" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
            lines.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: l.line_no }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "font-mono text-xs", children: l.material_code }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: l.description }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "num", children: formatQuantity(l.quantity, l.uom) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "num", children: formatCurrency(l.unit_price) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "num font-medium", children: formatCurrency(l.amount) })
            ] }, l.id)),
            !lines.length && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 6, className: "py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { title: "No line items", description: "This document was raised without item detail in SAP.", className: "border-0 bg-transparent py-4" }) }) })
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "card-pad", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-semibold mb-3", children: "Approval trail" }),
        steps.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { title: "No trail yet", description: "Approval steps appear here once the workflow starts.", className: "border-0 bg-transparent py-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("ol", { className: "space-y-3", children: steps.map((s) => {
          const isCurrent = s.seq === doc.current_step_seq && s.status === "pending";
          const icon = s.status === "approved" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-4 w-4 text-success", "aria-hidden": true }) : s.status === "rejected" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-4 w-4 text-destructive", "aria-hidden": true }) : s.status === "sent_back" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CornerUpLeft, { className: "h-4 w-4 text-warning", "aria-hidden": true }) : isCurrent ? /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-4 w-4 text-primary", "aria-hidden": true }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4 text-muted-foreground", "aria-hidden": true });
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: `flex items-start gap-3 p-2 rounded-md ${isCurrent ? "bg-accent" : ""}`, children: [
            icon,
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-medium", children: [
                "Step ",
                s.seq,
                ": ",
                ROLE_LABELS[s.role]
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground capitalize", children: [
                s.status,
                s.decided_at ? ` • ${formatDateTime(s.decided_at)}` : ""
              ] }),
              s.comments && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs italic mt-1", children: [
                '"',
                s.comments,
                '"'
              ] })
            ] })
          ] }, s.id);
        }) })
      ] })
    ] }),
    canAct && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "card-pad", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-semibold mb-3", children: "Your decision" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { placeholder: "Add comments (required for reject / send back)…", value: comments, onChange: (e) => setComments(e.target.value), rows: 3 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => act("approve"), disabled: !!busy, variant: "success", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-4 w-4 mr-2" }),
          " Approve"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => act("send_back"), disabled: !!busy, variant: "outline", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CornerUpLeft, { className: "h-4 w-4 mr-2" }),
          " Send back"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => act("reject"), disabled: !!busy, variant: "destructive", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-4 w-4 mr-2" }),
          " Reject"
        ] })
      ] })
    ] })
  ] });
}
export {
  ApprovalDetail as component
};
