import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { b as useMutation, a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { a as SkeletonRows } from "./skeleton-rows-C2wJYLiJ.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { A as Alert, b as AlertTitle, a as AlertDescription } from "./alert-C6rylLLk.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { T as Textarea } from "./textarea-DSyJ1nlY.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BhFPQiYt.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-CZRUt5a6.mjs";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, d as DialogDescription } from "./dialog--up_DbYf.mjs";
import { u as useActiveContext, r as releaseKeysFor } from "./use-active-context-CMJTykFM.mjs";
import { useSapProfile } from "./use-sap-profile-DRIQ-_33.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";
import { P as Popover, a as PopoverTrigger, b as PopoverContent, C as Command, c as CommandInput, d as CommandList, e as CommandEmpty, f as CommandGroup, g as CommandItem } from "./command-i9zWGkU5.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";

import "../_libs/seroval.mjs";
import { aa as Funnel, ad as KeyRound, x as TriangleAlert, ae as ListChecks, o as Check, X, a4 as ArrowLeft, af as MessageSquare, ag as MessagesSquare, a3 as LoaderCircle, t as Eye, q as Search, ah as UserRound, ai as Wrench, aj as Award, k as ChevronDown, a9 as ChevronRight, ak as Paperclip, n as ChevronsUpDown } from "../_libs/lucide-react.mjs";
import { a as objectType, z as stringType, D as enumType, y as booleanType } from "../_libs/zod.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "./client-CXnFcWf4.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "./screen-keys-mn2QOK0m.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-popover.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/tailwind-merge.mjs";
const fetchZnfaRelease = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user: stringType().trim().min(1, "SAP user id is required").max(30),
  relCode: stringType().trim().min(1, "Release Code is required").max(10),
  mode: enumType(["release", "app_list"]).default("release")
}).parse(d)).handler(createSsrRpc("ffb411bfba880fa33bd124f84a1fc903400081cef14611e19644999a1247ccba"));
const fetchZnfaDisplay = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  znfaNum: stringType().trim().min(1, "Main NFA Number is required").max(60)
}).parse(d)).handler(createSsrRpc("f0a6262092bad707ee5aed03cda207d75025e3652f20b17dcdb7736ff13edb70"));
const fetchZnfaClick = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  znfaNum: stringType().trim().min(1, "NFA Number is required").max(60),
  relCode: stringType().trim().max(10).optional().default("")
}).parse(d)).handler(createSsrRpc("7e864f52f21aaabcf6c8d4c86f03c7b0e4d48da7a2eb5961bf6dc44c25d8a8ed"));
const fetchZnfaPrint = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  znfaNum: stringType().trim().min(1, "NFA Number is required").max(60),
  relCode: stringType().trim().max(120).optional().default(""),
  nfaType: stringType().trim().max(120).optional().default("")
}).parse(d)).handler(createSsrRpc("1e5e814a51157b01d583ff19626620cd7a897297f833c446441ee151e9b6daff"));
const approveZnfa = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  znfaNum: stringType().trim().min(1, "NFA number is required").max(60),
  user: stringType().trim().min(1, "SAP user id is required").max(30),
  relCode: stringType().trim().min(1, "Release Code is required").max(10),
  reject: booleanType().default(false),
  reason: stringType().trim().max(500).default(""),
  clarify: booleanType().default(false),
  clarifyText: stringType().max(5e3).default(""),
  disClarify: booleanType().default(false)
}).parse(d)).handler(createSsrRpc("5618c2277fc49fa5461e378768e88786ab968ac4962130d80c22e0ff956350e7"));
const fetchZnfaNfaList = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user: stringType().trim().min(1, "SAP user id is required").max(60)
}).parse(d)).handler(createSsrRpc("46d8b9e944afc55cfbafa22398c29b77c8cdc3f2fea37a8ddd0da2100e324b5f"));
function NfaNumberSelect({
  value,
  onChange,
  user,
  disabled,
  className,
  placeholder = "Select NFA number…"
}) {
  const [open, setOpen] = reactExports.useState(false);
  const fetchList = useServerFn(fetchZnfaNfaList);
  const listQuery = useQuery({
    queryKey: ["znfa-nfa-list", user],
    queryFn: () => fetchList({ data: { user } }),
    enabled: !!user.trim(),
    staleTime: 5 * 60 * 1e3
  });
  const options = reactExports.useMemo(() => listQuery.data?.numbers ?? [], [listQuery.data]);
  const sapMessage = listQuery.data?.sapMessage ?? listQuery.data?.error ?? null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "outline",
        role: "combobox",
        "aria-expanded": open,
        disabled,
        className: cn(
          "h-9 w-full max-w-[420px] justify-between",
          !value && "font-sans text-muted-foreground",
          className
        ),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: cn("truncate text-left", value && "font-mono text-xs"), children: value || placeholder }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronsUpDown, { className: "ml-2 h-3.5 w-3.5 shrink-0 opacity-50" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PopoverContent,
      {
        className: "z-[1000] max-h-[60vh] w-[340px] p-0",
        align: "start",
        side: "bottom",
        sideOffset: 6,
        avoidCollisions: false,
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Command, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CommandInput, { placeholder: "Search NFA number…", className: "h-9" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CommandList, { className: "max-h-[calc(60vh-3rem)]", children: listQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 py-6 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Fetching NFA numbers…"
          ] }) : listQuery.isError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 px-3 py-4 text-xs text-destructive", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: "Failed to load NFA numbers." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "break-words text-[11px] opacity-80", children: listQuery.error?.message ?? "Unknown error" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "underline", onClick: () => listQuery.refetch(), children: "Retry" })
          ] }) : options.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-xs text-muted-foreground", children: sapMessage ?? "No NFA numbers returned. Check SAP API Settings." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CommandEmpty, { children: "No NFA number found." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CommandGroup, { children: options.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              CommandItem,
              {
                value: n,
                onSelect: () => {
                  onChange(n === value ? "" : n);
                  setOpen(false);
                },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Check,
                    {
                      className: cn("mr-2 h-3.5 w-3.5", value === n ? "opacity-100" : "opacity-0")
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-xs", children: n })
                ]
              },
              n
            )) })
          ] }) })
        ] })
      }
    )
  ] });
}
const DEFAULT_ACTIONS = ["Release", "Display", "Approved List"];
const SCOPE_CATEGORIES = [{
  id: "supply",
  label: "Supply",
  sapField: "SUPPLY"
}, {
  id: "installation",
  label: "Installation",
  sapField: "INSTALLATION"
}, {
  id: "construction-all",
  label: "Construction works including all supplies",
  sapField: "CONSTRUCTION_S"
}, {
  id: "construction-fim",
  label: "Construction with FIM (Free issue Material)",
  sapField: "CONSTRUCTION_R"
}, {
  id: "supervision",
  label: "Supervision",
  sapField: "SUPERVISION"
}, {
  id: "commissioning",
  label: "Commissioning",
  sapField: "COMMISION"
}, {
  id: "service",
  label: "Service",
  sapField: "SERVICES"
}, {
  id: "arc",
  label: "ARC",
  sapField: "ARC"
}];
function isSapFlag(v) {
  return String(v ?? "").trim().toUpperCase() === "X";
}
const PR_DETAIL_COLUMNS = [{
  key: "BANFN",
  label: "PR No"
}, {
  key: "BNFPO",
  label: "PR Item"
}, {
  key: "MATNR",
  label: "Material"
}, {
  key: "TXZ01",
  label: "Item Text",
  divider: true
}, {
  key: "MENGE",
  label: "Qty",
  numeric: true
}, {
  key: "MEINS",
  label: "UOM"
}, {
  key: "WERKS",
  label: "Plant"
}, {
  key: "NAME1",
  label: "Plant Name"
}, {
  key: "PR_APP_DATE",
  label: "PR Date"
}];
const RELEASE_RESULT_COLUMNS = [{
  key: "NFA_NO",
  label: "NFA No"
}, {
  key: "LIFNR",
  label: "Vendor Code"
}, {
  key: "EKGRP",
  label: "Purch. Group"
}, {
  key: "NAME1",
  label: "Vendor Name"
}, {
  key: "WERKS",
  label: "Plant"
}, {
  key: "WERKS_NAME",
  label: "Plant Name"
}, {
  key: "VENDOR_RATE",
  label: "Vendor Rate"
}, {
  key: "TER_RATE",
  label: "TER Rate"
}, {
  key: "TOTAL",
  label: "Total",
  numeric: true
}, {
  key: "TITLE",
  label: "Title"
}, {
  key: "NFA_DATE",
  label: "NFA Date"
}, {
  key: "RELEASE",
  label: "Release"
}, {
  key: "ACCEP_REJECT",
  label: "Accept/Reject"
}];
const REL_MATX_COLUMNS = [{
  key: "NFA_NO",
  label: "NFA No"
}, {
  key: "REL_CODE",
  label: "Release Code"
}, {
  key: "APPROVER",
  label: "Approver"
}, {
  key: "APP_NAME",
  label: "Approver Name"
}, {
  key: "FRGCT",
  label: "Release Group"
}, {
  key: "STATUS",
  label: "Status"
}, {
  key: "APPROVER_DATE",
  label: "Approver Date"
}, {
  key: "REL_SEQUENCE",
  label: "Sequence"
}];
const FINAL_RECOMMENDATION_COLUMNS = [{
  key: "APP_VENDOR",
  label: "Recommended Vendor",
  checkbox: true
}, {
  key: "EBELN",
  label: "RFQ Number"
}, {
  key: "LIFNR",
  label: "Vendor Code"
}, {
  key: "EKGRP",
  label: "Purchasing Group"
}, {
  key: "NAME1",
  label: "Vendor Name"
}, {
  key: "WERKS",
  label: "Plant"
}, {
  key: "VENDOR_RATE",
  label: "Commercial Rating"
}, {
  key: "TER_RATE",
  label: "TER Rating"
}, {
  key: "BASIC_COST",
  label: "Basic Cost",
  numeric: true
}, {
  key: "WAERS",
  label: "Currency"
}, {
  key: "TAX",
  label: "Tax",
  numeric: true
}, {
  key: "DISCOUNT",
  label: "Discount",
  numeric: true
}, {
  key: "FREIGHT",
  label: "Freight/Transportation",
  numeric: true
}, {
  key: "PACK_FWD",
  label: "Packing & Forward Charges",
  numeric: true
}, {
  key: "TOTAL",
  label: "Total",
  numeric: true
}, {
  key: "REMARKS",
  label: "Remarks"
}];
function cellText(row, column) {
  const primary = row[column.key];
  const secondary = column.also ? row[column.also] : void 0;
  const parts = [primary, secondary].filter((v) => v !== null && v !== void 0 && String(v).trim() !== "").map((v) => String(v).trim());
  return parts.length ? parts.join(" / ") : "—";
}
function DetailsTableCard({
  title,
  emptyText,
  columns = PR_DETAIL_COLUMNS,
  rows
}) {
  const data = rows ?? [];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ListChecks, { className: "h-3.5 w-3.5" }),
      " ",
      title
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "w-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Select" }) }),
        columns.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: cn("whitespace-nowrap text-xs", c.numeric && "text-right", c.divider && "min-w-[320px] border-r border-border"), children: c.label }, c.key))
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: data.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: columns.length + 1, className: "h-28 text-center text-sm text-muted-foreground", children: emptyText }) }) : data.map((row, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "w-10" }),
        columns.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: cn("text-sm", c.numeric ? "whitespace-nowrap text-right tabular-nums" : "whitespace-nowrap", c.divider && "min-w-[320px] whitespace-normal border-r border-border"), children: c.checkbox ? /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: isSapFlag(row[c.key]), disabled: true, "aria-label": c.label }) : cellText(row, c) }, c.key))
      ] }, `${title}-${i}`)) })
    ] }) })
  ] });
}
const PR_ITEM_COLUMNS = [{
  key: "BNFPO",
  label: "PR Item"
}, {
  key: "MATNR",
  label: "Material / Services"
}, {
  key: "TXZ01",
  label: "Item Text",
  divider: true
}, {
  key: "BADAT",
  label: "PR Creation Date"
}, {
  key: "ERNAM",
  label: "Created By"
}, {
  key: "MENGE",
  label: "Qty",
  numeric: true
}, {
  key: "MEINS",
  label: "UOM"
}, {
  key: "PR_APP_DATE",
  label: "PR Approval Date"
}, {
  key: "WERKS",
  label: "Plant"
}, {
  key: "NAME1",
  label: "Plant Name"
}];
function PrDetailsTreeCard({
  rows,
  emptyText
}) {
  const data = rows ?? [];
  const [expanded, setExpanded] = reactExports.useState(/* @__PURE__ */ new Set());
  const groups = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const row of data) {
      const key = String(row?.BANFN ?? "").trim() || "—";
      const list = map.get(key);
      if (list) list.push(row);
      else map.set(key, [row]);
    }
    return Array.from(map.entries()).map(([pr, items]) => ({
      pr,
      items
    }));
  }, [data]);
  const toggle = (pr) => setExpanded((prev) => {
    const next = new Set(prev);
    if (next.has(pr)) next.delete(pr);
    else next.add(pr);
    return next;
  });
  const colCount = PR_ITEM_COLUMNS.length + 1;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ListChecks, { className: "h-3.5 w-3.5" }),
      " PR DETAILS"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "w-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Expand" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "whitespace-nowrap text-xs", children: "Purchase Requisition No" }),
        PR_ITEM_COLUMNS.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: cn("whitespace-nowrap text-xs", c.numeric && "text-right", c.divider && "min-w-[320px] border-r border-border"), children: c.label }, c.key))
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: groups.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: colCount + 1, className: "h-28 text-center text-sm text-muted-foreground", children: emptyText }) }) : groups.map((group) => {
        const isOpen = expanded.has(group.pr);
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { className: "cursor-pointer bg-muted/30", onClick: () => toggle(group.pr), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "w-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", "aria-label": isOpen ? "Collapse" : "Expand", "aria-expanded": isOpen, onClick: (e) => {
              e.stopPropagation();
              toggle(group.pr);
            }, className: "flex h-6 w-6 items-center justify-center rounded hover:bg-muted", children: isOpen ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4" }) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "whitespace-nowrap text-sm font-medium", children: group.pr }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(TableCell, { colSpan: PR_ITEM_COLUMNS.length, className: "whitespace-nowrap text-xs text-muted-foreground", children: [
              group.items.length,
              " item",
              group.items.length === 1 ? "" : "s"
            ] })
          ] }),
          isOpen && group.items.map((row, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "w-10" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, {}),
            PR_ITEM_COLUMNS.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: cn("text-sm", c.numeric ? "whitespace-nowrap text-right tabular-nums" : "whitespace-nowrap", c.divider && "min-w-[320px] whitespace-normal border-r border-border"), children: cellText(row, c) }, c.key))
          ] }, `pr-${group.pr}-item-${i}`))
        ] }, `pr-${group.pr}`);
      }) })
    ] }) })
  ] });
}
const RFQ_ITEM_COLUMNS = [{
  key: "ANFNR",
  label: "RFQ No"
}, {
  key: "ANFPS",
  label: "RFQ Item"
}, {
  key: "WERKS",
  label: "Plant"
}, {
  key: "MATNR",
  label: "Material / Services"
}, {
  key: "TXZ01",
  label: "Item Text",
  divider: true
}, {
  key: "ANMNG",
  label: "Qty",
  numeric: true
}, {
  key: "MEINS",
  label: "UOM"
}, {
  key: "FINAL_RATE",
  label: "Unit Rate",
  numeric: true
}, {
  key: "WAERS",
  label: "Currency"
}, {
  key: "BASIC_COST",
  label: "Basic Rate",
  numeric: true
}, {
  key: "TAX",
  label: "Tax",
  numeric: true
}, {
  key: "MWSKZ",
  label: "Tax Code"
}, {
  key: "DISCOUNT",
  label: "Discount",
  numeric: true
}, {
  key: "FREIGHT",
  label: "Freight / Transportation",
  numeric: true
}, {
  key: "PACK_FWD",
  label: "Packing & Forwarding",
  numeric: true
}, {
  key: "TOTAL",
  label: "Final Rate",
  numeric: true
}, {
  key: "FINAL_REV",
  label: "Final Revision"
}, {
  key: "TER_RATE",
  label: "TE Rating"
}, {
  key: "TER_NAME",
  label: "Evaluator"
}];
function RfqDetailsTreeCard({
  rows,
  emptyText
}) {
  const data = rows ?? [];
  const [expanded, setExpanded] = reactExports.useState(/* @__PURE__ */ new Set());
  const groups = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const row of data) {
      const code = String(row?.LIFNR ?? "").trim();
      const name = String(row?.NAME1 ?? "").trim();
      const key = code || name || "—";
      const label = [name, code].filter(Boolean).join(" / ") || "—";
      const existing = map.get(key);
      if (existing) {
        existing.items.push(row);
      } else {
        map.set(key, {
          label,
          items: [row]
        });
      }
    }
    return Array.from(map.entries()).map(([key, group]) => ({
      key,
      ...group
    }));
  }, [data]);
  const toggle = (key) => setExpanded((prev) => {
    const next = new Set(prev);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    return next;
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ListChecks, { className: "h-3.5 w-3.5" }),
      " RFQ DETAILS"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "w-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Expand" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "whitespace-nowrap text-xs", children: "Vendor Name / Vendor Code" }),
        RFQ_ITEM_COLUMNS.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: cn("whitespace-nowrap text-xs", c.numeric && "text-right", c.divider && "min-w-[320px] border-r border-border"), children: c.label }, c.key))
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: groups.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: RFQ_ITEM_COLUMNS.length + 2, className: "h-28 text-center text-sm text-muted-foreground", children: emptyText }) }) : groups.map((group) => {
        const isOpen = expanded.has(group.key);
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { className: "cursor-pointer bg-muted/30", onClick: () => toggle(group.key), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "w-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", "aria-label": isOpen ? "Collapse" : "Expand", "aria-expanded": isOpen, onClick: (e) => {
              e.stopPropagation();
              toggle(group.key);
            }, className: "flex h-6 w-6 items-center justify-center rounded hover:bg-muted", children: isOpen ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4" }) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "whitespace-nowrap text-sm font-medium", children: group.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(TableCell, { colSpan: RFQ_ITEM_COLUMNS.length, className: "whitespace-nowrap text-xs text-muted-foreground", children: [
              group.items.length,
              " item",
              group.items.length === 1 ? "" : "s"
            ] })
          ] }),
          isOpen && group.items.map((row, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "w-10" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, {}),
            RFQ_ITEM_COLUMNS.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: cn("text-sm", c.numeric ? "whitespace-nowrap text-right tabular-nums" : "whitespace-nowrap", c.divider && "min-w-[320px] whitespace-normal border-r border-border"), children: cellText(row, c) }, c.key))
          ] }, `rfq-${group.key}-item-${i}`))
        ] }, `rfq-${group.key}`);
      }) })
    ] }) })
  ] });
}
const EMPTY_BUYER = {
  id: "",
  name: "",
  email: "",
  location: ""
};
function ZnfaReleasePage() {
  const [mode] = reactExports.useState("release");
  const [action, setAction] = reactExports.useState(null);
  const [nfaType, setNfaType] = reactExports.useState("");
  const [rfqNumber, setRfqNumber] = reactExports.useState("");
  const [nfaTitle, setNfaTitle] = reactExports.useState("");
  const [buyer, setBuyer] = reactExports.useState(EMPTY_BUYER);
  const [scopeCategories, setScopeCategories] = reactExports.useState([]);
  const [remarks, setRemarks] = reactExports.useState("");
  const [spendCategory, setSpendCategory] = reactExports.useState("");
  const [itemCategory, setItemCategory] = reactExports.useState("");
  const [purchasingGroup, setPurchasingGroup] = reactExports.useState("");
  const [proposedToAward, setProposedToAward] = reactExports.useState("");
  const [proposedToAwardDetail, setProposedToAwardDetail] = reactExports.useState("");
  const [awardRemarks, setAwardRemarks] = reactExports.useState("");
  const [approvedBudget, setApprovedBudget] = reactExports.useState("");
  const [balanceBudget, setBalanceBudget] = reactExports.useState("");
  const {
    plants: assignedPlants,
    activePlants
  } = useActiveContext();
  const profile = useSapProfile();
  const releaseId = profile?.user ?? "";
  const nfaKeys = reactExports.useMemo(() => releaseKeysFor(assignedPlants, "nfa", activePlants), [assignedPlants, activePlants.join(",")]);
  const releaseCodes = reactExports.useMemo(() => {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const k of nfaKeys) {
      if (!k.releaseCode || seen.has(k.releaseCode)) continue;
      seen.add(k.releaseCode);
      out.push(k.releaseCode);
    }
    return out.sort((a, b) => a.localeCompare(b));
  }, [nfaKeys]);
  const [releaseCode, setReleaseCode] = reactExports.useState("");
  const [mainNfaNumber, setMainNfaNumber] = reactExports.useState("");
  const [displayConfirmed, setDisplayConfirmed] = reactExports.useState(false);
  const [displayError, setDisplayError] = reactExports.useState(null);
  const [prRows, setPrRows] = reactExports.useState([]);
  const [rfqRows, setRfqRows] = reactExports.useState([]);
  const [recommendRows, setRecommendRows] = reactExports.useState([]);
  const [attachRows, setAttachRows] = reactExports.useState([]);
  const [nfaTextRows, setNfaTextRows] = reactExports.useState([]);
  const [expandedTextVendors, setExpandedTextVendors] = reactExports.useState(/* @__PURE__ */ new Set());
  const [selectedTextKey, setSelectedTextKey] = reactExports.useState(null);
  const [relMatxRows, setRelMatxRows] = reactExports.useState([]);
  const [clickedNfaNo, setClickedNfaNo] = reactExports.useState(null);
  const [docLoaded, setDocLoaded] = reactExports.useState(false);
  const [selectedAttachKeys, setSelectedAttachKeys] = reactExports.useState([]);
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const [printOpen, setPrintOpen] = reactExports.useState(false);
  const [printDataUrl, setPrintDataUrl] = reactExports.useState(null);
  const [printBase64, setPrintBase64] = reactExports.useState(null);
  const [printError, setPrintError] = reactExports.useState(null);
  const [printMimeType, setPrintMimeType] = reactExports.useState("application/pdf");
  function applyZnfaDocument(res) {
    const z2 = res.znfa ?? {};
    setNfaType(String(z2.TYPE_NFA ?? ""));
    setNfaTitle(String(z2.TITLE ?? ""));
    setRfqNumber(String(res.rfqs[0]?.RFQ ?? ""));
    setBuyer({
      id: String(z2.BUYER_ID ?? ""),
      name: String(z2.BUYER_NAME ?? ""),
      email: String(z2.BUYER_EMAIL ?? ""),
      location: String(z2.LOCATION ?? "")
    });
    setSpendCategory(String(z2.SPENDCATEGORY ?? ""));
    setItemCategory(String(z2.ITEM_CATEGORY ?? ""));
    setPurchasingGroup(String(z2.EKGRP ?? ""));
    setRemarks(String(z2.REMARKS ?? ""));
    setScopeCategories(SCOPE_CATEGORIES.filter((c) => isSapFlag(z2[c.sapField])).map((c) => c.label));
    setApprovedBudget(z2.APP_BUDGET === null || z2.APP_BUDGET === void 0 ? "" : String(z2.APP_BUDGET));
    setBalanceBudget(z2.BAL_BUDGET === null || z2.BAL_BUDGET === void 0 ? "" : String(z2.BAL_BUDGET));
    setPrRows(res.prDet);
    setRfqRows(res.rfqDet);
    setRecommendRows(res.recommend);
    setAttachRows(res.attach);
    setRelMatxRows(res.relMatx);
    setNfaTextRows(res.nfaTexts.filter((t) => String(t.AVL_TEXTS ?? "").trim() !== ""));
    const awardRow = res.nfaTexts.find((t) => String(t.VENDOR ?? "").trim() !== "" || String(t.NAME1 ?? "").trim() !== "");
    setProposedToAward(String(awardRow?.VENDOR ?? ""));
    setProposedToAwardDetail(String(awardRow?.NAME1 ?? ""));
    setExpandedTextVendors(/* @__PURE__ */ new Set());
    setSelectedTextKey(null);
  }
  const fetchDisplay = useServerFn(fetchZnfaDisplay);
  const displayMutation = useMutation({
    mutationFn: (vars) => fetchDisplay({
      data: vars
    }),
    onSuccess: (res) => {
      const msg = (res.sapMessage?.trim() ? res.sapMessage.trim() : null) ?? res.error;
      if (msg || !res.znfa) {
        setDisplayConfirmed(false);
        if (msg) {
          setDisplayError(msg);
          toast.error(msg);
        }
        return;
      }
      const z2 = res.znfa;
      setDisplayError(null);
      applyZnfaDocument(res);
      setDocLoaded(true);
      setDisplayConfirmed(true);
      toast.success(`NFA ${z2.NFA_NO ?? ""} loaded`);
    },
    onError: () => {
      const msg = "An unexpected error occurred while loading the NFA document.";
      setDisplayConfirmed(false);
      setDisplayError(msg);
      toast.error(msg);
    }
  });
  const fetchClick = useServerFn(fetchZnfaClick);
  const clickMutation = useMutation({
    mutationFn: (vars) => fetchClick({
      data: vars
    }),
    onSuccess: (res) => {
      const msg = (res.sapMessage?.trim() ? res.sapMessage.trim() : null) ?? res.error;
      if (msg || !res.znfa) {
        setDocLoaded(false);
        setClickedNfaNo(null);
        if (msg) {
          setDisplayError(msg);
          toast.error(msg);
        }
        return;
      }
      setDisplayError(null);
      applyZnfaDocument(res);
      setDocLoaded(true);
      toast.success(`NFA ${res.znfa.NFA_NO ?? ""} loaded`);
    },
    onError: () => {
      const msg = "An unexpected error occurred while loading the NFA document.";
      setDocLoaded(false);
      setClickedNfaNo(null);
      setDisplayError(msg);
      toast.error(msg);
    }
  });
  function onNfaNoClick(nfaNo) {
    if (!nfaNo.trim()) return;
    setClickedNfaNo(nfaNo);
    setDocLoaded(false);
    setDisplayError(null);
    clickMutation.mutate({
      znfaNum: nfaNo.trim(),
      relCode: releaseCode
    });
  }
  const fetchPrint = useServerFn(fetchZnfaPrint);
  const printMutation = useMutation({
    mutationFn: (vars) => fetchPrint({
      data: vars
    }),
    onSuccess: (res) => {
      const msg = (res.sapMessage?.trim() ? res.sapMessage.trim() : null) ?? res.error;
      if (msg || !res.base64) {
        setPrintBase64(null);
        setPrintDataUrl(null);
        setPrintMimeType("application/pdf");
        setPrintError(msg || "Could not generate the preview.");
        return;
      }
      setPrintError(null);
      setPrintMimeType(res.mimeType?.trim() || "application/pdf");
      setPrintBase64(res.base64);
      setPrintDataUrl(res.dataUrl);
    },
    onError: (err) => {
      setPrintBase64(null);
      setPrintDataUrl(null);
      setPrintMimeType("application/pdf");
      const raw = String(err?.message ?? err ?? "").trim();
      const unauthorized = /401|unauthor/i.test(raw);
      setPrintError(unauthorized ? "Your session has expired. Please sign in again and retry the preview." : raw ? `Preview failed: ${raw}` : "An unexpected error occurred while generating the preview.");
    }
  });
  const [printBlobUrl, setPrintBlobUrl] = reactExports.useState(null);
  reactExports.useEffect(() => {
    if (!printBase64) {
      setPrintBlobUrl(null);
      return;
    }
    let url = null;
    try {
      let b64 = printBase64.trim().replace(/^["']+/, "").replace(/["']+$/, "");
      b64 = b64.replace(/^data:[^;,]*;base64,/i, "");
      b64 = b64.replace(/[^A-Za-z0-9+/=_-]/g, "").replace(/-/g, "+").replace(/_/g, "/").replace(/=+$/, "");
      b64 = b64.padEnd(b64.length + (4 - b64.length % 4) % 4, "=");
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
      url = URL.createObjectURL(new Blob([bytes], {
        type: printMimeType || "application/pdf"
      }));
      setPrintBlobUrl(url);
      setPrintError(null);
    } catch {
      setPrintBlobUrl(null);
      setPrintError("The document returned by SAP could not be decoded for preview.");
    }
    return () => {
      if (url) URL.revokeObjectURL(url);
    };
  }, [printBase64, printMimeType]);
  const isImagePreview = (printMimeType || "").toLowerCase().startsWith("image/");
  function printFileExtension(mime) {
    const m = (mime || "").toLowerCase().split(";")[0].trim();
    const known = {
      "application/pdf": "pdf",
      "image/png": "png",
      "image/jpeg": "jpg",
      "image/jpg": "jpg",
      "image/gif": "gif",
      "image/webp": "webp",
      "image/bmp": "bmp",
      "image/tiff": "tiff",
      "image/svg+xml": "svg"
    };
    if (known[m]) return known[m];
    const sub = m.split("/")[1]?.replace(/[^\w]+/g, "");
    return sub || "pdf";
  }
  function onDocPreview() {
    if (!openedNfaNo) {
      toast.info("Open an NFA document first to preview it.");
      return;
    }
    setPrintError(null);
    setPrintBase64(null);
    setPrintDataUrl(null);
    setPrintMimeType("application/pdf");
    setPrintOpen(true);
    printMutation.mutate({
      znfaNum: openedNfaNo,
      relCode: releaseCode,
      nfaType
    });
  }
  function onPrintDownload() {
    const href = printBlobUrl;
    if (!href) return;
    const a = document.createElement("a");
    a.href = href;
    a.download = `${(openedNfaNo || "NFA").replace(/[^\w.-]+/g, "_")}.${printFileExtension(printMimeType)}`;
    a.click();
  }
  const [releaseRows, setReleaseRows] = reactExports.useState(null);
  const [releaseError, setReleaseError] = reactExports.useState(null);
  const fetchRelease = useServerFn(fetchZnfaRelease);
  const releaseMutation = useMutation({
    mutationFn: (vars) => fetchRelease({
      data: vars
    }),
    onSuccess: (res) => {
      const msg = res.sapMessage ?? res.error;
      if (msg) {
        setReleaseRows(null);
        setReleaseError(msg);
        toast.error(msg);
        return;
      }
      setReleaseError(null);
      setReleaseRows(res.rows);
      toast.success(`${res.rows.length} record(s) loaded`);
    },
    onError: () => {
      const msg = "An unexpected error occurred while loading ZNFA records.";
      setReleaseRows(null);
      setReleaseError(msg);
      toast.error(msg);
    }
  });
  const [clarifyOpen, setClarifyOpen] = reactExports.useState(false);
  const [clarifyText, setClarifyText] = reactExports.useState("");
  const approveFn = useServerFn(approveZnfa);
  const approveMutation = useMutation({
    mutationFn: (vars) => approveFn({
      data: {
        ...vars,
        reject: false,
        reason: ""
      }
    }),
    onSuccess: (res) => {
      const msg = res.sapMessage ?? res.error;
      if (!res.ok) {
        setDisplayError(msg ?? "SAP rejected the request.");
        toast.error(msg ?? "SAP rejected the request.");
        return;
      }
      setDisplayError(null);
      toast.success(msg ? msg : `NFA released${res.number ? ` (${res.number})` : ""}`);
      onDocBack();
      if (releaseId && releaseCode) {
        releaseMutation.mutate({
          user: releaseId,
          relCode: releaseCode,
          mode: action === "Approved List" ? "app_list" : "release"
        });
      }
    },
    onError: (e) => {
      const msg = typeof e?.message === "string" && e.message.trim() ? e.message : "An unexpected error occurred while releasing the NFA.";
      setDisplayError(msg);
      toast.error(msg);
    }
  });
  const [rejectOpen, setRejectOpen] = reactExports.useState(false);
  const [rejectReason, setRejectReason] = reactExports.useState("");
  const [rejectError, setRejectError] = reactExports.useState(null);
  const rejectMutation = useMutation({
    mutationFn: (vars) => approveFn({
      data: {
        znfaNum: vars.znfaNum,
        user: vars.user,
        relCode: vars.relCode,
        reject: true,
        reason: vars.reason
      }
    }),
    onSuccess: (res) => {
      const msg = res.sapMessage ?? res.error;
      if (!res.ok) {
        setRejectError(msg ?? "SAP rejected the request.");
        toast.error(msg ?? "SAP rejected the request.");
        return;
      }
      setRejectError(null);
      setRejectOpen(false);
      setRejectReason("");
      setDisplayError(null);
      toast.success(msg ? msg : `NFA rejected${res.number ? ` (${res.number})` : ""}`);
      onDocBack();
      if (releaseId && releaseCode) {
        releaseMutation.mutate({
          user: releaseId,
          relCode: releaseCode,
          mode: action === "Approved List" ? "app_list" : "release"
        });
      }
    },
    onError: (e) => {
      const msg = typeof e?.message === "string" && e.message.trim() ? e.message : "An unexpected error occurred while rejecting the NFA.";
      setRejectError(msg);
      toast.error(msg);
    }
  });
  const [clarifyError, setClarifyError] = reactExports.useState(null);
  const clarifyMutation = useMutation({
    mutationFn: (vars) => approveFn({
      data: {
        znfaNum: vars.znfaNum,
        user: vars.user,
        relCode: vars.relCode,
        reject: false,
        reason: "",
        clarify: true,
        clarifyText: vars.clarifyText
      }
    }),
    onSuccess: (res) => {
      const msg = res.sapMessage ?? res.error;
      if (!res.ok) {
        setClarifyError(msg ?? "SAP rejected the request.");
        toast.error(msg ?? "SAP rejected the request.");
        return;
      }
      setClarifyError(null);
      setClarifyOpen(false);
      setClarifyText("");
      toast.success(msg ? msg : "Clarification mail sent.");
    },
    onError: (e) => {
      const msg = typeof e?.message === "string" && e.message.trim() ? e.message : "An unexpected error occurred while sending the clarification.";
      setClarifyError(msg);
      toast.error(msg);
    }
  });
  function submitClarify() {
    const nfaNo = openedNfaNo?.trim();
    if (!nfaNo) {
      setClarifyError("No NFA document is open.");
      return;
    }
    if (!releaseId?.trim()) {
      setClarifyError("SAP user id is missing.");
      return;
    }
    if (!releaseCode?.trim()) {
      setClarifyError("Release Code is missing.");
      return;
    }
    setClarifyError(null);
    clarifyMutation.mutate({
      znfaNum: nfaNo,
      user: releaseId.trim(),
      relCode: releaseCode.trim(),
      clarifyText
    });
  }
  const [disClarifyOpen, setDisClarifyOpen] = reactExports.useState(false);
  const [disClarifyLines, setDisClarifyLines] = reactExports.useState([]);
  const [disClarifyError, setDisClarifyError] = reactExports.useState(null);
  const disClarifyMutation = useMutation({
    mutationFn: (vars) => approveFn({
      data: {
        znfaNum: vars.znfaNum,
        user: vars.user,
        relCode: vars.relCode,
        reject: false,
        reason: "",
        clarify: false,
        clarifyText: "",
        disClarify: true
      }
    }),
    onSuccess: (res) => {
      const msg = res.sapMessage ?? res.error;
      if (!res.ok) {
        setDisClarifyLines([]);
        setDisClarifyError(msg ?? "SAP rejected the request.");
        toast.error(msg ?? "SAP rejected the request.");
        return;
      }
      setDisClarifyError(null);
      setDisClarifyLines(res.lines ?? []);
    },
    onError: (e) => {
      const msg = typeof e?.message === "string" && e.message.trim() ? e.message : "An unexpected error occurred while loading the clarification.";
      setDisClarifyLines([]);
      setDisClarifyError(msg);
      toast.error(msg);
    }
  });
  function openDisClarify() {
    const nfaNo = openedNfaNo?.trim();
    setDisClarifyLines([]);
    setDisClarifyError(null);
    setDisClarifyOpen(true);
    if (!nfaNo) {
      setDisClarifyError("No NFA document is open.");
      return;
    }
    if (!releaseId?.trim()) {
      setDisClarifyError("SAP user id is missing.");
      return;
    }
    if (!releaseCode?.trim()) {
      setDisClarifyError("Release Code is missing.");
      return;
    }
    disClarifyMutation.mutate({
      znfaNum: nfaNo,
      user: releaseId.trim(),
      relCode: releaseCode.trim()
    });
  }
  function clearReleaseResults() {
    setReleaseRows(null);
    setReleaseError(null);
    setClickedNfaNo(null);
    setDocLoaded(false);
    setDisplayError(null);
  }
  const actions = DEFAULT_ACTIONS;
  const showDisplayStep = action === "Display";
  const showReleaseStep = action === "Release" || action === "Approved List";
  const showDocActions = !showDisplayStep && action !== "Approved List";
  const showCreate = mode === "creation" && (action === "Create" || action === "Change") || showDisplayStep && displayConfirmed || showReleaseStep && docLoaded;
  function resetCreateForm() {
    setNfaType("");
    setRfqNumber("");
    setNfaTitle("");
    setBuyer(EMPTY_BUYER);
    setScopeCategories([]);
    setRemarks("");
    setSpendCategory("");
    setItemCategory("");
    setPurchasingGroup("");
    setProposedToAward("");
    setProposedToAwardDetail("");
    setAwardRemarks("");
    setApprovedBudget("");
    setBalanceBudget("");
    setReleaseCode("");
    setMainNfaNumber("");
    setDisplayConfirmed(false);
    setDisplayError(null);
    setPrRows([]);
    setRfqRows([]);
    setRecommendRows([]);
    setAttachRows([]);
    setNfaTextRows([]);
    setExpandedTextVendors(/* @__PURE__ */ new Set());
    setSelectedTextKey(null);
    setRelMatxRows([]);
    setClickedNfaNo(null);
    setDocLoaded(false);
  }
  const fallbackVendorName = reactExports.useMemo(() => {
    const rec = recommendRows.find((r) => isSapFlag(r.APP_VENDOR)) ?? recommendRows[0] ?? null;
    return String(rec?.NAME1 ?? "").trim() || nfaTitle.trim() || "NFA Texts";
  }, [recommendRows, nfaTitle]);
  const nfaTextGroups = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const t of nfaTextRows) {
      const vendor = String(t.NAME1 ?? "").trim() || fallbackVendorName;
      if (!map.has(vendor)) map.set(vendor, {
        vendor,
        items: []
      });
      map.get(vendor).items.push(t);
    }
    return Array.from(map.values());
  }, [nfaTextRows, fallbackVendorName]);
  function textLines(t) {
    if (Array.isArray(t.HEADER)) {
      const lines = t.HEADER.map((h) => String(h?.LINE ?? "")).filter((l) => l.trim() !== "");
      if (lines.length > 0) return lines.join("\n");
    }
    return "";
  }
  function toggleTextVendor(vendor) {
    setExpandedTextVendors((prev) => {
      const next = new Set(prev);
      if (next.has(vendor)) next.delete(vendor);
      else next.add(vendor);
      return next;
    });
  }
  function onSelectNfaText(key, t) {
    setSelectedTextKey(key);
    setAwardRemarks(textLines(t));
  }
  function onAction(label) {
    setAction(label);
    resetCreateForm();
    clearReleaseResults();
    toast.info(`${label} selected`);
  }
  function onReleaseNext() {
    if (!releaseCode) {
      toast.error("Select a Release Code");
      return;
    }
    if (!releaseId) {
      toast.error("No SAP user id found — please sign in again.");
      return;
    }
    clearReleaseResults();
    releaseMutation.mutate({
      user: releaseId,
      relCode: releaseCode,
      mode: action === "Approved List" ? "app_list" : "release"
    });
  }
  function onDisplayNext() {
    if (!mainNfaNumber.trim()) {
      toast.error("Enter a Main NFA Number");
      return;
    }
    setDisplayError(null);
    displayMutation.mutate({
      znfaNum: mainNfaNumber.trim()
    });
  }
  function onRfqF4() {
    toast.info("RFQ Number F4 help will be enabled once the SAP API is configured.");
  }
  function onGetDetails() {
    if (!rfqNumber.trim()) {
      toast.error("Enter an RFQ Number");
      return;
    }
    toast.info("Get Details will fetch buyer details once the SAP API is configured.");
  }
  function onDisplayAttachments() {
    toast.info("Attachments will be available once the SAP API is configured.");
  }
  function toggleAttachRow(key) {
    setSelectedAttachKeys((prev) => prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]);
  }
  const openedNfaNo = clickedNfaNo?.trim() || mainNfaNumber.trim();
  async function onDocApprove() {
    const ok = await confirm({
      title: `Approve NFA ${openedNfaNo || ""}`.trim() + "?",
      description: "This will release the NFA document in SAP.",
      destructive: false,
      confirmLabel: "Approve"
    });
    if (!ok) return;
    if (!openedNfaNo) {
      toast.error("No NFA number is open.");
      return;
    }
    if (!releaseId) {
      toast.error("No SAP user id found — please sign in again.");
      return;
    }
    if (!releaseCode) {
      toast.error("Select a Release Code");
      return;
    }
    setDisplayError(null);
    approveMutation.mutate({
      znfaNum: openedNfaNo,
      user: releaseId,
      relCode: releaseCode
    });
  }
  function onDocReject() {
    if (!openedNfaNo) {
      toast.error("No NFA number is open.");
      return;
    }
    setRejectError(null);
    setRejectReason("");
    setRejectOpen(true);
  }
  function submitReject() {
    if (!openedNfaNo) {
      toast.error("No NFA number is open.");
      return;
    }
    if (!releaseId) {
      toast.error("No SAP user id found — please sign in again.");
      return;
    }
    if (!releaseCode) {
      toast.error("Select a Release Code");
      return;
    }
    if (!rejectReason.trim()) return;
    setRejectError(null);
    rejectMutation.mutate({
      znfaNum: openedNfaNo,
      user: releaseId,
      relCode: releaseCode,
      reason: rejectReason.trim()
    });
  }
  function onDocBack() {
    resetCreateForm();
    setDisplayError(null);
    setSelectedAttachKeys([]);
  }
  function toggleScopeCategory(value) {
    setScopeCategories((prev) => prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "MM Approvals", title: "ZNFA Release", subtitle: "Prepare and release Note For Approval documents." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3", children: actions.map((label) => {
        const active = action === label;
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "ghost", className: cn("h-11 min-w-[140px] justify-center rounded-xl border px-4 font-medium transition-all duration-200", active ? "border-primary bg-primary text-primary-foreground shadow-[var(--shadow-elegant)] hover:bg-primary/90 hover:text-primary-foreground" : "border-border bg-muted/60 text-muted-foreground hover:-translate-y-0.5 hover:bg-accent hover:text-accent-foreground hover:shadow-md"), onClick: () => onAction(label), children: label }, label);
      }) }) })
    ] }),
    showReleaseStep && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(KeyRound, { className: "h-3.5 w-3.5" }),
        " ",
        action?.toUpperCase()
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:gap-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-2 sm:grid-cols-[120px_1fr]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Release Code" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: releaseCodes.includes(releaseCode) ? releaseCode : "", onValueChange: (v) => {
              setReleaseCode(v);
              clearReleaseResults();
            }, disabled: releaseCodes.length === 0, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "h-9 w-full max-w-[220px] text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: releaseCodes.length === 0 ? "No keys assigned" : "Select code" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: releaseCodes.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: c, children: c }, c)) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-2 sm:grid-cols-[120px_1fr]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Release Id" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { readOnly: true, value: releaseId, className: "h-9 w-full max-w-[220px] bg-muted/60 text-sm font-medium", placeholder: "—" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "h-9 px-6 sm:self-end", disabled: !releaseCode || releaseMutation.isPending, onClick: onReleaseNext, children: releaseMutation.isPending ? "Loading…" : "Next" })
      ] })
    ] }),
    showReleaseStep && releaseError && /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { variant: "destructive", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-4 w-4", "aria-hidden": true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { children: "Could not load ZNFA records" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { children: releaseError })
    ] }),
    showReleaseStep && releaseMutation.isPending && /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { columns: 6 }),
    showReleaseStep && !releaseMutation.isPending && !releaseError && releaseRows && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ListChecks, { className: "h-3.5 w-3.5" }),
        " ",
        action?.toUpperCase(),
        " — ",
        releaseRows.length,
        " ",
        "RECORD(S)"
      ] }),
      releaseRows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "No records found for this Release Code." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: RELEASE_RESULT_COLUMNS.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: cn("whitespace-nowrap text-xs", c.numeric && "text-right"), children: c.label }, c.key)) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: releaseRows.map((row, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: RELEASE_RESULT_COLUMNS.map((c) => {
          const raw = row[c.key];
          const text = raw === null || raw === void 0 || raw === "" ? "" : String(raw);
          const isNfaNo = c.key === "NFA_NO" && text !== "";
          const isBusy = clickMutation.isPending && clickedNfaNo === text;
          return /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: cn("whitespace-nowrap text-sm", c.numeric && "text-right tabular-nums"), children: isNfaNo ? /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => onNfaNoClick(text), disabled: clickMutation.isPending, className: "font-medium text-primary underline underline-offset-2 hover:opacity-80 disabled:opacity-60", children: isBusy ? "Loading…" : text }) : text || "—" }, c.key);
        }) }, `${row.NFA_NO ?? "row"}-${i}`)) })
      ] }) })
    ] }),
    showReleaseStep && displayError && /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { variant: "destructive", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-4 w-4", "aria-hidden": true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { children: "Could not load the NFA document" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { children: displayError })
    ] }),
    showReleaseStep && clickMutation.isPending && /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { columns: 6 }),
    showDisplayStep && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(KeyRound, { className: "h-3.5 w-3.5" }),
        " DISPLAY"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:gap-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid flex-1 grid-cols-1 items-center gap-2 sm:grid-cols-[160px_1fr]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Main NFA Number" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(NfaNumberSelect, { value: mainNfaNumber, user: releaseId, onChange: (v) => {
            setMainNfaNumber(v);
            setDisplayConfirmed(false);
          } })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "h-9 px-6 sm:self-end", disabled: !mainNfaNumber.trim() || displayMutation.isPending, onClick: onDisplayNext, children: displayMutation.isPending ? "Loading…" : "Next" })
      ] })
    ] }),
    showDisplayStep && displayError && /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { variant: "destructive", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-4 w-4", "aria-hidden": true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { children: "Could not load the NFA document" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { children: displayError })
    ] }),
    showDisplayStep && displayMutation.isPending && /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { columns: 6 }),
    showCreate && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border border-border/60 p-2 shadow-card", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 overflow-x-auto", children: [
        openedNfaNo && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "shrink-0 px-2 font-mono text-xs text-muted-foreground", children: [
          "NFA ",
          openedNfaNo
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex shrink-0 items-center gap-1.5", children: [
          showDocActions && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", className: "h-8 px-3 text-xs", onClick: onDocApprove, disabled: approveMutation.isPending, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "mr-1.5 h-3.5 w-3.5" }),
              " ",
              approveMutation.isPending ? "Approving…" : "Approve"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", variant: "destructive", className: "h-8 px-3 text-xs", onClick: onDocReject, disabled: rejectMutation.isPending, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "mr-1.5 h-3.5 w-3.5" }),
              " ",
              rejectMutation.isPending ? "Rejecting…" : "Reject"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", variant: "outline", className: "h-8 px-3 text-xs", onClick: onDocBack, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "mr-1.5 h-3.5 w-3.5" }),
            " Back"
          ] }),
          showDocActions && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", variant: "outline", className: "h-8 px-3 text-xs", onClick: () => {
              setClarifyText("");
              setClarifyOpen(true);
            }, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "mr-1.5 h-3.5 w-3.5" }),
              " Clarification"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", variant: "outline", className: "h-8 px-3 text-xs", disabled: disClarifyMutation.isPending, onClick: openDisClarify, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MessagesSquare, { className: "mr-1.5 h-3.5 w-3.5" }),
              " ",
              disClarifyMutation.isPending ? "Loading…" : "Display Clarification"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", variant: "outline", className: "h-8 px-3 text-xs", onClick: onDocPreview, disabled: printMutation.isPending, children: [
            printMutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mr-1.5 h-3.5 w-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "mr-1.5 h-3.5 w-3.5" }),
            "Preview"
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DetailsTableCard, { title: "APPROVAL / RELEASE MATRIX", columns: REL_MATX_COLUMNS, rows: relMatxRows, emptyText: "No approval matrix returned by SAP." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-5 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "space-y-4 border border-border/60 p-5 shadow-card lg:col-span-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-end gap-3 sm:grid-cols-[160px_1fr]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Type of NFA" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: nfaType, onValueChange: setNfaType, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "h-9 text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "No values available" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: nfaType ? /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: nfaType, children: nfaType }) : null })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-end gap-3 sm:grid-cols-[160px_1fr]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "RFQ Number" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: rfqNumber, onChange: (e) => setRfqNumber(e.target.value), className: "h-9 w-full max-w-[200px] text-sm", placeholder: "RFQ Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", size: "icon", className: "h-9 w-9 shrink-0", "aria-label": "RFQ Number F4 help", onClick: onRfqF4, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-4 w-4" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "h-9 px-5", disabled: true, onClick: onGetDetails, children: "Get Details" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-end gap-3 sm:grid-cols-[160px_1fr]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "NFA Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: nfaTitle, onChange: (e) => setNfaTitle(e.target.value), className: "h-9 text-sm", placeholder: "NFA Title" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(UserRound, { className: "h-3.5 w-3.5" }),
            " BUYER DETAILS"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: [{
            label: "Buyer Id",
            value: buyer.id
          }, {
            label: "Name",
            value: buyer.name
          }, {
            label: "E-Mail",
            value: buyer.email
          }, {
            label: "Location",
            value: buyer.location
          }].map((f) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-2 sm:grid-cols-[110px_1fr]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs text-muted-foreground", children: f.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { readOnly: true, value: f.value, className: "h-9 bg-muted/60 text-sm", placeholder: "—" })
          ] }, f.label)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Wrench, { className: "h-3.5 w-3.5" }),
          " SCOPE OF WORK"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Scope Category" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: SCOPE_CATEGORIES.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { id: `scope-${category.id}`, checked: scopeCategories.includes(category.label), disabled: docLoaded, onCheckedChange: () => toggleScopeCategory(category.label) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: `scope-${category.id}`, className: docLoaded ? "text-sm font-normal leading-tight text-muted-foreground" : "cursor-pointer text-sm font-normal leading-tight", children: category.label })
            ] }, category.id)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Remarks" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: remarks, onChange: (e) => setRemarks(e.target.value), rows: 3, className: "min-h-0 text-sm", placeholder: "Enter remarks" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Purchase Type" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-2 sm:grid-cols-[120px_1fr]", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs text-muted-foreground", children: "Spend Category" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: spendCategory, onChange: (e) => setSpendCategory(e.target.value), className: "h-9 text-sm", placeholder: "Spend Category" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-2 sm:grid-cols-[120px_1fr]", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs text-muted-foreground", children: "Item Category" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: itemCategory, onChange: (e) => setItemCategory(e.target.value), className: "h-9 text-sm", placeholder: "Item Category" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-2 sm:grid-cols-[120px_1fr]", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs text-muted-foreground", children: "Purch. Group" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: purchasingGroup, onChange: (e) => setPurchasingGroup(e.target.value), className: "h-9 text-sm", placeholder: "Purchasing Group" })
              ] })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(PrDetailsTreeCard, { rows: prRows, emptyText: "No PR details returned by SAP." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(RfqDetailsTreeCard, { rows: rfqRows, emptyText: "No RFQ details returned by SAP." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DetailsTableCard, { title: "FINAL RECOMMENDATION", columns: FINAL_RECOMMENDATION_COLUMNS, rows: recommendRows, emptyText: "No recommendation data returned by SAP." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border border-border/60 p-5 shadow-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "h-3.5 w-3.5" }),
          " AWARD & ATTACHMENTS"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 grid grid-cols-1 items-start gap-3 sm:grid-cols-[160px_1fr]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium sm:pt-2", children: "Proposed to award" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: proposedToAward, onChange: (e) => setProposedToAward(e.target.value), className: "h-9 max-w-md text-sm", placeholder: "Proposed to award" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: proposedToAwardDetail, onChange: (e) => setProposedToAwardDetail(e.target.value), className: "h-9 text-sm", placeholder: "Additional details" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "NFA Texts" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "whitespace-nowrap text-xs", children: "NFA Texts" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "whitespace-nowrap text-xs", children: "T&C" })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: nfaTextGroups.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 2, className: "h-28 text-center text-sm text-muted-foreground", children: "No NFA texts returned by SAP." }) }) : nfaTextGroups.map((g) => {
                const open = expandedTextVendors.has(g.vendor);
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 2, className: "text-sm font-medium", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => toggleTextVendor(g.vendor), className: "flex items-center gap-2 text-left", "aria-expanded": open, children: [
                    open ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4" }),
                    g.vendor
                  ] }) }) }),
                  open && g.items.map((t, i) => {
                    const rfqNo = String(t.EBELN ?? t.RFQ ?? t.ANFNR ?? "").trim() || "—";
                    const key = `${g.vendor}-${rfqNo}-${t.AVL_TEXTS ?? "text"}-${i}`;
                    const selected = selectedTextKey === key;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { "data-state": selected ? "selected" : void 0, className: "cursor-pointer", onClick: () => onSelectNfaText(key, t), children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "whitespace-nowrap pl-10 text-sm", children: rfqNo }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-sm", children: String(t.AVL_TEXTS ?? "—") })
                    ] }, key);
                  })
                ] }, g.vendor);
              }) })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Remarks" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: awardRemarks, onChange: (e) => setAwardRemarks(e.target.value), rows: 8, className: "text-sm", placeholder: "Enter remarks" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Budget" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-2 sm:grid-cols-[130px_1fr]", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs text-muted-foreground", children: "Approved Budget" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: approvedBudget, onChange: (e) => setApprovedBudget(e.target.value), inputMode: "decimal", className: "h-9 text-right text-sm", placeholder: "0.00" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-2 sm:grid-cols-[130px_1fr]", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs text-muted-foreground", children: "Balance Budget" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { readOnly: true, value: balanceBudget, className: "h-9 bg-muted/60 text-right text-sm", placeholder: "—" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "flex items-center gap-2 text-sm font-medium", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Paperclip, { className: "h-3.5 w-3.5" }),
                  " Attachments List"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", className: "h-8 px-4", onClick: onDisplayAttachments, children: "Display" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "w-10 text-xs", children: "CB" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "whitespace-nowrap text-xs", children: "Vendor" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "whitespace-nowrap text-xs", children: "Name" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "whitespace-nowrap text-right text-xs", children: "Attachments" })
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: attachRows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 4, className: "h-24 text-center text-sm text-muted-foreground", children: "No attachments returned by SAP." }) }) : attachRows.map((a, i) => {
                  const attachKey = `${a.ATTACHMENT_ID ?? "attach"}-${i}`;
                  return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "w-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: selectedAttachKeys.includes(attachKey), onCheckedChange: () => toggleAttachRow(attachKey), "aria-label": `Select attachment ${String(a.NAME1 ?? i + 1)}` }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "whitespace-nowrap text-sm", children: String(a.VENDOR ?? "—").trim() || "—" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-sm", children: String(a.NAME1 ?? "—").trim() || "—" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "whitespace-nowrap text-right text-sm tabular-nums", children: String(a.NO_ATTACHMENTS ?? "").trim() || "—" })
                  ] }, attachKey);
                }) })
              ] }) })
            ] })
          ] })
        ] })
      ] })
    ] }),
    confirmDialog,
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: rejectOpen, onOpenChange: (o) => {
      setRejectOpen(o);
      if (!o) {
        setRejectReason("");
        setRejectError(null);
      }
    }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { children: [
          "Reject NFA ",
          openedNfaNo ? `— ${openedNfaNo}` : ""
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "Enter the reason for rejecting this NFA document." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: rejectReason, onChange: (e) => setRejectReason(e.target.value), rows: 5, placeholder: "Reject reason…", className: "text-sm" }),
      rejectError && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive", children: rejectError }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: () => setRejectOpen(false), disabled: rejectMutation.isPending, children: "Cancel" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", variant: "destructive", disabled: !rejectReason.trim() || rejectMutation.isPending, onClick: submitReject, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "mr-1.5 h-3.5 w-3.5" }),
          " ",
          rejectMutation.isPending ? "Rejecting…" : "Reject"
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: clarifyOpen, onOpenChange: (o) => {
      setClarifyOpen(o);
      if (!o) {
        setClarifyText("");
        setClarifyError(null);
      }
    }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { children: [
          "Clarification ",
          openedNfaNo ? `— ${openedNfaNo}` : ""
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "Enter the clarification you want to send for this NFA document." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: clarifyText, onChange: (e) => setClarifyText(e.target.value), rows: 6, placeholder: "Type your clarification…", className: "text-sm" }),
      clarifyError && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive", children: clarifyError }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: () => setClarifyOpen(false), disabled: clarifyMutation.isPending, children: "Cancel" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", disabled: !clarifyText.trim() || clarifyMutation.isPending, onClick: submitClarify, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "mr-1.5 h-3.5 w-3.5" }),
          " ",
          clarifyMutation.isPending ? "Sending…" : "Send Mail"
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: disClarifyOpen, onOpenChange: (o) => {
      setDisClarifyOpen(o);
      if (!o) {
        setDisClarifyLines([]);
        setDisClarifyError(null);
      }
    }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { children: [
          "Display Clarification ",
          openedNfaNo ? `— ${openedNfaNo}` : ""
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "Clarification text recorded in SAP for this NFA document." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { readOnly: true, rows: 10, value: disClarifyMutation.isPending ? "Loading…" : disClarifyLines.length > 0 ? disClarifyLines.join("\n") : disClarifyError ? "" : "No clarification found for this NFA.", className: "font-mono text-xs" }),
      disClarifyError && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive", children: disClarifyError }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end gap-2 pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: () => setDisClarifyOpen(false), children: "Cancel" }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: printOpen, onOpenChange: setPrintOpen, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-5xl p-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { className: "px-6 pt-6 pb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { children: [
          "NFA Preview ",
          openedNfaNo ? `— ${openedNfaNo}` : ""
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "PDF generated from SAP. Use your browser print controls if needed." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-6 pb-6", children: printMutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-[40vh] flex-col items-center justify-center gap-3 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-5 w-5 animate-spin" }),
        "Generating preview…"
      ] }) : printError ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border border-destructive/20 bg-destructive/10 p-4 text-sm text-destructive", children: printError }) : printBlobUrl ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border bg-white", children: isImagePreview ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-[65vh] w-full items-center justify-center overflow-auto rounded-md p-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: printBlobUrl, alt: `NFA preview${openedNfaNo ? ` for ${openedNfaNo}` : ""}`, className: "max-h-full max-w-full object-contain" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("iframe", { src: printBlobUrl, title: "NFA preview", className: "h-[65vh] w-full rounded-md" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex justify-end gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", size: "sm", variant: "outline", className: "h-8 px-3 text-xs", onClick: () => window.open(printBlobUrl, "_blank"), children: "Open in new tab" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", size: "sm", className: "h-8 px-3 text-xs", onClick: onPrintDownload, children: "Download" })
        ] })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-40 items-center justify-center text-sm text-muted-foreground", children: "No preview data available." }) })
    ] }) })
  ] });
}
export {
  ZnfaReleasePage as component
};
