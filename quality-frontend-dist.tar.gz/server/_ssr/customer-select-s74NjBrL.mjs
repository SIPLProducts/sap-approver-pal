import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { P as Popover, a as PopoverTrigger, b as PopoverContent, C as Command, c as CommandInput, d as CommandList, f as CommandGroup, g as CommandItem } from "./command-i9zWGkU5.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { r as runSapApi } from "./sap.functions-oOi__-nP.mjs";
import { a3 as LoaderCircle, n as ChevronsUpDown, o as Check } from "../_libs/lucide-react.mjs";
const getCustomerConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("307ceb1e128a1ba0f38d116939fb2f9581ea70c7b840b9f56eec0d9f6bbf58a5"));
const CODE_KEYS = ["KUNNR", "CUSTOMER", "Customer", "customer", "KUNAG", "CUST_CODE"];
const TEXT_KEYS = ["NAME1", "NAME", "CUSTOMER_NAME", "Name", "name", "DESCRIPTION"];
function extractCustomerOptions(resp) {
  const r = resp;
  let rows = [];
  if (Array.isArray(r)) rows = r;
  else if (r && typeof r === "object") {
    const candidates = [r.DATA, r.data?.DATA, r.data, r.ITEMS, r.items, r.RESULTS, r.results, r.CUSTOMER_LIST];
    rows = candidates.find((c) => Array.isArray(c)) ?? [];
    if (!rows.length) {
      for (const v of Object.values(r)) {
        if (Array.isArray(v)) {
          rows = v;
          break;
        }
      }
    }
  }
  const map = /* @__PURE__ */ new Map();
  for (const row of rows) {
    if (row == null) continue;
    if (typeof row === "string" || typeof row === "number") {
      const c = String(row).trim();
      if (c && !map.has(c)) map.set(c, "");
      continue;
    }
    let code = "";
    for (const k of CODE_KEYS) {
      const v = row?.[k];
      if (v != null && String(v).trim()) {
        code = String(v).trim();
        break;
      }
    }
    if (!code) continue;
    let text = "";
    for (const k of TEXT_KEYS) {
      const v = row?.[k];
      if (v != null && String(v).trim()) {
        text = String(v).trim();
        break;
      }
    }
    if (!map.has(code) || text && !map.get(code)) map.set(code, text);
  }
  return Array.from(map.entries()).map(([code, text]) => ({ code, text })).sort((a, b) => a.code.localeCompare(b.code));
}
function CustomerSelect({
  value,
  onChange,
  plants,
  placeholder = "Select customer…",
  disabled,
  className,
  onEnter: _onEnter
}) {
  const [open, setOpen] = reactExports.useState(false);
  const [search, setSearch] = reactExports.useState("");
  const [debouncedSearch, setDebouncedSearch] = reactExports.useState("");
  const PAGE_SIZE = 50;
  const [visibleCount, setVisibleCount] = reactExports.useState(PAGE_SIZE);
  const loadMoreRef = reactExports.useRef(null);
  const getCfg = useServerFn(getCustomerConfig);
  const runApi = useServerFn(runSapApi);
  reactExports.useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 250);
    return () => clearTimeout(t);
  }, [search]);
  reactExports.useEffect(() => {
    if (!open) {
      setSearch("");
      setDebouncedSearch("");
      setVisibleCount(PAGE_SIZE);
    }
  }, [open]);
  const cfgQuery = useQuery({
    queryKey: ["sap-customer-config"],
    queryFn: () => getCfg(),
    staleTime: 10 * 60 * 1e3
  });
  const configId = cfgQuery.data?.configId ?? null;
  const plantKey = (plants ?? []).join(",");
  const custQuery = useQuery({
    queryKey: ["sap-customers", configId, plantKey],
    enabled: !!configId && open,
    staleTime: 5 * 60 * 1e3,
    queryFn: async () => {
      const inputs = {};
      if (plants && plants.length > 0) {
        inputs.PLANT = plants[0];
        inputs.PLANTS = plants;
        inputs.VKORG = plants[0];
      }
      const resp = await runApi({ data: { configId, inputs } });
      return extractCustomerOptions(resp?.data ?? resp);
    }
  });
  const customers = reactExports.useMemo(() => custQuery.data ?? [], [custQuery.data]);
  const selectedOption = reactExports.useMemo(
    () => customers.find((c) => c.code === value),
    [customers, value]
  );
  const triggerLabel = value ? selectedOption && selectedOption.text ? `${selectedOption.code} - ${selectedOption.text}` : value : "";
  const hasQuery = debouncedSearch.length >= 1;
  const filtered = reactExports.useMemo(() => {
    if (!hasQuery) return customers;
    const q = debouncedSearch.toLowerCase();
    return customers.filter(
      (c) => c.code.toLowerCase().includes(q) || c.text.toLowerCase().includes(q)
    );
  }, [customers, debouncedSearch, hasQuery]);
  reactExports.useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [debouncedSearch, customers]);
  const visible = reactExports.useMemo(() => filtered.slice(0, visibleCount), [filtered, visibleCount]);
  const hasMore = filtered.length > visibleCount;
  reactExports.useEffect(() => {
    if (!hasMore || !loadMoreRef.current) return;
    const el = loadMoreRef.current;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisibleCount((c) => c + PAGE_SIZE);
        }
      },
      { root: el.closest("[cmdk-list]"), threshold: 0.1 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [hasMore, visibleCount, filtered.length]);
  if (!cfgQuery.isLoading && !configId) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Input,
      {
        value,
        onChange: (e) => onChange(e.target.value),
        onKeyDown: (e) => e.key === "Enter" && _onEnter?.(),
        placeholder: "optional",
        className: cn("h-9 font-mono", className),
        disabled
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "outline",
        role: "combobox",
        "aria-expanded": open,
        disabled: disabled || cfgQuery.isLoading,
        className: cn(
          "h-9 w-full justify-between",
          !value && "text-muted-foreground font-sans",
          className
        ),
        children: [
          cfgQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2 font-sans", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Loading…"
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate text-left", children: triggerLabel || placeholder }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronsUpDown, { className: "ml-2 h-3.5 w-3.5 shrink-0 opacity-50" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PopoverContent,
      {
        className: "z-[1000] w-[380px] p-0 max-h-[60vh]",
        align: "start",
        side: "bottom",
        sideOffset: 6,
        avoidCollisions: false,
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Command, { shouldFilter: false, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            CommandInput,
            {
              placeholder: "Search customer…",
              className: "h-9",
              value: search,
              onValueChange: setSearch
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CommandList, { className: "max-h-[calc(60vh-3rem)]", children: custQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 py-6 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Fetching customers…"
          ] }) : custQuery.isError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-4 text-xs text-destructive space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: "Failed to load customers." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] opacity-80 break-words", children: custQuery.error?.message ?? "Unknown error" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "underline", onClick: () => custQuery.refetch(), children: "Retry" })
          ] }) : customers.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-xs text-muted-foreground", children: "No customers returned by Customer_Fetch_API." }) : filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-xs text-muted-foreground", children: "No customer found." }) : /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandGroup, { children: [
            visible.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              CommandItem,
              {
                value: `${c.code} ${c.text}`,
                onSelect: () => {
                  onChange(c.code === value ? "" : c.code);
                  setOpen(false);
                },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Check,
                    {
                      className: cn(
                        "mr-2 h-3.5 w-3.5",
                        value === c.code ? "opacity-100" : "opacity-0"
                      )
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: c.code }),
                  c.text && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 text-muted-foreground truncate", children: [
                    "— ",
                    c.text
                  ] })
                ]
              },
              c.code
            )),
            hasMore && /* @__PURE__ */ jsxRuntimeExports.jsx(
              CommandItem,
              {
                value: "__load_more__",
                onSelect: () => setVisibleCount((c) => c + PAGE_SIZE),
                className: "justify-center text-xs text-muted-foreground",
                children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref: loadMoreRef, className: "w-full text-center", children: [
                  "Load more (showing ",
                  visible.length,
                  " of ",
                  filtered.length,
                  ")"
                ] })
              }
            )
          ] }) }) })
        ] })
      }
    )
  ] });
}
export {
  CustomerSelect as C
};
