import { c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { a as objectType, D as enumType, z as stringType } from "../_libs/zod.mjs";
const fetchBmwStatusReport = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  sales_org_from: stringType().trim().max(10),
  sales_org_to: stringType().trim().max(10),
  customer_from: stringType().trim().max(40).optional().default(""),
  customer_to: stringType().trim().max(40).optional().default(""),
  contract_from: stringType().trim().max(40).optional().default(""),
  contract_to: stringType().trim().max(40).optional().default(""),
  mode: enumType(["customer", "contract", "sales"])
}).parse(d)).handler(createSsrRpc("727b15fffa4ad8ec43f90290c8f3ef58b311dbb4b5e11f6f367881fa7d094582"));
export {
  fetchBmwStatusReport as f
};
