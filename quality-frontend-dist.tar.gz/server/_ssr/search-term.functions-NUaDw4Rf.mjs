import { c as createServerRpc } from "./createServerRpc-Bm5Y9dpM.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const getSearchTermConfig_createServerFn_handler = createServerRpc({
  id: "9032204eb35b34de05ff6c56419bf9ae7686d91dc7f3e6a54d7109b2318638db",
  name: "getSearchTermConfig",
  filename: "src/lib/sap/search-term.functions.ts"
}, (opts) => getSearchTermConfig.__executeServer(opts));
const getSearchTermConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getSearchTermConfig_createServerFn_handler, async () => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data
  } = await supabaseAdmin.from("sap_api_configs").select("id, is_active").ilike("name", "Get_Search_Term").maybeSingle();
  if (!data || !data.is_active) {
    return {
      configId: null
    };
  }
  return {
    configId: data.id
  };
});
export {
  getSearchTermConfig_createServerFn_handler
};
