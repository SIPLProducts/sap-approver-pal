import { c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { a as objectType, D as enumType, C as arrayType, z as stringType, A as unionType, B as numberType } from "../_libs/zod.mjs";
const fetchScSoApprovals = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().trim().min(1).max(40)).min(1, "At least one plant required"),
  user_id: stringType().trim().max(40).optional(),
  customer_from: stringType().trim().max(40).optional(),
  customer_to: stringType().trim().max(40).optional(),
  search_terms: arrayType(stringType().trim().min(1).max(40)).max(100).optional(),
  status: enumType(["pending", "accepted", "rejected", "all"]).default("pending"),
  approval_type: enumType(["service", "sales", "all"]).default("service")
}).parse(d)).handler(createSsrRpc("3e5039af411053f11aa69184274229697e6ca84d3d854e210edc988671b7c565"));
const ScSoRowSchema = objectType({
  select: stringType().nullable().optional(),
  company_code: stringType().nullable().optional(),
  sales_org: stringType().nullable().optional(),
  customer: stringType().nullable().optional(),
  customer_name: stringType().nullable().optional(),
  year: unionType([stringType(), numberType()]).nullable().optional(),
  contract_no: stringType().nullable().optional(),
  contract_item: unionType([stringType(), numberType()]).nullable().optional(),
  contract_ref_no: stringType().nullable().optional(),
  contract_ref_date: stringType().nullable().optional(),
  con_creation_date: stringType().nullable().optional(),
  contract_start_date: stringType().nullable().optional(),
  contract_end_date: stringType().nullable().optional(),
  down_pay_req_amount: unionType([stringType(), numberType()]).nullable().optional(),
  adv_doc_zeile: unionType([stringType(), numberType()]).nullable().optional(),
  adv_doc_ebelp: unionType([stringType(), numberType()]).nullable().optional(),
  adv_amount: unionType([stringType(), numberType()]).nullable().optional(),
  profit_center: stringType().nullable().optional(),
  clearing_document: stringType().nullable().optional(),
  customer_group: stringType().nullable().optional(),
  customer_price_group: stringType().nullable().optional(),
  service_valid_from: stringType().nullable().optional(),
  service_valid_to: stringType().nullable().optional(),
  service_start_date: stringType().nullable().optional(),
  registration_date: stringType().nullable().optional(),
  cus_agr_from: stringType().nullable().optional(),
  cus_agr_to: stringType().nullable().optional(),
  active_inactive: stringType().nullable().optional(),
  no_of_beds_to_be_inv: unionType([stringType(), numberType()]).nullable().optional(),
  fixed_rate: unionType([stringType(), numberType()]).nullable().optional(),
  per_bed_rate: unionType([stringType(), numberType()]).nullable().optional(),
  excess_qty_rate: unionType([stringType(), numberType()]).nullable().optional(),
  upper_slab_qty: unionType([stringType(), numberType()]).nullable().optional(),
  code_land_qty: unionType([stringType(), numberType()]).nullable().optional(),
  total_balance: unionType([stringType(), numberType()]).nullable().optional(),
  ph_reason_code: stringType().nullable().optional(),
  release_code_1: stringType().nullable().optional(),
  approval_status: stringType().nullable().optional(),
  reason: stringType().nullable().optional()
});
const submitScSoDecision = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["accepted", "rejected"]),
  user_id: stringType().trim().max(40).optional(),
  approval_type: enumType(["service", "sales"]).default("service"),
  rows: arrayType(ScSoRowSchema).min(1, "Select at least one row")
}).parse(d)).handler(createSsrRpc("99437d5650fafa19bc7e2c0d37d4bde1888acbb74149c270908943eced65be69"));
export {
  fetchScSoApprovals as f,
  submitScSoDecision as s
};
