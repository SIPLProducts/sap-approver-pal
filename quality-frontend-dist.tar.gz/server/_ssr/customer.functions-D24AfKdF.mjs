import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const getCustomerConfig_createServerFn_handler = createServerRpc({
  id: "307ceb1e128a1ba0f38d116939fb2f9581ea70c7b840b9f56eec0d9f6bbf58a5",
  name: "getCustomerConfig",
  filename: "src/lib/sap/customer.functions.ts"
}, (opts) => getCustomerConfig.__executeServer(opts));
const getCustomerConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getCustomerConfig_createServerFn_handler, async () => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data
  } = await supabaseAdmin.from("sap_api_configs").select("id, is_active").ilike("name", "Customer_Fetch_API").maybeSingle();
  if (!data || !data.is_active) {
    return {
      configId: null,
      codeField: "KUNNR",
      textField: "NAME1"
    };
  }
  return {
    configId: data.id,
    codeField: "KUNNR",
    textField: "NAME1"
  };
});
export {
  getCustomerConfig_createServerFn_handler
};
