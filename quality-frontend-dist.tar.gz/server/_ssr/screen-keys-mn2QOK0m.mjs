const PERMISSION_ACTIONS = [
  "view",
  "create",
  "edit",
  "delete",
  "approve",
  "export"
];
const SCREEN_GROUPS = [
  {
    module: "Approvals",
    screens: [
      { key: "approvals.inbox.mm", label: "MM Approvals Inbox", activity: "APPROVALS.INBOX_MM" },
      { key: "approvals.inbox.sd", label: "SD Approvals Inbox", activity: "APPROVALS.INBOX_SD" },
      { key: "approvals.history", label: "Approval History", activity: "APPROVALS.HISTORY" },
      { key: "approvals.detail", label: "Approval Detail", activity: "APPROVALS.DETAIL" }
    ]
  },
  {
    module: "Admin",
    screens: [
      { key: "admin.users", label: "Users & Roles", activity: "ADMIN.USERS" },
      { key: "admin.custom_roles", label: "Custom Roles", activity: "ADMIN.CUSTOM_ROLES" },
      { key: "admin.role_permissions", label: "Role Permissions", activity: "ADMIN.ROLE_PERMISSIONS" },
      { key: "admin.approval_matrix", label: "Approval Matrix", activity: "ADMIN.APPROVAL_MATRIX" },
      { key: "admin.strategies", label: "Release Strategies", activity: "ADMIN.STRATEGIES" }
    ]
  },
  {
    module: "SAP",
    screens: [
      { key: "sap.api_settings", label: "SAP API Settings", activity: "SAP.API_SETTINGS" },
      { key: "sap.integrations", label: "SAP Integrations", activity: "SAP.INTEGRATIONS" },
      { key: "sap.sync_log", label: "SAP Sync Log", activity: "SAP.SYNC_LOG" }
    ]
  },
  {
    module: "Reports",
    screens: [
      { key: "reports.audit", label: "Audit Log", activity: "REPORTS.AUDIT" },
      { key: "reports.notifications", label: "Notifications", activity: "REPORTS.NOTIFICATIONS" }
    ]
  },
  {
    module: "Settings",
    screens: [
      { key: "settings.email_config", label: "Email Configuration", activity: "SETTINGS.EMAIL_CONFIG" }
    ]
  }
];
const ALL_SCREENS = SCREEN_GROUPS.flatMap((g) => g.screens);
const ACTIVITY_TO_KEY = new Map(
  ALL_SCREENS.map((s) => [s.activity.toUpperCase(), s.key])
);
const KEY_TO_ACTIVITY = new Map(
  ALL_SCREENS.map((s) => [s.key, s.activity.toUpperCase()])
);
function activityToScreenKey(activity) {
  if (!activity) return null;
  return ACTIVITY_TO_KEY.get(activity.trim().toUpperCase()) ?? null;
}
function screenKeyToActivity(screenKey) {
  return KEY_TO_ACTIVITY.get(screenKey) ?? screenKey.trim().toUpperCase();
}
export {
  ALL_SCREENS,
  PERMISSION_ACTIONS,
  SCREEN_GROUPS,
  activityToScreenKey,
  screenKeyToActivity
};
