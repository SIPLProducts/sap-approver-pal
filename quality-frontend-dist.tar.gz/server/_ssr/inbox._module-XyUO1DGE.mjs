import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQueryClient, a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { u as useAuth } from "./use-auth-CXN9VXh3.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { B as Badge } from "./badge-DyfXZgLs.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { D as DOC_TYPE_LABELS } from "./constants-BH6qBFMC.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { K as KpiTile } from "./kpi-tile-DMYvOiIt.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { b as Route$n } from "./router-BdEqF8Cp.mjs";
import "../_libs/sonner.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/web-push.mjs";

import { D as Inbox, a6 as Clock3, a7 as Gauge, a8 as TrendingUp, q as Search, a9 as ChevronRight } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";

import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./screen-keys-mn2QOK0m.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/zod.mjs";
import "./client.server-D5ro3rAQ.mjs";

import "./sap-client.server-CglbxEth.mjs";
import "./push.server-Co_uxbPF.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";

import "../_libs/asn1.js.mjs";
import "../_libs/bn.js.mjs";
import "../_libs/inherits.mjs";
import "../_libs/safer-buffer.mjs";
import "../_libs/minimalistic-assert.mjs";
import "../_libs/jws.mjs";

import "../_libs/safe-buffer.mjs";
import "../_libs/jwa.mjs";
import "../_libs/ecdsa-sig-formatter.mjs";
import "../_libs/buffer-equal-constant-time.mjs";
import "../_libs/http_ece.mjs";

import "../_libs/https-proxy-agent.mjs";



import "../_libs/debug.mjs";
import "../_libs/ms.mjs";
import "../_libs/supports-color.mjs";

import "../_libs/has-flag.mjs";
import "../_libs/agent-base.mjs";

function InboxPage() {
  const {
    module
  } = Route$n.useParams();
  const mod = module.toUpperCase();
  const {
    user
  } = useAuth();
  const {
    activePlant
  } = useActiveContext();
  const qc = useQueryClient();
  const [q, setQ] = reactExports.useState("");
  reactExports.useEffect(() => {
    if (!user) return;
    const ch = supabase.channel(`inbox-${user.id}-${mod}`).on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "approval_steps",
      filter: `assigned_user=eq.${user.id}`
    }, () => qc.invalidateQueries({
      queryKey: ["inbox", user.id]
    })).on("postgres_changes", {
      event: "INSERT",
      schema: "public",
      table: "notifications",
      filter: `user_id=eq.${user.id}`
    }, () => qc.invalidateQueries({
      queryKey: ["inbox", user.id]
    })).subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [user, qc, mod]);
  const {
    data: rows = [],
    isLoading
  } = useQuery({
    queryKey: ["inbox", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data: mySteps
      } = await supabase.from("approval_steps").select("document_id, seq, role, status").eq("assigned_user", user.id).eq("status", "pending");
      const ids = (mySteps ?? []).map((s) => s.document_id);
      if (!ids.length) return [];
      const {
        data: docs
      } = await supabase.from("approval_documents").select("*").in("id", ids).order("created_at", {
        ascending: false
      });
      return docs ?? [];
    }
  });
  const moduleRows = reactExports.useMemo(() => rows.filter((r) => r.module === mod && (!activePlant || r.plant === activePlant)), [rows, mod, activePlant]);
  const filtered = reactExports.useMemo(() => moduleRows.filter((r) => !q || r.sap_doc_no.toLowerCase().includes(q.toLowerCase()) || r.title.toLowerCase().includes(q.toLowerCase()) || (r.vendor_name ?? r.customer_name ?? "").toLowerCase().includes(q.toLowerCase())), [moduleRows, q]);
  const totalValue = moduleRows.reduce((s, r) => s + Number(r.total_value || 0), 0);
  const now = Date.now();
  const overdue = moduleRows.filter((r) => now - new Date(r.created_at).getTime() > 1e3 * 60 * 60 * 24 * 2).length;
  const fmtCr = (n) => n >= 1e7 ? `₹${(n / 1e7).toFixed(2)} Cr` : n >= 1e5 ? `₹${(n / 1e5).toFixed(2)} L` : `₹${Math.round(n).toLocaleString("en-IN")}`;
  const heading = mod === "MM" ? "MM Approvals" : "SD Approvals";
  const subtitle = mod === "MM" ? "Materials Management documents awaiting your decision." : "Sales & Distribution documents awaiting your decision.";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: `${mod} Inbox · Executive`, title: heading, subtitle, meta: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "font-mono", children: mod === "MM" ? "ME21N / FBV1" : "VA01 / VK11" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "secondary", children: [
        moduleRows.length,
        " pending"
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { lead: true, accent: "gold", label: "Pending decisions", value: moduleRows.length, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Inbox, { className: "h-4 w-4" }), sub: `${mod} · live from SAP` }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { accent: "destructive", label: "Overdue · >48h", value: overdue, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Clock3, { className: "h-4 w-4" }), sub: "Breaching internal SLA" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { accent: "info", label: "Cumulative value", value: fmtCr(totalValue), icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Gauge, { className: "h-4 w-4" }), sub: "Across pending queue" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { accent: "success", label: "Approved · 7d", value: "184", delta: {
        value: "+12%",
        trend: "up"
      }, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "h-4 w-4" }), sub: "vs prior week" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-sm flex-1 min-w-[220px]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { className: "h-10 pl-9", placeholder: "Search by doc no, title, vendor or customer…", value: q, onChange: (e) => setQ(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground tabular-nums", children: [
        "Showing ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: filtered.length }),
        " of ",
        moduleRows.length
      ] })
    ] }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "p-10 text-center text-muted-foreground", children: "Loading inbox…" }) : filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-12 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto w-12 h-12 rounded-full bg-secondary grid place-items-center mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Inbox, { className: "h-5 w-5 text-muted-foreground" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-display text-lg font-semibold", children: "Nothing to approve right now" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground mt-1.5", children: "Use “Sync SAP” to pull the latest open documents." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "overflow-hidden p-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 sm:px-5 py-3 border-b bg-muted/30", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground", children: "Pending queue" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-muted-foreground tabular-nums", children: [
          filtered.length,
          " record",
          filtered.length === 1 ? "" : "s"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "divide-y", children: filtered.map((d) => {
        const meta = DOC_TYPE_LABELS[d.doc_type];
        const ageH = Math.max(0, Math.round((now - new Date(d.created_at).getTime()) / 36e5));
        const ageLabel = ageH < 24 ? `${ageH}h` : `${Math.floor(ageH / 24)}d ${ageH % 24}h`;
        const isOverdue = ageH > 48;
        return /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/approval/$id", params: {
          id: d.id
        }, className: "group grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 sm:px-5 py-4 hover:bg-accent/40 transition-colors", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[11px] text-muted-foreground", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "font-mono text-[10px] h-5", children: meta?.tcode ?? d.sap_t_code }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: d.sap_doc_no }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate", children: [
                d.plant,
                " / ",
                d.business_unit
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1.5 font-display text-[15px] font-semibold truncate", children: d.title }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1 text-[11px] text-muted-foreground truncate", children: [
              "Raised by ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground/80", children: d.requester_name }),
              d.vendor_name ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                " · Vendor ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground/80", children: d.vendor_name })
              ] }) : null,
              d.customer_name ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                " · Customer ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground/80", children: d.customer_name })
              ] }) : null
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 sm:gap-6 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-display text-lg sm:text-xl font-semibold tabular-nums", children: [
                "₹",
                Number(d.total_value).toLocaleString("en-IN")
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-0.5 flex items-center justify-end gap-1.5 text-[11px]", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "secondary", className: "h-5", children: [
                  "Step ",
                  d.current_step_seq
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: isOverdue ? "text-destructive font-medium" : "text-muted-foreground", children: ageLabel })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4 text-muted-foreground/60 group-hover:text-foreground transition-colors" })
          ] })
        ] }) }, d.id);
      }) })
    ] })
  ] });
}
export {
  InboxPage as component
};
