import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { u as useAuth } from "./use-auth-CXN9VXh3.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { S as StatusBadge } from "./status-badge-CHGzK-xV.mjs";
import { a as SkeletonRows } from "./skeleton-rows-C2wJYLiJ.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { f as formatDateTime } from "./format-D-HjDoz6.mjs";
import { H as History } from "../_libs/lucide-react.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";


import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./screen-keys-mn2QOK0m.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./skeleton-C5WX2eNf.mjs";
function HistoryPage() {
  const {
    user
  } = useAuth();
  const {
    activePlant
  } = useActiveContext();
  const {
    data: allRows = [],
    isLoading
  } = useQuery({
    queryKey: ["history", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data: mySteps
      } = await supabase.from("approval_steps").select("document_id, status, decided_at").eq("assigned_user", user.id).not("decided_at", "is", null).order("decided_at", {
        ascending: false
      });
      const ids = Array.from(new Set((mySteps ?? []).map((s) => s.document_id)));
      if (!ids.length) return [];
      const {
        data: docs
      } = await supabase.from("approval_documents").select("*").in("id", ids).order("updated_at", {
        ascending: false
      });
      return docs ?? [];
    }
  });
  const rows = reactExports.useMemo(() => activePlant ? allRows.filter((d) => d.plant === activePlant) : allRows, [allRows, activePlant]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Approvals", title: "History", subtitle: "Documents you've actioned." }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { rows: 6, columns: 3 }) : rows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(History, { className: "h-5 w-5" }), title: "No history yet", description: "Documents you action will appear here." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3", children: rows.map((d) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/approval/$id", params: {
      id: d.id
    }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 hover:shadow-elegant flex justify-between items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: d.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
          d.sap_doc_no,
          " • ",
          d.plant,
          "/",
          d.business_unit,
          " • ",
          formatDateTime(d.updated_at)
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: d.status })
    ] }) }, d.id)) })
  ] });
}
export {
  HistoryPage as component
};
