import { c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { a as objectType, D as enumType, C as arrayType, z as stringType, A as unionType, B as numberType } from "../_libs/zod.mjs";
const fetchSalesOrderApprovals = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().trim().min(1).max(40)).min(1, "At least one plant required"),
  user_id: stringType().trim().max(40).optional(),
  customer_from: stringType().trim().max(40).optional(),
  customer_to: stringType().trim().max(40).optional(),
  search_terms: arrayType(stringType().trim().min(1).max(40)).max(100).optional(),
  status: enumType(["pending", "accepted", "rejected", "all"]).default("pending")
}).parse(d)).handler(createSsrRpc("718e84eeac9d47deca78cde67fa3943bbf3252133ea8513629691da661a27fab"));
const SalesOrderRowSchema = objectType({
  select: stringType().nullable().optional(),
  company_code: stringType().nullable().optional(),
  sales_org: stringType().nullable().optional(),
  dis_chanel: stringType().nullable().optional(),
  division: stringType().nullable().optional(),
  customer: stringType().nullable().optional(),
  customer_name: stringType().nullable().optional(),
  customer_group: stringType().nullable().optional(),
  customer_price_group: stringType().nullable().optional(),
  year: stringType().nullable().optional(),
  contract_no: stringType().nullable().optional(),
  contract_item: unionType([stringType(), numberType()]).nullable().optional(),
  sales_document_no: stringType().nullable().optional(),
  so_creation_date: stringType().nullable().optional(),
  sales_item_no: unionType([stringType(), numberType()]).nullable().optional(),
  material: stringType().nullable().optional(),
  qty: unionType([stringType(), numberType()]).nullable().optional(),
  net_value: unionType([stringType(), numberType()]).nullable().optional(),
  tax_value: unionType([stringType(), numberType()]).nullable().optional(),
  reason: stringType().nullable().optional(),
  rel_1: stringType().nullable().optional(),
  status_1: stringType().nullable().optional(),
  rel_2: stringType().nullable().optional(),
  status_2: stringType().nullable().optional()
});
const submitSalesOrderDecision = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["accepted", "rejected"]),
  user_id: stringType().trim().max(40).optional(),
  rows: arrayType(SalesOrderRowSchema).min(1, "Select at least one row")
}).parse(d)).handler(createSsrRpc("f7b8b0ff56b716670cccc698350a7cef532f4b8aac683c44efd7919a1e3fe550"));
export {
  fetchSalesOrderApprovals as f,
  submitSalesOrderDecision as s
};
