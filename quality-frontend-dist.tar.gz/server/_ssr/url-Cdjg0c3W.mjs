function resolveSapUrl(endpoint, baseUrl) {
  const ep = (endpoint ?? "").trim();
  if (!ep) throw new Error("Endpoint URL is empty");
  if (/^https?:\/\//i.test(ep)) return ep;
  const base = (baseUrl ?? "").trim().replace(/\/+$/, "");
  if (!base) {
    throw new Error(
      "SAP Base URL is not configured. Set it in SAP API Settings → SAP Connection, or use a full http(s):// URL on this endpoint."
    );
  }
  return `${base}${ep.startsWith("/") ? "" : "/"}${ep}`;
}
export {
  resolveSapUrl
};
