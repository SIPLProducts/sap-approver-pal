import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, z as stringType, F as coerce, D as enumType } from "../_libs/zod.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
async function assertAdmin(userId) {
  const {
    assertAnyScreen
  } = await import("./assert-screen-DK8QvcMQ.mjs");
  await assertAnyScreen(userId, ["sap.api_settings", "admin.role_permissions"]);
}
const SettingsSchema = objectType({
  connection_mode: enumType(["direct", "via_proxy"]).default("direct"),
  deployment_mode: enumType(["lovable_cloud", "self_hosted"]).default("lovable_cloud"),
  middleware_port: coerce.number().int().min(1).max(65535).default(3002),
  middleware_url: stringType().max(500).optional().nullable(),
  proxy_secret: stringType().max(500).optional().nullable()
});
const SapConnectionSchema = objectType({
  sap_environment: stringType().max(60).optional().nullable(),
  sap_base_url: stringType().max(500).optional().nullable().refine((v) => !v || /^https?:\/\/[^\s]+$/i.test(v.trim()), "SAP Base URL must start with http:// or https://"),
  sap_username: stringType().max(200).optional().nullable(),
  sap_password: stringType().max(500).optional().nullable()
});
const getSapGlobalSettings_createServerFn_handler = createServerRpc({
  id: "3bc1b331640d24658e2002ec4b96bc690fb18a7acd693c59abea35338fb508d5",
  name: "getSapGlobalSettings",
  filename: "src/lib/admin/sap-global.functions.ts"
}, (opts) => getSapGlobalSettings.__executeServer(opts));
const getSapGlobalSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getSapGlobalSettings_createServerFn_handler, async ({
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: row
  } = await supabaseAdmin.from("sap_global_settings").select("*").eq("id", "default").maybeSingle();
  const {
    data: secret
  } = await supabaseAdmin.from("sap_global_secrets").select("proxy_secret, sap_password").eq("id", "default").maybeSingle();
  return {
    settings: row ?? {
      id: "default",
      connection_mode: "direct",
      deployment_mode: "lovable_cloud",
      middleware_port: 3002,
      middleware_url: null,
      sap_environment: null,
      sap_base_url: null,
      sap_username: null
    },
    proxy_secret_set: !!secret?.proxy_secret,
    sap_password_set: !!secret?.sap_password
  };
});
const upsertSapGlobalSettings_createServerFn_handler = createServerRpc({
  id: "3da792f8fc06d8b0a6cee78d7012abbd9b5369bfa9337ec1dc1ad1682a9e56f3",
  name: "upsertSapGlobalSettings",
  filename: "src/lib/admin/sap-global.functions.ts"
}, (opts) => upsertSapGlobalSettings.__executeServer(opts));
const upsertSapGlobalSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => SettingsSchema.parse(d)).handler(upsertSapGlobalSettings_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: existingSecret
  } = await supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle();
  const newSecret = data.proxy_secret && data.proxy_secret.length > 0 ? data.proxy_secret : existingSecret?.proxy_secret ?? null;
  if (data.connection_mode === "via_proxy") {
    if (!data.middleware_url) throw new Error("Node.js Middleware URL is required when Connection Mode = Via Proxy.");
    if (!newSecret) throw new Error("Proxy Secret / Password is required when Connection Mode = Via Proxy.");
  }
  const {
    error: upErr
  } = await supabaseAdmin.from("sap_global_settings").upsert({
    id: "default",
    connection_mode: data.connection_mode,
    deployment_mode: data.deployment_mode,
    middleware_port: data.middleware_port,
    middleware_url: data.middleware_url ?? null,
    updated_by: context.userId
  });
  if (upErr) throw new Error(upErr.message);
  if (data.proxy_secret !== void 0 && data.proxy_secret !== null && data.proxy_secret.length > 0) {
    const {
      error: secErr
    } = await supabaseAdmin.from("sap_global_secrets").upsert({
      id: "default",
      proxy_secret: data.proxy_secret
    });
    if (secErr) throw new Error(secErr.message);
  }
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "sap_global_settings.update",
    target_table: "sap_global_settings",
    target_id: null,
    payload: {
      connection_mode: data.connection_mode,
      deployment_mode: data.deployment_mode,
      middleware_port: data.middleware_port,
      middleware_url_set: !!data.middleware_url,
      secret_changed: !!(data.proxy_secret && data.proxy_secret.length > 0)
    }
  });
  return {
    ok: true
  };
});
const upsertSapConnection_createServerFn_handler = createServerRpc({
  id: "11b57b9ec98b858b0bf05e9a630555a0c211cc0e3630d5bfd0f6473b37f669f9",
  name: "upsertSapConnection",
  filename: "src/lib/admin/sap-global.functions.ts"
}, (opts) => upsertSapConnection.__executeServer(opts));
const upsertSapConnection = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => SapConnectionSchema.parse(d)).handler(upsertSapConnection_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const baseUrl = data.sap_base_url?.trim().replace(/\/+$/, "") || null;
  const {
    error: upErr
  } = await supabaseAdmin.from("sap_global_settings").upsert({
    id: "default",
    sap_environment: data.sap_environment?.trim() || null,
    sap_base_url: baseUrl,
    sap_username: data.sap_username?.trim() || null,
    updated_by: context.userId
  });
  if (upErr) throw new Error(upErr.message);
  if (data.sap_password && data.sap_password.length > 0) {
    const {
      error: secErr
    } = await supabaseAdmin.from("sap_global_secrets").upsert({
      id: "default",
      sap_password: data.sap_password
    });
    if (secErr) throw new Error(secErr.message);
  }
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "sap_connection.update",
    target_table: "sap_global_settings",
    target_id: null,
    payload: {
      sap_environment: data.sap_environment ?? null,
      sap_base_url_set: !!baseUrl,
      sap_username_set: !!data.sap_username,
      sap_password_changed: !!(data.sap_password && data.sap_password.length > 0)
    }
  });
  return {
    ok: true
  };
});
const testSapConnectionGlobal_createServerFn_handler = createServerRpc({
  id: "cf57eb70a5c50cc156ac9bf714da974d89848716e1247b1e403440a716c1b102",
  name: "testSapConnectionGlobal",
  filename: "src/lib/admin/sap-global.functions.ts"
}, (opts) => testSapConnectionGlobal.__executeServer(opts));
const testSapConnectionGlobal = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(testSapConnectionGlobal_createServerFn_handler, async ({
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: row
  } = await supabaseAdmin.from("sap_global_settings").select("sap_base_url, sap_username").eq("id", "default").maybeSingle();
  if (!row?.sap_base_url) return {
    ok: false,
    latency_ms: 0,
    message: "No SAP Base URL configured."
  };
  const {
    data: secret
  } = await supabaseAdmin.from("sap_global_secrets").select("sap_password").eq("id", "default").maybeSingle();
  const url = row.sap_base_url.replace(/\/+$/, "") + "/";
  const headers = {
    Accept: "*/*"
  };
  if (row.sap_username && secret?.sap_password) {
    headers.Authorization = "Basic " + Buffer.from(`${row.sap_username}:${secret.sap_password}`).toString("base64");
  }
  const t0 = Date.now();
  try {
    const r = await fetch(url, {
      method: "HEAD",
      headers
    });
    return {
      ok: r.status < 500,
      latency_ms: Date.now() - t0,
      message: `${r.status} ${r.statusText}`
    };
  } catch (e) {
    return {
      ok: false,
      latency_ms: Date.now() - t0,
      message: e.message
    };
  }
});
const testGlobalMiddleware_createServerFn_handler = createServerRpc({
  id: "05062241b1769d2bc70b04e910c81b7d7d937398a131af6b498508150155139b",
  name: "testGlobalMiddleware",
  filename: "src/lib/admin/sap-global.functions.ts"
}, (opts) => testGlobalMiddleware.__executeServer(opts));
const testGlobalMiddleware = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(testGlobalMiddleware_createServerFn_handler, async ({
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: row
  } = await supabaseAdmin.from("sap_global_settings").select("*").eq("id", "default").maybeSingle();
  if (!row?.middleware_url) return {
    ok: false,
    latency_ms: 0,
    message: "No middleware URL configured."
  };
  const {
    data: secret
  } = await supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle();
  const url = `${row.middleware_url.replace(/\/$/, "")}/__health`;
  const headers = {
    Accept: "application/json"
  };
  if (secret?.proxy_secret) headers["x-shared-secret"] = secret.proxy_secret;
  const t0 = Date.now();
  try {
    const r = await fetch(url, {
      method: "GET",
      headers
    });
    return {
      ok: r.ok,
      latency_ms: Date.now() - t0,
      message: `${r.status} ${r.statusText}`
    };
  } catch (e) {
    return {
      ok: false,
      latency_ms: Date.now() - t0,
      message: e.message
    };
  }
});
export {
  getSapGlobalSettings_createServerFn_handler,
  testGlobalMiddleware_createServerFn_handler,
  testSapConnectionGlobal_createServerFn_handler,
  upsertSapConnection_createServerFn_handler,
  upsertSapGlobalSettings_createServerFn_handler
};
