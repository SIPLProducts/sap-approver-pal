import { c as createServerRpc } from "./createServerRpc-Bm5Y9dpM.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, C as arrayType, D as enumType, z as stringType, G as literalType, y as booleanType } from "../_libs/zod.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const APP_ROLES = ["F1", "F2", "F3", "F4", "F5", "F6", "M1", "M2", "M3", "M4", "M5", "MD", "S2", "S3", "S4", "T1", "T4", "T5", "T6", "IC", "ZZ", "SR", "C1", "HOD", "PlantHead", "SCMHead", "StoreHOD", "ProjectHead", "FinanceHead", "MBD", "FA", "Admin"];
async function assertAdmin(userId) {
  const {
    assertAnyScreen
  } = await import("./assert-screen-DK8QvcMQ.mjs");
  await assertAnyScreen(userId, ["admin.users", "admin.custom_roles", "admin.role_permissions"]);
}
async function findSapConfigId(aliases) {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const norm = (s) => s.trim().toLowerCase().replace(/[\s_-]+/g, "");
  const wanted = new Set(aliases.map(norm));
  const {
    data
  } = await supabaseAdmin.from("sap_api_configs").select("id, name, is_active");
  const match = (data ?? []).find((r) => r.is_active && wanted.has(norm(r.name)));
  return match?.id ?? null;
}
function pickField(obj, key) {
  if (obj == null || typeof obj !== "object") return void 0;
  if (obj[key] !== void 0) return obj[key];
  const lower = key.toLowerCase();
  if (obj[lower] !== void 0) return obj[lower];
  const upper = key.toUpperCase();
  if (obj[upper] !== void 0) return obj[upper];
  for (const k of Object.keys(obj)) {
    if (k.toLowerCase() === lower) return obj[k];
  }
  return void 0;
}
const createUser_createServerFn_handler = createServerRpc({
  id: "c7e0cf2632e756ccee5db5413a91acdd15659102da2216731beffbac4553a21e",
  name: "createUser",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => createUser.__executeServer(opts));
const createUser = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  sap_user_id: stringType().trim().min(1).max(60),
  first_name: stringType().trim().min(1).max(100),
  last_name: stringType().trim().min(1).max(100),
  email: stringType().trim().email().max(200),
  contact_number: stringType().trim().max(20).optional().or(literalType("")),
  status: enumType(["Active", "Inactive"]).default("Active"),
  mode: enumType(["invite", "password"]),
  password: stringType().min(8).max(200).optional(),
  plants: arrayType(stringType().min(1).max(20)).max(50).default([]),
  roles: arrayType(enumType(APP_ROLES)).max(50).default([])
}).refine((v) => v.mode !== "password" || !!v.password, {
  message: "Password is required when setting a password",
  path: ["password"]
}).parse(d)).handler(createUser_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const full_name = `${data.first_name} ${data.last_name}`.trim();
  let newId;
  if (data.mode === "invite") {
    const {
      data: created,
      error
    } = await supabaseAdmin.auth.admin.inviteUserByEmail(data.email, {
      data: {
        full_name
      }
    });
    if (error) throw new Error(error.message);
    newId = created.user?.id;
  } else {
    const {
      data: created,
      error
    } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: {
        full_name
      }
    });
    if (error) throw new Error(error.message);
    newId = created.user?.id;
  }
  if (!newId) throw new Error("User creation returned no id");
  await supabaseAdmin.from("profiles").update({
    full_name,
    first_name: data.first_name,
    last_name: data.last_name,
    sap_user_id: data.sap_user_id,
    contact_number: data.contact_number || null,
    status: data.status
  }).eq("id", newId);
  const uniqueRoles = Array.from(new Set(data.roles));
  if (uniqueRoles.length > 0) {
    await supabaseAdmin.from("user_roles").insert(uniqueRoles.map((role) => ({
      user_id: newId,
      role
    })));
  }
  let matched = [];
  let skipped = [];
  if (data.plants.length > 0) {
    const codes = Array.from(new Set(data.plants.map((c) => c.trim()).filter(Boolean)));
    const {
      data: tRows
    } = await supabaseAdmin.from("tenants").select("id, code").in("code", codes);
    matched = tRows ?? [];
    const found = new Set(matched.map((t) => t.code));
    skipped = codes.filter((c) => !found.has(c));
    if (matched.length > 0) {
      await supabaseAdmin.from("user_tenants").insert(matched.map((t, i) => ({
        user_id: newId,
        tenant_id: t.id,
        is_default: i === 0
      })));
    }
  }
  if (data.status === "Inactive") {
    await supabaseAdmin.auth.admin.updateUserById(newId, {
      ban_duration: "876000h"
    });
  }
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "user.create",
    target_table: "auth.users",
    target_id: newId,
    payload: {
      email: data.email,
      mode: data.mode,
      status: data.status,
      roles: uniqueRoles,
      plants: data.plants,
      skipped_plants: skipped
    }
  });
  return {
    user_id: newId,
    plants_added: matched.length,
    plants_skipped: skipped
  };
});
const inviteUser_createServerFn_handler = createServerRpc({
  id: "64d6a954d8f8a1474bca74ad4044f858211bb58ed1b1b44b29877611033dbac6",
  name: "inviteUser",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => inviteUser.__executeServer(opts));
const inviteUser = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  email: stringType().email().max(200),
  full_name: stringType().min(1).max(200),
  role: enumType(APP_ROLES).optional(),
  plants: arrayType(stringType().min(1).max(20)).max(50).optional()
}).parse(d)).handler(inviteUser_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: created,
    error
  } = await supabaseAdmin.auth.admin.inviteUserByEmail(data.email, {
    data: {
      full_name: data.full_name
    }
  });
  if (error) throw new Error(error.message);
  const newId = created.user?.id;
  if (!newId) throw new Error("Invite returned no user id");
  if (data.role) await supabaseAdmin.from("user_roles").insert({
    user_id: newId,
    role: data.role
  });
  if (data.plants && data.plants.length > 0) {
    const codes = Array.from(new Set(data.plants.map((c) => c.trim()).filter(Boolean)));
    const {
      data: tRows
    } = await supabaseAdmin.from("tenants").select("id, code").in("code", codes);
    const matched = tRows ?? [];
    if (matched.length > 0) {
      await supabaseAdmin.from("user_tenants").insert(matched.map((t, i) => ({
        user_id: newId,
        tenant_id: t.id,
        is_default: i === 0
      })));
    }
  }
  return {
    user_id: newId
  };
});
const deleteUser_createServerFn_handler = createServerRpc({
  id: "b2477e5a9f5a0b29165ed7d5765895a398e841209bfb3cad7b1bd123575d740a",
  name: "deleteUser",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => deleteUser.__executeServer(opts));
const deleteUser = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1).max(60)
}).parse(d)).handler(deleteUser_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  if (data.user_id === context.userId) throw new Error("Cannot delete your own account");
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    error
  } = await supabaseAdmin.auth.admin.deleteUser(data.user_id);
  if (error) throw new Error(error.message);
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "user.delete",
    target_table: "auth.users",
    target_id: data.user_id
  });
  return {
    ok: true
  };
});
const setBuiltInRole_createServerFn_handler = createServerRpc({
  id: "0d51f39ce1e08ebc2f45fd2c231ce5c18c739b677378cdd088bd62c784f2e44d",
  name: "setBuiltInRole",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => setBuiltInRole.__executeServer(opts));
const setBuiltInRole = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1).max(60),
  role: enumType(APP_ROLES),
  action: enumType(["add", "remove"])
}).parse(d)).handler(setBuiltInRole_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  if (data.user_id === context.userId && data.role === "Admin") throw new Error("Cannot change your own Admin role");
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  if (data.action === "add") {
    await supabaseAdmin.from("user_roles").insert({
      user_id: data.user_id,
      role: data.role
    });
  } else {
    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.user_id).eq("role", data.role);
  }
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: `role.${data.action}`,
    target_table: "user_roles",
    target_id: data.user_id,
    payload: {
      role: data.role
    }
  });
  return {
    ok: true
  };
});
const createUserViaSap_createServerFn_handler = createServerRpc({
  id: "c1da24a0411917a72cc05169edcb50b74db1b6f9c0cdc0d4be2fa54f9a9b291f",
  name: "createUserViaSap",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => createUserViaSap.__executeServer(opts));
const createUserViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  sap_user_id: stringType().trim().min(1).max(60),
  first_name: stringType().trim().min(1).max(100),
  last_name: stringType().trim().min(1).max(100),
  email: stringType().trim().email().max(200),
  contact_number: stringType().trim().regex(/^\d{10}$/),
  password: stringType().min(8).max(200),
  confirm_password: stringType().min(8).max(200),
  status: enumType(["Active", "Inactive"]).default("Active"),
  plants: arrayType(stringType().min(1).max(20)).min(1).max(50),
  roles: arrayType(objectType({
    plant: stringType().trim().min(1).max(20),
    role: stringType().trim().min(1).max(60)
  })).min(1).max(200)
}).refine((v) => v.password === v.confirm_password, {
  message: "Passwords do not match",
  path: ["confirm_password"]
}).parse(d)).handler(createUserViaSap_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    invokeViaMiddleware
  } = await import("./sap-client.server-CglbxEth.mjs");
  const cfgId = await findSapConfigId(["USER_CREATE", "Create User", "CreateUser"]);
  if (!cfgId) {
    throw new Error("SAP Create User API is not configured. Add an active config named USER_CREATE (or 'Create User') in SAP API Settings.");
  }
  const uniquePlants = Array.from(new Set(data.plants.map((p) => p.trim()).filter(Boolean)));
  const inner = {
    USER: data.sap_user_id.toUpperCase(),
    FIRST_NAME: data.first_name.toUpperCase(),
    LAST_NAME: data.last_name.toUpperCase(),
    EMAIL: data.email,
    CONTACT: data.contact_number,
    PASSWORD: data.password,
    ZCONFPSWD: data.confirm_password,
    STATUS: data.status === "Active" ? "ACTIVE" : "INACTIVE",
    PLANTS: uniquePlants.map((p) => ({
      WERKS: p
    })),
    ROLES: data.roles.map(({
      plant,
      role
    }) => ({
      WERKS: plant.trim(),
      ROLE: String(role).trim().toUpperCase()
    }))
  };
  const payload = {
    CREATE: inner
  };
  const result = await invokeViaMiddleware(cfgId, payload);
  const sapBody = result.data ?? {};
  const rawStatus = pickField(sapBody, "STATUS");
  const statusStr = String(rawStatus ?? "").toUpperCase();
  const sapMessage = pickField(sapBody, "MESSAGE");
  const sapNumber = pickField(sapBody, "NUMBER");
  const isExplicitError = statusStr === "ERROR" || statusStr === "FAIL" || statusStr === "FAILURE" || statusStr === "FALSE" || statusStr === "E";
  const isExplicitSuccess = statusStr === "SUCCESS" || statusStr === "TRUE" || statusStr === "S" || statusStr === "OK";
  const success = result.ok && !isExplicitError && (isExplicitSuccess || statusStr === "");
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "user.sap_create",
    target_table: "sap_users",
    target_id: null,
    payload: {
      request: {
        CREATE: {
          ...inner,
          PASSWORD: "***",
          ZCONFPSWD: "***"
        }
      },
      response: sapBody,
      middleware_status: result.status,
      middleware_error: result.error ?? null,
      success
    }
  });
  if (!success) {
    const msg = sapMessage || result.error || `SAP rejected the request (status ${result.status})`;
    throw new Error(String(msg));
  }
  return {
    ok: true,
    message: String(sapMessage ?? `User ${inner.USER} created successfully`),
    number: sapNumber ?? null
  };
});
const listRolesForPlants_createServerFn_handler = createServerRpc({
  id: "60c738ac3d759acc4fdcdb57e2c21a1569a30c20025411875bd6cd60db2a272c",
  name: "listRolesForPlants",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => listRolesForPlants.__executeServer(opts));
const listRolesForPlants = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().min(1).max(20)).min(1).max(50)
}).parse(d)).handler(listRolesForPlants_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    invokeViaMiddleware
  } = await import("./sap-client.server-CglbxEth.mjs");
  const cfgId = await findSapConfigId(["ROLE_LIST", "Get Roles", "Role List", "GetRoles", "List Roles"]);
  if (!cfgId) {
    throw new Error("SAP Role List API is not configured. Add an active config named ROLE_LIST (or 'Get Roles') in SAP API Settings.");
  }
  const uniquePlants = Array.from(new Set(data.plants.map((p) => p.trim()).filter(Boolean)));
  const payload = {
    ROLE_LIST: {
      PLANTS: uniquePlants.map((p) => ({
        WERKS: p
      }))
    }
  };
  const result = await invokeViaMiddleware(cfgId, payload);
  const sapBody = result.data ?? {};
  if (!result.ok) {
    const msg = sapBody?.MESSAGE || result.error || `SAP request failed (status ${result.status})`;
    throw new Error(String(msg));
  }
  if (sapBody && typeof sapBody === "object" && "STATUS" in sapBody) {
    const status = String(sapBody.STATUS ?? "").toUpperCase();
    if (status && status !== "TRUE") {
      throw new Error(String(sapBody.MESSAGE || "SAP returned no roles"));
    }
  }
  const SKIP_KEYS = /* @__PURE__ */ new Set(["PLANTS", "WERKS", "STATUS", "MESSAGE", "NUMBER", "TYPE", "ID", "NO", "TIMESTAMP", "DATE", "TIME"]);
  const ROLE_FIELDS = /* @__PURE__ */ new Set(["ROLE", "ROLES", "AGR_NAME", "ROLE_ID", "ROLE_CODE", "ROLE_NAME", "Z_ROLE", "ZROLE", "ZAGR_NAME", "RNAME", "RID"]);
  const looksLikeRole = (s) => {
    const t = s.trim();
    if (!t) return false;
    if (/^\d{1,6}$/.test(t)) return false;
    return t.length <= 60;
  };
  const out = /* @__PURE__ */ new Set();
  const visit = (node) => {
    if (node == null) return;
    if (Array.isArray(node)) {
      node.forEach(visit);
      return;
    }
    if (typeof node === "string") {
      if (looksLikeRole(node)) out.add(node.trim().toUpperCase());
      return;
    }
    if (typeof node !== "object") return;
    for (const f of ROLE_FIELDS) {
      const v = node[f];
      if (typeof v === "string" && looksLikeRole(v)) out.add(v.trim().toUpperCase());
    }
    if (typeof node.WERKS === "string") {
      for (const [k, v] of Object.entries(node)) {
        if (k === "WERKS" || SKIP_KEYS.has(k)) continue;
        if (typeof v === "string" && looksLikeRole(v)) out.add(v.trim().toUpperCase());
      }
    }
    for (const [k, v] of Object.entries(node)) {
      if (SKIP_KEYS.has(k)) continue;
      if (v && typeof v === "object") visit(v);
    }
  };
  visit(sapBody);
  const roles = Array.from(out).filter(Boolean).sort();
  try {
    const snapshot = JSON.stringify(sapBody).slice(0, 4e3);
    await supabaseAdmin.from("admin_audit_log").insert({
      actor_id: context.userId,
      action: "user.sap_role_list",
      target_table: "sap_roles",
      target_id: null,
      payload: {
        request: payload,
        response_snapshot: snapshot,
        roles_count: roles.length
      }
    });
  } catch {
  }
  return {
    roles
  };
});
const createCustomRoleViaSap_createServerFn_handler = createServerRpc({
  id: "8209f80007aaeb764a059b5718a9b0aa3123c996fb2250b7225b15de94c85853",
  name: "createCustomRoleViaSap",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => createCustomRoleViaSap.__executeServer(opts));
const createCustomRoleViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  name: stringType().trim().min(1).max(60),
  description: stringType().trim().max(240).optional().or(literalType("")),
  tenant_id: stringType().trim().optional().or(literalType("")),
  screen_keys: arrayType(stringType().trim().min(1).max(80)).min(1).max(50)
}).parse(d)).handler(createCustomRoleViaSap_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    invokeViaMiddleware
  } = await import("./sap-client.server-CglbxEth.mjs");
  const cfgId = await findSapConfigId(["ROLE_CREATE", "Create Role", "CreateRole"]);
  if (!cfgId) {
    throw new Error("SAP Create Role API is not configured. Add an active config named ROLE_CREATE (or 'Create Role') in SAP API Settings.");
  }
  const {
    screenKeyToActivity,
    PERMISSION_ACTIONS
  } = await import("./screen-keys-mn2QOK0m.mjs");
  const uniqueScreens = Array.from(new Set(data.screen_keys.map((k) => k.trim()).filter(Boolean)));
  const inner = {
    ROLE: data.name.toUpperCase(),
    ROLE_DES: data.description || "",
    ACTIVITY: uniqueScreens.map((k) => ({
      ACTIVITY: screenKeyToActivity(k),
      RELEASE_CODE: ""
    }))
  };
  const payload = {
    CREATE: inner
  };
  const result = await invokeViaMiddleware(cfgId, payload);
  const sapBody = result.data ?? {};
  const rawStatus = pickField(sapBody, "STATUS");
  const statusStr = String(rawStatus ?? "").toUpperCase();
  const sapMessage = pickField(sapBody, "MESSAGE");
  const sapNumber = pickField(sapBody, "NUMBER");
  const isExplicitError = statusStr === "ERROR" || statusStr === "FAIL" || statusStr === "FAILURE" || statusStr === "FALSE" || statusStr === "E";
  const isExplicitSuccess = statusStr === "SUCCESS" || statusStr === "TRUE" || statusStr === "S" || statusStr === "OK";
  const success = result.ok && !isExplicitError && (isExplicitSuccess || statusStr === "");
  let dbError = null;
  let newRoleId = null;
  if (success) {
    const {
      data: inserted,
      error: insErr
    } = await supabaseAdmin.from("custom_roles").insert({
      name: data.name,
      description: data.description || null,
      tenant_id: data.tenant_id || null
    }).select("id").maybeSingle();
    if (insErr) {
      dbError = insErr.message;
    } else if (inserted?.id) {
      newRoleId = inserted.id;
      const permRows = uniqueScreens.flatMap((k) => PERMISSION_ACTIONS.map((action) => ({
        custom_role_id: newRoleId,
        screen_key: k,
        action,
        allowed: true
      })));
      const {
        error: permErr
      } = await supabaseAdmin.from("role_permissions").insert(permRows);
      if (permErr) dbError = permErr.message;
    }
  }
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "user.sap_role_create",
    target_table: "custom_roles",
    target_id: newRoleId,
    payload: {
      request: payload.CREATE,
      screen_keys: uniqueScreens,
      response: sapBody,
      middleware_status: result.status,
      middleware_error: result.error ?? null,
      success,
      db_error: dbError
    }
  });
  if (!success) {
    const msg = sapMessage || result.error || `SAP rejected the request (status ${result.status})`;
    throw new Error(String(msg));
  }
  return {
    ok: true,
    message: String(sapMessage ?? `Role ${payload.CREATE.ROLE} created successfully`),
    number: sapNumber ?? null,
    db_error: dbError
  };
});
function firstArray(node, keys) {
  if (!node) return [];
  if (Array.isArray(node)) return node;
  if (typeof node !== "object") return [];
  for (const k of keys) {
    const v = pickField(node, k);
    if (Array.isArray(v)) return v;
    if (v && typeof v === "object") {
      const inner = firstArray(v, keys);
      if (inner.length) return inner;
    }
  }
  for (const v of Object.values(node)) {
    if (Array.isArray(v)) return v;
  }
  for (const v of Object.values(node)) {
    if (v && typeof v === "object") {
      const inner = firstArray(v, keys);
      if (inner.length) return inner;
    }
  }
  return [];
}
function collectStrings(node, codeKeys) {
  if (node == null) return [];
  if (typeof node === "string" || typeof node === "number") {
    const s = String(node).trim();
    return s ? [s] : [];
  }
  if (Array.isArray(node)) {
    const out = [];
    for (const v of node) out.push(...collectStrings(v, codeKeys));
    return out;
  }
  if (typeof node === "object") {
    for (const k of codeKeys) {
      const v = node[k] ?? pickField(node, k);
      if (typeof v === "string" || typeof v === "number") {
        const s = String(v).trim();
        if (s) return [s];
      }
    }
  }
  return [];
}
const listUsersViaSap_createServerFn_handler = createServerRpc({
  id: "7f40ef2bebcf9a228055e3c974e63068a8616eac0fb0d894eb30116be31c5c27",
  name: "listUsersViaSap",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => listUsersViaSap.__executeServer(opts));
const listUsersViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(listUsersViaSap_createServerFn_handler, async ({
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    invokeViaMiddleware
  } = await import("./sap-client.server-CglbxEth.mjs");
  const cfgId = await findSapConfigId(["USER_DISPLAY_TABLE", "Create_User_Display_Table", "CreateUserDisplayTable", "User Display Table", "USER_LIST", "Display User Table"]);
  if (!cfgId) {
    throw new Error("SAP Create_User_Display_Table API is not configured. Add an active config named Create_User_Display_Table in SAP API Settings.");
  }
  const result = await invokeViaMiddleware(cfgId, {});
  const sapBody = result.data ?? {};
  const rawStatus = pickField(sapBody, "STATUS");
  const statusStr = String(rawStatus ?? "").toUpperCase();
  const isErr = statusStr === "ERROR" || statusStr === "FAIL" || statusStr === "FAILURE" || statusStr === "FALSE" || statusStr === "E";
  if (!result.ok || isErr) {
    const msg = pickField(sapBody, "MESSAGE") || result.error || `SAP request failed (status ${result.status})`;
    throw new Error(String(msg));
  }
  const rows = firstArray(sapBody, ["DATA", "ITEMS", "RESULTS", "USERS", "USER_LIST", "TABLE", "DISPLAY", "T_USER", "ET_USER"]);
  const normStatus = (s) => {
    const u = s.trim().toUpperCase();
    if (!u) return "";
    if (u === "A" || u === "ACTIVE" || u === "TRUE" || u === "1") return "ACTIVE";
    if (u === "I" || u === "INACTIVE" || u === "FALSE" || u === "0") return "INACTIVE";
    return u;
  };
  const byUser = /* @__PURE__ */ new Map();
  for (const r of rows) {
    if (r == null || typeof r !== "object") continue;
    const user = String(pickField(r, "ZUSER") ?? pickField(r, "USER") ?? pickField(r, "EMPNO") ?? pickField(r, "SAP_USER_ID") ?? pickField(r, "USERNAME") ?? "").trim();
    if (!user) continue;
    const key = user.toUpperCase();
    const first = String(pickField(r, "ZFIRST_NAME") ?? pickField(r, "FIRST_NAME") ?? pickField(r, "FNAME") ?? "").trim();
    const last = String(pickField(r, "ZLAST_NAME") ?? pickField(r, "LAST_NAME") ?? pickField(r, "LNAME") ?? "").trim();
    const full = String(pickField(r, "FULL_NAME") ?? pickField(r, "NAME") ?? `${first} ${last}`.trim()).trim();
    const email = String(pickField(r, "ZEMAIL") ?? pickField(r, "EMAIL") ?? pickField(r, "SMTP_ADDR") ?? "").trim();
    const contact = String(pickField(r, "ZCONTACT") ?? pickField(r, "CONTACT") ?? pickField(r, "MOBILE") ?? pickField(r, "TEL_NUMBER") ?? "").trim();
    const status = normStatus(String(pickField(r, "ZSTATUS") ?? pickField(r, "STATUS") ?? ""));
    const password = String(pickField(r, "ZPASSWORD") ?? pickField(r, "PASSWORD") ?? "").trim();
    const confirmPassword = String(pickField(r, "ZCONFPSWD") ?? pickField(r, "CONFPSWD") ?? pickField(r, "CONFIRM_PASSWORD") ?? "").trim();
    const singlePlant = String(pickField(r, "ZWERKS") ?? "").trim();
    const singleRole = String(pickField(r, "ZROLE") ?? "").trim();
    const plantsNode = pickField(r, "PLANTS") ?? pickField(r, "PLANT") ?? pickField(r, "WERKS");
    let nestedPlants = [];
    if (Array.isArray(plantsNode)) {
      const acc = /* @__PURE__ */ new Set();
      for (const p of plantsNode) for (const s of collectStrings(p, ["WERKS", "PLANT", "VKORG"])) acc.add(s);
      nestedPlants = Array.from(acc);
    } else if (plantsNode != null && typeof plantsNode !== "string" && typeof plantsNode !== "number") {
      nestedPlants = collectStrings(plantsNode, ["WERKS", "PLANT", "VKORG"]);
    }
    const rolesNode = pickField(r, "ROLES") ?? pickField(r, "ROLE");
    let nestedRoles = [];
    const nestedRoleAssignments = [];
    if (Array.isArray(rolesNode)) {
      const acc = /* @__PURE__ */ new Set();
      for (const ro of rolesNode) {
        for (const s of collectStrings(ro, ["ROLE", "AGR_NAME", "ROLE_NAME"])) acc.add(s.toUpperCase());
        if (ro && typeof ro === "object") {
          const w = String(ro.WERKS ?? ro.PLANT ?? "").trim();
          const rn = String(ro.ROLE ?? ro.AGR_NAME ?? ro.ROLE_NAME ?? "").trim().toUpperCase();
          if (w && rn) nestedRoleAssignments.push({
            werks: w,
            role: rn
          });
        }
      }
      nestedRoles = Array.from(acc);
    } else if (rolesNode != null && typeof rolesNode !== "string" && typeof rolesNode !== "number") {
      nestedRoles = collectStrings(rolesNode, ["ROLE", "AGR_NAME", "ROLE_NAME"]).map((s) => s.toUpperCase());
    }
    let entry = byUser.get(key);
    if (!entry) {
      entry = {
        user,
        first_name: first,
        last_name: last,
        full_name: full,
        email,
        contact,
        status,
        password,
        confirm_password: confirmPassword,
        plants: [],
        roles: [],
        role_assignments: [],
        raw: r,
        _plants: /* @__PURE__ */ new Set(),
        _roles: /* @__PURE__ */ new Set(),
        _assignments: /* @__PURE__ */ new Set()
      };
      byUser.set(key, entry);
    } else {
      if (!entry.first_name && first) entry.first_name = first;
      if (!entry.last_name && last) entry.last_name = last;
      if (!entry.full_name && full) entry.full_name = full;
      if (!entry.email && email) entry.email = email;
      if (!entry.contact && contact) entry.contact = contact;
      if (!entry.status && status) entry.status = status;
      if (!entry.password && password) entry.password = password;
      if (!entry.confirm_password && confirmPassword) entry.confirm_password = confirmPassword;
    }
    if (singlePlant) entry._plants.add(singlePlant);
    for (const p of nestedPlants) entry._plants.add(p);
    if (singleRole) entry._roles.add(singleRole.toUpperCase());
    for (const ro of nestedRoles) entry._roles.add(ro);
    if (singlePlant && singleRole) {
      entry._assignments.add(`${singlePlant}|${singleRole.toUpperCase()}`);
    }
    for (const a of nestedRoleAssignments) {
      entry._assignments.add(`${a.werks}|${a.role}`);
    }
  }
  const users = Array.from(byUser.values()).map((e) => ({
    user: e.user,
    first_name: e.first_name,
    last_name: e.last_name,
    full_name: e.full_name || `${e.first_name} ${e.last_name}`.trim() || e.user,
    email: e.email,
    contact: e.contact,
    status: e.status,
    password: e.password,
    confirm_password: e.confirm_password,
    plants: Array.from(e._plants).sort(),
    roles: Array.from(e._roles).sort(),
    role_assignments: Array.from(e._assignments).sort().map((s) => {
      const [werks, role] = s.split("|");
      return {
        werks,
        role
      };
    }),
    raw: e.raw
  }));
  try {
    await supabaseAdmin.from("admin_audit_log").insert({
      actor_id: context.userId,
      action: "user.sap_user_list",
      target_table: "sap_users",
      target_id: null,
      payload: {
        rows: users.length,
        raw_rows: rows.length,
        sample_keys: rows[0] && typeof rows[0] === "object" ? Object.keys(rows[0]) : [],
        middleware_status: result.status
      }
    });
  } catch {
  }
  return {
    users
  };
});
const editUserViaSap_createServerFn_handler = createServerRpc({
  id: "8eded77647e6b34303d8fe16a70f6892c87190c6fb0b44ee837fd2012697788b",
  name: "editUserViaSap",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => editUserViaSap.__executeServer(opts));
const editUserViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  sap_user_id: stringType().trim().min(1).max(60),
  first_name: stringType().trim().min(1).max(100),
  last_name: stringType().trim().min(1).max(100),
  email: stringType().trim().email().max(200),
  contact_number: stringType().trim().regex(/^\d{10}$/),
  password: stringType().max(200).optional().default(""),
  confirm_password: stringType().max(200).optional().default(""),
  status: enumType(["Active", "Inactive"]).default("Active"),
  plants: arrayType(stringType().min(1).max(20)).min(1).max(50),
  roles: arrayType(objectType({
    plant: stringType().trim().min(1).max(20),
    role: stringType().trim().min(1).max(60)
  })).min(1).max(200)
}).refine((v) => !v.password || v.password === v.confirm_password, {
  message: "Passwords do not match",
  path: ["confirm_password"]
}).refine((v) => !v.password || v.password.length >= 8, {
  message: "Password must be at least 8 characters",
  path: ["password"]
}).parse(d)).handler(editUserViaSap_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    invokeViaMiddleware
  } = await import("./sap-client.server-CglbxEth.mjs");
  const cfgId = await findSapConfigId(["Edit_User", "EDITUSER", "Edit User"]);
  if (!cfgId) {
    throw new Error("SAP Edit User API is not configured. Add an active config named Edit_User (or 'Edit User') in SAP API Settings.");
  }
  const uniquePlants = Array.from(new Set(data.plants.map((p) => p.trim()).filter(Boolean)));
  const inner = {
    USER: data.sap_user_id.toUpperCase(),
    FIRST_NAME: data.first_name.toUpperCase(),
    LAST_NAME: data.last_name.toUpperCase(),
    EMAIL: data.email,
    CONTACT: data.contact_number,
    STATUS: data.status === "Active" ? "ACTIVE" : "INACTIVE",
    PLANTS: uniquePlants.map((p) => ({
      WERKS: p
    })),
    ROLES: data.roles.map(({
      plant,
      role
    }) => ({
      WERKS: plant.trim(),
      ROLE: String(role).trim().toUpperCase()
    }))
  };
  if (data.password) {
    inner.PASSWORD = data.password;
    inner.ZCONFPSWD = data.confirm_password || data.password;
  }
  const payload = {
    EDIT: inner
  };
  const result = await invokeViaMiddleware(cfgId, payload);
  const sapBody = result.data ?? {};
  const rawStatus = pickField(sapBody, "STATUS");
  const statusStr = String(rawStatus ?? "").toUpperCase();
  const sapMessage = pickField(sapBody, "MESSAGE");
  const sapNumber = pickField(sapBody, "NUMBER");
  const isExplicitError = statusStr === "ERROR" || statusStr === "FAIL" || statusStr === "FAILURE" || statusStr === "FALSE" || statusStr === "E";
  const isExplicitSuccess = statusStr === "SUCCESS" || statusStr === "TRUE" || statusStr === "S" || statusStr === "OK";
  const success = result.ok && !isExplicitError && (isExplicitSuccess || statusStr === "");
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "user.sap_edit",
    target_table: "sap_users",
    target_id: null,
    payload: {
      request: {
        EDIT: {
          ...inner,
          ...inner.PASSWORD ? {
            PASSWORD: "***",
            ZCONFPSWD: "***"
          } : {}
        }
      },
      response: sapBody,
      middleware_status: result.status,
      middleware_error: result.error ?? null,
      success
    }
  });
  if (!success) {
    const msg = sapMessage || result.error || `SAP rejected the request (status ${result.status})`;
    throw new Error(String(msg));
  }
  return {
    ok: true,
    message: String(sapMessage ?? `User ${inner.USER} updated successfully`),
    number: sapNumber ?? null
  };
});
const editCustomRoleViaSap_createServerFn_handler = createServerRpc({
  id: "8d51b44c0921a084509abedb1a7300027832af7daaf4fcdde34490bfa2235f63",
  name: "editCustomRoleViaSap",
  filename: "src/lib/admin/user-mgmt.functions.ts"
}, (opts) => editCustomRoleViaSap.__executeServer(opts));
const editCustomRoleViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  role_id: stringType().trim().min(1).max(60),
  name: stringType().trim().min(1).max(60),
  description: stringType().trim().max(240).optional().or(literalType("")),
  tenant_id: stringType().trim().optional().or(literalType("")),
  screen_keys: arrayType(stringType().trim().min(1).max(80)).min(1).max(50),
  is_active: booleanType().default(true)
}).parse(d)).handler(editCustomRoleViaSap_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertAdmin(context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    invokeViaMiddleware
  } = await import("./sap-client.server-CglbxEth.mjs");
  const cfgId = await findSapConfigId(["Edit_Role", "EDITROLE", "Edit Role"]);
  if (!cfgId) {
    throw new Error("SAP Edit Role API is not configured. Add an active config named Edit_Role (or 'Edit Role') in SAP API Settings.");
  }
  const {
    screenKeyToActivity,
    PERMISSION_ACTIONS
  } = await import("./screen-keys-mn2QOK0m.mjs");
  const uniqueScreens = Array.from(new Set(data.screen_keys.map((k) => k.trim()).filter(Boolean)));
  const inner = {
    ROLE: data.name.toUpperCase(),
    ROLE_DES: data.description || "",
    ACTIVITY: uniqueScreens.map((k) => ({
      ACTIVITY: screenKeyToActivity(k),
      RELEASE_CODE: ""
    }))
  };
  const payload = {
    EDIT: inner
  };
  const result = await invokeViaMiddleware(cfgId, payload);
  const sapBody = result.data ?? {};
  const rawStatus = pickField(sapBody, "STATUS");
  const statusStr = String(rawStatus ?? "").toUpperCase();
  const sapMessage = pickField(sapBody, "MESSAGE");
  const sapNumber = pickField(sapBody, "NUMBER");
  const isExplicitError = statusStr === "ERROR" || statusStr === "FAIL" || statusStr === "FAILURE" || statusStr === "FALSE" || statusStr === "E";
  const isExplicitSuccess = statusStr === "SUCCESS" || statusStr === "TRUE" || statusStr === "S" || statusStr === "OK";
  const success = result.ok && !isExplicitError && (isExplicitSuccess || statusStr === "");
  let dbError = null;
  if (success) {
    const {
      error: updErr
    } = await supabaseAdmin.from("custom_roles").update({
      name: data.name,
      description: data.description || null,
      tenant_id: data.tenant_id || null,
      is_active: data.is_active
    }).eq("id", data.role_id);
    if (updErr) {
      dbError = updErr.message;
    } else {
      const {
        data: existingPerms
      } = await supabaseAdmin.from("role_permissions").select("screen_key, action, allowed").eq("custom_role_id", data.role_id);
      const existingAllowed = new Map((existingPerms ?? []).map((p) => [`${p.screen_key}:${p.action}`, Boolean(p.allowed)]));
      await supabaseAdmin.from("role_permissions").delete().eq("custom_role_id", data.role_id);
      const permRows = uniqueScreens.flatMap((k) => PERMISSION_ACTIONS.map((action) => ({
        custom_role_id: data.role_id,
        screen_key: k,
        action,
        allowed: existingAllowed.get(`${k}:${action}`) ?? true
      })));
      const {
        error: permErr
      } = await supabaseAdmin.from("role_permissions").insert(permRows);
      if (permErr) dbError = permErr.message;
    }
  }
  await supabaseAdmin.from("admin_audit_log").insert({
    actor_id: context.userId,
    action: "user.sap_role_edit",
    target_table: "custom_roles",
    target_id: data.role_id,
    payload: {
      request: payload.EDIT,
      screen_keys: uniqueScreens,
      response: sapBody,
      middleware_status: result.status,
      middleware_error: result.error ?? null,
      success,
      db_error: dbError
    }
  });
  if (!success) {
    const msg = sapMessage || result.error || `SAP rejected the request (status ${result.status})`;
    throw new Error(String(msg));
  }
  return {
    ok: true,
    message: String(sapMessage ?? `Role ${payload.EDIT.ROLE} updated successfully`),
    number: sapNumber ?? null,
    db_error: dbError
  };
});
export {
  createCustomRoleViaSap_createServerFn_handler,
  createUserViaSap_createServerFn_handler,
  createUser_createServerFn_handler,
  deleteUser_createServerFn_handler,
  editCustomRoleViaSap_createServerFn_handler,
  editUserViaSap_createServerFn_handler,
  inviteUser_createServerFn_handler,
  listRolesForPlants_createServerFn_handler,
  listUsersViaSap_createServerFn_handler,
  setBuiltInRole_createServerFn_handler
};
