import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, d as DialogDescription, e as DialogFooter } from "./dialog--up_DbYf.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { B as BrandLogo } from "./brand-logo-CzKKMZ3Z.mjs";

import "../_libs/seroval.mjs";
import { c as Lock, S as ShieldCheck, e as FileCheckCorner, A as ArrowRight } from "../_libs/lucide-react.mjs";
import { a as objectType, z as stringType } from "../_libs/zod.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
const sapLogin = createServerFn({
  method: "POST"
}).inputValidator((d) => objectType({
  username: stringType().min(1).max(200),
  password: stringType().min(1).max(500)
}).parse(d)).handler(createSsrRpc("14406b97199b712cac31b7f3b7d951f7d7c866b758ebdb9b9486e8cbce3b1ffb"));
const sapForgot = createServerFn({
  method: "POST"
}).inputValidator((d) => objectType({
  email: stringType().trim().email().max(200)
}).parse(d)).handler(createSsrRpc("6bba54cc43020d453a07320410b5c96e58b9bb0247272ab27cee712921e4b4c8"));
function LoginPage() {
  const nav = useNavigate();
  const sapLoginFn = useServerFn(sapLogin);
  const sapForgotFn = useServerFn(sapForgot);
  const [userId, setUserId] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [busy, setBusy] = reactExports.useState(false);
  const [forgotOpen, setForgotOpen] = reactExports.useState(false);
  const [forgotEmail, setForgotEmail] = reactExports.useState("");
  const [forgotBusy, setForgotBusy] = reactExports.useState(false);
  reactExports.useEffect(() => {
    supabase.auth.getSession().then(({
      data
    }) => {
      if (data.session) nav({
        to: "/inbox"
      });
    });
  }, [nav]);
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    try {
      {
        const looksLikeEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userId);
        if (looksLikeEmail) {
          const {
            error
          } = await supabase.auth.signInWithPassword({
            email: userId,
            password
          });
          if (!error) {
            toast.success("Welcome");
            nav({
              to: "/inbox"
            });
            return;
          }
        }
        const result = await sapLoginFn({
          data: {
            username: userId,
            password
          }
        });
        if (!result.ok) {
          toast.error(result.error ?? `Login failed (${result.status})`);
          return;
        }
        if (!result.email || !result.tokenHash) {
          toast.error("SAP login succeeded, but the app session could not be created.");
          return;
        }
        const {
          error: verifyError
        } = await supabase.auth.verifyOtp({
          type: "magiclink",
          token_hash: result.tokenHash
        });
        if (verifyError) throw verifyError;
        if (result.profile) {
          const {
            setSapProfile
          } = await import("./use-sap-profile-DRIQ-_33.mjs");
          setSapProfile(result.profile);
        }
        toast.success("Welcome");
        nav({
          to: "/inbox"
        });
      }
    } catch (err) {
      toast.error(err.message ?? "Authentication failed");
    } finally {
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-dvh grid lg:grid-cols-[1.15fr_1fr] bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative isolate overflow-hidden bg-gradient-exec text-white flex flex-col justify-between p-8 lg:p-14 min-h-[38vh] lg:min-h-dvh", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "dot-grid absolute inset-0 text-white/40 opacity-40 pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-32 -left-32 h-[28rem] w-[28rem] rounded-full blur-3xl opacity-50 pointer-events-none", style: {
        background: "radial-gradient(circle, var(--primary) 0%, transparent 60%)"
      } }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-32 -right-32 h-[22rem] w-[22rem] rounded-full blur-3xl opacity-30 pointer-events-none", style: {
        background: "radial-gradient(circle, var(--gold) 0%, transparent 65%)"
      } }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "inline-flex items-center gap-3 rounded-xl bg-white/95 px-3 py-2 shadow-card", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BrandLogo, { className: "h-7" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden sm:block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-sm font-semibold tracking-tight", children: "Re Sustainability" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] uppercase tracking-[0.22em] text-white/55", children: "Executive Approvals" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-[11px] uppercase tracking-[0.22em] text-white/75", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1.5 w-1.5 rounded-full bg-gold" }),
          " Secure SAP Approvals"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "mt-5 font-display text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.02] tracking-tight", children: [
          "Approve with",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-white/55", children: "confidence." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 max-w-md text-[15px] leading-relaxed text-white/70", children: "A secure, single sign-on gateway to review and approve your SAP transactions — protected end-to-end and fully audit-ready." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-10 space-y-3 max-w-md text-sm text-white/75", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "mt-0.5 h-4 w-4 text-gold shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Enterprise-grade authentication with encrypted sessions." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "mt-0.5 h-4 w-4 text-gold shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Role-based access aligned to your SAP authorizations." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheckCorner, { className: "mt-0.5 h-4 w-4 text-gold shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Every approval signed, timestamped and audit-logged." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center justify-between gap-4 text-[11px] text-white/55", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "h-3.5 w-3.5" }),
          " SSO · MFA · SAP-certified"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
          "© ",
          (/* @__PURE__ */ new Date()).getFullYear(),
          " Re Sustainability Limited"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center p-6 sm:p-10 bg-background", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-[420px]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:hidden mb-8 flex justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BrandLogo, { className: "h-9" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-medium uppercase tracking-[0.22em] text-muted-foreground", children: "Welcome To Re Sustainability" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-2 font-display text-3xl font-semibold tracking-tight", children: "Sign in to your Account" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Use your Re Sustainability corporate credentials." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "userId", className: "text-xs font-medium", children: "User ID" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "userId", type: "text", autoComplete: "username", value: userId, onChange: (e) => setUserId(e.target.value), required: true, className: "h-11" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "password", className: "text-xs font-medium", children: "Password" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => {
              setForgotEmail(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userId) ? userId : "");
              setForgotOpen((v) => !v);
            }, className: "text-[11px] font-medium text-primary hover:text-primary/80", children: "Forgot Password?" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "password", type: "password", value: password, onChange: (e) => setPassword(e.target.value), required: true, minLength: 8, className: "h-11" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: forgotOpen, onOpenChange: setForgotOpen, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-md", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Recover your password" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "Enter your account email and we'll send you a password." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 py-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "forgotEmail", className: "text-xs font-medium uppercase tracking-wide", children: "Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "forgotEmail", type: "email", placeholder: "you@company.com", value: forgotEmail, onChange: (e) => setForgotEmail(e.target.value), className: "h-11", autoFocus: true })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", onClick: () => setForgotOpen(false), disabled: forgotBusy, className: "h-11", children: "Cancel" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", disabled: forgotBusy || !forgotEmail.trim(), className: "h-11", onClick: async () => {
              setForgotBusy(true);
              try {
                const result = await sapForgotFn({
                  data: {
                    email: forgotEmail.trim()
                  }
                });
                if (result.ok) {
                  toast.success("Password reset request sent");
                  setForgotOpen(false);
                  setForgotEmail("");
                } else {
                  toast.error(result.error ?? "Could not send reset request");
                }
              } catch (err) {
                toast.error(err?.message ?? "Could not send reset request");
              } finally {
                setForgotBusy(false);
              }
            }, children: forgotBusy ? "Sending…" : "Send" })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", disabled: busy, className: "w-full h-11 font-medium group", children: busy ? "Please wait…" : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "Sign in",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4 ml-1 transition-transform group-hover:translate-x-0.5" })
        ] }) })
      ] })
    ] }) })
  ] });
}
export {
  LoginPage as component
};
