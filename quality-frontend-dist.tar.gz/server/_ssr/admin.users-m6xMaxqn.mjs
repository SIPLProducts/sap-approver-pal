import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useQueryClient, a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { T as Tabs, a as TabsList, b as TabsTrigger, c as TabsContent } from "./tabs-D_u1EXWn.mjs";
import { B as Badge } from "./badge-DyfXZgLs.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { S as Switch } from "./switch-CQ4rbtn8.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-CZRUt5a6.mjs";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, e as DialogFooter } from "./dialog--up_DbYf.mjs";
import { P as Popover, a as PopoverTrigger, b as PopoverContent, C as Command, c as CommandInput, d as CommandList, e as CommandEmpty, f as CommandGroup, g as CommandItem } from "./command-i9zWGkU5.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BhFPQiYt.mjs";
import { T as Textarea } from "./textarea-DSyJ1nlY.mjs";
import { R as ROLE_LABELS } from "./constants-BH6qBFMC.mjs";
import { SCREEN_GROUPS, PERMISSION_ACTIONS } from "./screen-keys-mn2QOK0m.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { S as StatusBadge } from "./status-badge-CHGzK-xV.mjs";
import { a as SkeletonRows } from "./skeleton-rows-C2wJYLiJ.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";
import { P as PlantSelect } from "./plant-select-BIpZq3f7.mjs";
import { P as PlantMultiSelect } from "./plant-multi-select-ZAM7hHZh.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";

import "../_libs/seroval.mjs";
import { O as UserPlus, Q as RefreshCw, V as Plus, X, v as Save, W as Building2, Y as UserCog, s as EyeOff, t as Eye, _ as UsersRound, S as ShieldCheck, $ as UserX, q as Search, a0 as Pencil, a1 as Trash2, a2 as Shield, C as CircleCheck, k as ChevronDown, o as Check } from "../_libs/lucide-react.mjs";
import { a as objectType, C as arrayType, z as stringType, D as enumType, y as booleanType, G as literalType } from "../_libs/zod.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-tabs.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-popover.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./skeleton-C5WX2eNf.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "./sap.functions-oOi__-nP.mjs";
import "./use-active-context-CMJTykFM.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/tailwind-merge.mjs";
const APP_ROLES = ["F1", "F2", "F3", "F4", "F5", "F6", "M1", "M2", "M3", "M4", "M5", "MD", "S2", "S3", "S4", "T1", "T4", "T5", "T6", "IC", "ZZ", "SR", "C1", "HOD", "PlantHead", "SCMHead", "StoreHOD", "ProjectHead", "FinanceHead", "MBD", "FA", "Admin"];
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  sap_user_id: stringType().trim().min(1).max(60),
  first_name: stringType().trim().min(1).max(100),
  last_name: stringType().trim().min(1).max(100),
  email: stringType().trim().email().max(200),
  contact_number: stringType().trim().max(20).optional().or(literalType("")),
  status: enumType(["Active", "Inactive"]).default("Active"),
  mode: enumType(["invite", "password"]),
  password: stringType().min(8).max(200).optional(),
  plants: arrayType(stringType().min(1).max(20)).max(50).default([]),
  roles: arrayType(enumType(APP_ROLES)).max(50).default([])
}).refine((v) => v.mode !== "password" || !!v.password, {
  message: "Password is required when setting a password",
  path: ["password"]
}).parse(d)).handler(createSsrRpc("c7e0cf2632e756ccee5db5413a91acdd15659102da2216731beffbac4553a21e"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  email: stringType().email().max(200),
  full_name: stringType().min(1).max(200),
  role: enumType(APP_ROLES).optional(),
  plants: arrayType(stringType().min(1).max(20)).max(50).optional()
}).parse(d)).handler(createSsrRpc("64d6a954d8f8a1474bca74ad4044f858211bb58ed1b1b44b29877611033dbac6"));
const deleteUser = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1).max(60)
}).parse(d)).handler(createSsrRpc("b2477e5a9f5a0b29165ed7d5765895a398e841209bfb3cad7b1bd123575d740a"));
const setBuiltInRole = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1).max(60),
  role: enumType(APP_ROLES),
  action: enumType(["add", "remove"])
}).parse(d)).handler(createSsrRpc("0d51f39ce1e08ebc2f45fd2c231ce5c18c739b677378cdd088bd62c784f2e44d"));
const createUserViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  sap_user_id: stringType().trim().min(1).max(60),
  first_name: stringType().trim().min(1).max(100),
  last_name: stringType().trim().min(1).max(100),
  email: stringType().trim().email().max(200),
  contact_number: stringType().trim().regex(/^\d{10}$/),
  password: stringType().min(8).max(200),
  confirm_password: stringType().min(8).max(200),
  status: enumType(["Active", "Inactive"]).default("Active"),
  plants: arrayType(stringType().min(1).max(20)).min(1).max(50),
  roles: arrayType(objectType({
    plant: stringType().trim().min(1).max(20),
    role: stringType().trim().min(1).max(60)
  })).min(1).max(200)
}).refine((v) => v.password === v.confirm_password, {
  message: "Passwords do not match",
  path: ["confirm_password"]
}).parse(d)).handler(createSsrRpc("c1da24a0411917a72cc05169edcb50b74db1b6f9c0cdc0d4be2fa54f9a9b291f"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().min(1).max(20)).min(1).max(50)
}).parse(d)).handler(createSsrRpc("60c738ac3d759acc4fdcdb57e2c21a1569a30c20025411875bd6cd60db2a272c"));
const createCustomRoleViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  name: stringType().trim().min(1).max(60),
  description: stringType().trim().max(240).optional().or(literalType("")),
  tenant_id: stringType().trim().optional().or(literalType("")),
  screen_keys: arrayType(stringType().trim().min(1).max(80)).min(1).max(50)
}).parse(d)).handler(createSsrRpc("8209f80007aaeb764a059b5718a9b0aa3123c996fb2250b7225b15de94c85853"));
const listUsersViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("7f40ef2bebcf9a228055e3c974e63068a8616eac0fb0d894eb30116be31c5c27"));
const editUserViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  sap_user_id: stringType().trim().min(1).max(60),
  first_name: stringType().trim().min(1).max(100),
  last_name: stringType().trim().min(1).max(100),
  email: stringType().trim().email().max(200),
  contact_number: stringType().trim().regex(/^\d{10}$/),
  password: stringType().max(200).optional().default(""),
  confirm_password: stringType().max(200).optional().default(""),
  status: enumType(["Active", "Inactive"]).default("Active"),
  plants: arrayType(stringType().min(1).max(20)).min(1).max(50),
  roles: arrayType(objectType({
    plant: stringType().trim().min(1).max(20),
    role: stringType().trim().min(1).max(60)
  })).min(1).max(200)
}).refine((v) => !v.password || v.password === v.confirm_password, {
  message: "Passwords do not match",
  path: ["confirm_password"]
}).refine((v) => !v.password || v.password.length >= 8, {
  message: "Password must be at least 8 characters",
  path: ["password"]
}).parse(d)).handler(createSsrRpc("8eded77647e6b34303d8fe16a70f6892c87190c6fb0b44ee837fd2012697788b"));
const editCustomRoleViaSap = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  role_id: stringType().trim().min(1).max(60),
  name: stringType().trim().min(1).max(60),
  description: stringType().trim().max(240).optional().or(literalType("")),
  tenant_id: stringType().trim().optional().or(literalType("")),
  screen_keys: arrayType(stringType().trim().min(1).max(80)).min(1).max(50),
  is_active: booleanType().default(true)
}).parse(d)).handler(createSsrRpc("8d51b44c0921a084509abedb1a7300027832af7daaf4fcdde34490bfa2235f63"));
const ALL_ROLES = Object.keys(ROLE_LABELS);
const HEAD_ROLE_KEYS = ["PlantHead", "SCMHead", "StoreHOD", "ProjectHead", "FinanceHead", "HOD", "M1", "S4", "T6"];
function UserManagementPage() {
  const [tab, setTab] = reactExports.useState("users");
  const [tenantScope, setTenantScope] = reactExports.useState("all");
  const [inviteOpen, setInviteOpen] = reactExports.useState(false);
  const [roleCreateOpen, setRoleCreateOpen] = reactExports.useState(false);
  const [roleForm, setRoleForm] = reactExports.useState({
    name: "",
    description: "",
    tenant_id: "",
    screen_keys: [],
    is_active: true
  });
  const [creatingRole, setCreatingRole] = reactExports.useState(false);
  const createRoleSap = useServerFn(createCustomRoleViaSap);
  const editRoleSap = useServerFn(editCustomRoleViaSap);
  const qc = useQueryClient();
  const allScreens = reactExports.useMemo(() => SCREEN_GROUPS.flatMap((g) => g.screens.map((s) => ({
    ...s,
    module: g.module
  }))), []);
  const {
    data: tenants = []
  } = useQuery({
    queryKey: ["tenants"],
    queryFn: async () => (await supabase.from("tenants").select("*").order("name")).data ?? []
  });
  function onUserCreated() {
    setInviteOpen(false);
    qc.invalidateQueries({
      queryKey: ["admin-sap-users"]
    });
    qc.invalidateQueries({
      queryKey: ["admin-user-roles"]
    });
  }
  async function submitSaveRole() {
    if (!roleForm.name.trim()) return toast.error("Role name is required");
    if (roleForm.screen_keys.length === 0) return toast.error("Select at least one screen");
    const tenant_id = roleForm.tenant_id || (tenantScope !== "all" ? tenantScope : "");
    setCreatingRole(true);
    try {
      let res;
      if (roleForm.id) {
        res = await editRoleSap({
          data: {
            role_id: roleForm.id,
            name: roleForm.name,
            description: roleForm.description,
            tenant_id,
            screen_keys: roleForm.screen_keys,
            is_active: roleForm.is_active
          }
        });
        toast.success(res?.message || "Custom role updated");
      } else {
        res = await createRoleSap({
          data: {
            name: roleForm.name,
            description: roleForm.description,
            tenant_id,
            screen_keys: roleForm.screen_keys
          }
        });
        toast.success(res?.message || "Custom role created");
      }
      if (res?.db_error) toast.warning(`Saved in SAP but local insert failed: ${res.db_error}`);
      setRoleCreateOpen(false);
      setRoleForm({
        name: "",
        description: "",
        tenant_id: "",
        screen_keys: [],
        is_active: true
      });
      qc.invalidateQueries({
        queryKey: ["admin-custom-roles"]
      });
    } catch (e) {
      toast.error(e?.message || "Failed to save role");
    } finally {
      setCreatingRole(false);
    }
  }
  function refreshAll() {
    if (tab === "custom_roles") {
      qc.invalidateQueries({
        queryKey: ["admin-custom-roles"]
      });
    } else {
      qc.invalidateQueries({
        queryKey: ["admin-sap-users"]
      });
      qc.invalidateQueries({
        queryKey: ["admin-user-roles"]
      });
    }
    toast.success("Refreshed");
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Admin", title: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "h-6 w-6 text-primary" }),
      " User & Role Management"
    ] }), subtitle: "Create user accounts, assign roles (from Role Management), and manage access", actions: tab === "users" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:flex-shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CreateUserDialog, { open: inviteOpen, onOpenChange: setInviteOpen, onCreated: onUserCreated }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => setInviteOpen(true), children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-4 w-4 mr-2" }),
        " Create User"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", onClick: refreshAll, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "h-4 w-4 mr-2" }),
        " Refresh"
      ] })
    ] }) : tab === "custom_roles" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:flex-shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", onClick: refreshAll, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "h-4 w-4 mr-2" }),
        " Refresh"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Dialog, { open: roleCreateOpen, onOpenChange: (v) => {
        setRoleCreateOpen(v);
        if (!v) setRoleForm({
          id: "",
          name: "",
          description: "",
          tenant_id: "",
          screen_keys: [],
          is_active: true
        });
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => {
          setRoleForm({
            id: "",
            name: "",
            description: "",
            tenant_id: "",
            screen_keys: [],
            is_active: true
          });
          setRoleCreateOpen(true);
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-2" }),
          " Add Role"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-2xl max-h-[90vh] overflow-y-auto", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: roleForm.id ? "Edit Role" : "Add New Role" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { children: [
                "Role Name ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Enter role name", value: roleForm.name, onChange: (e) => setRoleForm({
                ...roleForm,
                name: e.target.value
              }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Role Description" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { placeholder: "Enter role description", rows: 3, value: roleForm.description, onChange: (e) => setRoleForm({
                ...roleForm,
                description: e.target.value
              }) })
            ] }),
            tenants.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Tenant scope" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: roleForm.tenant_id, onValueChange: (v) => setRoleForm({
                ...roleForm,
                tenant_id: v
              }), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: tenantScope !== "all" ? "Current tenant" : "Global" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: tenants.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: t.id, children: t.name }, t.id)) })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-semibold", children: "Screen Permissions" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Select which screens this role can access" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground whitespace-nowrap", children: [
                  roleForm.screen_keys.length,
                  " of ",
                  allScreens.length,
                  " assigned"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: () => setRoleForm({
                  ...roleForm,
                  screen_keys: allScreens.map((s) => s.key)
                }), children: "Select All" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: () => setRoleForm({
                  ...roleForm,
                  screen_keys: []
                }), children: "Deselect All" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1", children: allScreens.map((s) => {
                const selected = roleForm.screen_keys.includes(s.key);
                return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => {
                  setRoleForm({
                    ...roleForm,
                    screen_keys: selected ? roleForm.screen_keys.filter((k) => k !== s.key) : [...roleForm.screen_keys, s.key]
                  });
                }, className: cn("flex items-center justify-between gap-2 rounded-md border px-3 py-2 text-sm text-left transition-colors", selected ? "border-primary/60 bg-primary/5 text-foreground" : "border-dashed border-border bg-background text-muted-foreground hover:border-primary/40 hover:text-foreground"), children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: s.label }),
                  selected && /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4 shrink-0 opacity-70" })
                ] }, s.key);
              }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: roleForm.is_active, onCheckedChange: (v) => setRoleForm({
              ...roleForm,
              is_active: v
            }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Active" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => setRoleCreateOpen(false), disabled: creatingRole, children: "Cancel" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: submitSaveRole, disabled: creatingRole, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-2" }),
              creatingRole ? "Saving..." : "Save"
            ] })
          ] })
        ] })
      ] })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "h-4 w-4 text-muted-foreground" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: tenantScope, onValueChange: setTenantScope, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "w-56", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Tenant scope" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "all", children: "All Tenants" }),
          tenants.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectItem, { value: t.id, children: [
            t.name,
            " (",
            t.code,
            ")"
          ] }, t.id))
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { value: tab, onValueChange: setTab, className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid w-full grid-cols-2 sm:grid-cols-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "users", children: "Users" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "custom_roles", children: "Custom Roles" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "permissions", children: "Role Permissions" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "matrix", children: "Approval Matrix" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "users", children: /* @__PURE__ */ jsxRuntimeExports.jsx(UsersTab, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "custom_roles", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CustomRolesTab, { tenantScope, onEditRole: (r) => {
        setRoleForm({
          id: r.id,
          name: r.name,
          description: r.description ?? "",
          tenant_id: r.tenant_id ?? "",
          screen_keys: r.screen_keys ?? [],
          is_active: r.is_active ?? true
        });
        setRoleCreateOpen(true);
      } }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "permissions", children: /* @__PURE__ */ jsxRuntimeExports.jsx(PermissionsTab, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "matrix", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ApprovalMatrixTab, { tenantScope, tenants }) })
    ] })
  ] });
}
function KpiTile({
  icon: Icon,
  value,
  label,
  tone
}) {
  const toneCls = tone === "primary" ? "bg-primary/10 text-primary" : tone === "destructive" ? "bg-destructive/10 text-destructive" : tone === "accent" ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 flex items-center gap-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-11 w-11 rounded-lg flex items-center justify-center ${toneCls}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-bold leading-tight", children: value }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground", children: label })
    ] })
  ] });
}
function UsersTab() {
  const qc = useQueryClient();
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const [search, setSearch] = reactExports.useState("");
  const [plantFilter, setPlantFilter] = reactExports.useState("all");
  const [editUserOpen, setEditUserOpen] = reactExports.useState(false);
  const [editingUser, setEditingUser] = reactExports.useState(null);
  const [detail, setDetail] = reactExports.useState(null);
  const deleteFn = useServerFn(deleteUser);
  useServerFn(setBuiltInRole);
  const listFn = useServerFn(listUsersViaSap);
  const usersQuery = useQuery({
    queryKey: ["admin-sap-users"],
    queryFn: () => listFn(),
    staleTime: 6e4
  });
  const users = usersQuery.data?.users ?? [];
  const {
    data: localRoles = []
  } = useQuery({
    queryKey: ["admin-user-roles"],
    queryFn: async () => (await supabase.from("user_roles").select("*")).data ?? []
  });
  const filtered = reactExports.useMemo(() => {
    const s = search.trim().toLowerCase();
    return users.filter((u) => {
      if (s && !`${u.full_name} ${u.email} ${u.user}`.toLowerCase().includes(s)) return false;
      if (plantFilter !== "all" && !u.plants.includes(plantFilter)) return false;
      return true;
    });
  }, [users, search, plantFilter]);
  const kpis = reactExports.useMemo(() => {
    const total = users.length;
    const admins = users.filter((u) => u.roles.includes("ADMIN")).length;
    const heads = users.filter((u) => u.roles.some((r) => HEAD_ROLE_KEYS.map((h) => h.toUpperCase()).includes(r))).length;
    const unassigned = users.filter((u) => u.roles.length === 0).length;
    return {
      total,
      admins,
      heads,
      unassigned
    };
  }, [users]);
  async function handleDelete(userId) {
    if (!await confirm({
      title: `Delete user ${userId} permanently?`,
      description: "This cannot be undone.",
      confirmLabel: "Delete"
    })) return;
    try {
      await deleteFn({
        data: {
          user_id: userId
        }
      });
      toast.success("User deleted");
      qc.invalidateQueries({
        queryKey: ["admin-sap-users"]
      });
    } catch (e) {
      toast.error(e.message);
    }
  }
  function rolePillFor(u) {
    if (u.roles.length === 0) return null;
    const primary = u.roles[0];
    const isAdmin = primary === "ADMIN";
    const cls = isAdmin ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground";
    return {
      label: primary,
      cls,
      extra: u.roles.length - 1
    };
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { icon: UsersRound, value: kpis.total, label: "Total Users", tone: "primary" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { icon: ShieldCheck, value: kpis.admins, label: "Administrators", tone: "destructive" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { icon: Building2, value: kpis.heads, label: "Role Heads", tone: "accent" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { icon: UserX, value: kpis.unassigned, label: "Unassigned", tone: "muted" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold", children: "Users" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Source: SAP Create_User_Display_Table" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row gap-2 sm:items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-56", children: /* @__PURE__ */ jsxRuntimeExports.jsx(PlantSelect, { value: plantFilter === "all" ? "" : plantFilter, onChange: (v) => setPlantFilter(v ? v : "all"), placeholder: "All plants", restrictToActive: false, source: "user-plant" }) }),
            plantFilter !== "all" && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: () => setPlantFilter("all"), children: "Clear" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full sm:w-72", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Search users...", value: search, onChange: (e) => setSearch(e.target.value), className: "pl-8" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Employee ID" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Email" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Plants" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Roles" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-right", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TableBody, { children: [
          usersQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 6, className: "p-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { rows: 5, columns: 6 }) }) }) }) : usersQuery.isError ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 6, className: "py-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-destructive space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: "Failed to load users." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-80 break-words", children: usersQuery.error?.message ?? "Unknown error" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => usersQuery.refetch(), children: "Retry" })
          ] }) }) }) : filtered.map((u) => {
            localRoles.filter((r) => r.user_id === u.user);
            rolePillFor(u);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "font-medium", children: u.full_name || "—" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-sm text-muted-foreground font-mono", children: u.user }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-sm text-muted-foreground", children: u.email || "—" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: u.plants.length > 0 ? "outline" : "ghost", disabled: u.plants.length === 0, className: "rounded-md", onClick: () => setDetail({
                user: u,
                kind: "plants"
              }), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3.5 w-3.5 mr-1.5" }),
                " Plants (",
                u.plants.length,
                ")"
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: (() => {
                const count = (u.role_assignments?.length ?? 0) || u.roles.length;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: count > 0 ? "outline" : "ghost", disabled: count === 0, className: "rounded-md", onClick: () => setDetail({
                  user: u,
                  kind: "roles"
                }), children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3.5 w-3.5 mr-1.5" }),
                  " Roles (",
                  count,
                  ")"
                ] });
              })() }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: () => {
                  setEditingUser(u);
                  setEditUserOpen(true);
                }, children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3.5 w-3.5 mr-1.5" }),
                  " Edit"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", onClick: () => handleDelete(u.user), className: "h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10", "aria-label": "Delete user", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
              ] }) })
            ] }, u.user);
          }),
          !usersQuery.isLoading && !usersQuery.isError && filtered.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 6, className: "p-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { title: "No users match the filters", description: "Try clearing search or plant filters." }) }) })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CreateUserDialog, { open: editUserOpen, onOpenChange: (v) => {
      setEditUserOpen(v);
      if (!v) setEditingUser(null);
    }, onCreated: () => {
      setEditUserOpen(false);
      setEditingUser(null);
      qc.invalidateQueries({
        queryKey: ["admin-sap-users"]
      });
      qc.invalidateQueries({
        queryKey: ["admin-user-roles"]
      });
    }, editUser: editingUser ?? void 0 }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AssignmentDetailDialog, { detail, onClose: () => setDetail(null) }),
    confirmDialog
  ] });
}
function AssignmentDetailDialog({
  detail,
  onClose
}) {
  const u = detail?.user;
  const kind = detail?.kind ?? "plants";
  const plants = u?.plants ?? [];
  const assignments = u?.role_assignments ?? [];
  const grouped = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const a of assignments) {
      if (!a?.werks || !a?.role) continue;
      const list = map.get(a.werks) ?? [];
      if (!list.includes(a.role)) list.push(a.role);
      map.set(a.werks, list);
    }
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [assignments]);
  const flatRoles = u?.roles ?? [];
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: !!detail, onOpenChange: (v) => {
    if (!v) onClose();
  }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-lg", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: kind === "plants" ? "Assigned Plants" : "Assigned Roles" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: u ? `${u.full_name || u.user} (${u.user})` : "" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[60vh] overflow-y-auto space-y-2 pr-1", children: kind === "plants" ? plants.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground py-6 text-center", children: "No plants assigned" }) : plants.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between rounded-lg border px-4 py-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: p }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4 text-primary" })
    ] }, p)) : grouped.length > 0 ? grouped.map(([plant, roles]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-muted/60 px-4 py-2.5 font-semibold", children: [
        "Plant ",
        plant
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y", children: roles.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 px-4 py-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: r }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "outline", className: "rounded-full font-normal", children: [
          plant,
          "–",
          r
        ] })
      ] }, r)) })
    ] }, plant)) : flatRoles.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2 py-2", children: flatRoles.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "rounded-full font-normal", children: r }, r)) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground py-6 text-center", children: "No roles assigned" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: onClose, children: "Close" }) })
  ] }) });
}
function CustomRolesTab({
  tenantScope: _tenantScope,
  onEditRole
}) {
  const qc = useQueryClient();
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const [permRole, setPermRole] = reactExports.useState(null);
  const {
    data: customRoles = []
  } = useQuery({
    queryKey: ["admin-custom-roles"],
    queryFn: async () => (await supabase.from("custom_roles").select("*, user_custom_roles(count)").order("name")).data ?? []
  });
  const {
    data: allPerms = []
  } = useQuery({
    queryKey: ["admin-role-permissions-all"],
    queryFn: async () => (await supabase.from("role_permissions").select("custom_role_id, screen_key")).data ?? []
  });
  const screensByRole = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const p of allPerms) {
      if (!p?.custom_role_id || !p?.screen_key) continue;
      const list = map.get(p.custom_role_id) ?? [];
      if (!list.includes(p.screen_key)) list.push(p.screen_key);
      map.set(p.custom_role_id, list);
    }
    return map;
  }, [allPerms]);
  const screenLabels = reactExports.useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const g of SCREEN_GROUPS) for (const s of g.screens) m.set(s.key, s.label);
    return m;
  }, []);
  async function toggleActive(id, next) {
    const {
      error
    } = await supabase.from("custom_roles").update({
      is_active: next
    }).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({
      queryKey: ["admin-custom-roles"]
    });
  }
  async function handleEdit(r) {
    const {
      data
    } = await supabase.from("role_permissions").select("screen_key").eq("custom_role_id", r.id);
    const screen_keys = Array.from(new Set((data ?? []).map((p) => p.screen_key).filter(Boolean)));
    onEditRole?.({
      ...r,
      screen_keys
    });
  }
  async function deleteRole(id, userCount) {
    if (userCount > 0) return toast.error("Unassign users from this role first");
    if (!await confirm({
      title: "Delete this role?",
      description: "This cannot be undone.",
      confirmLabel: "Delete"
    })) return;
    const {
      error
    } = await supabase.from("custom_roles").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    qc.invalidateQueries({
      queryKey: ["admin-custom-roles"]
    });
  }
  const permScreens = permRole ? screensByRole.get(permRole.id) ?? [] : [];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-0 overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 border-b", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-base font-semibold", children: "All Roles" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
        customRoles.length,
        " role(s) configured"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Role Name" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Description" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Status" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Screen Permissions" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-right", children: "Actions" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TableBody, { children: [
        customRoles.map((r) => {
          const count = screensByRole.get(r.id)?.length ?? 0;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "font-semibold", children: r.name }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-muted-foreground", children: r.description || "—" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: !!r.is_active, onCheckedChange: (v) => toggleActive(r.id, v) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: r.is_active ? "success" : "neutral", label: r.is_active ? "Active" : "Inactive" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", className: "rounded-md", disabled: count === 0, onClick: () => setPermRole(r), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-3.5 w-3.5 mr-1.5" }),
              " Screens (",
              count,
              ")"
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", onClick: () => handleEdit(r), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "text-destructive", onClick: () => deleteRole(r.id, r.user_custom_roles?.[0]?.count ?? 0), "aria-label": `Delete role ${r.name}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
            ] }) })
          ] }, r.id);
        }),
        customRoles.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 5, className: "text-center text-muted-foreground py-8", children: "No custom roles yet." }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: !!permRole, onOpenChange: (v) => {
      if (!v) setPermRole(null);
    }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-3xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-5 w-5 text-primary" }),
          "Screen Permissions – ",
          permRole?.name
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Screens this role can access." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[60vh] overflow-y-auto pr-1", children: permScreens.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground py-8 text-center", children: "No screens assigned to this role" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2", children: permScreens.map((k) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 rounded-lg border px-4 py-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-muted-foreground", children: screenLabels.get(k) ?? k }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-5 w-5 shrink-0 text-muted-foreground" })
      ] }, k)) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => setPermRole(null), children: "Close" }) })
    ] }) }),
    confirmDialog
  ] });
}
function PermissionsTab() {
  const qc = useQueryClient();
  const [target, setTarget] = reactExports.useState("");
  const {
    data: customRoles = []
  } = useQuery({
    queryKey: ["admin-custom-roles-simple"],
    queryFn: async () => (await supabase.from("custom_roles").select("id, name").order("name")).data ?? []
  });
  reactExports.useEffect(() => {
    if (!target && customRoles.length > 0) {
      setTarget(`custom:${customRoles[0].id}`);
    }
  }, [customRoles, target]);
  const {
    data: perms = []
  } = useQuery({
    queryKey: ["role-permissions", target],
    enabled: target.startsWith("custom:"),
    queryFn: async () => {
      const q = supabase.from("role_permissions").select("*").eq("custom_role_id", target.slice(7));
      return (await q).data ?? [];
    }
  });
  const allowedSet = reactExports.useMemo(() => new Set(perms.filter((p) => p.allowed).map((p) => `${p.screen_key}:${p.action}`)), [perms]);
  async function toggle(screen, action) {
    if (!target.startsWith("custom:")) return;
    const key = `${screen}:${action}`;
    const allowed = !allowedSet.has(key);
    const row = {
      screen_key: screen,
      action,
      allowed,
      custom_role_id: target.slice(7)
    };
    const existing = perms.find((p) => p.screen_key === screen && p.action === action);
    if (existing) {
      await supabase.from("role_permissions").update({
        allowed
      }).eq("id", existing.id);
    } else {
      await supabase.from("role_permissions").insert(row);
    }
    qc.invalidateQueries({
      queryKey: ["role-permissions", target]
    });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: "Role permission matrix" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Toggles persist immediately. Select a custom role to load its current allowed permissions." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: target, onValueChange: setTarget, disabled: customRoles.length === 0, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "w-72", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: customRoles.length === 0 ? "No custom roles yet" : "Select a role" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { className: "max-h-80", children: customRoles.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: `custom:${r.id}`, children: r.name }, r.id)) })
      ] })
    ] }),
    customRoles.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border p-6 text-center text-sm text-muted-foreground", children: "No custom roles yet. Create a custom role first to manage its permissions." }) : SCREEN_GROUPS.map((g) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold mb-2 text-sm tracking-wide uppercase text-muted-foreground", children: g.module }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Screen" }),
          PERMISSION_ACTIONS.map((a) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "capitalize text-center", children: a }, a))
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: g.screens.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TableCell, { className: "font-medium", children: [
            s.label,
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "text-[10px] text-muted-foreground", children: s.key })
          ] }),
          PERMISSION_ACTIONS.map((a) => /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: allowedSet.has(`${s.key}:${a}`), onCheckedChange: () => toggle(s.key, a) }) }, a))
        ] }, s.key)) })
      ] }) })
    ] }, g.module))
  ] });
}
function ApprovalMatrixTab({
  tenantScope,
  tenants
}) {
  const qc = useQueryClient();
  const activeTenant = tenantScope !== "all" ? tenantScope : tenants[0]?.id;
  const {
    data: rows = []
  } = useQuery({
    queryKey: ["approval-matrix", activeTenant],
    enabled: !!activeTenant,
    queryFn: async () => (await supabase.from("approval_matrix").select("*").eq("tenant_id", activeTenant).order("stage_no")).data ?? []
  });
  async function addRow() {
    if (!activeTenant) return toast.error("Select a tenant scope first");
    const {
      error
    } = await supabase.from("approval_matrix").insert({
      tenant_id: activeTenant,
      stage_no: (rows.at(-1)?.stage_no ?? 0) + 1,
      role_key: "Admin",
      min_amount: 0,
      max_amount: null,
      currency: "INR"
    });
    if (error) return toast.error(error.message);
    qc.invalidateQueries({
      queryKey: ["approval-matrix", activeTenant]
    });
  }
  async function patchRow(id, patch) {
    const {
      error
    } = await supabase.from("approval_matrix").update(patch).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({
      queryKey: ["approval-matrix", activeTenant]
    });
  }
  async function deleteRow(id) {
    await supabase.from("approval_matrix").delete().eq("id", id);
    qc.invalidateQueries({
      queryKey: ["approval-matrix", activeTenant]
    });
  }
  if (!activeTenant) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-8 text-center text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "h-8 w-8 mx-auto mb-2" }),
      "Create a tenant first to configure an approval matrix."
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
        "Tenant: ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: tenants.find((t) => t.id === activeTenant)?.name ?? activeTenant })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: addRow, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-2" }),
        " Add stage"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Stage" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Role" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Min amount" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Max amount" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Currency" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Active" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, {})
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TableBody, { children: [
        rows.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: r.stage_no, onChange: (e) => patchRow(r.id, {
            stage_no: Number(e.target.value)
          }), className: "w-20" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: r.role_key, onValueChange: (v) => patchRow(r.id, {
            role_key: v
          }), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "w-40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { className: "max-h-72", children: ALL_ROLES.map((rr) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: rr, children: rr }, rr)) })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: r.min_amount, onChange: (e) => patchRow(r.id, {
            min_amount: Number(e.target.value)
          }), className: "w-32" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: r.max_amount ?? "", onChange: (e) => patchRow(r.id, {
            max_amount: e.target.value ? Number(e.target.value) : null
          }), className: "w-32", placeholder: "∞" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: r.currency, onChange: (e) => patchRow(r.id, {
            currency: e.target.value
          }), className: "w-20" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: r.is_active, onCheckedChange: (v) => patchRow(r.id, {
            is_active: v
          }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: () => deleteRow(r.id), className: "text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
        ] }, r.id)),
        rows.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { colSpan: 7, className: "text-center text-muted-foreground py-6", children: "No stages configured for this tenant." }) })
      ] })
    ] }) })
  ] });
}
const emptyForm = () => ({
  sap_user_id: "",
  first_name: "",
  last_name: "",
  email: "",
  contact_number: "",
  status: "Active",
  password: "",
  confirm_password: ""
});
function CreateUserDialog({
  open,
  onOpenChange,
  onCreated,
  editUser
}) {
  const createFn = useServerFn(createUserViaSap);
  const editFn = useServerFn(editUserViaSap);
  const [form, setForm] = reactExports.useState(emptyForm);
  const [plants, setPlants] = reactExports.useState([]);
  const [roles, setRoles] = reactExports.useState([]);
  const [showPw, setShowPw] = reactExports.useState(false);
  const [submitting, setSubmitting] = reactExports.useState(false);
  const [changePassword, setChangePassword] = reactExports.useState(false);
  const sortedPlants = reactExports.useMemo(() => [...plants].sort(), [plants]);
  const rolesQuery = useQuery({
    queryKey: ["custom-roles-all"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("custom_roles").select("id, name").eq("is_active", true).order("name");
      if (error) throw new Error(error.message);
      return data ?? [];
    },
    staleTime: 6e4
  });
  const customRoles = rolesQuery.data ?? [];
  const roleOptions = reactExports.useMemo(() => {
    if (sortedPlants.length === 0) return [];
    return sortedPlants.flatMap((p) => customRoles.map((r) => ({
      value: `${p}::${r.name}`,
      label: `${p} - ${r.name}`
    })));
  }, [sortedPlants, customRoles]);
  reactExports.useEffect(() => {
    if (rolesQuery.isLoading) return;
    if (roleOptions.length === 0) return;
    const byKey = new Map(roleOptions.map((o) => [o.value.toUpperCase(), o.value]));
    setRoles((prev) => {
      let changed = false;
      const next = [];
      for (const r of prev) {
        const canonical = byKey.get(r.toUpperCase());
        if (canonical) {
          if (canonical !== r) changed = true;
          next.push(canonical);
        } else {
          changed = true;
        }
      }
      return changed ? Array.from(new Set(next)) : prev;
    });
  }, [roleOptions, rolesQuery.isLoading]);
  const lastErrRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (rolesQuery.isError) {
      const msg = rolesQuery.error?.message ?? "Failed to load roles";
      if (lastErrRef.current !== msg) {
        lastErrRef.current = msg;
        toast.error(msg);
      }
    } else if (!rolesQuery.isFetching) {
      lastErrRef.current = null;
    }
  }, [rolesQuery.isError, rolesQuery.error, rolesQuery.isFetching]);
  reactExports.useEffect(() => {
    if (editUser) {
      const existingPwd = String(editUser.password ?? "");
      const existingConfirm = String(editUser.confirm_password ?? existingPwd ?? "");
      setForm({
        sap_user_id: editUser.user ?? "",
        first_name: editUser.first_name ?? "",
        last_name: editUser.last_name ?? "",
        email: editUser.email ?? "",
        contact_number: editUser.contact ?? "",
        status: editUser.status === "ACTIVE" || editUser.status === "Active" ? "Active" : "Inactive",
        password: existingPwd,
        confirm_password: existingConfirm
      });
      const editPlants = editUser.plants ?? [];
      setPlants(editPlants);
      const assignments = Array.isArray(editUser.role_assignments) ? editUser.role_assignments : [];
      let composite = [];
      if (assignments.length > 0) {
        composite = assignments.map((a) => a.werks && a.role ? `${a.werks}::${String(a.role).toUpperCase()}` : "").filter(Boolean);
      } else {
        const rs = editUser.roles ?? [];
        for (const p of editPlants) for (const r of rs) composite.push(`${p}::${String(r).toUpperCase()}`);
      }
      setRoles(Array.from(new Set(composite)));
      setChangePassword(false);
      setShowPw(false);
    } else {
      setForm(emptyForm());
      setPlants([]);
      setRoles([]);
      setChangePassword(false);
      setShowPw(false);
    }
  }, [editUser]);
  function reset() {
    setForm(emptyForm());
    setPlants([]);
    setRoles([]);
    setShowPw(false);
    setChangePassword(false);
  }
  function close(next) {
    if (!next) reset();
    onOpenChange(next);
  }
  async function submit() {
    if (plants.length === 0) return toast.error("Please select at least one plant");
    if (!form.sap_user_id.trim()) return toast.error("User ID is required");
    if (!form.first_name.trim() || !form.last_name.trim()) return toast.error("First and Last name are required");
    if (!form.email.trim()) return toast.error("Email is required");
    if (!/^\d{10}$/.test(form.contact_number.trim())) return toast.error("Contact number must be 10 digits");
    if (roles.length === 0) return toast.error("Please select at least one role");
    const passwordUnchanged = editUser && !changePassword;
    if (!passwordUnchanged) {
      if (form.password.length < 8) return toast.error("Password must be at least 8 characters");
      if (form.password !== form.confirm_password) return toast.error("Passwords do not match");
    }
    setSubmitting(true);
    try {
      const sendPwd = form.password;
      const sendConfirm = form.confirm_password || form.password;
      const base = {
        sap_user_id: form.sap_user_id.trim(),
        first_name: form.first_name.trim(),
        last_name: form.last_name.trim(),
        email: form.email.trim(),
        contact_number: form.contact_number.trim(),
        status: form.status === "Active" ? "Active" : "Inactive",
        password: sendPwd,
        confirm_password: sendConfirm,
        plants,
        roles: roles.map((v) => {
          const [plant, role] = v.split("::");
          return plant && role ? {
            plant,
            role
          } : null;
        }).filter((x) => !!x)
      };
      if (editUser) {
        const res = await editFn({
          data: base
        });
        toast.success(res?.message ?? "User updated successfully");
      } else {
        const res = await createFn({
          data: base
        });
        toast.success(res?.message ?? "User created successfully");
      }
      reset();
      onCreated();
    } catch (e) {
      toast.error(e.message ?? (editUser ? "Failed to update user" : "Failed to create user"));
    } finally {
      setSubmitting(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open, onOpenChange: close, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-5xl p-0 gap-0 max-h-[90vh] flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { className: "px-6 py-4 border-b", children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { className: "text-base font-semibold", children: editUser ? "Edit User" : "Add New User" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto px-6 py-5 grid grid-cols-1 md:grid-cols-3 gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "User ID", required: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.sap_user_id, onChange: (e) => setForm({
        ...form,
        sap_user_id: e.target.value
      }), placeholder: "Enter User ID (e.g., USR001)", disabled: !!editUser, className: editUser ? "bg-muted" : "" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "First Name", required: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.first_name, onChange: (e) => setForm({
        ...form,
        first_name: e.target.value
      }), placeholder: "Enter first name" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Last Name", required: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.last_name, onChange: (e) => setForm({
        ...form,
        last_name: e.target.value
      }), placeholder: "Enter last name" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Email ID", required: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "email", value: form.email, onChange: (e) => setForm({
        ...form,
        email: e.target.value
      }), placeholder: "Enter email" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Contact Number", required: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.contact_number, onChange: (e) => setForm({
        ...form,
        contact_number: e.target.value.replace(/\D/g, "").slice(0, 10)
      }), placeholder: "Enter 10-digit number", inputMode: "numeric" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Plant", required: true, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(PlantMultiSelect, { value: plants, onChange: setPlants, placeholder: "— Select Plants —", restrictToActive: false, source: "user-plant" }),
        plants.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-muted-foreground mt-1", children: "Please select at least one plant" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Role", required: true, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(RoleMultiSelect, { value: roles, onChange: setRoles, options: roleOptions, loading: rolesQuery.isFetching, placeholder: plants.length === 0 ? "— Select plants first —" : rolesQuery.isFetching ? "Loading roles…" : "— Select Roles —" }),
        plants.length > 0 && !rolesQuery.isFetching && !rolesQuery.isError && roleOptions.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-destructive mt-1", children: "No custom roles configured." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Password", required: !editUser || changePassword, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: showPw ? "text" : "password", value: form.password, onChange: (e) => setForm({
          ...form,
          password: e.target.value
        }), placeholder: editUser && !changePassword ? "Check Change Password to edit" : "Enter password", disabled: !!editUser && !changePassword, className: "pr-9" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setShowPw((v) => !v), className: "absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground", "aria-label": showPw ? "Hide password" : "Show password", children: showPw ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-4 w-4" }) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Confirm Password", required: !editUser || changePassword, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: showPw ? "text" : "password", value: form.confirm_password, onChange: (e) => setForm({
          ...form,
          confirm_password: e.target.value
        }), placeholder: editUser && !changePassword ? "Check Change Password to edit" : "Re-enter password", disabled: !!editUser && !changePassword, className: "pr-9" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setShowPw((v) => !v), className: "absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground", "aria-label": showPw ? "Hide password" : "Show password", children: showPw ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-4 w-4" }) })
      ] }) }),
      editUser && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs font-medium", children: " " }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 h-9", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { id: "change-password", checked: changePassword, onCheckedChange: (checked) => {
            const enabled = checked === true;
            setChangePassword(enabled);
            if (enabled) {
              setForm((f) => ({
                ...f,
                password: "",
                confirm_password: ""
              }));
            } else {
              const existingPwd = String(editUser?.password ?? "");
              const existingConfirm = String(editUser?.confirm_password ?? existingPwd);
              setForm((f) => ({
                ...f,
                password: existingPwd,
                confirm_password: existingConfirm
              }));
              setShowPw(false);
            }
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "change-password", className: "text-sm font-normal cursor-pointer", children: "Change Password" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Status", required: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: form.status, onValueChange: (v) => setForm({
        ...form,
        status: v
      }), children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "Active", children: "Active" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "Inactive", children: "Inactive" })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { className: "px-6 py-4 border-t bg-background gap-2 sm:gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => close(false), disabled: submitting, children: "Cancel" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: submit, disabled: submitting, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-1.5" }),
        submitting ? "Saving..." : "Save"
      ] })
    ] })
  ] }) });
}
function Field({
  label,
  required,
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs font-medium", children: [
      label,
      required && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive ml-0.5", children: "*" })
    ] }),
    children
  ] });
}
function RoleMultiSelect({
  value,
  onChange,
  options,
  loading,
  placeholder = "— Select Roles —"
}) {
  const [open, setOpen] = reactExports.useState(false);
  const selected = reactExports.useMemo(() => new Set(value), [value]);
  const labelByValue = reactExports.useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const o of options) m.set(o.value, o.label);
    return m;
  }, [options]);
  function toggle(r) {
    if (selected.has(r)) onChange(value.filter((x) => x !== r));
    else onChange([...value, r]);
  }
  const label = value.length === 0 ? placeholder : value.length <= 2 ? value.map((v) => labelByValue.get(v) ?? v).join(", ") : `${value.length} roles selected`;
  const allSelected = options.length > 0 && value.length === options.length;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", role: "combobox", "aria-expanded": open, className: cn("h-9 w-full justify-between font-normal", value.length === 0 && "text-muted-foreground"), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: label }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "ml-2 h-4 w-4 shrink-0 opacity-50" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverContent, { className: "w-[var(--radix-popover-trigger-width)] p-0 max-h-[340px] overflow-hidden", align: "start", onWheel: (e) => e.stopPropagation(), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Command, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CommandInput, { placeholder: "Search role…", className: "h-9" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandList, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CommandEmpty, { children: loading ? "Loading roles…" : options.length === 0 ? "Select plants to load roles." : "No role found." }),
        options.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandGroup, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandItem, { value: "__select_all_roles__", onSelect: () => {
            if (allSelected) onChange([]);
            else onChange(options.map((o) => o.value));
          }, className: "font-medium border-b rounded-none", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: allSelected, tabIndex: -1, className: "pointer-events-none mr-2" }),
            allSelected ? `Clear all (${options.length})` : `Select all (${options.length})`
          ] }),
          options.map((o) => {
            const isSel = selected.has(o.value);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandItem, { value: o.label, onSelect: () => toggle(o.value), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: isSel, tabIndex: -1, className: "pointer-events-none mr-2" }),
              o.label
            ] }, o.value);
          })
        ] })
      ] })
    ] }) })
  ] });
}
export {
  UserManagementPage as component
};
