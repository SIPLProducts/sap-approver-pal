import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useQueryClient, a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-CXnFcWf4.mjs";
import { u as useAuth } from "./use-auth-CXN9VXh3.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { a as SkeletonRows } from "./skeleton-rows-C2wJYLiJ.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { f as formatDateTime } from "./format-D-HjDoz6.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";
import { B as Bell } from "../_libs/lucide-react.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
function Notifications() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const {
    data: rows = [],
    isLoading
  } = useQuery({
    queryKey: ["notifications", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("notifications").select("*").eq("user_id", user.id).order("created_at", {
      ascending: false
    }).limit(100)).data ?? []
  });
  async function markAll() {
    if (!await confirm({
      title: "Mark all notifications as read?",
      description: "This will clear the unread indicator on every notification.",
      confirmLabel: "Mark all read",
      destructive: false
    })) return;
    await supabase.from("notifications").update({
      read_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("user_id", user.id).is("read_at", null);
    qc.invalidateQueries();
    toast.success("All marked as read");
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack max-w-3xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Settings", title: "Notifications", subtitle: "Real-time approval alerts.", actions: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", size: "sm", onClick: markAll, children: "Mark all read" }) }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { rows: 5, columns: 1 }) : rows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "h-5 w-5" }), title: "No notifications yet", description: "You'll see real-time approval alerts here." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: rows.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/approval/$id", params: {
      id: n.document_id
    }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: `p-4 hover:shadow-elegant ${!n.read_at ? "border-l-4 border-l-primary" : ""}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: n.title }),
      n.body && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground mt-1", children: n.body }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground mt-1 tabular-nums", children: formatDateTime(n.created_at) })
    ] }) }, n.id)) }),
    confirmDialog
  ] });
}
export {
  Notifications as component
};
