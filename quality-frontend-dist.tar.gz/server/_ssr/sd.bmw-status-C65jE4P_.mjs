import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn } from "./createSsrRpc-Bx8XQbeC.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { R as RadioGroup, a as RadioGroupItem } from "./radio-group-CxFG_eHv.mjs";
import { C as CloudscapeApprovalTable } from "./cloudscape-approval-table-B3gA6T4g.mjs";
import { b as buildDynamicColumns } from "./dynamic-columns-C64XiqUr.mjs";
import { P as PlantSelect } from "./plant-select-BIpZq3f7.mjs";
import { C as CustomerSelect } from "./customer-select-s74NjBrL.mjs";
import { f as fetchBmwStatusReport } from "./bmw-status-report.functions-B3pVONqA.mjs";

import "../_libs/seroval.mjs";
import { aa as Funnel, a3 as LoaderCircle, ab as RotateCcw } from "../_libs/lucide-react.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./server-6SfJ9jtE.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-radio-group.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "./checkbox-mmp_duDa.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./empty-state-DA5qeMhN.mjs";
import "./skeleton-rows-C2wJYLiJ.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./format-D-HjDoz6.mjs";
import "./table-BhFPQiYt.mjs";
import "./command-i9zWGkU5.mjs";
import "../_libs/radix-ui__react-popover.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "./auth-middleware-Drtg4FDX.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./sap.functions-oOi__-nP.mjs";
import "../_libs/zod.mjs";
import "./use-active-context-CMJTykFM.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./client-CXnFcWf4.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "./screen-keys-mn2QOK0m.mjs";
const CORE_COLS = [{
  key: "COMPANY_CODE",
  label: "Company Code",
  type: "text",
  group: "core"
}, {
  key: "SALES_ORG",
  label: "Sales Org",
  type: "text",
  group: "core"
}, {
  key: "CUSTOMER",
  label: "Customer",
  type: "text",
  group: "core"
}, {
  key: "CUSTOMER_NAME",
  label: "Customer Name",
  type: "text",
  group: "core"
}, {
  key: "DIS_CHANNEL",
  label: "Dist. Channel",
  type: "text",
  group: "core"
}, {
  key: "DIVISION",
  label: "Division",
  type: "text",
  group: "core"
}];
const BP_COLS = [{
  key: "BP_CUS_GROUP",
  label: "Cust. Group",
  type: "text",
  group: "bp"
}, {
  key: "BP_PRICE_GROUP",
  label: "Price Group",
  type: "text",
  group: "bp"
}, {
  key: "BP_SERVICE_VALID_FROM",
  aliases: ["BP_SRV_VALID_FROM"],
  label: "Srv Valid From",
  type: "date",
  group: "bp"
}, {
  key: "BP_SERVICE_VALID_TO",
  aliases: ["BP_SRV_VALID_TO"],
  label: "Srv Valid To",
  type: "date",
  group: "bp"
}, {
  key: "BP_SERVICE_START_DATE",
  aliases: ["BP_SRV_START_DATE"],
  label: "Srv Start Date",
  type: "date",
  group: "bp"
}, {
  key: "BP_REG_DATE",
  label: "Reg. Date",
  type: "date",
  group: "bp"
}, {
  key: "BP_UPPER_SLAB",
  label: "Upper Slab",
  type: "decimal3",
  group: "bp"
}, {
  key: "BP_NO_BEDS_INV",
  aliases: ["BP_NO_BEDS_INVOICE"],
  label: "Beds to Invoice",
  type: "int",
  group: "bp"
}, {
  key: "BP_AGR_FROM",
  aliases: ["BP_AGR_VALID_FROM"],
  label: "Agr. Valid From",
  type: "date",
  group: "bp"
}, {
  key: "BP_AGR_TO",
  aliases: ["BP_AGR_VALID_TO"],
  label: "Agr. Valid To",
  type: "date",
  group: "bp"
}, {
  key: "BP_ACTIVE_INACTIVE",
  label: "Status",
  type: "status",
  group: "bp"
}, {
  key: "BP_FIXED_RATE",
  label: "Fixed Rate",
  type: "currency2",
  group: "bp"
}, {
  key: "BP_PER_BED_RATE",
  label: "Per Bed Rate",
  type: "currency2",
  group: "bp"
}, {
  key: "BP_EXCESS_QTY_RATE",
  label: "Excess Qty Rate",
  type: "currency2",
  group: "bp"
}];
const MBD_COLS = [{
  key: "MBD_ID",
  label: "MBD ID",
  type: "text",
  group: "mbd"
}, {
  key: "MBD_NAME",
  label: "MBD Name",
  type: "text",
  group: "mbd"
}];
const CONTRACT_COLS = [{
  key: "CONTRACT_NO",
  label: "Contract No",
  type: "text",
  group: "contract"
}, {
  key: "CONTRACT_ITEM",
  label: "Item",
  type: "int",
  group: "contract"
}, {
  key: "CONTRACT_DATE",
  aliases: ["CONTRACT_CREATE_DATE"],
  label: "Create Date",
  type: "date",
  group: "contract"
}, {
  key: "CONTRACT_CREATED_BY",
  label: "Created By",
  type: "text",
  group: "contract"
}, {
  key: "MATERIAL_CODE",
  label: "Material Code",
  type: "text",
  group: "contract"
}, {
  key: "CONTRACT_NET_VALUE",
  aliases: ["NET_VALUE"],
  label: "Net Value",
  type: "currency2",
  group: "contract"
}, {
  key: "CONTRACT_TAX",
  aliases: ["TAX"],
  label: "Tax",
  type: "currency2",
  group: "contract"
}, {
  key: "CONTRACT_TOTAL",
  aliases: ["TOTAL"],
  label: "Total",
  type: "currency2",
  group: "contract"
}, {
  key: "CON_CUS_GROUP",
  label: "Con Cust. Group",
  type: "text",
  group: "contract"
}, {
  key: "CON_PRICE_GROUP",
  label: "Con Price Group",
  type: "text",
  group: "contract"
}, {
  key: "CON_SERVICE_VALID_FRM",
  aliases: ["CON_SRV_VALID_FROM"],
  label: "Con Srv Valid From",
  type: "date",
  group: "contract"
}, {
  key: "CON_SERVICE_VALID_TO",
  aliases: ["CON_SRV_VALID_TO"],
  label: "Con Srv Valid To",
  type: "date",
  group: "contract"
}, {
  key: "CON_SERVICE_START_DT",
  aliases: ["CON_SRV_START_DATE"],
  label: "Con Srv Start",
  type: "date",
  group: "contract"
}, {
  key: "CON_REG_DATE",
  label: "Con Reg. Date",
  type: "date",
  group: "contract"
}, {
  key: "CON_UPPER_SLAB",
  label: "Con Upper Slab",
  type: "decimal3",
  group: "contract"
}, {
  key: "CON_NO_BEDS_INV",
  aliases: ["CON_NO_BEDS_INVOICE"],
  label: "Con Beds to Invoice",
  type: "int",
  group: "contract"
}, {
  key: "CON_AGR_FROM",
  aliases: ["CON_AGR_VALID_FROM"],
  label: "Con Agr. Valid From",
  type: "date",
  group: "contract"
}, {
  key: "CON_AGR_TO",
  aliases: ["CON_AGR_VALID_TO"],
  label: "Con Agr. Valid To",
  type: "date",
  group: "contract"
}, {
  key: "CON_ACTIVE_INACTIVE",
  label: "Con Status",
  type: "status",
  group: "contract"
}, {
  key: "CON_FIXED_RATE",
  label: "Con Fixed Rate",
  type: "currency2",
  group: "contract"
}, {
  key: "CON_PER_BED_RATE",
  label: "Con Per Bed Rate",
  type: "currency2",
  group: "contract"
}, {
  key: "CON_EXCESS_QTY_RATE",
  label: "Con Excess Qty Rate",
  type: "currency2",
  group: "contract"
}];
function releaseCols(suffix, group) {
  const out = [];
  for (let n = 1; n <= 8; n++) {
    out.push({
      key: `REL_${n}${suffix}`,
      label: `Release ${n}`,
      type: "text",
      group
    });
    out.push({
      key: `STATUS_${n}${suffix}`,
      label: `Status ${n}`,
      type: "text",
      group
    });
    out.push({
      key: `APP_REJ_DATE${n}${suffix}`,
      label: `Date ${n}`,
      type: "date",
      group
    });
    out.push({
      key: `APP_REJ_REASON${n}${suffix}`,
      label: `Reason ${n}`,
      type: "text",
      group
    });
  }
  return out;
}
const PH_COLS = [{
  key: "PH_APPROVE_TYPE",
  label: "Approve Type",
  type: "text",
  group: "ph"
}, {
  key: "PH_INITIATED_ID",
  label: "Initiated ID",
  type: "text",
  group: "ph"
}, {
  key: "PH_NAME",
  label: "Name",
  type: "text",
  group: "ph"
}, {
  key: "PH_INITIATED_DATE",
  label: "Initiated Date",
  type: "date",
  group: "ph"
}, {
  key: "PH_STATUS",
  label: "Status",
  type: "text",
  group: "ph"
}, {
  key: "PH_APPROVE_DATE",
  label: "Approve Date",
  type: "date",
  group: "ph"
}, {
  key: "PH_REASON",
  label: "Reason",
  type: "text",
  group: "ph"
}];
const SERVICE_CERT_COLS = [{
  key: "SERVICE_CERT_NO",
  label: "Cert No",
  type: "text",
  group: "service_cert"
}, {
  key: "SERVICE_VALID_FROM",
  label: "Valid From",
  type: "date",
  group: "service_cert"
}, {
  key: "SERVICE_VALID_TO",
  label: "Valid To",
  type: "date",
  group: "service_cert"
}, {
  key: "ISSUE_DATE",
  label: "Issue Date",
  type: "date",
  group: "service_cert"
}, {
  key: "ISSUE_ID",
  label: "Issue ID",
  type: "text",
  group: "service_cert"
}];
const PH_SALES_COLS = [{
  key: "PH_SALES_APPR_TYPE",
  label: "Approve Type",
  type: "text",
  group: "ph_sales"
}, {
  key: "PH_SALES_INIT_ID",
  label: "Initiated ID",
  type: "text",
  group: "ph_sales"
}, {
  key: "PH_SALES_NAME",
  label: "Name",
  type: "text",
  group: "ph_sales"
}, {
  key: "PH_SALES_INIT_DATE",
  label: "Initiated Date",
  type: "date",
  group: "ph_sales"
}, {
  key: "PH_SALES_STATUS",
  label: "Status",
  type: "text",
  group: "ph_sales"
}, {
  key: "PH_SALES_APPR_DATE",
  label: "Approve Date",
  type: "date",
  group: "ph_sales"
}];
const SALES_COLS = [{
  key: "SALES_ORDER_NO",
  label: "Sales Order No",
  type: "text",
  group: "sales"
}, {
  key: "SALES_ITEM",
  label: "Item",
  type: "int",
  group: "sales"
}, {
  key: "SALES_CREATE_DATE",
  label: "Create Date",
  type: "date",
  group: "sales"
}, {
  key: "SALES_CREATED_BY",
  label: "Created By",
  type: "text",
  group: "sales"
}, {
  key: "SALES_MATERIAL",
  label: "Material",
  type: "text",
  group: "sales"
}, {
  key: "SALES_NET_VALUE",
  label: "Net Value",
  type: "currency2",
  group: "sales"
}, {
  key: "SALES_TAX",
  label: "Tax",
  type: "currency2",
  group: "sales"
}, {
  key: "SALES_TOTAL",
  label: "Total",
  type: "currency2",
  group: "sales"
}];
const BILLING_COLS = [{
  key: "BILLING_DOC",
  label: "Billing Doc",
  type: "text",
  group: "billing"
}, {
  key: "ACCOUNTING_DOC",
  label: "Accounting Doc",
  type: "text",
  group: "billing"
}];
const CUSTOMER_SCHEMA = [...CORE_COLS, ...BP_COLS, ...MBD_COLS, ...CONTRACT_COLS];
const CONTRACT_SCHEMA = [...CUSTOMER_SCHEMA, ...releaseCols("_C", "release_c"), ...PH_COLS, ...SERVICE_CERT_COLS];
const SALES_SCHEMA = [...CONTRACT_SCHEMA, ...PH_SALES_COLS, ...SALES_COLS, ...releaseCols("", "release_s"), ...BILLING_COLS];
const SCHEMAS = {
  customer: CUSTOMER_SCHEMA,
  contract: CONTRACT_SCHEMA,
  sales: SALES_SCHEMA
};
function schemaWithSapExtras(schema, rows) {
  const known = new Set(schema.flatMap((c) => [c.key, ...c.aliases ?? []]));
  const extra = [];
  const seen = /* @__PURE__ */ new Set();
  for (const row of rows) {
    for (const key of Object.keys(row)) {
      if (known.has(key) || seen.has(key)) continue;
      seen.add(key);
      extra.push({
        key,
        label: key,
        type: "text",
        group: "extra"
      });
    }
  }
  return extra.length ? [...schema, ...extra] : schema;
}
function splitDateRange(from, to) {
  const single = [{
    from,
    to
  }];
  if (!from || !to) return single;
  const start = /* @__PURE__ */ new Date(`${from}T00:00:00`);
  const end = /* @__PURE__ */ new Date(`${to}T00:00:00`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) return single;
  const iso = (d) => d.toISOString().slice(0, 10);
  const out = [];
  let cursor = start;
  while (cursor <= end && out.length < 60) {
    const next = new Date(cursor);
    next.setMonth(next.getMonth() + 1);
    const chunkEnd = new Date(Math.min(next.getTime() - 864e5, end.getTime()));
    out.push({
      from: iso(cursor),
      to: iso(chunkEnd)
    });
    cursor = new Date(chunkEnd.getTime() + 864e5);
  }
  return out.length > 1 ? out : single;
}
function friendlyFetchError(msg) {
  if (/\b(524|504|502|timed? ?out|timeout)\b/i.test(msg)) {
    return "The SAP call exceeded the gateway timeout before returning data. Narrow the 'Contract/sales created' date range (or the customer range) and try again.";
  }
  return msg;
}
function BmwStatusReportPage() {
  const fetchFn = useServerFn(fetchBmwStatusReport);
  const [salesOrgFrom, setSalesOrgFrom] = reactExports.useState("");
  const [salesOrgTo, setSalesOrgTo] = reactExports.useState("");
  const [customerFrom, setCustomerFrom] = reactExports.useState("");
  const [customerTo, setCustomerTo] = reactExports.useState("");
  const [contractFrom, setContractFrom] = reactExports.useState("");
  const [contractTo, setContractTo] = reactExports.useState("");
  const [mode, setMode] = reactExports.useState("customer");
  const [rows, setRows] = reactExports.useState([]);
  const [activeMode, setActiveMode] = reactExports.useState("customer");
  const [lastFetchedAt, setLastFetchedAt] = reactExports.useState(null);
  const [duplicatesRemoved, setDuplicatesRemoved] = reactExports.useState(0);
  const [progress, setProgress] = reactExports.useState(null);
  const requestSeq = reactExports.useRef(0);
  const mutation = useMutation({
    mutationFn: async () => {
      const reqId = ++requestSeq.current;
      const windows = splitDateRange(contractFrom.trim(), contractTo.trim());
      setProgress(windows.length > 1 ? {
        done: 0,
        total: windows.length
      } : null);
      const seen = /* @__PURE__ */ new Set();
      const merged = [];
      let dupTotal = 0;
      let resolvedMode = mode;
      let lastErr = null;
      for (let i = 0; i < windows.length; i++) {
        const w = windows[i];
        if (reqId !== requestSeq.current) return {
          __reqId: reqId,
          __stale: true
        };
        let v;
        try {
          v = await fetchFn({
            data: {
              sales_org_from: salesOrgFrom.trim(),
              sales_org_to: (salesOrgTo || salesOrgFrom).trim(),
              customer_from: customerFrom.trim(),
              customer_to: customerTo.trim(),
              contract_from: w.from,
              contract_to: w.to,
              mode
            }
          });
        } catch (e) {
          lastErr = friendlyFetchError(e?.message ?? "");
          if (windows.length === 1) throw new Error(lastErr ?? "Failed to fetch report");
          setProgress({
            done: i + 1,
            total: windows.length
          });
          continue;
        }
        if (reqId !== requestSeq.current) return {
          __reqId: reqId,
          __stale: true
        };
        if (v?.error) lastErr = friendlyFetchError(String(v.error));
        resolvedMode = v?.mode ?? mode;
        dupTotal += typeof v?.duplicates_removed === "number" ? v.duplicates_removed : 0;
        const chunk = Array.isArray(v?.rows) ? v.rows : [];
        for (const r of chunk) {
          const key = JSON.stringify(r);
          if (seen.has(key)) {
            dupTotal += 1;
            continue;
          }
          seen.add(key);
          merged.push(r);
        }
        setRows([...merged]);
        setDuplicatesRemoved(dupTotal);
        setActiveMode(resolvedMode);
        setProgress(windows.length > 1 ? {
          done: i + 1,
          total: windows.length
        } : null);
      }
      return {
        __reqId: reqId,
        rows: merged,
        duplicates_removed: dupTotal,
        mode: resolvedMode,
        fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
        error: lastErr,
        chunks: windows.length
      };
    },
    onSettled: () => setProgress(null),
    onSuccess: (res) => {
      if (res?.__reqId !== requestSeq.current || res?.__stale) return;
      const r = Array.isArray(res?.rows) ? res.rows : [];
      const dup = typeof res?.duplicates_removed === "number" ? res.duplicates_removed : 0;
      setRows(r);
      setDuplicatesRemoved(dup);
      setActiveMode(res?.mode ?? mode);
      setLastFetchedAt(res?.fetched_at ?? (/* @__PURE__ */ new Date()).toISOString());
      if (res?.error && r.length === 0) toast.error(res.error);
      else {
        if (res?.error) toast.warning(res.error);
        toast.success(`Loaded ${r.length} record${r.length === 1 ? "" : "s"} from SAP` + (res?.chunks > 1 ? ` in ${res.chunks} date windows` : "") + (dup > 0 ? ` (${dup} exact duplicate row${dup === 1 ? "" : "s"} removed)` : ""));
      }
    },
    onError: (e) => toast.error(friendlyFetchError(e.message ?? "") || "Failed to fetch report")
  });
  function execute() {
    if (mutation.isPending) return;
    if (!salesOrgFrom.trim()) return toast.error("Select Sales Organization From");
    setRows([]);
    setDuplicatesRemoved(0);
    setLastFetchedAt(null);
    setActiveMode(mode);
    mutation.mutate();
  }
  function reset() {
    setSalesOrgFrom("");
    setSalesOrgTo("");
    setCustomerFrom("");
    setCustomerTo("");
    setContractFrom("");
    setContractTo("");
    setMode("customer");
    setRows([]);
    setDuplicatesRemoved(0);
    setActiveMode("customer");
    setLastFetchedAt(null);
  }
  const canExecute = !!salesOrgFrom && !mutation.isPending;
  schemaWithSapExtras(SCHEMAS[activeMode], rows);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "SD Reports", title: "BMW Status Report", subtitle: "Cross-reference customer, contract and sales order approval status in one view." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-2 lg:grid-cols-4 items-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs", children: [
            "Sales Organization From ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(PlantSelect, { value: salesOrgFrom, onChange: setSalesOrgFrom, placeholder: "Select…" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Sales Organization To" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(PlantSelect, { value: salesOrgTo, onChange: setSalesOrgTo, placeholder: "Select…" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Customer From" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CustomerSelect, { value: customerFrom, onChange: setCustomerFrom, plants: salesOrgFrom ? [salesOrgFrom] : [], onEnter: execute, placeholder: "Select customer…" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Customer To" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CustomerSelect, { value: customerTo, onChange: setCustomerTo, plants: salesOrgFrom ? [salesOrgFrom] : [], onEnter: execute, placeholder: "Select customer…" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Contract/sales created from" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: contractFrom, type: "date", onChange: (e) => setContractFrom(e.target.value), onKeyDown: (e) => e.key === "Enter" && execute(), placeholder: "optional", className: "h-9 font-mono" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Contract/sales created to" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: contractTo, type: "date", onChange: (e) => setContractTo(e.target.value), onKeyDown: (e) => e.key === "Enter" && execute(), placeholder: "optional", className: "h-9 font-mono" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 md:col-span-2 lg:col-span-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs", children: [
            "Selection Type ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(RadioGroup, { value: mode, onValueChange: (v) => setMode(v), className: "flex items-center gap-5 h-9", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RadioGroupItem, { value: "customer", id: "bmw-r-cus" }),
              "Customer"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RadioGroupItem, { value: "contract", id: "bmw-r-cont" }),
              "Contract"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RadioGroupItem, { value: "sales", id: "bmw-r-sales" }),
              "Sales Order"
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2 pt-2 border-t", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Reset" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: !canExecute, children: [
          mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
          progress ? `Fetching… (${progress.done}/${progress.total})` : "Execute"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CloudscapeApprovalTable, { title: `BMW Status Report${rows.length > 0 ? ` — ${activeMode}-wise` : ""}`, countLabel: `(${rows.length}${duplicatesRemoved > 0 ? ` · ${duplicatesRemoved} dup removed` : ""})`, rows, rowKey: (_r, i) => String(i), loading: mutation.isPending && rows.length === 0, emptyMessage: mutation.isPending ? progress ? `Fetching… window ${progress.done}/${progress.total}` : "Fetching…" : "No data. Set filters and click Execute.", columns: buildDynamicColumns(rows) })
  ] });
}
export {
  BmwStatusReportPage as component
};
