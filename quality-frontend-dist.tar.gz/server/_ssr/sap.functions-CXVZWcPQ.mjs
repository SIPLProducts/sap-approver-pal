import { c as createServerRpc } from "./createServerRpc-Bm5Y9dpM.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { supabaseAdmin } from "./client.server-D5ro3rAQ.mjs";
import { sapEnabled, fetchOpenApprovals, postDecision, invokeViaMiddleware } from "./sap-client.server-CglbxEth.mjs";
import { s as sendPushToUser } from "./push.server-Co_uxbPF.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import "../_libs/web-push.mjs";
import { a as objectType, z as stringType, D as enumType, E as recordType, H as unknownType } from "../_libs/zod.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";


import "../_libs/asn1.js.mjs";
import "../_libs/bn.js.mjs";
import "../_libs/inherits.mjs";
import "../_libs/safer-buffer.mjs";
import "../_libs/minimalistic-assert.mjs";
import "../_libs/jws.mjs";

import "../_libs/safe-buffer.mjs";
import "../_libs/jwa.mjs";
import "../_libs/ecdsa-sig-formatter.mjs";
import "../_libs/buffer-equal-constant-time.mjs";
import "../_libs/http_ece.mjs";
import "../_libs/https-proxy-agent.mjs";



import "../_libs/debug.mjs";
import "../_libs/ms.mjs";
import "../_libs/supports-color.mjs";

import "../_libs/has-flag.mjs";
import "../_libs/agent-base.mjs";
const DOC_TYPES = ["ZNFA", "ZNFA_TER", "PR", "PO", "SR", "MIGO", "ZGP", "ZMM_REV", "BMW_PRICE", "BMW_CONTRACT", "BMW_SO", "BMW_ZERO_WASTE", "BMW_SC_ISSUE", "IWM_PRICE", "SD_VK11", "SD_ZV13", "SD_ZREP_SCR"];
const STRATEGY = {
  ZNFA: {
    roles: ["F1", "F6", "M1", "M3", "M5", "MD"],
    sapTCode: "ZNFA",
    module: "MM"
  },
  ZNFA_TER: {
    roles: ["T4"],
    sapTCode: "ZNFA_TER",
    module: "MM"
  },
  PR: {
    roles: ["IC", "M1", "M2", "M3", "T1", "T4", "T6"],
    sapTCode: "ME54N",
    module: "MM"
  },
  PO: {
    roles: ["ZZ", "F3", "F6", "T6", "S4"],
    sapTCode: "ME29N",
    module: "MM"
  },
  SR: {
    roles: ["SR", "F1", "M3", "M4"],
    sapTCode: "ML81N",
    module: "MM"
  },
  MIGO: {
    roles: ["PlantHead"],
    sapTCode: "MIGO",
    module: "MM"
  },
  ZGP: {
    roles: ["HOD", "StoreHOD", "SCMHead", "PlantHead", "StoreHOD"],
    sapTCode: "ZGP",
    module: "MM"
  },
  ZMM_REV: {
    roles: ["HOD"],
    sapTCode: "ZMM_REV",
    module: "MM"
  },
  BMW_PRICE: {
    roles: ["ProjectHead"],
    sapTCode: "ZBMW_VK11_APP",
    module: "SD"
  },
  BMW_CONTRACT: {
    roles: ["FinanceHead", "ProjectHead"],
    sapTCode: "ZBMW_CONTRACT_APP",
    module: "SD"
  },
  BMW_SO: {
    roles: ["FinanceHead", "ProjectHead"],
    sapTCode: "ZSD_BMW_SO_APP",
    module: "SD"
  },
  BMW_ZERO_WASTE: {
    roles: ["ProjectHead"],
    sapTCode: "ZBMW_COCKPIT",
    module: "SD"
  },
  BMW_SC_ISSUE: {
    roles: ["ProjectHead"],
    sapTCode: "ZBMW_SC_ISSUE_PH",
    module: "SD"
  },
  IWM_PRICE: {
    roles: ["ProjectHead"],
    sapTCode: "ZIWM_APPROVE",
    module: "SD"
  },
  SD_VK11: {
    roles: ["MBD"],
    sapTCode: "VK11",
    module: "SD"
  },
  SD_ZV13: {
    roles: ["MBD"],
    sapTCode: "ZV13",
    module: "SD"
  },
  SD_ZREP_SCR: {
    roles: ["FA"],
    sapTCode: "ZREP_SCR",
    module: "SD"
  }
};
const PLANTS = ["RES-HYD-01", "RES-MUM-02", "RES-BLR-03", "RES-DEL-04"];
const BUS = ["IWM", "BMW", "Recycling", "ISS"];
const VENDORS = ["Acme Industrial Pvt Ltd", "Greentech Recyclers", "Veolia India", "Bharat Sustainable Co", "Eco-Logix Ltd"];
const CUSTOMERS = ["Tata Steel", "Reliance", "ITC Ltd", "Aditya Birla", "Mahindra"];
function rng(seed) {
  let s = seed;
  return () => (s = (s * 9301 + 49297) % 233280) / 233280;
}
function generateMockBatch(now) {
  const out = [];
  let i = 0;
  for (const dt of DOC_TYPES) {
    const r = rng(dt.length * 1e3 + dt.charCodeAt(0));
    const count = 2 + Math.floor(r() * 3);
    for (let n = 0; n < count; n++) {
      i++;
      const strat = STRATEGY[dt];
      const isSD = strat.module === "SD";
      const value = Math.round((1e4 + r() * 9e6) * 100) / 100;
      const plant = PLANTS[Math.floor(r() * PLANTS.length)];
      const bu = isSD ? r() < 0.5 ? "BMW" : "IWM" : BUS[Math.floor(r() * BUS.length)];
      const sapDocNo = `${dt}-${String(1e5 + i * 17).padStart(7, "0")}`;
      const title = isSD ? `${dt.replace("_", " ")} for ${CUSTOMERS[Math.floor(r() * CUSTOMERS.length)]}` : `${dt.replace("_", " ")} – ${VENDORS[Math.floor(r() * VENDORS.length)]}`;
      const days = Math.floor(r() * 6);
      const ddate = new Date(now.getTime() - days * 24 * 3600 * 1e3);
      const linesCount = 1 + Math.floor(r() * 4);
      const lines = Array.from({
        length: linesCount
      }, (_, li) => {
        const qty = 1 + Math.floor(r() * 20);
        const price = Math.round(value / linesCount / Math.max(qty, 1) * 100) / 100;
        return {
          line_no: li + 1,
          material_code: `M-${1e5 + Math.floor(r() * 9e5)}`,
          description: isSD ? ["Hazardous waste handling", "Scrap collection", "Service certificate", "Plant maintenance"][li % 4] : ["Industrial bearings", "Safety gloves – pack of 50", "Hydraulic oil drum", "HDPE liner roll"][li % 4],
          quantity: qty,
          uom: ["EA", "KG", "LTR", "ROLL"][li % 4],
          unit_price: price,
          amount: Math.round(qty * price * 100) / 100
        };
      });
      out.push({
        doc: {
          module: strat.module,
          doc_type: dt,
          sap_t_code: strat.sapTCode,
          sap_doc_no: sapDocNo,
          title,
          description: isSD ? "Sales-side approval routed from SAP cockpit." : "Procurement document pending release.",
          plant,
          business_unit: bu,
          company_code: isSD ? bu : "1000",
          vendor_name: isSD ? null : VENDORS[Math.floor(r() * VENDORS.length)],
          customer_name: isSD ? CUSTOMERS[Math.floor(r() * CUSTOMERS.length)] : null,
          requester_name: ["A. Rao", "S. Kumar", "N. Iyer", "R. Singh", "P. Mehta"][Math.floor(r() * 5)],
          requester_sap_id: `EMP${String(1e3 + Math.floor(r() * 9e3))}`,
          total_value: value,
          currency: "INR",
          document_date: ddate.toISOString().slice(0, 10),
          current_step_seq: 1,
          status: "pending",
          sap_payload: {
            source: "MOCK",
            t_code: strat.sapTCode
          }
        },
        steps: strat.roles.map((role, idx) => ({
          seq: idx + 1,
          role
        })),
        lines
      });
    }
  }
  return out;
}
function mapSapItem(it) {
  return {
    doc: {
      module: it.module,
      doc_type: it.doc_type,
      sap_t_code: it.sap_t_code,
      sap_doc_no: it.sap_doc_no,
      title: it.title,
      description: it.description ?? null,
      plant: it.plant ?? null,
      business_unit: it.business_unit ?? null,
      company_code: it.company_code ?? null,
      vendor_name: it.vendor_name ?? null,
      customer_name: it.customer_name ?? null,
      requester_name: it.requester_name,
      requester_sap_id: it.requester_sap_id ?? null,
      total_value: it.total_value,
      currency: it.currency || "INR",
      document_date: it.document_date,
      current_step_seq: 1,
      status: "pending",
      sap_payload: {
        source: "SAP",
        t_code: it.sap_t_code
      }
    },
    steps: it.steps,
    lines: it.lines
  };
}
const syncFromSAP_createServerFn_handler = createServerRpc({
  id: "e588a3a42a79643703e8fc58b19550c2e037b2e8f676047ac729abc367bacc7e",
  name: "syncFromSAP",
  filename: "src/lib/sap/sap.functions.ts"
}, (opts) => syncFromSAP.__executeServer(opts));
const syncFromSAP = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(syncFromSAP_createServerFn_handler, async () => {
  let batch;
  if (sapEnabled()) {
    const items = await fetchOpenApprovals();
    batch = items.map(mapSapItem);
  } else {
    batch = generateMockBatch(/* @__PURE__ */ new Date());
  }
  const {
    data: roleRows
  } = await supabaseAdmin.from("user_roles").select("user_id, role");
  const roleMap = /* @__PURE__ */ new Map();
  for (const r of roleRows ?? []) {
    const list = roleMap.get(r.role) ?? [];
    list.push(r.user_id);
    roleMap.set(r.role, list);
  }
  let inserted = 0;
  for (const item of batch) {
    const {
      data: existing
    } = await supabaseAdmin.from("approval_documents").select("id").eq("doc_type", item.doc.doc_type).eq("sap_doc_no", item.doc.sap_doc_no).maybeSingle();
    if (existing) continue;
    const {
      data: doc,
      error: docErr
    } = await supabaseAdmin.from("approval_documents").insert(item.doc).select().single();
    if (docErr || !doc) continue;
    inserted++;
    if (item.lines.length) {
      await supabaseAdmin.from("approval_line_items").insert(item.lines.map((l) => ({
        ...l,
        document_id: doc.id
      })));
    }
    const steps = item.steps.map((s, idx) => {
      const candidates = roleMap.get(s.role) ?? [];
      const assigned = candidates[0] ?? null;
      return {
        document_id: doc.id,
        seq: s.seq,
        role: s.role,
        assigned_user: assigned,
        status: idx === 0 ? "pending" : "waiting"
      };
    });
    await supabaseAdmin.from("approval_steps").insert(steps);
    const firstAssignee = steps[0]?.assigned_user;
    if (firstAssignee) {
      await supabaseAdmin.from("notifications").insert({
        user_id: firstAssignee,
        document_id: doc.id,
        title: `New approval: ${doc.sap_doc_no}`,
        body: `${doc.title} — ₹${doc.total_value.toLocaleString("en-IN")}`,
        kind: "assignment"
      });
      await sendPushToUser(firstAssignee, {
        title: `New approval: ${doc.sap_doc_no}`,
        body: `${doc.title} — ₹${doc.total_value.toLocaleString("en-IN")}`,
        url: `/approval/${doc.id}`,
        tag: `doc-${doc.id}`
      });
    }
    await supabaseAdmin.from("audit_log").insert({
      document_id: doc.id,
      actor: null,
      actor_name: "SAP Sync",
      action: "imported",
      details: {
        sap_t_code: doc.sap_t_code
      }
    });
  }
  return {
    inserted,
    total_pulled: batch.length
  };
});
const ActionInput = objectType({
  documentId: stringType().uuid(),
  action: enumType(["approve", "reject", "send_back"]),
  comments: stringType().max(2e3).optional()
});
const decideStep_createServerFn_handler = createServerRpc({
  id: "2168ff80ec4bfb5ab4f8ec9cac835108649eedc4efba3a710d6090bee795b1bc",
  name: "decideStep",
  filename: "src/lib/sap/sap.functions.ts"
}, (opts) => decideStep.__executeServer(opts));
const decideStep = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => ActionInput.parse(input)).handler(decideStep_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase: userClient,
    userId
  } = context;
  const {
    data: doc,
    error: docErr
  } = await userClient.from("approval_documents").select("*").eq("id", data.documentId).maybeSingle();
  if (docErr || !doc) throw new Error("Document not found or not visible");
  const {
    data: steps
  } = await userClient.from("approval_steps").select("*").eq("document_id", doc.id).order("seq", {
    ascending: true
  });
  if (!steps?.length) throw new Error("No approval chain found");
  const current = steps.find((s) => s.seq === doc.current_step_seq);
  if (!current) throw new Error("No active step");
  if (current.assigned_user !== userId) throw new Error("Not your step to action");
  if (current.status !== "pending") throw new Error("Step already decided");
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const newStatus = data.action === "approve" ? "approved" : data.action === "reject" ? "rejected" : "sent_back";
  await userClient.from("approval_steps").update({
    status: newStatus,
    decided_at: now,
    comments: data.comments ?? null
  }).eq("id", current.id);
  if (data.action === "approve") {
    const next = steps.find((s) => s.seq === current.seq + 1);
    if (next) {
      await supabaseAdmin.from("approval_steps").update({
        status: "pending"
      }).eq("id", next.id);
      await supabaseAdmin.from("approval_documents").update({
        current_step_seq: next.seq
      }).eq("id", doc.id);
      if (next.assigned_user) {
        await supabaseAdmin.from("notifications").insert({
          user_id: next.assigned_user,
          document_id: doc.id,
          title: `Approval pending: ${doc.sap_doc_no}`,
          body: `${doc.title} — your action required`,
          kind: "assignment"
        });
        await sendPushToUser(next.assigned_user, {
          title: `Approval pending: ${doc.sap_doc_no}`,
          body: `${doc.title} — your action required`,
          url: `/approval/${doc.id}`,
          tag: `doc-${doc.id}`
        });
      }
    } else {
      await supabaseAdmin.from("approval_documents").update({
        status: "approved"
      }).eq("id", doc.id);
      if (doc.raised_by_user) {
        await supabaseAdmin.from("notifications").insert({
          user_id: doc.raised_by_user,
          document_id: doc.id,
          title: `Approved: ${doc.sap_doc_no}`,
          body: `${doc.title} is fully approved.`,
          kind: "outcome"
        });
        await sendPushToUser(doc.raised_by_user, {
          title: `Approved: ${doc.sap_doc_no}`,
          body: `${doc.title} is fully approved.`,
          url: `/approval/${doc.id}`,
          tag: `doc-${doc.id}`
        });
      }
    }
  } else {
    await supabaseAdmin.from("approval_documents").update({
      status: newStatus
    }).eq("id", doc.id);
    if (doc.raised_by_user) {
      await supabaseAdmin.from("notifications").insert({
        user_id: doc.raised_by_user,
        document_id: doc.id,
        title: `${newStatus.toUpperCase()}: ${doc.sap_doc_no}`,
        body: data.comments ?? "",
        kind: "outcome"
      });
      await sendPushToUser(doc.raised_by_user, {
        title: `${newStatus.toUpperCase()}: ${doc.sap_doc_no}`,
        body: data.comments ?? "",
        url: `/approval/${doc.id}`,
        tag: `doc-${doc.id}`
      });
    }
  }
  await supabaseAdmin.from("audit_log").insert({
    document_id: doc.id,
    actor: userId,
    actor_name: null,
    action: data.action,
    details: {
      comments: data.comments ?? null,
      step_seq: current.seq,
      role: current.role
    }
  });
  if (sapEnabled()) {
    try {
      await postDecision({
        sapDocNo: doc.sap_doc_no,
        action: data.action,
        comments: data.comments ?? null,
        role: current.role,
        stepSeq: current.seq,
        actorSapId: null
      });
    } catch (err) {
      console.error("SAP postDecision failed", err);
      await supabaseAdmin.from("audit_log").insert({
        document_id: doc.id,
        actor: userId,
        action: "sap_post_failed",
        details: {
          error: err.message
        }
      });
    }
  }
  return {
    ok: true
  };
});
const RunSapInput = objectType({
  configId: stringType().uuid(),
  inputs: recordType(stringType(), unknownType()).optional().default({})
});
const runSapApi_createServerFn_handler = createServerRpc({
  id: "15429faf95fe4dfe7a1118d539cb815e469213051e804670c84f9a95063282d0",
  name: "runSapApi",
  filename: "src/lib/sap/sap.functions.ts"
}, (opts) => runSapApi.__executeServer(opts));
const runSapApi = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => RunSapInput.parse(d)).handler(runSapApi_createServerFn_handler, async ({
  data
}) => {
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("auth_type, is_active").eq("id", data.configId).maybeSingle();
  if (!cfg) throw new Error("API config not found");
  if (!cfg.is_active) throw new Error("API config is inactive");
  const {
    data: global
  } = await supabaseAdmin.from("sap_global_settings").select("connection_mode").eq("id", "default").maybeSingle();
  const useProxy = cfg.auth_type === "proxy" || global?.connection_mode === "via_proxy";
  if (useProxy) {
    return invokeViaMiddleware(data.configId, data.inputs);
  }
  throw new Error("Direct mode is not supported for generic API calls yet. Set Connection Mode = Via Proxy in SAP API Settings → Middleware Configuration.");
});
export {
  decideStep_createServerFn_handler,
  runSapApi_createServerFn_handler,
  syncFromSAP_createServerFn_handler
};
