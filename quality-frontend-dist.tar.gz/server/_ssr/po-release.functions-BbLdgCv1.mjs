import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-Bm5Y9dpM.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, C as arrayType, z as stringType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "PO_Release_Multiple_Fetch_API";
const fetchPoReleaseMultiple_createServerFn_handler = createServerRpc({
  id: "cbf5aefc482f7a31847fd5286ecb4dce5e98caf7ca607189c5fa428c35006db5",
  name: "fetchPoReleaseMultiple",
  filename: "src/lib/mm/po-release.functions.ts"
}, (opts) => fetchPoReleaseMultiple.__executeServer(opts));
const fetchPoReleaseMultiple = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  relgroup: stringType().trim().min(1, "Release Group is required").max(10),
  relcode: stringType().trim().min(1, "Release Code is required").max(10),
  plants: arrayType(stringType().trim().min(1)).min(1, "At least one plant is required")
}).parse(d)).handler(fetchPoReleaseMultiple_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const inputs = {
    RELGROUP: data.relgroup.trim(),
    RELCODE: data.relcode.trim(),
    PLANTS: data.plants.map((p) => ({
      PLANT: p.trim()
    }))
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "GET";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs
    });
    proxied = true;
  } else {
    const qs = new URLSearchParams({
      RELGROUP: data.relgroup.trim(),
      RELCODE: data.relcode.trim(),
      PLANTS: data.plants.join(",")
    }).toString();
    const join = cfg.endpoint_url.includes("?") ? "&" : "?";
    target = `${cfg.endpoint_url}${join}${qs}`;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `po-release-multi network: ${errMsg}`
    });
    return {
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      error: `Could not reach SAP. ${errMsg}.`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `po-release-multi: ${message} ${text.slice(0, 500)}`
    });
    return {
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  const dataArr = Array.isArray(sapJson) ? sapJson : Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : [];
  const rows = dataArr.map((r) => r && typeof r === "object" ? {
    ...r
  } : {});
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `po-release-multi: ${message}`
  });
  return {
    data: rows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    error: null
  };
});
const RELEASE_CONFIG_NAME = "PO_Release_API";
const REJECT_CONFIG_NAME = "PO_REJECT_API";
async function processPoAction(configName, payloadKey, data, logTag) {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", configName).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${configName}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${configName}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  const baseHeaders = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  if (useProxy) {
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) baseHeaders["x-shared-secret"] = secret;
  } else if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
    baseHeaders.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    baseHeaders[k] = v;
  }
  const results = [];
  const isRelease = payloadKey === "RELEASE";
  const groups = /* @__PURE__ */ new Map();
  for (const it of data.items) {
    const g = groups.get(it.EBELN);
    if (g) {
      g.ebelps.push(it.EBELP);
      if (!g.remarks && it.REMARKS) g.remarks = it.REMARKS;
    } else {
      groups.set(it.EBELN, {
        ebelps: [it.EBELP],
        remarks: it.REMARKS ?? ""
      });
    }
  }
  for (const [ebeln, grp] of groups) {
    const ebelp = "";
    const inputs = isRelease ? {
      RELEASE: {
        EBELN: ebeln,
        FRGCO: data.relcode.trim(),
        REMARKS: grp.remarks
      }
    } : {
      REJECT: {
        EBELN: ebeln,
        REMARKS: grp.remarks
      }
    };
    let target;
    let method = cfg.http_method ?? "POST";
    let bodyOut;
    let proxied = false;
    if (useProxy) {
      if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
      target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
      method = "POST";
      bodyOut = JSON.stringify({
        configId: cfg.id,
        inputs
      });
      proxied = true;
    } else {
      target = cfg.endpoint_url;
      bodyOut = JSON.stringify(inputs);
    }
    const t0 = Date.now();
    let msgtxt = "";
    let ok = false;
    let errMsg;
    let sapResponse = void 0;
    let primaryOut = void 0;
    try {
      const res = await fetch(target, {
        method,
        headers: baseHeaders,
        body: bodyOut
      });
      const text = await res.text().catch(() => "");
      const latency_ms = Date.now() - t0;
      if (!res.ok) {
        errMsg = `SAP ${res.status} ${res.statusText}: ${text.slice(0, 200)}`;
      } else {
        let json = {};
        try {
          json = text ? JSON.parse(text) : {};
        } catch {
          errMsg = `Invalid JSON from SAP: ${text.slice(0, 200)}`;
        }
        if (!errMsg) {
          if (proxied && json?.ok !== true) {
            errMsg = String(json?.error ?? `Middleware reported SAP status ${json?.status ?? "unknown"}.`);
          } else {
            const sapJson = proxied ? json?.data : json;
            sapResponse = sapJson;
            const primary = Array.isArray(sapJson) ? sapJson[0] : Array.isArray(sapJson?.DATA) ? sapJson.DATA[0] : Array.isArray(sapJson?.data) ? sapJson.data[0] : sapJson;
            primaryOut = primary;
            const findFirst = (obj, keys) => {
              if (!obj || typeof obj !== "object") return void 0;
              const wanted = new Set(keys.map((key) => key.toUpperCase()));
              for (const [key, value] of Object.entries(obj)) {
                if (wanted.has(key.toUpperCase())) return value;
              }
              for (const value of Object.values(obj)) {
                const found = findFirst(value, keys);
                if (found !== void 0) return found;
              }
              return void 0;
            };
            msgtxt = String(findFirst(primary, ["MSGTXT", "MESSAGE"]) ?? "");
            const status = String(findFirst(primary, ["STATUS", "MSGTY", "TYPE"]) ?? "").trim().toUpperCase();
            const successStatuses = /* @__PURE__ */ new Set(["S", "I", "SUCCESS", "OK", "RELEASED", "TRUE", "T", "Y", "YES"]);
            const failureStatuses = /* @__PURE__ */ new Set(["FALSE", "F", "N", "NO", "E"]);
            const hasPayload = sapJson !== null && typeof sapJson === "object" && (Array.isArray(sapJson) ? sapJson.length > 0 : Object.keys(sapJson).length > 0);
            if (!hasPayload) {
              errMsg = `SAP returned an empty response; ${logTag} success could not be confirmed.`;
            } else if (!status) {
              errMsg = msgtxt || `SAP response did not include a ${logTag} status.`;
            } else if (successStatuses.has(status)) {
              ok = true;
            } else if (failureStatuses.has(status)) {
              errMsg = msgtxt || `SAP returned ${logTag} status ${status}.`;
            } else {
              errMsg = msgtxt || `SAP returned ${logTag} status ${status}.`;
            }
          }
        }
      }
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: ok && !errMsg ? "ok" : "error",
        latency_ms,
        rows_processed: 1,
        message: `po-${logTag} ${ebeln}${ebelp ? `/${ebelp}` : ""}: ${errMsg ?? msgtxt ?? "done"}`.slice(0, 500)
      });
    } catch (e) {
      errMsg = e.message || "fetch failed";
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: "error",
        latency_ms: Date.now() - t0,
        message: `po-${logTag} network ${ebeln}: ${errMsg}`.slice(0, 500)
      });
    }
    const pick = (k) => {
      const src = primaryOut;
      if (!src || typeof src !== "object") return void 0;
      for (const [key, value] of Object.entries(src)) {
        if (key.toUpperCase() === k) return value == null ? void 0 : String(value);
      }
      return void 0;
    };
    const common = {
      ok: ok && !errMsg,
      msgtxt,
      error: errMsg,
      response: sapResponse,
      MSGTXT: pick("MSGTXT"),
      STATUS: pick("STATUS"),
      RELSTATUS: pick("RELSTATUS"),
      INDICATOR: pick("INDICATOR")
    };
    for (const ep of grp.ebelps) {
      results.push({
        ebeln,
        ebelp: ep,
        ...common
      });
    }
  }
  return {
    results,
    error: null
  };
}
const poActionInput = objectType({
  relgroup: stringType().trim().min(1).max(10),
  relcode: stringType().trim().min(1).max(10),
  items: arrayType(objectType({
    EBELN: stringType().trim().min(1),
    EBELP: stringType().trim().default(""),
    REMARKS: stringType().optional().default("")
  })).min(1)
});
const releasePoItems_createServerFn_handler = createServerRpc({
  id: "8d5655541850e5c45ac9b1924025c12a3db2078072827ad9f3467aa7b30c68a6",
  name: "releasePoItems",
  filename: "src/lib/mm/po-release.functions.ts"
}, (opts) => releasePoItems.__executeServer(opts));
const releasePoItems = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => poActionInput.parse(d)).handler(releasePoItems_createServerFn_handler, async ({
  data
}) => processPoAction(RELEASE_CONFIG_NAME, "RELEASE", data, "release"));
const rejectPoItems_createServerFn_handler = createServerRpc({
  id: "fcc316c5f4e14fd42cdb8e9dac52f02d2be76ef2509026ada47ac8702d0d7509",
  name: "rejectPoItems",
  filename: "src/lib/mm/po-release.functions.ts"
}, (opts) => rejectPoItems.__executeServer(opts));
const rejectPoItems = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => poActionInput.parse(d)).handler(rejectPoItems_createServerFn_handler, async ({
  data
}) => processPoAction(REJECT_CONFIG_NAME, "REJECT", data, "reject"));
const PO_GET_CONFIG_NAME = "PO_GET_API";
const fetchPoGet_createServerFn_handler = createServerRpc({
  id: "2268d63a82c03e043889eab91ed815ce2b8ac40adedbaf16cbade97047f7b6fa",
  name: "fetchPoGet",
  filename: "src/lib/mm/po-release.functions.ts"
}, (opts) => fetchPoGet.__executeServer(opts));
const fetchPoGet = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  relgroup: stringType().trim().min(1, "Release Group is required").max(10),
  relcode: stringType().trim().min(1, "Release Code is required").max(10),
  plants: arrayType(stringType().trim().min(1)).min(1, "At least one plant is required")
}).parse(d)).handler(fetchPoGet_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", PO_GET_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${PO_GET_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${PO_GET_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  const baseHeaders = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  if (useProxy) {
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) baseHeaders["x-shared-secret"] = secret;
  } else if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
    baseHeaders.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    baseHeaders[k] = v;
  }
  const allRows = [];
  let firstError = null;
  for (const plant of data.plants) {
    const inputs = {
      GET: {
        WERKS: plant.trim(),
        FRGGR: data.relgroup.trim(),
        FRGCO: data.relcode.trim()
      }
    };
    let target;
    let method = cfg.http_method ?? "POST";
    let bodyOut;
    let proxied = false;
    if (useProxy) {
      if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
      target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
      method = "POST";
      bodyOut = JSON.stringify({
        configId: cfg.id,
        inputs,
        raw: true
      });
      proxied = true;
    } else {
      target = cfg.endpoint_url;
      bodyOut = JSON.stringify(inputs);
    }
    const t0 = Date.now();
    try {
      const res = await fetch(target, {
        method,
        headers: baseHeaders,
        body: bodyOut
      });
      const text = await res.text().catch(() => "");
      const latency_ms = Date.now() - t0;
      if (!res.ok) {
        const msg = `SAP ${res.status} ${res.statusText}: ${text.slice(0, 200)}`;
        if (!firstError) firstError = msg;
        await supabaseAdmin.from("sap_api_sync_log").insert({
          config_id: cfg.id,
          status: "error",
          latency_ms,
          message: `po-get ${plant}: ${msg}`.slice(0, 500)
        });
        continue;
      }
      let json = {};
      try {
        json = text ? JSON.parse(text) : {};
      } catch {
        const msg = `Invalid JSON from SAP: ${text.slice(0, 200)}`;
        if (!firstError) firstError = msg;
        continue;
      }
      const sapJson = proxied ? json?.data ?? json ?? {} : json;
      const arr = Array.isArray(sapJson) ? sapJson : Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : [];
      for (const r of arr) {
        if (r && typeof r === "object") allRows.push({
          ...r
        });
      }
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: "ok",
        latency_ms,
        rows_processed: arr.length,
        message: `po-get ${plant}: ${res.status} ${res.statusText}`.slice(0, 500)
      });
    } catch (e) {
      const errMsg = e.message || "fetch failed";
      if (!firstError) firstError = `Could not reach SAP. ${errMsg}.`;
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: "error",
        latency_ms: Date.now() - t0,
        message: `po-get network ${plant}: ${errMsg}`.slice(0, 500)
      });
    }
  }
  return {
    data: allRows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    error: allRows.length === 0 ? firstError : null
  };
});
export {
  fetchPoGet_createServerFn_handler,
  fetchPoReleaseMultiple_createServerFn_handler,
  rejectPoItems_createServerFn_handler,
  releasePoItems_createServerFn_handler
};
