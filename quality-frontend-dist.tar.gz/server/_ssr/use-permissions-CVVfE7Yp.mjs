import { r as reactExports } from "../_libs/react.mjs";
import { u as useAuth } from "./use-auth-CXN9VXh3.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { activityToScreenKey } from "./screen-keys-mn2QOK0m.mjs";
function usePermissions() {
  const { user, loading: authLoading } = useAuth();
  const { activeRole, activeActivities, loading: ctxLoading } = useActiveContext();
  const allowedScreens = reactExports.useMemo(() => {
    const s = /* @__PURE__ */ new Set();
    for (const a of activeActivities) {
      const key = activityToScreenKey(a);
      if (key) s.add(key);
    }
    return s;
  }, [activeActivities]);
  const isAdmin = reactExports.useMemo(
    () => activeActivities.some((a) => a.trim().toUpperCase().startsWith("ADMIN.")),
    [activeActivities]
  );
  const loading = authLoading || ctxLoading;
  const ready = !loading && !!user;
  function can(screen, _action = "view") {
    return allowedScreens.has(screen);
  }
  return {
    loading,
    ready,
    isAdmin,
    activeRoleLabel: activeRole?.label ?? null,
    allowedScreens,
    can
  };
}
export {
  usePermissions as u
};
