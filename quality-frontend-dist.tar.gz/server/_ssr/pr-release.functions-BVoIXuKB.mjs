import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, C as arrayType, z as stringType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "PR_Release_Multiple_Fetch_API";
const fetchPrReleaseMultiple_createServerFn_handler = createServerRpc({
  id: "f32a083b61e4d5b77868a768fb0b2c49fb26ba96b02ce15094cd38900080ed89",
  name: "fetchPrReleaseMultiple",
  filename: "src/lib/mm/pr-release.functions.ts"
}, (opts) => fetchPrReleaseMultiple.__executeServer(opts));
const fetchPrReleaseMultiple = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  relgroup: stringType().trim().min(1, "Release Group is required").max(10),
  relcode: stringType().trim().min(1, "Release Code is required").max(10),
  plants: arrayType(stringType().trim().min(1)).min(1, "At least one plant is required")
}).parse(d)).handler(fetchPrReleaseMultiple_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  const headers = {
    Accept: "application/json"
  };
  if (useProxy) {
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
  } else if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
    headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const allRows = [];
  let firstError = null;
  for (const plantRaw of data.plants) {
    const inputs = {
      PLANT: plantRaw.trim(),
      RELGROUP: data.relgroup.trim(),
      RELCODE: data.relcode.trim()
    };
    let target;
    let method = cfg.http_method ?? "GET";
    let bodyOut;
    let proxied = false;
    if (useProxy) {
      if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
      target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
      method = "POST";
      bodyOut = JSON.stringify({
        configId: cfg.id,
        inputs
      });
      proxied = true;
    } else {
      const qs = new URLSearchParams(inputs).toString();
      const join = cfg.endpoint_url.includes("?") ? "&" : "?";
      target = `${cfg.endpoint_url}${join}${qs}`;
    }
    const t0 = Date.now();
    let res;
    try {
      res = await fetch(target, {
        method,
        headers,
        body: bodyOut
      });
    } catch (e) {
      const errMsg = e.message || "fetch failed";
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: "error",
        latency_ms: Date.now() - t0,
        message: `pr-release-multi network: ${errMsg}`
      });
      firstError = firstError ?? `Could not reach SAP. ${errMsg}.`;
      continue;
    }
    const text = await res.text().catch(() => "");
    const message = `${res.status} ${res.statusText}`;
    const latency_ms = Date.now() - t0;
    if (!res.ok) {
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: "error",
        latency_ms,
        message: `pr-release-multi: ${message} ${text.slice(0, 500)}`
      });
      firstError = firstError ?? `SAP returned ${message}: ${text.slice(0, 200)}`;
      continue;
    }
    let json = {};
    try {
      json = text ? JSON.parse(text) : {};
    } catch {
      firstError = firstError ?? `Invalid JSON from SAP: ${text.slice(0, 200)}`;
      continue;
    }
    const sapJson = proxied ? json?.data ?? json ?? {} : json;
    const dataArr = Array.isArray(sapJson) ? sapJson : Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : [];
    const rows = dataArr.map((r) => r && typeof r === "object" ? {
      ...r
    } : {});
    allRows.push(...rows);
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "ok",
      latency_ms,
      rows_processed: rows.length,
      message: `pr-release-multi: ${message}`
    });
  }
  return {
    data: allRows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    error: allRows.length === 0 ? firstError : null
  };
});
const RELEASE_CONFIG_NAME = "PR_Release_API";
const REJECT_CONFIG_NAME = "PR_Reject_API";
async function processPrAction(configName, payloadKey, data, logTag) {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", configName).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${configName}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${configName}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  const baseHeaders = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  if (useProxy) {
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) baseHeaders["x-shared-secret"] = secret;
  } else if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
    baseHeaders.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    baseHeaders[k] = v;
  }
  const results = [];
  for (const item of data.items) {
    const inputs = {
      [payloadKey]: {
        BANFN: item.PREQ_NO,
        BNFPO: item.PREQ_ITEM,
        REL_CODE: data.relcode.trim(),
        REL_GRP: data.relgroup.trim(),
        REMARKS: item.REMARKS ?? ""
      }
    };
    let target;
    let method = cfg.http_method ?? "POST";
    let bodyOut;
    let proxied = false;
    if (useProxy) {
      if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
      target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
      method = "POST";
      bodyOut = JSON.stringify({
        configId: cfg.id,
        inputs
      });
      proxied = true;
    } else {
      target = cfg.endpoint_url;
      bodyOut = JSON.stringify(inputs);
    }
    const t0 = Date.now();
    let msgtxt = "";
    let ok = false;
    let errMsg;
    try {
      const res = await fetch(target, {
        method,
        headers: baseHeaders,
        body: bodyOut
      });
      const text = await res.text().catch(() => "");
      const latency_ms = Date.now() - t0;
      if (!res.ok) {
        errMsg = `SAP ${res.status} ${res.statusText}: ${text.slice(0, 200)}`;
      } else {
        let json = {};
        try {
          json = text ? JSON.parse(text) : {};
        } catch {
          errMsg = `Invalid JSON from SAP: ${text.slice(0, 200)}`;
        }
        if (!errMsg) {
          if (proxied && json?.ok !== true) {
            errMsg = String(json?.error ?? `Middleware reported SAP status ${json?.status ?? "unknown"}.`);
          } else {
            const sapJson = proxied ? json?.data : json;
            const primary = Array.isArray(sapJson) ? sapJson[0] : Array.isArray(sapJson?.DATA) ? sapJson.DATA[0] : Array.isArray(sapJson?.data) ? sapJson.data[0] : sapJson;
            const findFirst = (obj, keys) => {
              if (!obj || typeof obj !== "object") return void 0;
              const wanted = new Set(keys.map((key) => key.toUpperCase()));
              for (const [key, value] of Object.entries(obj)) {
                if (wanted.has(key.toUpperCase())) return value;
              }
              for (const value of Object.values(obj)) {
                const found = findFirst(value, keys);
                if (found !== void 0) return found;
              }
              return void 0;
            };
            msgtxt = String(findFirst(primary, ["MSGTXT", "MESSAGE"]) ?? "");
            const status = String(findFirst(primary, ["STATUS", "MSGTY", "TYPE"]) ?? "").trim().toUpperCase();
            const successStatuses = /* @__PURE__ */ new Set(["S", "I", "SUCCESS", "OK", "RELEASED", "TRUE", "T", "Y", "YES"]);
            const failureStatuses = /* @__PURE__ */ new Set(["FALSE", "F", "N", "NO", "E"]);
            const hasPayload = sapJson !== null && typeof sapJson === "object" && (Array.isArray(sapJson) ? sapJson.length > 0 : Object.keys(sapJson).length > 0);
            if (!hasPayload) {
              errMsg = `SAP returned an empty response; ${logTag} success could not be confirmed.`;
            } else if (!status) {
              errMsg = msgtxt || `SAP response did not include a ${logTag} status.`;
            } else if (successStatuses.has(status)) {
              ok = true;
            } else if (failureStatuses.has(status)) {
              errMsg = msgtxt || `SAP returned ${logTag} status ${status}.`;
            } else {
              errMsg = msgtxt || `SAP returned ${logTag} status ${status}.`;
            }
          }
        }
      }
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: ok && !errMsg ? "ok" : "error",
        latency_ms,
        rows_processed: 1,
        message: `pr-${logTag} ${item.PREQ_NO}/${item.PREQ_ITEM}: ${errMsg ?? msgtxt ?? "done"}`.slice(0, 500)
      });
    } catch (e) {
      errMsg = e.message || "fetch failed";
      await supabaseAdmin.from("sap_api_sync_log").insert({
        config_id: cfg.id,
        status: "error",
        latency_ms: Date.now() - t0,
        message: `pr-${logTag} network ${item.PREQ_NO}/${item.PREQ_ITEM}: ${errMsg}`.slice(0, 500)
      });
    }
    results.push({
      preq_no: item.PREQ_NO,
      preq_item: item.PREQ_ITEM,
      ok: ok && !errMsg,
      msgtxt,
      error: errMsg
    });
  }
  return {
    results,
    error: null
  };
}
const prActionInput = objectType({
  relgroup: stringType().trim().min(1).max(10),
  relcode: stringType().trim().min(1).max(10),
  items: arrayType(objectType({
    PREQ_NO: stringType().trim().min(1),
    PREQ_ITEM: stringType().trim().min(1),
    REMARKS: stringType().optional().default("")
  })).min(1)
});
const prRejectInput = objectType({
  relgroup: stringType().trim().min(1).max(10),
  relcode: stringType().trim().min(1).max(10),
  items: arrayType(objectType({
    PREQ_NO: stringType().trim().min(1),
    PREQ_ITEM: stringType().trim().default(""),
    REMARKS: stringType().optional().default("")
  })).min(1)
});
const releasePrItems_createServerFn_handler = createServerRpc({
  id: "3c2983e5abf9d12c25d78a2e7541d575a295f2864dda39fb3f1192c35f9ca330",
  name: "releasePrItems",
  filename: "src/lib/mm/pr-release.functions.ts"
}, (opts) => releasePrItems.__executeServer(opts));
const releasePrItems = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => prActionInput.parse(d)).handler(releasePrItems_createServerFn_handler, async ({
  data
}) => processPrAction(RELEASE_CONFIG_NAME, "RELEASE", data, "release"));
const rejectPrItems_createServerFn_handler = createServerRpc({
  id: "eacd81e7375c7cba6710b717d4d56612e6fecd56f82e375eb0e5407a80f75755",
  name: "rejectPrItems",
  filename: "src/lib/mm/pr-release.functions.ts"
}, (opts) => rejectPrItems.__executeServer(opts));
const rejectPrItems = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => prRejectInput.parse(d)).handler(rejectPrItems_createServerFn_handler, async ({
  data
}) => processPrAction(REJECT_CONFIG_NAME, "REJECT", data, "reject"));
export {
  fetchPrReleaseMultiple_createServerFn_handler,
  rejectPrItems_createServerFn_handler,
  releasePrItems_createServerFn_handler
};
