import process from "node:process";
import { w as webpush } from "../_libs/web-push.mjs";
import { supabaseAdmin } from "./client.server-D5ro3rAQ.mjs";
let configured = false;
function configure() {
  if (configured) return;
  const pub = process.env.VAPID_PUBLIC_KEY;
  const priv = process.env.VAPID_PRIVATE_KEY;
  const subject = process.env.VAPID_SUBJECT || "mailto:notify@resustainability.local";
  if (!pub || !priv) throw new Error("VAPID keys not configured");
  webpush.setVapidDetails(subject, pub, priv);
  configured = true;
}
async function sendPushToUser(userId, payload) {
  try {
    configure();
  } catch (e) {
    console.warn("Push not configured:", e.message);
    return { sent: 0, removed: 0 };
  }
  const { data: subs } = await supabaseAdmin.from("push_subscriptions").select("*").eq("user_id", userId);
  if (!subs?.length) return { sent: 0, removed: 0 };
  let sent = 0;
  let removed = 0;
  const json = JSON.stringify(payload);
  await Promise.all(
    subs.map(async (s) => {
      try {
        await webpush.sendNotification(
          { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          json
        );
        sent++;
      } catch (err) {
        const status = err.statusCode;
        if (status === 404 || status === 410) {
          await supabaseAdmin.from("push_subscriptions").delete().eq("id", s.id);
          removed++;
        } else {
          console.error("Push send failed", status, err.message);
        }
      }
    })
  );
  return { sent, removed };
}
export {
  sendPushToUser as s
};
