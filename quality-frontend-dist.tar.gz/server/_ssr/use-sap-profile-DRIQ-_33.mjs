import { r as reactExports } from "../_libs/react.mjs";

const SAP_PROFILE_KEY = "sap.profile";
let cachedRaw = null;
let cachedSnapshot = null;
function readSnapshot() {
  if (typeof window === "undefined") return null;
  const raw = window.localStorage.getItem(SAP_PROFILE_KEY);
  if (raw === cachedRaw) return cachedSnapshot;
  cachedRaw = raw;
  if (!raw) {
    cachedSnapshot = null;
    return null;
  }
  try {
    const parsed = JSON.parse(raw);
    cachedSnapshot = parsed && Array.isArray(parsed.plants) ? parsed : null;
  } catch {
    cachedSnapshot = null;
  }
  return cachedSnapshot;
}
function subscribe(cb) {
  if (typeof window === "undefined") return () => {
  };
  const onStorage = (e) => {
    if (e.key === SAP_PROFILE_KEY || e.key === null) cb();
  };
  window.addEventListener("storage", onStorage);
  window.addEventListener("sap-profile-changed", cb);
  return () => {
    window.removeEventListener("storage", onStorage);
    window.removeEventListener("sap-profile-changed", cb);
  };
}
function useSapProfile() {
  return reactExports.useSyncExternalStore(subscribe, readSnapshot, () => null);
}
function setSapProfile(profile) {
  if (typeof window === "undefined") return;
  if (profile) localStorage.setItem(SAP_PROFILE_KEY, JSON.stringify(profile));
  else localStorage.removeItem(SAP_PROFILE_KEY);
  cachedRaw = null;
  cachedSnapshot = null;
  window.dispatchEvent(new Event("sap-profile-changed"));
}
export {
  SAP_PROFILE_KEY,
  setSapProfile,
  useSapProfile
};
