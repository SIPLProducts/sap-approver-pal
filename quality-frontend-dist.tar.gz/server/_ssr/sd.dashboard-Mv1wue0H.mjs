import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn } from "./createSsrRpc-XOrxmi8L.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { B as Badge } from "./badge-DyfXZgLs.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { S as Skeleton } from "./skeleton-C5WX2eNf.mjs";
import { K as KpiTile } from "./kpi-tile-DMYvOiIt.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { f as fetchBmwStatusReport } from "./bmw-status-report.functions-D6YGNvCd.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";

import "../_libs/seroval.mjs";
import { a3 as LoaderCircle, Q as RefreshCw, W as Building2, r as CircleAlert, am as Activity, U as Users, F as FileText, f as ShoppingCart, an as Wallet, a8 as TrendingUp, ao as Workflow, ap as ChartPie, P as Package, aq as Receipt, ar as Landmark, e as FileCheckCorner } from "../_libs/lucide-react.mjs";
import { R as ResponsiveContainer, B as BarChart, C as CartesianGrid, X as XAxis, Y as YAxis, T as Tooltip, a as Bar, P as PieChart, b as Pie, c as Cell, L as Legend, d as LineChart, e as Line } from "../_libs/recharts.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./server-CeMw7B2X.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./client-CXnFcWf4.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "./screen-keys-mn2QOK0m.mjs";
import "./auth-middleware-BtdUo7VX.mjs";
import "../_libs/zod.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/lodash.mjs";
import "../_libs/react-smooth.mjs";
import "../_libs/prop-types.mjs";
import "../_libs/fast-equals.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/react-is.mjs";
import "../_libs/d3-shape.mjs";
import "../_libs/d3-path.mjs";
import "../_libs/victory-vendor.mjs";
import "../_libs/d3-scale.mjs";
import "../_libs/internmap.mjs";
import "../_libs/d3-array.mjs";
import "../_libs/d3-time-format.mjs";
import "../_libs/d3-time.mjs";
import "../_libs/d3-interpolate.mjs";
import "../_libs/d3-color.mjs";
import "../_libs/d3-format.mjs";
import "../_libs/recharts-scale.mjs";
import "../_libs/decimal.js-light.mjs";
import "../_libs/eventemitter3.mjs";
const CHART_COLORS = ["hsl(221 83% 53%)", "hsl(210 90% 55%)", "hsl(145 65% 45%)", "hsl(38 92% 55%)", "var(--destructive)", "hsl(262 80% 60%)", "hsl(190 85% 50%)", "hsl(24 90% 58%)", "hsl(340 82% 60%)", "hsl(160 70% 45%)"];
const STATUS_COLORS = {
  Approved: "hsl(145 65% 45%)",
  Pending: "hsl(38 92% 55%)",
  Rejected: "var(--destructive)",
  Other: "hsl(220 10% 60%)"
};
function toNum(v) {
  if (v == null) return 0;
  const n = parseFloat(String(v).trim());
  return Number.isFinite(n) ? n : 0;
}
function nonEmpty(v) {
  if (v == null) return null;
  const s = String(v).trim();
  return s === "" || s === "0000-00-00" ? null : s;
}
function fmtCompact(n) {
  const abs = Math.abs(n);
  if (abs >= 1e7) return (n / 1e7).toFixed(2) + " Cr";
  if (abs >= 1e5) return (n / 1e5).toFixed(2) + " L";
  if (abs >= 1e3) return (n / 1e3).toFixed(1) + " K";
  return n.toLocaleString(void 0, {
    maximumFractionDigits: 0
  });
}
function fmtInt(n) {
  return n.toLocaleString();
}
function bucketStatus(raw) {
  if (!raw) return "Other";
  const s = raw.trim().toUpperCase();
  if (["A", "APPROVED", "01", "1", "APP", "R"].includes(s) && s !== "R") return "Approved";
  if (["A", "APPROVED", "01", "1", "APP"].includes(s)) return "Approved";
  if (["P", "PENDING", "00", "0", "N", "OPEN", "WAIT"].includes(s)) return "Pending";
  if (["X", "REJECTED", "REJ", "02", "2", "D", "DENIED"].includes(s)) return "Rejected";
  return "Other";
}
function relTime(ts) {
  if (!ts) return "—";
  const diff = Math.max(0, Date.now() - ts);
  const s = Math.floor(diff / 1e3);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return new Date(ts).toLocaleString();
}
const TOOLTIP_STYLE = {
  background: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: 10,
  fontSize: 12,
  boxShadow: "var(--shadow-elegant, 0 10px 30px -10px rgba(0,0,0,0.2))"
};
function SdDashboardPage() {
  const fetchFn = useServerFn(fetchBmwStatusReport);
  const {
    activePlants
  } = useActiveContext();
  const sorted = reactExports.useMemo(() => [...activePlants].sort(), [activePlants]);
  const from = sorted[0] ?? "";
  const to = sorted[sorted.length - 1] ?? "";
  const query = useQuery({
    queryKey: ["sd-dashboard-bmw", from, to],
    enabled: !!from && !!to,
    staleTime: 5 * 6e4,
    gcTime: 30 * 6e4,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    placeholderData: (prev) => prev,
    queryFn: async () => {
      const res = await fetchFn({
        data: {
          sales_org_from: from,
          sales_org_to: to,
          customer_from: "",
          customer_to: "",
          contract_from: "",
          contract_to: "",
          mode: "sales"
        }
      });
      return res?.rows ?? [];
    }
  });
  const rows = query.data ?? [];
  const stats = reactExports.useMemo(() => {
    const customers = /* @__PURE__ */ new Set();
    const contracts = /* @__PURE__ */ new Set();
    const salesOrders = /* @__PURE__ */ new Set();
    const billingDocs = /* @__PURE__ */ new Set();
    const acctDocs = /* @__PURE__ */ new Set();
    const serviceCerts = /* @__PURE__ */ new Set();
    const bySalesOrg = /* @__PURE__ */ new Map();
    const byCustomerValue = /* @__PURE__ */ new Map();
    const byMaterialValue = /* @__PURE__ */ new Map();
    const byMonth = /* @__PURE__ */ new Map();
    const releaseBuckets = {};
    for (let n = 1; n <= 8; n++) releaseBuckets[n] = {
      Approved: 0,
      Pending: 0,
      Rejected: 0,
      Other: 0
    };
    const phBuckets = {
      Approved: 0,
      Pending: 0,
      Rejected: 0,
      Other: 0
    };
    let contractValue = 0;
    let salesValue = 0;
    let activeBp = 0;
    let inactiveBp = 0;
    const seenBp = /* @__PURE__ */ new Set();
    const seenContractForValue = /* @__PURE__ */ new Set();
    const seenPhContract = /* @__PURE__ */ new Set();
    for (const r of rows) {
      const cust = nonEmpty(r.CUSTOMER);
      if (cust) customers.add(cust);
      const contract = nonEmpty(r.CONTRACT_NO);
      if (contract) contracts.add(contract);
      const so = nonEmpty(r.SALES_ORDER_NO);
      if (so) salesOrders.add(so);
      const bd = nonEmpty(r.BILLING_DOC);
      if (bd) billingDocs.add(bd);
      const ad = nonEmpty(r.ACCOUNTING_DOC);
      if (ad) acctDocs.add(ad);
      const sc = nonEmpty(r.SERVICE_CERT_NO);
      if (sc) serviceCerts.add(sc);
      const org = nonEmpty(r.SALES_ORG) ?? "—";
      bySalesOrg.set(org, (bySalesOrg.get(org) ?? 0) + 1);
      const cnv = toNum(r.CONTRACT_NET_VALUE ?? r.NET_VALUE);
      contractValue += cnv;
      salesValue += toNum(r.SALES_NET_VALUE);
      if (cust && cnv > 0) {
        const label = nonEmpty(r.CUSTOMER_NAME) ?? cust;
        const cur = byCustomerValue.get(cust) ?? {
          name: label,
          value: 0
        };
        cur.value += cnv;
        cur.name = label;
        byCustomerValue.set(cust, cur);
      }
      const mat = nonEmpty(r.MATERIAL_CODE);
      if (mat && cnv > 0) byMaterialValue.set(mat, (byMaterialValue.get(mat) ?? 0) + cnv);
      const cd = nonEmpty(r.CONTRACT_DATE) ?? nonEmpty(r.CONTRACT_CREATE_DATE);
      const sd = nonEmpty(r.SALES_CREATE_DATE);
      const addMonth = (dateStr, kind, key) => {
        if (!dateStr || !key) return;
        const m = /^(\d{4})-(\d{2})/.exec(dateStr);
        if (!m) return;
        const mk = `${m[1]}-${m[2]}`;
        const b = byMonth.get(mk) ?? {
          contracts: /* @__PURE__ */ new Set(),
          sales: /* @__PURE__ */ new Set()
        };
        b[kind].add(key);
        byMonth.set(mk, b);
      };
      addMonth(cd, "contracts", contract);
      addMonth(sd, "sales", so);
      for (let n = 1; n <= 8; n++) {
        const st = nonEmpty(r[`STATUS_${n}_C`]);
        if (st == null) continue;
        releaseBuckets[n][bucketStatus(st)]++;
      }
      if (contract && !seenPhContract.has(contract)) {
        seenPhContract.add(contract);
        phBuckets[bucketStatus(nonEmpty(r.PH_STATUS))]++;
      }
      if (cust && !seenBp.has(cust)) {
        seenBp.add(cust);
        const st = nonEmpty(r.BP_ACTIVE_INACTIVE);
        if (st === "01") activeBp++;
        else if (st) inactiveBp++;
      }
      if (contract && !seenContractForValue.has(contract)) {
        seenContractForValue.add(contract);
      }
    }
    const salesOrgData = Array.from(bySalesOrg.entries()).map(([name, count]) => ({
      name,
      count
    })).sort((a, b) => b.count - a.count);
    const topCustomers = Array.from(byCustomerValue.values()).sort((a, b) => b.value - a.value).slice(0, 10).map((c) => ({
      name: c.name.length > 22 ? c.name.slice(0, 22) + "…" : c.name,
      value: Math.round(c.value)
    }));
    const topMaterials = Array.from(byMaterialValue.entries()).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, value]) => ({
      name,
      value: Math.round(value)
    }));
    const monthly = Array.from(byMonth.entries()).sort(([a], [b]) => a < b ? -1 : 1).slice(-12).map(([month, b]) => ({
      month: month.slice(2),
      contracts: b.contracts.size,
      sales: b.sales.size
    }));
    const releaseData = Object.entries(releaseBuckets).map(([n, b]) => ({
      name: `R${n}`,
      Approved: b.Approved,
      Pending: b.Pending,
      Rejected: b.Rejected,
      Other: b.Other,
      total: b.Approved + b.Pending + b.Rejected + b.Other
    })).filter((d) => d.total > 0);
    const phData = Object.keys(phBuckets).map((k) => ({
      name: k,
      value: phBuckets[k]
    })).filter((d) => d.value > 0);
    const bpStatus = [{
      name: "Active",
      value: activeBp
    }, {
      name: "Inactive",
      value: inactiveBp
    }].filter((d) => d.value > 0);
    return {
      totalRecords: rows.length,
      customers: customers.size,
      contracts: contracts.size,
      salesOrders: salesOrders.size,
      contractValue,
      salesValue,
      activeBp,
      inactiveBp,
      billingDocs: billingDocs.size,
      acctDocs: acctDocs.size,
      serviceCerts: serviceCerts.size,
      avgContract: contracts.size ? contractValue / contracts.size : 0,
      salesOrgData,
      topCustomers,
      topMaterials,
      monthly,
      releaseData,
      phData,
      bpStatus
    };
  }, [rows]);
  const hasContext = !!from && !!to;
  const loading = query.isFetching;
  const empty = !loading && hasContext && rows.length === 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "SD Approvals · Live analytics", title: "SD Dashboard", subtitle: "Portfolio KPIs, approval throughput and trends derived directly from the BMW Status Report.", meta: hasContext && !loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "secondary", className: "text-xs h-7 font-mono", children: [
      fmtInt(stats.totalRecords),
      " rows · updated ",
      relTime(query.dataUpdatedAt)
    ] }) : void 0, actions: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: () => query.refetch(), disabled: loading || !hasContext, className: "h-8", children: [
      loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "h-3.5 w-3.5 mr-1.5" }),
      "Refresh"
    ] }) }),
    !hasContext ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "h-5 w-5", "aria-hidden": true }), title: "Select a plant to continue", description: "Choose at least one plant from the top-bar plant selector to load the dashboard." }) : query.isError ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-5 w-5 text-destructive", "aria-hidden": true }), title: "Couldn't load dashboard data", description: query.error?.message ?? "The SAP request failed. Try refreshing.", action: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", onClick: () => query.refetch(), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "h-3.5 w-3.5 mr-1.5" }),
      " Retry"
    ] }) }) : loading && rows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(DashboardSkeleton, {}) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid gap-3 grid-cols-2 lg:grid-cols-3 xl:grid-cols-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { label: "Records", value: fmtInt(stats.totalRecords), sub: "Rows returned by SAP", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className: "h-4 w-4" }), accent: "primary", lead: true }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { label: "Customers", value: fmtInt(stats.customers), sub: `${stats.activeBp} active · ${stats.inactiveBp} inactive`, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-4 w-4" }), accent: "info" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { label: "Contracts", value: fmtInt(stats.contracts), sub: `avg ${fmtCompact(stats.avgContract)}`, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-4 w-4" }), accent: "gold" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { label: "Sales Orders", value: fmtInt(stats.salesOrders), sub: `${fmtInt(stats.billingDocs)} billing docs`, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ShoppingCart, { className: "h-4 w-4" }), accent: "success" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { label: "Contract Net Value", value: fmtCompact(stats.contractValue), sub: "Σ across contracts", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "h-4 w-4" }), accent: "primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(KpiTile, { label: "Sales Net Value", value: fmtCompact(stats.salesValue), sub: "Σ across sales orders", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "h-4 w-4" }), accent: "warning" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid gap-4 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChartCard, { className: "lg:col-span-2", title: "Top 10 Customers by Contract Value", subtitle: "Aggregated across returned rows", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "h-4 w-4" }), empty: empty || stats.topCustomers.length === 0, height: 340, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(BarChart, { data: stats.topCustomers, layout: "vertical", margin: {
          left: 8,
          right: 24
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "grad-cust", x1: "0", y1: "0", x2: "1", y2: "0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "var(--primary)", stopOpacity: 0.95 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "hsl(210 90% 55%)", stopOpacity: 0.95 })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", horizontal: false, stroke: "var(--border)", opacity: 0.5 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { type: "number", tickFormatter: fmtCompact, tick: {
            fontSize: 11
          }, stroke: "var(--muted-foreground)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { type: "category", dataKey: "name", width: 150, tick: {
            fontSize: 11
          }, stroke: "var(--muted-foreground)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { formatter: (v) => fmtCompact(v), contentStyle: TOOLTIP_STYLE, cursor: {
            fill: "var(--muted)",
            opacity: 0.4
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "value", fill: "url(#grad-cust)", radius: [0, 6, 6, 0] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChartCard, { title: "BP Status", subtitle: "Active vs inactive customers", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-4 w-4" }), empty: empty || stats.bpStatus.length === 0, height: 340, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(PieChart, { margin: {
          top: 16,
          right: 24,
          bottom: 16,
          left: 24
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Pie, { data: stats.bpStatus, dataKey: "value", nameKey: "name", innerRadius: "55%", outerRadius: "78%", paddingAngle: 3, stroke: "var(--card)", strokeWidth: 2, label: (e) => `${e.value}`, labelLine: {
            stroke: "var(--muted-foreground)",
            strokeOpacity: 0.5
          }, children: stats.bpStatus.map((d, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Cell, { fill: d.name === "Active" ? STATUS_COLORS.Approved : STATUS_COLORS.Rejected }, i)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { contentStyle: TOOLTIP_STYLE }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Legend, { wrapperStyle: {
            fontSize: 12
          } })
        ] }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid gap-4 lg:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChartCard, { title: "Contracts vs Sales Orders", subtitle: "Last 12 months", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "h-4 w-4" }), empty: empty || stats.monthly.length === 0, height: 300, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(LineChart, { data: stats.monthly, margin: {
          left: 0,
          right: 12
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)", opacity: 0.5 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "month", tick: {
            fontSize: 11
          }, stroke: "var(--muted-foreground)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { allowDecimals: false, tick: {
            fontSize: 11
          }, stroke: "var(--muted-foreground)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { contentStyle: TOOLTIP_STYLE }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Legend, { wrapperStyle: {
            fontSize: 12
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { type: "monotone", dataKey: "contracts", name: "Contracts", stroke: CHART_COLORS[0], strokeWidth: 2.5, dot: {
            r: 3
          }, activeDot: {
            r: 5
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { type: "monotone", dataKey: "sales", name: "Sales Orders", stroke: CHART_COLORS[2], strokeWidth: 2.5, dot: {
            r: 3
          }, activeDot: {
            r: 5
          } })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChartCard, { title: "Records by Sales Org", subtitle: "Row distribution", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "h-4 w-4" }), empty: empty || stats.salesOrgData.length === 0, height: 300, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(BarChart, { data: stats.salesOrgData, margin: {
          left: 0,
          right: 12
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)", opacity: 0.5 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "name", tick: {
            fontSize: 11
          }, stroke: "var(--muted-foreground)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { allowDecimals: false, tick: {
            fontSize: 11
          }, stroke: "var(--muted-foreground)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { contentStyle: TOOLTIP_STYLE, cursor: {
            fill: "var(--muted)",
            opacity: 0.4
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "count", radius: [8, 8, 0, 0], children: stats.salesOrgData.map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Cell, { fill: CHART_COLORS[i % CHART_COLORS.length] }, i)) })
        ] }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid gap-4 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChartCard, { className: "lg:col-span-2", title: "Contract Release Pipeline", subtitle: "Status counts across release levels (STATUS_1_C … STATUS_8_C)", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Workflow, { className: "h-4 w-4" }), empty: empty || stats.releaseData.length === 0, height: 320, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(BarChart, { data: stats.releaseData, margin: {
          left: 0,
          right: 12
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)", opacity: 0.5 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "name", tick: {
            fontSize: 11
          }, stroke: "var(--muted-foreground)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { allowDecimals: false, tick: {
            fontSize: 11
          }, stroke: "var(--muted-foreground)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { contentStyle: TOOLTIP_STYLE, cursor: {
            fill: "var(--muted)",
            opacity: 0.4
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Legend, { wrapperStyle: {
            fontSize: 12
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "Approved", stackId: "s", fill: STATUS_COLORS.Approved, radius: [0, 0, 0, 0] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "Pending", stackId: "s", fill: STATUS_COLORS.Pending }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "Rejected", stackId: "s", fill: STATUS_COLORS.Rejected }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "Other", stackId: "s", fill: STATUS_COLORS.Other, radius: [6, 6, 0, 0] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChartCard, { title: "Approval Throughput", subtitle: "Contract PH_STATUS distribution", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ChartPie, { className: "h-4 w-4" }), empty: empty || stats.phData.length === 0, height: 320, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(PieChart, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Pie, { data: stats.phData, dataKey: "value", nameKey: "name", innerRadius: 60, outerRadius: 100, paddingAngle: 3, stroke: "var(--card)", strokeWidth: 2, label: (e) => `${e.name}: ${e.value}`, children: stats.phData.map((d, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Cell, { fill: STATUS_COLORS[d.name] }, i)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { contentStyle: TOOLTIP_STYLE }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Legend, { wrapperStyle: {
            fontSize: 12
          } })
        ] }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "grid gap-4 lg:grid-cols-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChartCard, { title: "Top Materials by Contract Value", subtitle: "Top 8 material codes", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { className: "h-4 w-4" }), empty: empty || stats.topMaterials.length === 0, height: 300, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(BarChart, { data: stats.topMaterials, margin: {
        left: 0,
        right: 12
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "grad-mat", x1: "0", y1: "0", x2: "0", y2: "1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "hsl(38 92% 55%)", stopOpacity: 0.95 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "hsl(24 90% 58%)", stopOpacity: 0.9 })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)", opacity: 0.5 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "name", tick: {
          fontSize: 11
        }, stroke: "var(--muted-foreground)", interval: 0, angle: -20, textAnchor: "end", height: 50 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { tickFormatter: fmtCompact, tick: {
          fontSize: 11
        }, stroke: "var(--muted-foreground)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { formatter: (v) => fmtCompact(v), contentStyle: TOOLTIP_STYLE, cursor: {
          fill: "var(--muted)",
          opacity: 0.4
        } }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "value", fill: "url(#grad-mat)", radius: [8, 8, 0, 0] })
      ] }) }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid gap-3 grid-cols-2 lg:grid-cols-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MicroTile, { label: "Billing Docs", value: fmtInt(stats.billingDocs), icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Receipt, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MicroTile, { label: "Accounting Docs", value: fmtInt(stats.acctDocs), icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Landmark, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MicroTile, { label: "Service Certificates", value: fmtInt(stats.serviceCerts), icon: /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheckCorner, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MicroTile, { label: "Avg Contract Value", value: fmtCompact(stats.avgContract), icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "h-4 w-4" }) })
      ] })
    ] })
  ] });
}
function ChartCard({
  title,
  subtitle,
  icon,
  empty,
  height,
  className,
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: cn("p-4 shadow-card transition-shadow hover:shadow-elegant", className), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between mb-3 gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold truncate", children: title }),
        subtitle && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground truncate", children: subtitle })
      ] }),
      icon && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground/70 shrink-0", children: icon })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
      height
    }, children: empty ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyChart, {}) : children })
  ] });
}
function MicroTile({
  label,
  value,
  icon
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 flex items-center gap-3 shadow-card", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-10 rounded-lg grid place-items-center text-primary", style: {
      background: "color-mix(in oklab, var(--primary) 10%, transparent)"
    }, children: icon }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground", children: label }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-display text-lg font-semibold tabular-nums leading-tight", children: value })
    ] })
  ] });
}
function DashboardSkeleton() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 grid-cols-2 lg:grid-cols-3 xl:grid-cols-6", children: Array.from({
      length: 6
    }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-[104px] rounded-xl" }, i)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 lg:grid-cols-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-[380px] rounded-xl lg:col-span-2" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-[380px] rounded-xl" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-[340px] rounded-xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-[340px] rounded-xl" })
    ] })
  ] });
}
function EmptyChart() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-full grid place-items-center text-xs text-muted-foreground", children: "No data available for the current selection." });
}
export {
  SdDashboardPage as component
};
