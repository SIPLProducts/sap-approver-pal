import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { C as CloudscapeApprovalTable } from "./cloudscape-approval-table-B3gA6T4g.mjs";
import { g as getMySapUserId } from "./price-approval.functions-D1l7f9uf.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";

import "../_libs/seroval.mjs";
import { aa as Funnel, a3 as LoaderCircle, ab as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as objectType, y as booleanType, z as stringType, C as arrayType, A as unionType, B as numberType } from "../_libs/zod.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "./empty-state-DA5qeMhN.mjs";
import "./skeleton-rows-C2wJYLiJ.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./format-D-HjDoz6.mjs";
import "./table-BhFPQiYt.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
const fetchGatePass = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  gate_pass_number: stringType().trim().max(40).optional().default(""),
  hod_approval: booleanType().optional().default(false),
  store_approval: booleanType().optional().default(false),
  scm_head: booleanType().optional().default(false),
  plant_head: booleanType().optional().default(false),
  return_receipt: booleanType().optional().default(false)
}).parse(d)).handler(createSsrRpc("979f43fae68437941ded0e262c04aecc2048a75d5147e33c0a862ab14ec6957b"));
const gpSaveRowSchema = objectType({
  MATERIAL: stringType().optional().default(""),
  DESCRIPTION: stringType().optional().default(""),
  MEINS: stringType().optional().default(""),
  QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  VALUE: unionType([stringType(), numberType()]).optional().default(0),
  EXPECTED_DATE_OF_RETURN: stringType().optional().default(""),
  USER_REMARKS: stringType().optional().default(""),
  HOD_APPROVAL: stringType().optional().default(""),
  HOD_REJECTION: stringType().optional().default(""),
  HOD_REMARKS: stringType().optional().default(""),
  ISSUED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  STORE_APPROVAL: stringType().optional().default(""),
  JUSTIFICATION: stringType().optional().default(""),
  SCM_HEAD: stringType().optional().default(""),
  PH_APPROVAL: stringType().optional().default(""),
  PH_REJECTION: stringType().optional().default(""),
  RETURN_STATUS: stringType().optional().default(""),
  REMARKS: stringType().optional().default(""),
  RETURNED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0)
}).passthrough();
const saveGatePass = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  header: objectType({
    GATEPASS_NUMBER: unionType([stringType(), numberType()]).optional().default(""),
    GATE_PASS_TYPE: stringType().optional().default(""),
    GATEPASS_DATE: stringType().optional().default(""),
    PLANT: stringType().optional().default(""),
    VEHICLE_NO: stringType().optional().default(""),
    VENDOR: stringType().optional().default(""),
    VENDOR_NAME: stringType().optional().default(""),
    PURPOSE: stringType().optional().default("")
  }).passthrough(),
  data: arrayType(gpSaveRowSchema).min(1, "At least one row is required")
}).parse(d)).handler(createSsrRpc("bfd48e87678e43e6e840b81605f9ccd3edda183570bf46342ce06e81faa3cf57"));
function rowKey(r, i) {
  return [r.GATEPASS_NUMBER, r.GATE_PASS_NUMBER, r.SNO, r.MATERIAL, i].map((x) => x ?? "").join("|");
}
function toStr(v) {
  if (v == null) return "";
  return String(v);
}
function humanize(k) {
  return k.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
}
function GatePassPage() {
  const fetchFn = useServerFn(fetchGatePass);
  const userIdFn = useServerFn(getMySapUserId);
  const {
    data: userIdData
  } = useQuery({
    queryKey: ["mm-gate-pass", "sap-user-id"],
    queryFn: () => userIdFn()
  });
  const [userId, setUserId] = reactExports.useState("");
  const [gatePassNumber, setGatePassNumber] = reactExports.useState("");
  const [hodApproval, setHodApproval] = reactExports.useState(false);
  const [storeApproval, setStoreApproval] = reactExports.useState(false);
  const [scmHead, setScmHead] = reactExports.useState(false);
  const [plantHead, setPlantHead] = reactExports.useState(false);
  const [returnReceipt, setReturnReceipt] = reactExports.useState(false);
  const [header, setHeader] = reactExports.useState(null);
  const [rows, setRows] = reactExports.useState([]);
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const hasResults = header !== null || rows.length > 0;
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  reactExports.useEffect(() => {
    if (userIdData?.sap_user_id && !userId) setUserId(userIdData.sap_user_id);
  }, [userIdData?.sap_user_id]);
  const mutation = useMutation({
    mutationFn: async (vars) => {
      const v = await fetchFn({
        data: vars
      });
      const data = Array.isArray(v?.data) ? v.data : [];
      return {
        header: v?.header ?? null,
        data,
        count: data.length,
        error: v?.error ?? null
      };
    },
    onSuccess: (res) => {
      setHeader(res.header);
      setRows(res.data);
      setSelected(/* @__PURE__ */ new Set());
      if (res.error) toast.error(res.error);
      else toast.success(`Loaded ${res.count} record${res.count === 1 ? "" : "s"} from SAP`);
    },
    onError: (e) => toast.error(e.message ?? "Failed to fetch from SAP")
  });
  const saveFn = useServerFn(saveGatePass);
  const saveMutation = useMutation({
    mutationFn: async (selectedRows) => {
      if (selectedRows.length === 0) throw new Error("Select at least one row to save");
      const h = header ?? {};
      const res = await saveFn({
        data: {
          header: {
            GATEPASS_NUMBER: h.GATEPASS_NUMBER ?? h.GATE_PASS_NUMBER ?? "",
            GATE_PASS_TYPE: h.GATE_PASS_TYPE ?? h.GATEPASS_TYPE ?? "",
            GATEPASS_DATE: h.GATEPASS_DATE ?? h.GATE_PASS_DATE ?? "",
            PLANT: h.PLANT ?? "",
            VEHICLE_NO: h.VEHICLE_NO ?? "",
            VENDOR: h.VENDOR ?? "",
            VENDOR_NAME: h.VENDOR_NAME ?? "",
            PURPOSE: h.PURPOSE ?? ""
          },
          data: selectedRows
        }
      });
      return res;
    },
    onSuccess: (res) => {
      const msg = res.document_number ? `${res.message} (Doc: ${res.document_number})` : res.message;
      if (res.ok) {
        toast.success(msg);
        setSelected(/* @__PURE__ */ new Set());
        if (userId.trim()) {
          mutation.mutate({
            user_id: userId.trim(),
            gate_pass_number: gatePassNumber.trim(),
            hod_approval: hodApproval,
            store_approval: storeApproval,
            scm_head: scmHead,
            plant_head: plantHead,
            return_receipt: returnReceipt
          });
        }
      } else {
        toast.error(res.error ?? msg);
      }
    },
    onError: (e) => toast.error(e.message ?? "Failed to save")
  });
  function execute() {
    if (!userId.trim()) {
      toast.error("User ID is required");
      return;
    }
    mutation.mutate({
      user_id: userId.trim(),
      gate_pass_number: gatePassNumber.trim(),
      hod_approval: hodApproval,
      store_approval: storeApproval,
      scm_head: scmHead,
      plant_head: plantHead,
      return_receipt: returnReceipt
    });
  }
  function reset() {
    setUserId(userIdData?.sap_user_id ?? "");
    setGatePassNumber("");
    setHodApproval(false);
    setStoreApproval(false);
    setScmHead(false);
    setPlantHead(false);
    setReturnReceipt(false);
    setHeader(null);
    setRows([]);
    setSelected(/* @__PURE__ */ new Set());
  }
  function onSave() {
    const selectedRows = rows.filter((r, i) => selected.has(rowKey(r, i)));
    if (selectedRows.length === 0) {
      toast.error("Select at least one row to save");
      return;
    }
    void (async () => {
      if (!await confirm({
        title: `Save ${selectedRows.length} selected item(s)?`,
        description: "This posts the update to SAP and cannot be undone.",
        confirmLabel: "Save",
        destructive: false
      })) return;
      saveMutation.mutate(selectedRows);
    })();
  }
  function updateRowField(item, key, value) {
    setRows((prev) => prev.map((r) => r === item ? {
      ...r,
      [key]: value
    } : r));
  }
  const headerKeys = reactExports.useMemo(() => {
    if (!header) return [];
    return Object.keys(header);
  }, [header]);
  const columns = reactExports.useMemo(() => {
    const readonly = (k, label, minWidth = 120) => ({
      id: k,
      header: label ?? humanize(k),
      minWidth,
      cell: (item) => {
        const v = item[k];
        if (v == null || v === "") return "—";
        return String(v);
      }
    });
    const editCheckbox = (k, label) => ({
      id: k,
      header: label ?? humanize(k),
      minWidth: 110,
      cell: (item) => /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: item[k] === "X", onCheckedChange: (v) => updateRowField(item, k, v === true ? "X" : "") })
    });
    const editInput = (k, label, minWidth = 200) => ({
      id: k,
      header: label ?? humanize(k),
      minWidth,
      cell: (item) => /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: toStr(item[k]), onChange: (e) => updateRowField(item, k, e.target.value), className: "h-8 text-sm" })
    });
    return [readonly("MATERIAL"), readonly("DESCRIPTION", "Description", 220), readonly("MEINS", "UoM", 80), readonly("QUANTITY"), readonly("VALUE"), readonly("EXPECTED_DATE_OF_RETURN", "Expected Return", 150), readonly("USER_REMARKS", "User Remarks", 180), editCheckbox("HOD_APPROVAL", "HOD Approval"), editCheckbox("HOD_REJECTION", "HOD Rejection"), editInput("HOD_REMARKS", "HOD Remarks"), readonly("ISSUED_QUANTITY", "Issued Qty"), editCheckbox("STORE_APPROVAL", "Store Approval"), editInput("JUSTIFICATION", "Justification"), readonly("SCM_HEAD", "SCM Head"), readonly("PH_APPROVAL", "PH Approval"), readonly("PH_REJECTION", "PH Rejection"), readonly("RETURN_STATUS", "Return Status"), editInput("REMARKS", "Remarks"), readonly("RETURNED_QUANTITY", "Returned Qty")];
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "MM Approvals", title: "Gate Pass", subtitle: "Review and approve gate pass items." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-2 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Gate Pass Number" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: gatePassNumber, onChange: (e) => setGatePassNumber(e.target.value), placeholder: "Gate pass number", className: "h-9 text-sm" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "HOD Approval" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-9 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: hodApproval, onCheckedChange: (v) => setHodApproval(v === true) }),
            "HOD Approval"
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Store Approval" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-9 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: storeApproval, onCheckedChange: (v) => setStoreApproval(v === true) }),
            "Store Approval"
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "SCM Head" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-9 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: scmHead, onCheckedChange: (v) => setScmHead(v === true) }),
            "SCM Head"
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Plant Head" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-9 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: plantHead, onCheckedChange: (v) => setPlantHead(v === true) }),
            "Plant Head"
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Return Receipt" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-9 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Checkbox, { checked: returnReceipt, onCheckedChange: (v) => setReturnReceipt(v === true) }),
            "Return Receipt"
          ] }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 justify-end mt-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: !userId.trim() || mutation.isPending, children: [
          mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
          "Execute"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Reset" })
      ] })
    ] }),
    hasResults && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      headerKeys.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
          " HEADER"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 md:grid-cols-2 lg:grid-cols-5", children: headerKeys.map((k) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: humanize(k) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: toStr(header?.[k]), readOnly: true, className: "h-9 text-sm bg-muted/40" })
        ] }, k)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", disabled: selected.size === 0 || saveMutation.isPending, onClick: onSave, children: saveMutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }),
        "Saving…"
      ] }) : "Save" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CloudscapeApprovalTable, { title: "Gate Pass Items", countLabel: `(${rows.length})`, rows, rowKey, loading: mutation.isPending, emptyMessage: "No line items.", showSelect: true, selectedKeys: selected, onSelectionChange: setSelected, columns })
    ] }),
    confirmDialog
  ] });
}
export {
  GatePassPage as component
};
