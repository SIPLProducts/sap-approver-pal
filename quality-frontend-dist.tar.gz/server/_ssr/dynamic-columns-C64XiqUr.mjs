const RESERVED = /* @__PURE__ */ new Set(["select", "__key"]);
const FORCE_TEXT_KEYS = /* @__PURE__ */ new Set([
  "customer",
  "year",
  "contract_no",
  "contract_item",
  "sales_document_no",
  "sales_item_no",
  "company_code",
  "sales_org",
  "dis_chanel",
  "division",
  "material",
  "customer_group",
  "customer_price_group",
  "plant",
  "rel_1",
  "rel_2",
  "rel_3",
  "rel_4",
  "rel_5",
  "rel_6",
  "rel_7",
  "rel_8",
  "release_code_1",
  "approval_status",
  "status_1",
  "status_2",
  "status_3",
  "status_4",
  "status_5",
  "status_6",
  "status_7",
  "status_8"
]);
function isEmpty(v) {
  return v === null || v === void 0 || v === "";
}
function prettify(key) {
  return key.split(/[_\s]+/).filter(Boolean).map((s) => s.length <= 3 ? s.toUpperCase() : s.charAt(0).toUpperCase() + s.slice(1).toLowerCase()).join(" ");
}
function isDateLike(v) {
  if (typeof v !== "string" || !v) return false;
  if (/^\d{8}$/.test(v)) return true;
  if (/^\d{4}-\d{2}-\d{2}/.test(v)) return true;
  return false;
}
function fmtDate(v) {
  if (/^\d{8}$/.test(v)) return `${v.slice(6, 8)}.${v.slice(4, 6)}.${v.slice(0, 4)}`;
  const d = new Date(v);
  if (!isNaN(+d)) return d.toLocaleDateString("en-GB").replaceAll("/", ".");
  return v;
}
function isNumericStrict(v) {
  if (typeof v === "number") return isFinite(v);
  if (typeof v !== "string") return false;
  const s = v.trim();
  if (!s) return false;
  return /^-?\d+(\.\d+)?$/.test(s) && /[.,-]/.test(s);
}
function isFinancialLoose(v) {
  if (typeof v === "number") return isFinite(v);
  if (typeof v !== "string") return false;
  const s = v.trim();
  return !!s && /^-?\d+(\.\d+)?$/.test(s);
}
function fmtNum(v) {
  const n = typeof v === "number" ? v : Number(v);
  if (!isFinite(n)) return String(v);
  return n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function buildDynamicColumns(rows, options = {}) {
  if (!Array.isArray(rows) || rows.length === 0) return [];
  const exclude = /* @__PURE__ */ new Set([...options.exclude ?? []]);
  const forceText = /* @__PURE__ */ new Set([...options.textKeys ?? []]);
  const forceNum = /* @__PURE__ */ new Set([...options.numericKeys ?? []]);
  const alwaysInclude = options.alwaysInclude ?? [];
  const alwaysSet = new Set(alwaysInclude);
  const headerLabels = options.headerLabels ?? {};
  const keys = [];
  const seen = /* @__PURE__ */ new Set();
  for (const row of rows) {
    if (!row || typeof row !== "object") continue;
    for (const k of Object.keys(row)) {
      if (seen.has(k)) continue;
      if (RESERVED.has(k) || exclude.has(k)) continue;
      seen.add(k);
      keys.push(k);
    }
  }
  for (const k of alwaysInclude) {
    if (RESERVED.has(k) || exclude.has(k)) continue;
    if (!seen.has(k)) {
      seen.add(k);
      keys.push(k);
    }
  }
  const nonEmpty = keys.filter((k) => alwaysSet.has(k) || rows.some((r) => !isEmpty(r?.[k])));
  return nonEmpty.map((key) => {
    const forcedText = forceText.has(key) || FORCE_TEXT_KEYS.has(key);
    const forcedNumeric = forceNum.has(key);
    const samples = rows.map((r) => r?.[key]).filter((v) => !isEmpty(v));
    const looksDate = !forcedNumeric && !forcedText && samples.length > 0 && samples.every(isDateLike);
    let looksNumeric = false;
    if (forcedNumeric) {
      looksNumeric = true;
    } else if (!forcedText && !looksDate && samples.length > 0) {
      const numericCount = samples.filter((v) => isFinancialLoose(v)).length;
      const strictCount = samples.filter((v) => isNumericStrict(v)).length;
      looksNumeric = strictCount === samples.length || numericCount === samples.length && /(value|amount|price|rate|qty|quantity|total|tax|net|amt)/i.test(key);
    }
    const header = headerLabels[key] ?? prettify(key);
    const render = (v) => {
      if (isEmpty(v)) return "—";
      if (looksDate) return fmtDate(String(v));
      if (looksNumeric) return fmtNum(v);
      return String(v);
    };
    let maxCellLen = 0;
    for (const r of rows) {
      const s = render(r?.[key]);
      if (s && s.length > maxCellLen) maxCellLen = s.length;
    }
    const chars = Math.max(header.length, maxCellLen);
    const padding = looksNumeric ? 44 : 32;
    const minWidth = Math.min(360, Math.max(96, chars * 8 + padding));
    return {
      id: key,
      header,
      align: looksNumeric ? "right" : void 0,
      minWidth,
      cell: (r) => render(r?.[key])
    };
  });
}
export {
  buildDynamicColumns as b
};
