import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { a as SkeletonRows } from "./skeleton-rows-C2wJYLiJ.mjs";
import { d as formatAmount } from "./format-D-HjDoz6.mjs";
import { a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BhFPQiYt.mjs";
import { q as Search, a3 as LoaderCircle, D as Inbox, ac as ChevronLeft, a9 as ChevronRight } from "../_libs/lucide-react.mjs";
function isDecimalValue(node) {
  if (typeof node === "number") return Number.isFinite(node) && !Number.isInteger(node);
  if (typeof node !== "string") return false;
  const v = node.trim();
  if (!v) return false;
  return /^-?\d{1,3}(,\d{3})*\.\d+$|^-?\d+\.\d+$/.test(v);
}
function stringifyCell(node) {
  if (node == null || typeof node === "boolean") return "";
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(stringifyCell).join(" ");
  if (typeof node === "object" && "props" in node) {
    const p = node.props ?? {};
    return [p.children, p.value, p.title, p["aria-label"]].filter(Boolean).map(stringifyCell).join(" ");
  }
  return "";
}
function CloudscapeApprovalTable({
  title,
  countLabel,
  rows,
  columns,
  rowKey,
  loading,
  showSelect,
  selectedKeys,
  onSelectionChange,
  onAccept,
  onReject,
  acceptDisabled,
  rejectDisabled,
  acceptLoading,
  rejectLoading,
  showReason,
  reasonValue,
  onReasonChange,
  reasonInvalid,
  readonlyReason,
  emptyMessage,
  pageSize = 25,
  headerExtras
}) {
  const [search, setSearch] = reactExports.useState("");
  const [page, setPage] = reactExports.useState(1);
  const keyed = reactExports.useMemo(
    () => rows.map((r, i) => ({ r, i, k: rowKey(r, i) })),
    [rows, rowKey]
  );
  const allColumns = reactExports.useMemo(() => {
    const cols = [...columns];
    if (showReason) {
      cols.push({
        id: "__reason",
        header: "Reason",
        cell: (item) => {
          const idx = keyed.find((x) => x.r === item)?.i ?? 0;
          const k = rowKey(item, idx);
          if (readonlyReason && !showSelect) return readonlyReason(item) ?? "—";
          const val = reasonValue?.(k) ?? "";
          const invalid = reasonInvalid?.(k) ?? false;
          return /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              value: val,
              onChange: (e) => onReasonChange?.(k, e.target.value),
              placeholder: "Required",
              className: `h-8 text-xs min-w-[180px] ${invalid ? "border-destructive" : ""}`
            }
          );
        },
        minWidth: 200
      });
    } else if (readonlyReason) {
      cols.push({
        id: "__reason",
        header: "Reason",
        cell: (item) => readonlyReason(item) ?? "—",
        minWidth: 160
      });
    }
    return cols;
  }, [columns, showReason, showSelect, readonlyReason, reasonValue, reasonInvalid, onReasonChange, rowKey, keyed]);
  const filtered = reactExports.useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return keyed;
    return keyed.filter(
      ({ r }) => allColumns.some((c) => stringifyCell(c.cell(r)).toLowerCase().includes(q))
    );
  }, [keyed, search, allColumns]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paged = reactExports.useMemo(
    () => filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize),
    [filtered, currentPage, pageSize]
  );
  const pagedKeys = paged.map((x) => x.k);
  const allSelected = pagedKeys.length > 0 && pagedKeys.every((k) => selectedKeys?.has(k));
  const someSelected = !!selectedKeys && selectedKeys.size > 0 && !allSelected;
  function toggleAll(checked) {
    if (!onSelectionChange) return;
    const next = new Set(selectedKeys ?? []);
    if (checked) pagedKeys.forEach((k) => next.add(k));
    else pagedKeys.forEach((k) => next.delete(k));
    onSelectionChange(next);
  }
  function toggleRow(k, checked) {
    if (!onSelectionChange) return;
    const next = new Set(selectedKeys ?? []);
    if (checked) next.add(k);
    else next.delete(k);
    onSelectionChange(next);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide truncate", children: title }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
          countLabel ?? `${filtered.length}${search.trim() ? ` / ${rows.length}` : ""} row(s)`,
          showSelect && selectedKeys ? ` · ${selectedKeys.size} selected` : ""
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 flex-wrap", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              value: search,
              onChange: (e) => {
                setSearch(e.target.value);
                setPage(1);
              },
              placeholder: "Search...",
              className: "h-9 text-sm pl-8"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
          headerExtras,
          showSelect && onReject && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              variant: "destructive",
              size: "sm",
              onClick: onReject,
              disabled: rejectDisabled,
              children: [
                rejectLoading && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }),
                "Reject"
              ]
            }
          ),
          showSelect && onAccept && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              variant: "success",
              size: "sm",
              onClick: onAccept,
              disabled: acceptDisabled,
              children: [
                acceptLoading && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }),
                "Accept"
              ]
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "overflow-auto border rounded-md",
        style: { maxHeight: "calc(100vh - 220px)" },
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full caption-bottom text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { className: "sticky top-0 z-10", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { className: "bg-[var(--table-header-bg)] hover:bg-[var(--table-header-bg)] border-b border-[var(--table-header-border)]", children: [
            showSelect && /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "w-10 h-12 px-4 py-3 bg-[var(--table-header-bg)] text-[var(--table-header-text)] font-bold border-b border-[var(--table-header-border)]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              Checkbox,
              {
                checked: allSelected ? true : someSelected ? "indeterminate" : false,
                onCheckedChange: (v) => toggleAll(v === true),
                "aria-label": "Select all"
              }
            ) }),
            allColumns.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              TableHead,
              {
                className: "whitespace-nowrap text-xs h-12 px-4 py-3 bg-[var(--table-header-bg)] text-[var(--table-header-text)] font-bold border-b border-[var(--table-header-border)]",
                style: { minWidth: c.minWidth ?? 120, textAlign: c.align === "right" ? "right" : void 0 },
                children: c.header
              },
              c.id
            ))
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            TableCell,
            {
              colSpan: allColumns.length + (showSelect ? 1 : 0),
              className: "px-4 py-4",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRows, { rows: 6, columns: Math.min(allColumns.length || 4, 6) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Fetching from SAP…" })
              ]
            }
          ) }) : paged.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TableRow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            TableCell,
            {
              colSpan: allColumns.length + (showSelect ? 1 : 0),
              className: "px-4 py-6",
              children: rows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                EmptyState,
                {
                  icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Inbox, { className: "h-5 w-5", "aria-hidden": true }),
                  title: emptyMessage ?? "No records",
                  description: "Run the search above to load records from SAP.",
                  className: "border-0 bg-transparent py-6"
                }
              ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                EmptyState,
                {
                  icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-5 w-5", "aria-hidden": true }),
                  title: "No matches",
                  description: `No rows match “${search.trim()}”. Clear the search to see all ${rows.length} records.`,
                  className: "border-0 bg-transparent py-6"
                }
              )
            }
          ) }) : paged.map(({ r, i, k }) => {
            const checked = selectedKeys?.has(k) ?? false;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { "data-state": checked ? "selected" : void 0, className: "hover:bg-[var(--table-row-hover)]", children: [
              showSelect && /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "w-10 px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                Checkbox,
                {
                  checked,
                  onCheckedChange: (v) => toggleRow(k, v === true),
                  "aria-label": `Select row ${i + 1}`
                }
              ) }),
              allColumns.map((c) => {
                const raw = c.cell(r);
                const decimal = isDecimalValue(raw);
                const right = c.align === "right" || decimal;
                return /* @__PURE__ */ jsxRuntimeExports.jsx(
                  TableCell,
                  {
                    className: `whitespace-nowrap text-xs px-4 py-3 ${right ? "tabular-nums" : ""}`,
                    style: {
                      minWidth: c.minWidth ?? 120,
                      textAlign: right ? "right" : void 0
                    },
                    children: decimal ? formatAmount(raw) : raw
                  },
                  c.id
                );
              })
            ] }, k);
          }) })
        ] })
      }
    ),
    filtered.length > pageSize && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mt-3 text-xs text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        "Page ",
        currentPage,
        " of ",
        totalPages
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "outline",
            size: "sm",
            onClick: () => setPage((p) => Math.max(1, p - 1)),
            disabled: currentPage <= 1,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-3.5 w-3.5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "outline",
            size: "sm",
            onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
            disabled: currentPage >= totalPages,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-3.5 w-3.5" })
          }
        )
      ] })
    ] })
  ] });
}
export {
  CloudscapeApprovalTable as C
};
