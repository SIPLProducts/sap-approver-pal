import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-Bm5Y9dpM.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, D as enumType, C as arrayType, z as stringType, A as unionType, B as numberType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "Sales_Approval_Fetch";
const DECISION_CONFIG_NAME = "Sales_Order_Approve_Reject";
function pick(o, k) {
  if (!o || typeof o !== "object") return null;
  const hit = Object.keys(o).find((x) => x.toLowerCase() === k.toLowerCase());
  return hit ? o[hit] ?? null : null;
}
function mapRow(raw) {
  return {
    select: pick(raw, "SELECT"),
    company_code: pick(raw, "COMPANY_CODE"),
    sales_org: pick(raw, "SALES_ORG"),
    dis_chanel: pick(raw, "DIS_CHANEL"),
    division: pick(raw, "DIVISION"),
    customer: pick(raw, "CUSTOMER"),
    customer_name: pick(raw, "CUSTOMER_NAME"),
    customer_group: pick(raw, "CUSTOMER_GROUP"),
    customer_price_group: pick(raw, "CUSTOMER_PRICE_GROUP"),
    year: pick(raw, "YEAR"),
    contract_no: pick(raw, "CONTRACT_NO"),
    contract_item: pick(raw, "CONTRACT_ITEM"),
    sales_document_no: pick(raw, "SALES_DOCUMENT_NO"),
    so_creation_date: pick(raw, "SO_CREATION_DATE"),
    sales_item_no: pick(raw, "SALES_ITEM_NO"),
    material: pick(raw, "MATERIAL"),
    qty: pick(raw, "QTY"),
    net_value: pick(raw, "NET_VALUE"),
    tax_value: pick(raw, "TAX_VALUE"),
    reason: pick(raw, "REASON"),
    rel_1: pick(raw, "REL_1"),
    status_1: pick(raw, "STATUS_1"),
    rel_2: pick(raw, "REL_2"),
    status_2: pick(raw, "STATUS_2")
  };
}
const fetchSalesOrderApprovals_createServerFn_handler = createServerRpc({
  id: "718e84eeac9d47deca78cde67fa3943bbf3252133ea8513629691da661a27fab",
  name: "fetchSalesOrderApprovals",
  filename: "src/lib/sd/sales-order-approval.functions.ts"
}, (opts) => fetchSalesOrderApprovals.__executeServer(opts));
const fetchSalesOrderApprovals = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().trim().min(1).max(40)).min(1, "At least one plant required"),
  user_id: stringType().trim().max(40).optional(),
  customer_from: stringType().trim().max(40).optional(),
  customer_to: stringType().trim().max(40).optional(),
  search_terms: arrayType(stringType().trim().min(1).max(40)).max(100).optional(),
  status: enumType(["pending", "accepted", "rejected", "all"]).default("pending")
}).parse(d)).handler(fetchSalesOrderApprovals_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: prof
  }, {
    data: userIdField
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("profiles").select("sap_user_id").eq("id", context.userId).maybeSingle(), supabaseAdmin.from("sap_api_request_fields").select("default_value").eq("config_id", cfg.id).eq("field_name", "USER_ID").maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const userId = data.user_id && data.user_id.trim() || prof?.sap_user_id && prof.sap_user_id.trim() || userIdField?.default_value || "";
  const isAll = data.status === "all";
  const R_PEND = isAll || data.status === "pending" ? "X" : "";
  const R_ACCP = isAll || data.status === "accepted" ? "X" : "";
  const R_REJ = isAll || data.status === "rejected" ? "X" : "";
  const custFrom = (data.customer_from ?? "").trim();
  const custTo = (data.customer_to ?? "").trim() || custFrom;
  const searchTerms = (data.search_terms ?? []).map((s2) => s2.trim()).filter(Boolean);
  const inputs = {
    PLANT: data.plants.map((p) => ({
      plant: p
    })),
    CUSTOMER_FROM: custFrom,
    CUSTOMER_TO: custTo,
    SEARCH_TERMS: searchTerms.map((s2) => ({
      search_term: s2
    })),
    SORTL: searchTerms[0] ?? "",
    USER_ID: userId,
    R_PEND,
    R_ACCP,
    R_REJ
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "GET";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sales_order_approval/Fetch`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      inputs
    });
    proxied = true;
  } else {
    const firstPlant = data.plants[0];
    const join = cfg.endpoint_url.includes("?") ? "&" : "?";
    const qs = `${join}PLANT=${encodeURIComponent(firstPlant)}&CUSTOMER_FROM=${encodeURIComponent(inputs.CUSTOMER_FROM)}&CUSTOMER_TO=${encodeURIComponent(inputs.CUSTOMER_TO)}&SORTL=${encodeURIComponent(inputs.SORTL)}&SEARCH_TERMS=${encodeURIComponent(searchTerms.join(","))}&USER_ID=${encodeURIComponent(inputs.USER_ID)}&R_PEND=${encodeURIComponent(inputs.R_PEND)}&R_ACCP=${encodeURIComponent(inputs.R_ACCP)}&R_REJ=${encodeURIComponent(inputs.R_REJ)}`;
    target = cfg.endpoint_url + qs;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
    if (proxied && res.status === 404) {
      const peek = await res.clone().text().catch(() => "");
      if (/Cannot\s+POST/i.test(peek)) {
        const fallback = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
        res = await fetch(fallback, {
          method: "POST",
          headers,
          body: JSON.stringify({
            configId: cfg.id,
            inputs
          })
        });
        target = fallback;
      }
    }
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `so-fetch network: ${errMsg}`
    });
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `Could not reach SAP at ${cfg.endpoint_url.split("?")[0]}. ${errMsg}.`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `so-fetch: ${message} ${text.slice(0, 500)}`
    });
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? {} : json;
  const arr = Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : Array.isArray(sapJson) ? sapJson : [];
  const rows = arr.map(mapRow);
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `so-fetch: ${message}`
  });
  return {
    rows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    count: rows.length,
    error: null
  };
});
function s(v) {
  return v == null ? "" : String(v);
}
function padCustomer(v) {
  const x = s(v).trim();
  return x && /^\d+$/.test(x) ? x.padStart(10, "0") : x;
}
const SalesOrderRowSchema = objectType({
  select: stringType().nullable().optional(),
  company_code: stringType().nullable().optional(),
  sales_org: stringType().nullable().optional(),
  dis_chanel: stringType().nullable().optional(),
  division: stringType().nullable().optional(),
  customer: stringType().nullable().optional(),
  customer_name: stringType().nullable().optional(),
  customer_group: stringType().nullable().optional(),
  customer_price_group: stringType().nullable().optional(),
  year: stringType().nullable().optional(),
  contract_no: stringType().nullable().optional(),
  contract_item: unionType([stringType(), numberType()]).nullable().optional(),
  sales_document_no: stringType().nullable().optional(),
  so_creation_date: stringType().nullable().optional(),
  sales_item_no: unionType([stringType(), numberType()]).nullable().optional(),
  material: stringType().nullable().optional(),
  qty: unionType([stringType(), numberType()]).nullable().optional(),
  net_value: unionType([stringType(), numberType()]).nullable().optional(),
  tax_value: unionType([stringType(), numberType()]).nullable().optional(),
  reason: stringType().nullable().optional(),
  rel_1: stringType().nullable().optional(),
  status_1: stringType().nullable().optional(),
  rel_2: stringType().nullable().optional(),
  status_2: stringType().nullable().optional()
});
function toSapSoRow(r) {
  return {
    SELECT: "X",
    COMPANY_CODE: s(r.company_code),
    SALES_ORG: s(r.sales_org),
    DIS_CHANEL: s(r.dis_chanel),
    DIVISION: s(r.division),
    CUSTOMER: padCustomer(r.customer),
    CUSTOMER_NAME: s(r.customer_name),
    CUSTOMER_GROUP: s(r.customer_group),
    CUSTOMER_PRICE_GROUP: s(r.customer_price_group),
    YEAR: s(r.year),
    CONTRACT_NO: s(r.contract_no),
    CONTRACT_ITEM: s(r.contract_item),
    SALES_DOCUMENT_NO: s(r.sales_document_no),
    SO_CREATION_DATE: s(r.so_creation_date),
    SALES_ITEM_NO: s(r.sales_item_no),
    MATERIAL: s(r.material),
    QTY: s(r.qty),
    NET_VALUE: s(r.net_value),
    TAX_VALUE: s(r.tax_value),
    REASON: s(r.reason),
    REL_1: s(r.rel_1),
    STATUS_1: s(r.status_1),
    REL_2: s(r.rel_2),
    STATUS_2: s(r.status_2)
  };
}
const submitSalesOrderDecision_createServerFn_handler = createServerRpc({
  id: "f7b8b0ff56b716670cccc698350a7cef532f4b8aac683c44efd7919a1e3fe550",
  name: "submitSalesOrderDecision",
  filename: "src/lib/sd/sales-order-approval.functions.ts"
}, (opts) => submitSalesOrderDecision.__executeServer(opts));
const submitSalesOrderDecision = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["accepted", "rejected"]),
  user_id: stringType().trim().max(40).optional(),
  rows: arrayType(SalesOrderRowSchema).min(1, "Select at least one row")
}).parse(d)).handler(submitSalesOrderDecision_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", DECISION_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${DECISION_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${DECISION_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: prof
  }, {
    data: userIdField
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("profiles").select("sap_user_id").eq("id", context.userId).maybeSingle(), supabaseAdmin.from("sap_api_request_fields").select("default_value").eq("config_id", cfg.id).eq("field_name", "USER_ID").maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const resolvedUserId = data.user_id && data.user_id.trim() || prof?.sap_user_id && prof.sap_user_id.trim() || userIdField?.default_value || "NEOBMWCONS";
  const sapPayload = {
    USER_ID: resolvedUserId,
    APPROV: data.action === "accepted" ? "X" : "",
    REJ: data.action === "rejected" ? "X" : "",
    DATA: data.rows.map(toSapSoRow)
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "PUT";
  let bodyOut;
  const headers = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sales_order_approval/Sales_Order_Approve_Reject`;
    method = "POST";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      inputs: sapPayload
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url.trim();
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
    bodyOut = JSON.stringify(sapPayload);
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const redacted = (h) => {
    const o = {};
    for (const [k, v] of Object.entries(h)) {
      if (/^(authorization|x-shared-secret)$/i.test(k)) o[k] = "***redacted***";
      else o[k] = v;
    }
    return o;
  };
  const t0 = Date.now();
  console.log("[submitSalesOrderDecision] target=", target, "method=", method, "proxied=", proxied, "payload=", sapPayload);
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
    if (proxied && res.status === 404) {
      const peek = await res.clone().text().catch(() => "");
      if (/Cannot\s+(POST|PUT)/i.test(peek)) {
        const fallback = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
        res = await fetch(fallback, {
          method: "POST",
          headers,
          body: JSON.stringify({
            configId: cfg.id,
            inputs: sapPayload
          })
        });
        target = fallback;
      }
    }
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    console.error("[submitSalesOrderDecision] network error", errMsg);
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `so-decision ${data.action}: network ${errMsg}`
    });
    return {
      ok: false,
      action: data.action,
      count: data.rows.length,
      error: `Could not reach SAP: ${errMsg}`,
      sap_response: null,
      debug: {
        target,
        method,
        proxied,
        request_headers: redacted(headers),
        request_payload: sapPayload,
        response_status: null,
        response_body_preview: "",
        latency_ms: latency_ms2
      }
    };
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  console.log("[submitSalesOrderDecision] status=", res.status, "latency_ms=", latency_ms, "body=", text.slice(0, 1e3));
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = {
      raw: text
    };
  }
  if (!res.ok) {
    let upstream = "";
    try {
      if (json?.error) upstream = String(json.error);
      else if (json?.data) upstream = typeof json.data === "string" ? json.data : JSON.stringify(json.data);
    } catch {
    }
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `so-decision ${data.action}: ${res.status} ${text.slice(0, 500)}`
    });
    return {
      ok: false,
      action: data.action,
      count: data.rows.length,
      error: `SAP returned ${res.status} ${res.statusText}: ${upstream || text.slice(0, 300) || "(empty body)"}`,
      sap_response: json,
      debug: {
        target,
        method,
        proxied,
        request_headers: redacted(headers),
        request_payload: sapPayload,
        response_status: res.status,
        response_body_preview: text.slice(0, 4e3),
        latency_ms
      }
    };
  }
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: data.rows.length,
    message: `so-decision ${data.action}: ${res.status}`
  });
  return {
    ok: true,
    action: data.action,
    count: data.rows.length,
    error: null,
    sap_response: json,
    debug: {
      target,
      method,
      proxied,
      request_headers: redacted(headers),
      request_payload: sapPayload,
      response_status: res.status,
      response_body_preview: text.slice(0, 4e3),
      latency_ms
    }
  };
});
export {
  fetchSalesOrderApprovals_createServerFn_handler,
  submitSalesOrderDecision_createServerFn_handler
};
