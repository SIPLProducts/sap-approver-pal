import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-CZRUt5a6.mjs";
const BLANK = "__blank__";
function ReleaseKeySelect({
  keys,
  group,
  code,
  onGroupChange,
  onCodeChange,
  disabled
}) {
  const groups = reactExports.useMemo(() => {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const k of keys) {
      if (seen.has(k.relGroup)) continue;
      seen.add(k.relGroup);
      out.push(k.relGroup);
    }
    return out.sort((a, b) => a.localeCompare(b));
  }, [keys]);
  const codes = reactExports.useMemo(() => {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const k of keys) {
      if (k.relGroup !== group) continue;
      if (seen.has(k.releaseCode)) continue;
      seen.add(k.releaseCode);
      out.push(k.releaseCode);
    }
    return out.sort((a, b) => a.localeCompare(b));
  }, [keys, group]);
  const hasKeys = keys.length > 0;
  const groupSelected = groups.includes(group);
  reactExports.useEffect(() => {
    if (!hasKeys) return;
    if (!groupSelected && (group || code)) {
      onGroupChange("");
      onCodeChange("");
      return;
    }
    if (code && !codes.includes(code)) onCodeChange("");
  }, [hasKeys, groupSelected, codes.join(","), group, code]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Release Group" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Select,
        {
          value: groupSelected ? group || BLANK : "",
          onValueChange: (v) => {
            onGroupChange(v === BLANK ? "" : v);
            onCodeChange("");
          },
          disabled: disabled || !hasKeys,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "h-9 text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: hasKeys ? "Select group" : "No keys assigned" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: groups.map((g) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: g || BLANK, children: g || "(blank)" }, g || BLANK)) })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Release Code" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Select,
        {
          value: codes.includes(code) ? code : "",
          onValueChange: onCodeChange,
          disabled: disabled || !groupSelected || codes.length === 0,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "h-9 text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              SelectValue,
              {
                placeholder: !hasKeys ? "No keys assigned" : groupSelected ? "Select code" : "Select group first"
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: codes.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: c, children: c }, c)) })
          ]
        }
      )
    ] })
  ] });
}
export {
  ReleaseKeySelect as R
};
