import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn } from "./createSsrRpc-Bx8XQbeC.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, e as DialogFooter } from "./dialog--up_DbYf.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";
import { S as StatusBadge } from "./status-badge-CHGzK-xV.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { R as RadioGroup, a as RadioGroupItem } from "./radio-group-CxFG_eHv.mjs";
import { C as CloudscapeApprovalTable } from "./cloudscape-approval-table-B3gA6T4g.mjs";
import { b as buildDynamicColumns } from "./dynamic-columns-C64XiqUr.mjs";
import { P as PlantMultiSelect } from "./plant-multi-select-ZAM7hHZh.mjs";
import { C as CustomerSelect } from "./customer-select-s74NjBrL.mjs";
import { S as SearchTermMultiSelect } from "./search-term-multi-select-DzkIn2hy.mjs";
import { u as useActiveContext } from "./use-active-context-CMJTykFM.mjs";
import { f as fetchSalesOrderApprovals, s as submitSalesOrderDecision } from "./sales-order-approval.functions-BC09jn3I.mjs";
import { c as Route$8 } from "./router-BdEqF8Cp.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/web-push.mjs";

import { aa as Funnel, a3 as LoaderCircle, ab as RotateCcw, F as FileText, x as TriangleAlert, y as CircleX, C as CircleCheck } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./server-6SfJ9jtE.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";






import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-radio-group.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "./input-C0QjszdI.mjs";
import "./checkbox-mmp_duDa.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./empty-state-DA5qeMhN.mjs";
import "./skeleton-rows-C2wJYLiJ.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./format-D-HjDoz6.mjs";
import "./table-BhFPQiYt.mjs";
import "./command-i9zWGkU5.mjs";
import "../_libs/radix-ui__react-popover.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/cmdk.mjs";
import "./plant-select-BIpZq3f7.mjs";
import "./auth-middleware-Drtg4FDX.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./sap.functions-oOi__-nP.mjs";
import "../_libs/zod.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "./client-CXnFcWf4.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "./screen-keys-mn2QOK0m.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "./client.server-D5ro3rAQ.mjs";
import "./sap-client.server-CglbxEth.mjs";
import "./push.server-Co_uxbPF.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";

import "../_libs/asn1.js.mjs";
import "../_libs/bn.js.mjs";
import "../_libs/inherits.mjs";
import "../_libs/safer-buffer.mjs";
import "../_libs/minimalistic-assert.mjs";
import "../_libs/jws.mjs";

import "../_libs/safe-buffer.mjs";
import "../_libs/jwa.mjs";
import "../_libs/ecdsa-sig-formatter.mjs";
import "../_libs/buffer-equal-constant-time.mjs";
import "../_libs/http_ece.mjs";
import "../_libs/https-proxy-agent.mjs";



import "../_libs/debug.mjs";
import "../_libs/ms.mjs";
import "../_libs/supports-color.mjs";

import "../_libs/has-flag.mjs";
import "../_libs/agent-base.mjs";
function rowKey(r, i) {
  return [r.sales_document_no, r.sales_item_no, r.customer, r.material, i].map((x) => x ?? "").join("|");
}
function mapSeverity(raw) {
  const t = String(raw ?? "").toUpperCase().trim();
  if (["@01@", "@5B@", "S"].includes(t)) return "success";
  if (["@02@", "@09@", "W"].includes(t)) return "warning";
  if (["@03@", "@5C@", "@AY@", "E", "A"].includes(t)) return "error";
  if (["@04@", "@08@", "I"].includes(t)) return "info";
  return "info";
}
function SalesOrderPage() {
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const {
    status: urlStatus
  } = Route$8.useSearch();
  const navigate = useNavigate();
  const fetchFn = useServerFn(fetchSalesOrderApprovals);
  const decisionFn = useServerFn(submitSalesOrderDecision);
  const {
    activePlants: __aps
  } = useActiveContext();
  const [plants, setPlants] = reactExports.useState(__aps);
  reactExports.useEffect(() => {
    setPlants((prev) => {
      if (__aps.length === 0) return [];
      const allowed = new Set(__aps);
      const kept = prev.filter((c) => allowed.has(c));
      return kept.length === 0 ? __aps : kept;
    });
  }, [__aps.join(",")]);
  const [userId, setUserId] = reactExports.useState("");
  const [customerFrom, setCustomerFrom] = reactExports.useState("");
  const [searchTerms, setSearchTerms] = reactExports.useState([]);
  const [status, setStatusState] = reactExports.useState(urlStatus);
  const [rows, setRows] = reactExports.useState([]);
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const [reasons, setReasons] = reactExports.useState(/* @__PURE__ */ new Map());
  const [lastFetchedAt, setLastFetchedAt] = reactExports.useState(null);
  function setReasonFor(k, value) {
    setReasons((prev) => {
      const next = new Map(prev);
      next.set(k, value);
      return next;
    });
  }
  const [resultOpen, setResultOpen] = reactExports.useState(false);
  const [resultData, setResultData] = reactExports.useState({
    action: "accepted",
    messages: [],
    total: 0
  });
  const mutation = useMutation({
    mutationFn: async (vars) => {
      const v = await fetchFn({
        data: {
          plants: vars.plants,
          user_id: vars.user_id,
          customer_from: vars.customer_from,
          customer_to: vars.customer_to,
          search_terms: vars.search_terms,
          status: vars.status
        }
      });
      const rows2 = Array.isArray(v?.rows) ? v.rows : [];
      return {
        rows: rows2,
        count: rows2.length,
        error: v?.error ?? null,
        fetched_at: v?.fetched_at ?? (/* @__PURE__ */ new Date()).toISOString()
      };
    },
    onSuccess: (res) => {
      setRows(res.rows);
      setSelected(/* @__PURE__ */ new Set());
      setReasons(/* @__PURE__ */ new Map());
      setLastFetchedAt(res.fetched_at);
      if (res.error) toast.error(res.error);
      else toast.success(`Loaded ${res.count} record${res.count === 1 ? "" : "s"} from SAP`);
    },
    onError: (e) => toast.error(e.message ?? "Failed to fetch from SAP")
  });
  function fetchFor(s) {
    if (plants.length === 0) return;
    mutation.mutate({
      plants,
      user_id: userId.trim(),
      customer_from: customerFrom.trim(),
      customer_to: customerFrom.trim(),
      search_terms: searchTerms,
      status: s
    });
  }
  function execute() {
    if (plants.length === 0) return toast.error("Select at least one plant");
    fetchFor(status);
  }
  function onStatusChange(s) {
    setStatusState(s);
    setRows([]);
    setSelected(/* @__PURE__ */ new Set());
    setReasons(/* @__PURE__ */ new Map());
    setLastFetchedAt(null);
    if (plants.length > 0) {
      fetchFor(s);
    } else {
      toast.info("Select a plant and click Execute");
    }
  }
  function reset() {
    setPlants([]);
    setUserId("");
    setCustomerFrom("");
    setSearchTerms([]);
    setStatusState("pending");
    setRows([]);
    setSelected(/* @__PURE__ */ new Set());
    setReasons(/* @__PURE__ */ new Map());
    setLastFetchedAt(null);
  }
  const canExecute = plants.length > 0 && !mutation.isPending;
  const indexed = reactExports.useMemo(() => rows.map((r, i) => ({
    r,
    k: rowKey(r, i)
  })), [rows]);
  const decisionMutation = useMutation({
    mutationFn: (vars) => decisionFn({
      data: vars
    }),
    onSuccess: (res, vars) => {
      const dbg = res?.debug;
      if (dbg) {
        const st = dbg.response_status ?? "ERR";
        console.groupCollapsed(`[SAP] Sales_Order_Approve_Reject · ${vars.action} · ${st} (${dbg.latency_ms}ms)`);
        console.log("URL:", dbg.target);
        console.log("Method:", dbg.method, "proxied:", dbg.proxied);
        console.log("Request headers:", dbg.request_headers);
        console.log("Request payload:", dbg.request_payload);
        console.log("Response status:", dbg.response_status);
        console.log("Response body:", dbg.response_body_preview);
        console.groupEnd();
      }
      const sap = res?.sap_response ?? {};
      let inner = sap?.data ?? sap;
      if (typeof inner === "string") {
        try {
          inner = JSON.parse(inner);
        } catch {
        }
      }
      let rawMsgs = inner?.MESSAGE ?? inner?.message ?? inner?.Messages ?? inner?.MSG ?? sap?.MESSAGE ?? sap?.message ?? sap?.Messages ?? null;
      if (!rawMsgs) {
        const preview2 = res?.debug?.response_body_preview;
        if (typeof preview2 === "string" && preview2.trim()) {
          try {
            const p = JSON.parse(preview2);
            const pInner = p?.data ?? p;
            rawMsgs = pInner?.MESSAGE ?? pInner?.message ?? pInner?.Messages ?? pInner?.MSG ?? p?.MESSAGE ?? null;
          } catch {
          }
        }
      }
      const msgs = Array.isArray(rawMsgs) ? rawMsgs : rawMsgs ? [rawMsgs] : [];
      const isOk = res?.ok !== false;
      const preview = res?.debug?.response_body_preview ?? "";
      if (!isOk && msgs.length === 0 && !preview.trim()) {
        toast.error(res.error ?? "SAP submission failed");
        return;
      }
      const finalMsgs = msgs.length > 0 ? msgs : [{
        TYPE: "I",
        MSG: preview.trim() || res?.error || "No response body from SAP"
      }];
      setResultData({
        action: vars.action,
        messages: finalMsgs,
        total: vars.rows.length
      });
      setResultOpen(true);
      setSelected(/* @__PURE__ */ new Set());
      setReasons(/* @__PURE__ */ new Map());
      fetchFor("pending");
    },
    onError: (e) => {
      console.error("[SAP] Sales_Order_Approve_Reject failed:", e?.message ?? e);
      toast.error(e.message ?? "SAP submission failed");
    }
  });
  const missingReason = reactExports.useMemo(() => {
    if (status !== "pending") return false;
    for (const {
      k
    } of indexed) {
      if (selected.has(k) && !(reasons.get(k) ?? "").trim()) return true;
    }
    return false;
  }, [status, indexed, selected, reasons]);
  async function decide(action) {
    if (status !== "pending" || selected.size === 0 || decisionMutation.isPending) return;
    const selectedRows = indexed.filter(({
      k
    }) => selected.has(k)).map(({
      r,
      k
    }) => ({
      ...r,
      reason: (reasons.get(k) ?? "").trim()
    }));
    if (selectedRows.some((r) => !r.reason)) {
      toast.error("Reason is required for all selected rows");
      return;
    }
    const ok = await confirm({
      title: `${action === "accepted" ? "Approve" : "Reject"} ${selectedRows.length} selected item(s)?`,
      description: "This submits the decision to SAP and cannot be undone.",
      confirmLabel: action === "accepted" ? "Approve" : "Reject",
      destructive: action !== "accepted"
    });
    if (!ok) return;
    decisionMutation.mutate({
      action,
      user_id: userId.trim(),
      rows: selectedRows
    });
  }
  const showSelect = status === "pending";
  const canAct = showSelect && selected.size > 0 && !missingReason;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "SD Approvals", title: "Sales Order Approvals", subtitle: "Review and action pending sales order approval requests routed from SAP." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }),
        " SELECTION SCREEN"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-3 lg:grid-cols-5 items-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs", children: [
            "Plant ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(PlantMultiSelect, { value: plants, onChange: setPlants })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Customer" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CustomerSelect, { value: customerFrom, onChange: setCustomerFrom, plants, onEnter: execute })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-xs", children: "Search Term" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(SearchTermMultiSelect, { value: searchTerms, onChange: setSearchTerms, plants })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: execute, disabled: !canExecute, children: [
            mutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 mr-1.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Execute"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", onClick: () => navigate({
            to: "/sd/sales-order-reports"
          }), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-3.5 w-3.5 mr-1.5" }),
            "Reports"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: reset, children: "Reset" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 -mx-4 px-4 pt-3 border-t", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-6 flex-wrap", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-xs text-muted-foreground", children: [
          "Status ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(RadioGroup, { value: status, onValueChange: (v) => onStatusChange(v), className: "flex items-center gap-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RadioGroupItem, { value: "pending", id: "st-pending" }),
            "Pending"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RadioGroupItem, { value: "accepted", id: "st-accepted" }),
            "Accepted"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RadioGroupItem, { value: "rejected", id: "st-rejected" }),
            "Rejected"
          ] })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CloudscapeApprovalTable, { title: `Sales Order Approvals — ${status}`, countLabel: `(${rows.length})`, rows, rowKey, loading: mutation.isPending, showSelect, selectedKeys: selected, onSelectionChange: setSelected, onAccept: () => decide("accepted"), onReject: () => decide("rejected"), acceptDisabled: !canAct || decisionMutation.isPending, rejectDisabled: !canAct || decisionMutation.isPending, acceptLoading: decisionMutation.isPending && decisionMutation.variables?.action === "accepted", rejectLoading: decisionMutation.isPending && decisionMutation.variables?.action === "rejected", showReason: showSelect, reasonValue: (k) => reasons.get(k) ?? "", onReasonChange: setReasonFor, reasonInvalid: (k) => selected.has(k) && !(reasons.get(k) ?? "").trim(), readonlyReason: (r) => r.reason ?? "—", emptyMessage: lastFetchedAt ? `No ${status} records.` : "Enter Plant and click Execute to load sales orders from SAP.", columns: buildDynamicColumns(rows, {
      exclude: ["rel_1", "status_1"]
    }) }),
    confirmDialog,
    /* @__PURE__ */ jsxRuntimeExports.jsx(ResultDialog, { open: resultOpen, onOpenChange: setResultOpen, action: resultData.action, messages: resultData.messages, total: resultData.total })
  ] });
}
function ResultDialog({
  open,
  onOpenChange,
  action,
  messages,
  total
}) {
  const severities = messages.map((m) => mapSeverity(m?.TYPE));
  const hasError = severities.some((s) => s === "error");
  const hasWarn = severities.some((s) => s === "warning");
  severities.filter((s) => s === "success").length;
  const tone = hasError ? "error" : hasWarn ? "warning" : "success";
  const banner = {
    success: {
      bg: "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-5 w-5 text-emerald-600" }),
      title: action === "accepted" ? "Approved successfully" : "Rejected successfully"
    },
    error: {
      bg: "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-5 w-5 text-red-600" }),
      title: "Completed with errors"
    },
    warning: {
      bg: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-5 w-5 text-amber-600" }),
      title: "Completed with warnings"
    }
  }[tone];
  function badge(sev) {
    if (sev === "success") return /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: "success", label: "Success" });
    if (sev === "error") return /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: "error", label: "Error" });
    if (sev === "warning") return /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: "warning", label: "Warning" });
    return /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: "neutral", label: "Info" });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open, onOpenChange, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "SAP Response" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-start gap-3 rounded-lg border p-3 ${banner.bg}`, children: [
      banner.icon,
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-sm", children: banner.title }) })
    ] }),
    messages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-muted-foreground mt-2", children: "SAP Response Details" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[55vh] overflow-auto space-y-2 pr-1", children: messages.map((m, i) => {
        const contract = (m.CONTRACT ?? m.SALES_DOCUMENT_NO ?? "").toString().trim();
        const customer = (m.CUSTOMER ?? "").toString().trim();
        const type = (m.TYPE ?? "").toString().trim();
        const msg = m?.MSG || m?.MESSAGE || "—";
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-md border bg-card p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium leading-snug min-w-0", children: msg }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0", children: badge(severities[i]) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 grid grid-cols-[90px_1fr] gap-x-3 gap-y-1 text-[11px] font-mono", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground", children: "TYPE" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: type || "—" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground", children: "CUSTOMER" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: customer || "—" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground", children: "CONTRACT" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: contract || "—" })
          ] })
        ] }, i);
      }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => onOpenChange(false), children: "Close" }) })
  ] }) });
}
export {
  SalesOrderPage as component
};
