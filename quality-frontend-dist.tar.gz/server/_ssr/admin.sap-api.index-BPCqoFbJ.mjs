import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQueryClient, a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { B as Badge } from "./badge-DyfXZgLs.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { D as Dialog, f as DialogTrigger, a as DialogContent, b as DialogHeader, c as DialogTitle, e as DialogFooter } from "./dialog--up_DbYf.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-CZRUt5a6.mjs";
import { T as Tabs, a as TabsList, b as TabsTrigger, c as TabsContent } from "./tabs-D_u1EXWn.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { l as listSapConfigs, u as upsertSapConfig, d as deleteSapConfig, t as testSapConnection } from "./sap-api.functions-DdXsBya3.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { S as StatusBadge } from "./status-badge-CHGzK-xV.mjs";
import { S as SkeletonCards } from "./skeleton-rows-C2wJYLiJ.mjs";
import { E as EmptyState } from "./empty-state-DA5qeMhN.mjs";
import { f as formatDateTime } from "./format-D-HjDoz6.mjs";
import { u as useConfirm } from "./confirm-dialog-BICeYF_N.mjs";

import "../_libs/seroval.mjs";
import { i as Plug, as as Database, h as Server, V as Plus, a0 as Pencil, a3 as LoaderCircle, am as Activity, a1 as Trash2, v as Save } from "../_libs/lucide-react.mjs";
import { a as objectType, z as stringType, F as coerce, D as enumType } from "../_libs/zod.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-tabs.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
const SettingsSchema = objectType({
  connection_mode: enumType(["direct", "via_proxy"]).default("direct"),
  deployment_mode: enumType(["lovable_cloud", "self_hosted"]).default("lovable_cloud"),
  middleware_port: coerce.number().int().min(1).max(65535).default(3002),
  middleware_url: stringType().max(500).optional().nullable(),
  proxy_secret: stringType().max(500).optional().nullable()
});
const SapConnectionSchema = objectType({
  sap_environment: stringType().max(60).optional().nullable(),
  sap_base_url: stringType().max(500).optional().nullable().refine((v) => !v || /^https?:\/\/[^\s]+$/i.test(v.trim()), "SAP Base URL must start with http:// or https://"),
  sap_username: stringType().max(200).optional().nullable(),
  sap_password: stringType().max(500).optional().nullable()
});
const getSapGlobalSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("3bc1b331640d24658e2002ec4b96bc690fb18a7acd693c59abea35338fb508d5"));
const upsertSapGlobalSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => SettingsSchema.parse(d)).handler(createSsrRpc("3da792f8fc06d8b0a6cee78d7012abbd9b5369bfa9337ec1dc1ad1682a9e56f3"));
const upsertSapConnection = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => SapConnectionSchema.parse(d)).handler(createSsrRpc("11b57b9ec98b858b0bf05e9a630555a0c211cc0e3630d5bfd0f6473b37f669f9"));
const testSapConnectionGlobal = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("cf57eb70a5c50cc156ac9bf714da974d89848716e1247b1e403440a716c1b102"));
const testGlobalMiddleware = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("05062241b1769d2bc70b04e910c81b7d7d937398a131af6b498508150155139b"));
function SapApiListPage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Admin", title: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Plug, { className: "h-6 w-6" }),
      " SAP API Settings"
    ] }), subtitle: "Register dynamic SAP/REST endpoints and configure the shared Node.js middleware." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { defaultValue: "apis", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "apis", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Plug, { className: "h-4 w-4 mr-1" }),
          " APIs"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "sap-conn", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "h-4 w-4 mr-1" }),
          " SAP Connection"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "middleware", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Server, { className: "h-4 w-4 mr-1" }),
          " Middleware Configuration"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "apis", className: "mt-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ApisTab, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "sap-conn", className: "mt-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SapConnectionTab, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "middleware", className: "mt-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MiddlewareTab, {}) })
    ] })
  ] });
}
function ApisTab() {
  const qc = useQueryClient();
  const nav = useNavigate();
  const {
    confirm,
    confirmDialog
  } = useConfirm();
  const listFn = useServerFn(listSapConfigs);
  const upsertFn = useServerFn(upsertSapConfig);
  const deleteFn = useServerFn(deleteSapConfig);
  const testFn = useServerFn(testSapConnection);
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["sap-configs"],
    queryFn: () => listFn()
  });
  const [open, setOpen] = reactExports.useState(false);
  const [testing, setTesting] = reactExports.useState(null);
  const [form, setForm] = reactExports.useState({
    name: "",
    description: "",
    module: "COMMON",
    endpoint_url: "",
    auth_type: "basic"
  });
  async function createNew() {
    if (!form.name || !form.endpoint_url) return toast.error("Name and endpoint URL are required");
    try {
      const res = await upsertFn({
        data: {
          name: form.name,
          description: form.description,
          module: form.module,
          endpoint_url: form.endpoint_url,
          http_method: "GET",
          auth_type: form.auth_type,
          api_type: "fetch",
          auto_sync_enabled: false,
          is_active: true
        }
      });
      toast.success("Endpoint created");
      setOpen(false);
      nav({
        to: "/admin/sap-api/$id",
        params: {
          id: res.config.id
        }
      });
    } catch (e) {
      toast.error(e.message);
    }
  }
  async function handleDelete(id, name) {
    if (!await confirm({
      title: `Delete endpoint "${name}"?`,
      description: "This will remove the endpoint configuration permanently.",
      confirmLabel: "Delete"
    })) return;
    try {
      await deleteFn({
        data: {
          id
        }
      });
      toast.success("Deleted");
      qc.invalidateQueries({
        queryKey: ["sap-configs"]
      });
    } catch (e) {
      toast.error(e.message);
    }
  }
  async function handleTest(id) {
    setTesting(id);
    try {
      const r = await testFn({
        data: {
          id
        }
      });
      r.ok ? toast.success(`OK — ${r.message} (${r.latency_ms}ms)`) : toast.error(`${r.message} (${r.latency_ms}ms)`);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(null);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Dialog, { open, onOpenChange: setOpen, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-2" }),
        " New endpoint"
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Register a new SAP endpoint" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.name, onChange: (e) => setForm({
              ...form,
              name: e.target.value
            }), placeholder: "e.g. PR_GET" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Description" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.description, onChange: (e) => setForm({
              ...form,
              description: e.target.value
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Module" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: form.module, onValueChange: (v) => setForm({
                ...form,
                module: v
              }), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "MM", children: "MM" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "SD", children: "SD" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "COMMON", children: "Common" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Auth type" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: form.auth_type, onValueChange: (v) => setForm({
                ...form,
                auth_type: v
              }), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "basic", children: "Basic" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "oauth", children: "OAuth" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "none", children: "None" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "proxy", children: "Proxy / Middleware" })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Endpoint Path or URL" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.endpoint_url, onChange: (e) => setForm({
              ...form,
              endpoint_url: e.target.value
            }), placeholder: "/sd_approval_mng/zvk11_app/vk11_app?sap-client=300" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-muted-foreground mt-1", children: [
              "Use a relative path (starting with ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "/" }),
              ") to inherit the SAP Base URL from ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "SAP Connection" }),
              ". A full ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "http(s)://…" }),
              " URL is also accepted."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => setOpen(false), children: "Cancel" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: createNew, children: "Create" })
        ] })
      ] })
    ] }) }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonCards, { count: 3 }) : data?.configs.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Plug, { className: "h-5 w-5" }), title: "No endpoints yet", description: 'Click "New endpoint" to register the first SAP REST endpoint.' }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-3", children: data?.configs.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold truncate", children: c.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground line-clamp-1", children: c.description || c.endpoint_url })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-end gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", children: c.module }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "text-[10px]", children: c.auth_type })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: c.is_active ? "success" : "warning", label: c.is_active ? "Active" : "Inactive" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: c.last_synced_at ? `Last synced ${formatDateTime(c.last_synced_at)}` : "Never synced" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1 pt-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/admin/sap-api/$id", params: {
          id: c.id
        }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3 w-3 mr-1" }),
          " Edit"
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: () => handleTest(c.id), disabled: testing === c.id, children: [
          testing === c.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3 w-3 mr-1 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className: "h-3 w-3 mr-1" }),
          " Test"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", className: "text-destructive", onClick: () => handleDelete(c.id, c.name), "aria-label": `Delete endpoint ${c.name}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3 w-3" }) })
      ] })
    ] }, c.id)) }),
    confirmDialog
  ] });
}
function MiddlewareTab() {
  const qc = useQueryClient();
  const getFn = useServerFn(getSapGlobalSettings);
  const saveFn = useServerFn(upsertSapGlobalSettings);
  const testFn = useServerFn(testGlobalMiddleware);
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["sap-global-settings"],
    queryFn: () => getFn()
  });
  const [form, setForm] = reactExports.useState({
    connection_mode: "direct",
    deployment_mode: "lovable_cloud",
    middleware_port: 3002,
    middleware_url: "",
    proxy_secret: ""
  });
  const [secretSet, setSecretSet] = reactExports.useState(false);
  const [busy, setBusy] = reactExports.useState(false);
  const [testing, setTesting] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (data?.settings) {
      setForm({
        connection_mode: data.settings.connection_mode ?? "direct",
        deployment_mode: data.settings.deployment_mode ?? "lovable_cloud",
        middleware_port: data.settings.middleware_port ?? 3002,
        middleware_url: data.settings.middleware_url ?? "",
        proxy_secret: ""
      });
      setSecretSet(!!data.proxy_secret_set);
    }
  }, [data]);
  const proxy = form.connection_mode === "via_proxy";
  async function save() {
    setBusy(true);
    try {
      await saveFn({
        data: {
          connection_mode: form.connection_mode,
          deployment_mode: form.deployment_mode,
          middleware_port: form.middleware_port,
          middleware_url: form.middleware_url || null,
          proxy_secret: form.proxy_secret || null
        }
      });
      toast.success("Middleware settings saved");
      setForm((f) => ({
        ...f,
        proxy_secret: ""
      }));
      setSecretSet((s) => s || !!form.proxy_secret);
      qc.invalidateQueries({
        queryKey: ["sap-global-settings"]
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function runTest() {
    setTesting(true);
    try {
      const r = await testFn();
      r.ok ? toast.success(`OK — ${r.message} (${r.latency_ms}ms)`) : toast.error(`${r.message} (${r.latency_ms}ms)`);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(false);
    }
  }
  if (isLoading) return /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonCards, { count: 2 });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "font-semibold flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Server, { className: "h-4 w-4" }),
          " Node.js Middleware"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "These settings are shared by every SAP API integration whose Auth Type is set to Proxy / Middleware." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", onClick: runTest, disabled: testing || !form.middleware_url, children: [
        testing ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 mr-1 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className: "h-4 w-4 mr-1" }),
        " Test middleware"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Connection Mode" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: form.connection_mode, onValueChange: (v) => setForm({
          ...form,
          connection_mode: v
        }), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "direct", children: "Direct" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "via_proxy", children: "Via Proxy Server" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Deployment Mode" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: form.deployment_mode, onValueChange: (v) => setForm({
          ...form,
          deployment_mode: v
        }), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "lovable_cloud", children: "Lovable Cloud" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "self_hosted", children: "Self-hosted" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Middleware Port" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: form.middleware_port, onChange: (e) => setForm({
          ...form,
          middleware_port: Number(e.target.value) || 0
        }), placeholder: "3002" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { children: [
          "Node.js Middleware URL ",
          proxy && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.middleware_url, onChange: (e) => setForm({
          ...form,
          middleware_url: e.target.value
        }), placeholder: "https://your-middleware.example.com" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { children: [
          "Proxy Secret / Password ",
          proxy && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-destructive", children: "*" }),
          secretSet && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", className: "ml-2 text-[10px]", children: "set" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "password", value: form.proxy_secret, onChange: (e) => setForm({
          ...form,
          proxy_secret: e.target.value
        }), placeholder: secretSet ? "•••••••• (leave blank to keep)" : "Enter shared secret" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: save, disabled: busy, children: [
      busy ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 mr-2 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-2" }),
      " Save middleware settings"
    ] }) })
  ] });
}
function SapConnectionTab() {
  const qc = useQueryClient();
  const getFn = useServerFn(getSapGlobalSettings);
  const saveFn = useServerFn(upsertSapConnection);
  const testFn = useServerFn(testSapConnectionGlobal);
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["sap-global-settings"],
    queryFn: () => getFn()
  });
  const [form, setForm] = reactExports.useState({
    sap_environment: "",
    sap_base_url: "",
    sap_username: "",
    sap_password: ""
  });
  const [passwordSet, setPasswordSet] = reactExports.useState(false);
  const [busy, setBusy] = reactExports.useState(false);
  const [testing, setTesting] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (data?.settings) {
      const s = data.settings;
      setForm({
        sap_environment: s.sap_environment ?? "",
        sap_base_url: s.sap_base_url ?? "",
        sap_username: s.sap_username ?? "",
        sap_password: ""
      });
      setPasswordSet(!!data.sap_password_set);
    }
  }, [data]);
  async function save() {
    if (form.sap_base_url && !/^https?:\/\//i.test(form.sap_base_url.trim())) {
      return toast.error("SAP Base URL must start with http:// or https://");
    }
    setBusy(true);
    try {
      await saveFn({
        data: {
          sap_environment: form.sap_environment || null,
          sap_base_url: form.sap_base_url || null,
          sap_username: form.sap_username || null,
          sap_password: form.sap_password || null
        }
      });
      toast.success("SAP connection saved");
      setForm((f) => ({
        ...f,
        sap_password: ""
      }));
      setPasswordSet((s) => s || !!form.sap_password);
      qc.invalidateQueries({
        queryKey: ["sap-global-settings"]
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function runTest() {
    setTesting(true);
    try {
      const r = await testFn();
      r.ok ? toast.success(`OK — ${r.message} (${r.latency_ms}ms)`) : toast.error(`${r.message} (${r.latency_ms}ms)`);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(false);
    }
  }
  if (isLoading) return /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonCards, { count: 2 });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "font-semibold flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "h-4 w-4" }),
          " SAP Connection"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground mt-1", children: [
          "Base URL and shared technical-user credentials used by every SAP API integration. Endpoint definitions can store a relative path (e.g. ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "/sd_approval_mng/..." }),
          ") and will inherit this Base URL automatically — switching DEV → Quality is then a one-field change."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", onClick: runTest, disabled: testing || !form.sap_base_url, children: [
        testing ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 mr-1 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className: "h-4 w-4 mr-1" }),
        " Test connection"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Environment" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.sap_environment, onChange: (e) => setForm({
          ...form,
          sap_environment: e.target.value
        }), placeholder: "DEV / QUALITY / PROD" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "SAP Base URL" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.sap_base_url, onChange: (e) => setForm({
          ...form,
          sap_base_url: e.target.value
        }), placeholder: "http://10.150.150.155:8005" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "SAP Username" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.sap_username, onChange: (e) => setForm({
          ...form,
          sap_username: e.target.value
        }), placeholder: "Technical user" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { children: [
          "SAP Password",
          passwordSet && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", className: "ml-2 text-[10px]", children: "set" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "password", value: form.sap_password, onChange: (e) => setForm({
          ...form,
          sap_password: e.target.value
        }), placeholder: passwordSet ? "•••••••• (leave blank to keep)" : "Enter password" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: save, disabled: busy, children: [
      busy ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 mr-2 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-2" }),
      " Save SAP connection"
    ] }) })
  ] });
}
export {
  SapApiListPage as component
};
