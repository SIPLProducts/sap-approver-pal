import process from "node:process";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, z as stringType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const getVapidPublicKey_createServerFn_handler = createServerRpc({
  id: "3b65599ef4be62ae58ca53057726d74d6b12362a7b2a9d484b24502f2314e944",
  name: "getVapidPublicKey",
  filename: "src/lib/push/push.functions.ts"
}, (opts) => getVapidPublicKey.__executeServer(opts));
const getVapidPublicKey = createServerFn({
  method: "GET"
}).handler(getVapidPublicKey_createServerFn_handler, async () => {
  return {
    publicKey: process.env.VAPID_PUBLIC_KEY ?? ""
  };
});
const SubInput = objectType({
  endpoint: stringType().url().max(2e3),
  p256dh: stringType().min(1).max(500),
  auth: stringType().min(1).max(500),
  device_label: stringType().max(120).optional()
});
const subscribePush_createServerFn_handler = createServerRpc({
  id: "6de3a7c2061580c60ac513b1a1b3fff95d728e2816e2ad6b9ec872e0c95dc780",
  name: "subscribePush",
  filename: "src/lib/push/push.functions.ts"
}, (opts) => subscribePush.__executeServer(opts));
const subscribePush = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => SubInput.parse(input)).handler(subscribePush_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    error
  } = await supabase.from("push_subscriptions").upsert({
    user_id: userId,
    endpoint: data.endpoint,
    p256dh: data.p256dh,
    auth: data.auth,
    device_label: data.device_label ?? null
  }, {
    onConflict: "endpoint"
  });
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const unsubscribePush_createServerFn_handler = createServerRpc({
  id: "59fe8778a670f746039c968d8a3b8f17d0fe359eef7504227b8b658e55daef74",
  name: "unsubscribePush",
  filename: "src/lib/push/push.functions.ts"
}, (opts) => unsubscribePush.__executeServer(opts));
const unsubscribePush = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => objectType({
  endpoint: stringType().url()
}).parse(input)).handler(unsubscribePush_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  await supabase.from("push_subscriptions").delete().eq("endpoint", data.endpoint);
  return {
    ok: true
  };
});
export {
  getVapidPublicKey_createServerFn_handler,
  subscribePush_createServerFn_handler,
  unsubscribePush_createServerFn_handler
};
