import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, y as booleanType, z as stringType, A as unionType, B as numberType, C as arrayType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "Material_Fetch_API";
const fetchMaterialReservation_createServerFn_handler = createServerRpc({
  id: "01d2f77dc8711dbe6b11028bdfdf11124329d9b4ce59e347b0fbc83246dd038d",
  name: "fetchMaterialReservation",
  filename: "src/lib/mm/material-reservation.functions.ts"
}, (opts) => fetchMaterialReservation.__executeServer(opts));
const fetchMaterialReservation = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  document_number: stringType().trim().max(40).optional().default(""),
  hod_approve: booleanType().optional().default(false)
}).parse(d)).handler(fetchMaterialReservation_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const userId = data.user_id.trim();
  const documentNumber = (data.document_number ?? "").trim();
  const hodFlag = data.hod_approve ? "X" : "";
  const inputs = {
    DOCUMENT_NUMBER: documentNumber,
    HOD_APPROVE: hodFlag,
    USER_ID: userId
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "GET";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/material_fetch/Fetch`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      inputs
    });
    proxied = true;
  } else {
    const qs = new URLSearchParams(inputs).toString();
    const join = cfg.endpoint_url.includes("?") ? "&" : "?";
    target = `${cfg.endpoint_url}${join}${qs}`;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
    if (proxied && res.status === 404) {
      const peek = await res.clone().text().catch(() => "");
      if (/Cannot\s+POST/i.test(peek)) {
        const fallback = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
        res = await fetch(fallback, {
          method: "POST",
          headers,
          body: JSON.stringify({
            configId: cfg.id,
            inputs
          })
        });
        target = fallback;
      }
    }
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `material-fetch network: ${errMsg}`
    });
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      user_id: userId,
      error: `Could not reach SAP at ${cfg.endpoint_url.split("?")[0]}. ${errMsg}.`
    };
  }
  const text = await res.text().catch(() => "");
  const message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `material-fetch: ${message} ${text.slice(0, 500)}`
    });
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      user_id: userId,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      header: null,
      data: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      user_id: userId,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  const headerArr = Array.isArray(sapJson?.HEADER) ? sapJson.HEADER : Array.isArray(sapJson?.header) ? sapJson.header : [];
  const dataArr = Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : [];
  const header = headerArr.length > 0 && headerArr[0] && typeof headerArr[0] === "object" ? {
    ...headerArr[0]
  } : null;
  const rows = dataArr.map((r) => r && typeof r === "object" ? {
    ...r
  } : {});
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `material-fetch: ${message}`
  });
  return {
    header,
    data: rows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    user_id: userId,
    error: null
  };
});
const SAVE_CONFIG_NAME = "Material_Save_API";
const saveItemSchema = objectType({
  SNO: unionType([stringType(), numberType()]).optional(),
  GOODS_RECEPIENT: stringType().optional().default(""),
  MATERIAL: stringType().optional().default(""),
  MATERIAL_DESCRIPTION: stringType().optional().default(""),
  UOM: stringType().optional().default(""),
  ORDER_NUMBER: stringType().optional().default(""),
  COST_CENTER: stringType().optional().default(""),
  REQUESTED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  APPROVED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  ISSUED_QUANTITY: unionType([stringType(), numberType()]).optional().default(0),
  STORAGE_LOCATION: stringType().optional().default(""),
  TOTAL_STOCK: unionType([stringType(), numberType()]).optional().default(0),
  COST_CENT_DESC: stringType().optional().default(""),
  HOD_APRROVAL: stringType().optional().default(""),
  HOD_REJECTION: stringType().optional().default(""),
  REMARKS: stringType().optional().default("")
}).passthrough();
const saveMaterialReservation_createServerFn_handler = createServerRpc({
  id: "b8722dff6c5541251aa1deb4f7802a20a268cb1f7141e0b4382a7dc299e56ecb",
  name: "saveMaterialReservation",
  filename: "src/lib/mm/material-reservation.functions.ts"
}, (opts) => saveMaterialReservation.__executeServer(opts));
const saveMaterialReservation = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  user_id: stringType().trim().min(1, "User ID is required").max(60),
  header: objectType({
    DOCUMENT_NUMBER: stringType().optional().default(""),
    HOD_APPROVE: stringType().optional().default(""),
    DOCUMENT_DATE: stringType().optional().default(""),
    MOVEMENT_TYPE: stringType().optional().default(""),
    PLANT: stringType().optional().default(""),
    MATERIAL_TYPE: stringType().optional().default("")
  }).passthrough(),
  data: arrayType(saveItemSchema).min(1, "At least one row is required")
}).parse(d)).handler(saveMaterialReservation_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", SAVE_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${SAVE_CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${SAVE_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const userId = data.user_id.trim();
  const payload = {
    DOCUMENT_NUMBER: data.header.DOCUMENT_NUMBER ?? "",
    HOD_APPROVE: data.header.HOD_APPROVE ?? "",
    DOCUMENT_DATE: data.header.DOCUMENT_DATE ?? "",
    MOVEMENT_TYPE: data.header.MOVEMENT_TYPE ?? "",
    PLANT: data.header.PLANT ?? "",
    MATERIAL_TYPE: data.header.MATERIAL_TYPE ?? "",
    USER_ID: userId,
    DATA: data.data.map((r) => ({
      SNO: String(r.SNO ?? ""),
      GOODS_RECEPIENT: r.GOODS_RECEPIENT ?? "",
      MATERIAL: r.MATERIAL ?? "",
      MATERIAL_DESCRIPTION: r.MATERIAL_DESCRIPTION ?? "",
      UOM: r.UOM ?? "",
      ORDER_NUMBER: r.ORDER_NUMBER ?? "",
      COST_CENTER: r.COST_CENTER ?? "",
      REQUESTED_QUANTITY: Number(r.REQUESTED_QUANTITY ?? 0) || 0,
      APPROVED_QUANTITY: Number(r.APPROVED_QUANTITY ?? 0) || 0,
      ISSUED_QUANTITY: Number(r.ISSUED_QUANTITY ?? 0) || 0,
      STORAGE_LOCATION: r.STORAGE_LOCATION ?? "",
      TOTAL_STOCK: Number(r.TOTAL_STOCK ?? 0) || 0,
      COST_CENT_DESC: r.COST_CENT_DESC ?? "",
      HOD_APRROVAL: r.HOD_APRROVAL ?? "",
      HOD_REJECTION: r.HOD_REJECTION ?? "",
      REMARKS: r.REMARKS ?? ""
    }))
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs: payload
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url;
    headers["Content-Type"] = "application/json";
    bodyOut = JSON.stringify(payload);
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `material-save network: ${errMsg}`
    });
    return {
      ok: false,
      message: `Could not reach SAP: ${errMsg}`,
      documentNumber: null
    };
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `material-save: invalid JSON ${text.slice(0, 300)}`
    });
    return {
      ok: false,
      message: `Invalid JSON from SAP: ${text.slice(0, 200)}`,
      documentNumber: null
    };
  }
  const sapJson = proxied ? json?.data ?? json ?? {} : json;
  if (Array.isArray(sapJson?.MESSAGES) && sapJson.MESSAGES.length > 0) {
    const msg = sapJson.MESSAGES.map((m) => String(m?.MESSAGE ?? "").trim()).filter(Boolean).join("; ") || "SAP returned an error";
    const anyError = sapJson.MESSAGES.some((m) => String(m?.TYPE ?? "").toUpperCase() === "E" || String(m?.TYPE ?? "").toUpperCase() === "A");
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: anyError ? "error" : "ok",
      latency_ms,
      message: `material-save: ${msg}`
    });
    return {
      ok: !anyError,
      message: msg,
      documentNumber: sapJson?.DOCUMENT_NUMBER ?? null
    };
  }
  const type = String(sapJson?.TYPE ?? "").toUpperCase();
  const message = String(sapJson?.MESSAGE ?? "").trim();
  const ok = res.ok && (type === "S" || type === "I" || type === "");
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: ok ? "ok" : "error",
    latency_ms,
    message: `material-save: ${type || "?"} ${message || text.slice(0, 200)}`
  });
  return {
    ok,
    message: message || (ok ? "Saved successfully" : `SAP returned ${res.status}`),
    documentNumber: sapJson?.DOCUMENT_NUMBER ?? null
  };
});
export {
  fetchMaterialReservation_createServerFn_handler,
  saveMaterialReservation_createServerFn_handler
};
