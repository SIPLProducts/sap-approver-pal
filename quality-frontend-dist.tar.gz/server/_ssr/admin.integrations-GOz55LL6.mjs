import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-XOrxmi8L.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { C as Card } from "./card-DcbU6Qrh.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { S as StatusBadge } from "./status-badge-CHGzK-xV.mjs";
import { S as SkeletonCards } from "./skeleton-rows-C2wJYLiJ.mjs";

import "../_libs/seroval.mjs";
import { J as Copy, K as ExternalLink } from "../_libs/lucide-react.mjs";
import { a as objectType, z as stringType } from "../_libs/zod.mjs";

import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./skeleton-C5WX2eNf.mjs";
const getIntegrationStatus = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("bbdcf3c2fb277f21c95d0d963ec1660f6cae78764ce1a89329e8d988171f28aa"));
const testSapConnection = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("979cda470c83d4637138c99f1a5980ef2e5bee56765ee8687dcbaf09c095f9ff"));
const sendTestPush = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => objectType({
  userId: stringType().uuid().optional()
}).parse(input)).handler(createSsrRpc("b17c43c371ad3e0b19c6dc99564e6f0b89482e742639c04a3b9da2eb0e849e83"));
function Row({
  label,
  ok,
  hint
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between py-2 border-b last:border-0", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium", children: label }),
      hint && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: hint })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: ok ? "success" : "error", label: ok ? "Set" : "Missing" })
  ] });
}
function IntegrationsPage() {
  const statusFn = useServerFn(getIntegrationStatus);
  const sapTestFn = useServerFn(testSapConnection);
  const pushTestFn = useServerFn(sendTestPush);
  const [testing, setTesting] = reactExports.useState(null);
  const {
    data,
    isLoading,
    refetch
  } = useQuery({
    queryKey: ["integration-status"],
    queryFn: () => statusFn()
  });
  async function runSapTest() {
    setTesting("sap");
    try {
      const r = await sapTestFn();
      r.ok ? toast.success(r.message) : toast.error(r.message);
    } finally {
      setTesting(null);
    }
  }
  async function runPushTest() {
    setTesting("push");
    try {
      const r = await pushTestFn({
        data: {}
      });
      toast.success(`Push attempt: ${r.sent} sent, ${r.removed} stale removed`);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(null);
    }
  }
  function copy(v) {
    navigator.clipboard.writeText(v);
    toast.success("Copied");
  }
  const cronUrl = `${typeof window !== "undefined" ? window.location.origin : ""}/api/public/hooks/sap-sync`;
  if (isLoading || !data) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack max-w-3xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Admin", title: "Integrations", subtitle: "Configure SAP Gateway and Web Push." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonCards, { count: 3 })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack max-w-3xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Admin", title: "Integrations", subtitle: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Configure SAP Gateway and Web Push. Secret values are entered in ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "View Backend → Secrets" }),
      "; this page only shows whether each one is present."
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-6 space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-semibold", children: "SAP Gateway (Z REST wrapper)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground mt-1", children: [
            "Live mode is enabled when ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "SAP_USE_REAL=true" }),
            " AND base URL + technical user are set. Otherwise the app uses mock data."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { tone: data.sap.liveMode ? "success" : "warning", label: data.sap.liveMode ? "LIVE" : "MOCK" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-md border p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "SAP_BASE_URL", ok: data.sap.baseUrlSet, hint: "e.g. https://sap-gw.resustainability.in" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "SAP_USER", ok: data.sap.userSet, hint: "Technical user for Basic auth" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "SAP_PASSWORD", ok: data.sap.passwordSet }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: `SAP_USE_REAL = "${data.sap.useRealFlag}"`, ok: data.sap.useRealFlag === "true", hint: 'Set to "true" to flip from mock to live' })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: runSapTest, disabled: testing === "sap" || !data.sap.configured, children: testing === "sap" ? "Testing…" : "Test SAP connection" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => refetch(), children: "Refresh status" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-6 space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-semibold", children: "Web Push (VAPID)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground mt-1", children: "Required for real-time push notifications on desktop and installed PWA. The public key is shipped to the browser; the private key never leaves the server." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-md border p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "VAPID_PUBLIC_KEY", ok: data.push.publicKeySet }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "VAPID_PRIVATE_KEY", ok: data.push.privateKeySet }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "VAPID_SUBJECT", ok: data.push.subjectSet, hint: "mailto:ops@resustainability.in" })
      ] }),
      data.push.publicKey && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground mb-1", children: "Current public key (safe to share):" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "flex-1 truncate rounded bg-muted px-2 py-1", children: data.push.publicKey }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", onClick: () => copy(data.push.publicKey), "aria-label": "Copy public key", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "w-4 h-4" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: runPushTest, disabled: testing === "push" || !data.push.privateKeySet, children: testing === "push" ? "Sending…" : "Send test push to myself" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
        "Don't have keys? Generate a pair on any machine with",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "npx web-push generate-vapid-keys" }),
        " and paste them as secrets."
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-6 space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-semibold", children: "Scheduled SAP sync" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground mt-1", children: [
          "Once SAP is live, point pg_cron (or any scheduler) at the endpoint below every few minutes. Requests must include the ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: "x-cron-secret" }),
          " header."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "CRON_SECRET", ok: data.cron.secretSet, hint: "Any long random string; shared with the scheduler" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground mb-1", children: "Endpoint:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "flex-1 truncate rounded bg-muted px-2 py-1", children: cronUrl }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", onClick: () => copy(cronUrl), "aria-label": "Copy cron endpoint URL", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "w-4 h-4" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { className: "inline-flex items-center gap-1 text-sm text-primary hover:underline", href: "https://supabase.com/docs/guides/database/extensions/pg_cron", target: "_blank", rel: "noreferrer", children: [
        "pg_cron docs ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
      ] })
    ] })
  ] });
}
export {
  IntegrationsPage as component
};
