import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { w as CornerUpLeft, I as Info, x as TriangleAlert, y as CircleX, z as Clock, C as CircleCheck } from "../_libs/lucide-react.mjs";
const TONES = {
  success: {
    className: "border-success/30 bg-success/10 text-success",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-3.5 w-3.5", "aria-hidden": true })
  },
  pending: {
    className: "border-warning/40 bg-warning/10 text-warning-foreground",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3.5 w-3.5", "aria-hidden": true })
  },
  error: {
    className: "border-destructive/30 bg-destructive/10 text-destructive",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-3.5 w-3.5", "aria-hidden": true })
  },
  warning: {
    className: "border-warning/40 bg-warning/10 text-warning-foreground",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-3.5 w-3.5", "aria-hidden": true })
  },
  info: {
    className: "border-info/30 bg-info/10 text-info",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "h-3.5 w-3.5", "aria-hidden": true })
  },
  neutral: {
    className: "border-border bg-muted text-muted-foreground",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(CornerUpLeft, { className: "h-3.5 w-3.5", "aria-hidden": true })
  }
};
function statusTone(status) {
  const s = (status ?? "").toLowerCase();
  if (!s) return "neutral";
  if (/(approved|released|success|complete|posted|active|ok)/.test(s)) return "success";
  if (/(rejected|failed|error|cancel|blocked|inactive)/.test(s)) return "error";
  if (/(pending|awaiting|in progress|open)/.test(s)) return "pending";
  if (/(warning|hold|partial)/.test(s)) return "warning";
  if (/(sent.?back|returned)/.test(s)) return "neutral";
  return "info";
}
function StatusBadge({ status, tone, label, className }) {
  const t = tone ?? statusTone(status);
  const { className: toneClass, icon } = TONES[t];
  const text = label ?? (status ? String(status) : "Unknown");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "span",
    {
      className: cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-xs font-medium",
        toneClass,
        className
      ),
      children: [
        icon,
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: text })
      ]
    }
  );
}
export {
  StatusBadge as S
};
