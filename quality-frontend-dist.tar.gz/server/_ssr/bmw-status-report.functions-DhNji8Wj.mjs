import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-vRnzxAp6.mjs";
import { a as createServerFn } from "./server-CeMw7B2X.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-BtdUo7VX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, D as enumType, z as stringType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "BMW_Status_Report";
const fetchBmwStatusReport_createServerFn_handler = createServerRpc({
  id: "727b15fffa4ad8ec43f90290c8f3ef58b311dbb4b5e11f6f367881fa7d094582",
  name: "fetchBmwStatusReport",
  filename: "src/lib/sd/bmw-status-report.functions.ts"
}, (opts) => fetchBmwStatusReport.__executeServer(opts));
const fetchBmwStatusReport = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  sales_org_from: stringType().trim().max(10),
  sales_org_to: stringType().trim().max(10),
  customer_from: stringType().trim().max(40).optional().default(""),
  customer_to: stringType().trim().max(40).optional().default(""),
  contract_from: stringType().trim().max(40).optional().default(""),
  contract_to: stringType().trim().max(40).optional().default(""),
  mode: enumType(["customer", "contract", "sales"])
}).parse(d)).handler(fetchBmwStatusReport_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url, sap_base_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const inputs = {
    SALES_ORG_FROM: data.sales_org_from,
    SALES_ORG_TO: data.sales_org_to || data.sales_org_from,
    CUSTOMER_FROM: data.customer_from,
    CUSTOMER_TO: data.customer_to || data.customer_from,
    CONTRACT_FROM: data.contract_from,
    CONTRACT_TO: data.contract_to || data.contract_from,
    R_CUS: data.mode === "customer" ? "X" : "",
    R_CONT: data.mode === "contract" ? "X" : "",
    R_SALES: data.mode === "sales" ? "X" : ""
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "POST";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      configId: cfg.id,
      inputs
    });
    proxied = true;
  } else {
    const {
      resolveSapUrl
    } = await import("./url-Cdjg0c3W.mjs");
    target = resolveSapUrl(cfg.endpoint_url.trim(), globalSettings?.sap_base_url ?? null);
    headers["Content-Type"] = "application/json";
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
    bodyOut = JSON.stringify(inputs);
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const {
    createHash
  } = await import("node:crypto");
  const payloadHash = createHash("sha256").update(bodyOut ?? "").digest("hex");
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `bmw-status network: ${errMsg}`
    });
    return {
      rows: [],
      columns: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `Could not reach SAP: ${errMsg}`
    };
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  const message = `${res.status} ${res.statusText}`;
  if (!res.ok) {
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `bmw-status: ${message} sha256=${payloadHash.slice(0, 16)} ${text.slice(0, 400)}`
    });
    return {
      rows: [],
      columns: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      rows: [],
      columns: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? json : json;
  const arr = Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : Array.isArray(sapJson) ? sapJson : [];
  const allRows = arr.map((r) => {
    const o = {};
    for (const k of Object.keys(r ?? {})) o[k] = r[k] ?? null;
    return o;
  });
  const seen = /* @__PURE__ */ new Set();
  const rows = [];
  for (const r of allRows) {
    const key = JSON.stringify(r);
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push(r);
  }
  const duplicates_removed = allRows.length - rows.length;
  const columns = rows.length > 0 ? Object.keys(rows[0]) : [];
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `bmw-status: ${message} · sha256=${payloadHash.slice(0, 16)} · raw_rows=${allRows.length} deduped=${rows.length} dup_removed=${duplicates_removed} · bytes=${text.length}`
  });
  return {
    rows,
    columns,
    mode: data.mode,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    count: rows.length,
    raw_count: allRows.length,
    duplicates_removed,
    error: null
  };
});
export {
  fetchBmwStatusReport_createServerFn_handler
};
