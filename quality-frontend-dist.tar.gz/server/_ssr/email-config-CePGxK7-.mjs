import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { P as PageHeader } from "./page-header-T_FU5SF3.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { S as Switch } from "./switch-CQ4rbtn8.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-CZRUt5a6.mjs";
import { A as Alert, a as AlertDescription } from "./alert-C6rylLLk.mjs";
import { S as SkeletonCards } from "./skeleton-rows-C2wJYLiJ.mjs";
import { u as usePermissions } from "./use-permissions-CVVfE7Yp.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";

import "../_libs/seroval.mjs";
import { r as CircleAlert, M as Mail, s as EyeOff, t as Eye, X, I as Info, u as Send, v as Save } from "../_libs/lucide-react.mjs";
import { a as objectType, z as stringType, C as arrayType, G as literalType, B as numberType, y as booleanType, D as enumType } from "../_libs/zod.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "./skeleton-C5WX2eNf.mjs";
import "./use-auth-CXN9VXh3.mjs";
import "./client-CXnFcWf4.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./use-active-context-CMJTykFM.mjs";
import "./use-sap-profile-DRIQ-_33.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./screen-keys-mn2QOK0m.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




const encryptionSchema = enumType(["none", "ssl", "tls", "starttls"]);
const configSchema = objectType({
  enabled: booleanType(),
  host: stringType().trim().max(200).nullable().optional().default(null),
  port: numberType().int().min(1).max(65535).nullable().optional().default(null),
  encryption: encryptionSchema.default("tls"),
  username: stringType().trim().max(200).nullable().optional().default(null),
  from_email: stringType().trim().email().max(200).nullable().or(literalType("")).optional(),
  from_name: stringType().trim().max(200).nullable().optional().default(null),
  cc_recipients: arrayType(stringType().trim().email().max(200)).max(50).default([]),
  app_password: stringType().max(500).optional()
  // empty/undefined = keep existing
});
const getNoReplyEmailConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("3bb6f4f62712d6fe529a483b782014c5e5a9ee261c9f21644b66f7ea45cd0728"));
const saveNoReplyEmailConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => configSchema.parse(d)).handler(createSsrRpc("24c9b8c545ac80eace6b3e6fc3038857c795f0f1c7ed5f5ced2c5d9a8e02811e"));
const sendNoReplyTestEmail = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  to: stringType().trim().email().max(200)
}).parse(d)).handler(createSsrRpc("27cdea68d5651b3c710b32a7cce10b3e2072834255ac838bce2a9dc9826bbecb"));
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function EmailConfigPage() {
  const perms = usePermissions();
  const allowed = perms.can("settings.email_config");
  const loadFn = useServerFn(getNoReplyEmailConfig);
  const saveFn = useServerFn(saveNoReplyEmailConfig);
  const testFn = useServerFn(sendNoReplyTestEmail);
  const [loading, setLoading] = reactExports.useState(true);
  const [saving, setSaving] = reactExports.useState(false);
  const [testing, setTesting] = reactExports.useState(false);
  const [enabled, setEnabled] = reactExports.useState(true);
  const [host, setHost] = reactExports.useState("smtp.gmail.com");
  const [port, setPort] = reactExports.useState("587");
  const [encryption, setEncryption] = reactExports.useState("tls");
  const [username, setUsername] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [hasPassword, setHasPassword] = reactExports.useState(false);
  const [showPw, setShowPw] = reactExports.useState(false);
  const [fromEmail, setFromEmail] = reactExports.useState("");
  const [fromName, setFromName] = reactExports.useState("");
  const [cc, setCc] = reactExports.useState([]);
  const [ccInput, setCcInput] = reactExports.useState("");
  const [testTo, setTestTo] = reactExports.useState("");
  reactExports.useEffect(() => {
    if (!allowed) return;
    let cancelled = false;
    (async () => {
      try {
        const cfg = await loadFn();
        if (cancelled) return;
        setEnabled(cfg.enabled);
        setHost(cfg.host ?? "");
        setPort(cfg.port != null ? String(cfg.port) : "");
        setEncryption(cfg.encryption);
        setUsername(cfg.username ?? "");
        setFromEmail(cfg.from_email ?? "");
        setFromName(cfg.from_name ?? "");
        setCc(cfg.cc_recipients ?? []);
        setHasPassword(cfg.hasPassword);
      } catch (e) {
        toast.error("Failed to load email configuration", {
          description: e.message
        });
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [allowed, loadFn]);
  function commitCc(raw) {
    const parts = raw.split(/[,\s]+/).map((s) => s.trim()).filter(Boolean);
    const next = [...cc];
    for (const p of parts) if (EMAIL_RE.test(p) && !next.includes(p)) next.push(p);
    setCc(next);
    setCcInput("");
  }
  function onCcKey(e) {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      if (ccInput.trim()) commitCc(ccInput);
    } else if (e.key === "Backspace" && !ccInput && cc.length) {
      setCc(cc.slice(0, -1));
    }
  }
  async function onSave() {
    if (fromEmail && !EMAIL_RE.test(fromEmail)) {
      toast.error("From Email is not a valid email address");
      return;
    }
    setSaving(true);
    try {
      await saveFn({
        data: {
          enabled,
          host: host.trim() || null,
          port: port.trim() ? Number(port) : null,
          encryption,
          username: username.trim() || null,
          from_email: fromEmail.trim() || null,
          from_name: fromName.trim() || null,
          cc_recipients: cc,
          app_password: password
        }
      });
      if (password) setHasPassword(true);
      setPassword("");
      toast.success("Configuration saved");
    } catch (e) {
      toast.error("Failed to save", {
        description: e.message
      });
    } finally {
      setSaving(false);
    }
  }
  async function onTest() {
    if (!testTo || !EMAIL_RE.test(testTo)) {
      toast.error("Enter a valid test recipient email");
      return;
    }
    setTesting(true);
    try {
      await testFn({
        data: {
          to: testTo
        }
      });
      toast.success(`Test email sent to ${testTo}`);
    } catch (e) {
      toast.error("Test email failed", {
        description: e.message
      });
    } finally {
      setTesting(false);
    }
  }
  if (perms.loading || loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "page-shell page-stack max-w-5xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonCards, { count: 1 }) });
  }
  if (!allowed) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "page-shell max-w-2xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { variant: "destructive", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { children: "You are not authorized to view this screen." })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "page-shell page-stack max-w-5xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Settings", title: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-6 w-6 text-primary" }),
      "Email Configuration"
    ] }), subtitle: "Configure the No-Reply SMTP sender used for all outbound system emails." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-card border border-border rounded-lg shadow-card p-6 space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "font-semibold text-lg inline-flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-5 w-5 text-primary" }),
          "No Reply Email Configuration"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground mt-1", children: "System sender used for vendor-related notifications (invitations, submission alerts, password resets, etc.)." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-4 rounded-md border border-border bg-muted/40 px-4 py-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold", children: "Enable No-Reply Sending" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground mt-0.5", children: "When off, system notifications are not sent." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: enabled, onCheckedChange: setEnabled })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid md:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "host", children: "SMTP Host" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "host", value: host, onChange: (e) => setHost(e.target.value), placeholder: "smtp.gmail.com" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "port", children: "Port" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "port", type: "number", value: port, onChange: (e) => setPort(e.target.value), placeholder: "587" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "encryption", children: "Encryption" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: encryption, onValueChange: (v) => setEncryption(v), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { id: "encryption", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "none", children: "None" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "ssl", children: "SSL (465)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "tls", children: "TLS (587)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "starttls", children: "STARTTLS" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "username", children: "Username" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "username", value: username, onChange: (e) => setUsername(e.target.value), placeholder: "user@example.com" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { htmlFor: "password", children: [
            "App Password",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground font-normal", children: hasPassword ? "(leave empty to keep existing)" : "(required)" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "password", type: showPw ? "text" : "password", value: password, onChange: (e) => setPassword(e.target.value), className: "pr-10", placeholder: hasPassword ? "••••••••" : "" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setShowPw((v) => !v), className: "absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1", "aria-label": showPw ? "Hide password" : "Show password", children: showPw ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-4 w-4" }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "from-email", children: "From Email" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "from-email", type: "email", value: fromEmail, onChange: (e) => setFromEmail(e.target.value) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "from-name", children: "From Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "from-name", value: fromName, onChange: (e) => setFromName(e.target.value) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { htmlFor: "cc", children: [
            "CC Recipients ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground font-normal", children: "(optional)" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-10 flex flex-wrap items-center gap-1.5 rounded-md border border-input bg-background px-2 py-1.5 focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-0", children: [
            cc.map((email) => /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-accent text-accent-foreground text-xs font-medium px-2.5 py-1", children: [
              email,
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setCc(cc.filter((e) => e !== email)), className: "hover:text-destructive", "aria-label": `Remove ${email}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3 w-3" }) })
            ] }, email)),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { id: "cc", className: "flex-1 min-w-[8rem] bg-transparent outline-none text-sm py-1", value: ccInput, onChange: (e) => setCcInput(e.target.value), onKeyDown: onCcKey, onBlur: () => ccInput.trim() && commitCc(ccInput), placeholder: cc.length ? "Add another…" : "name@example.com" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Add one or more emails. Press Enter or comma after each. Every valid address here is CC'd on the buyer notification email. Invalid entries are skipped automatically." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { className: "border-info/30 bg-info/5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "h-4 w-4 text-info" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDescription, { className: "text-sm", children: [
          "This account is the ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "From" }),
          " address for buyer notifications and the SAP-triggered password reset emails."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 pt-2 border-t border-border", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 sm:max-w-sm w-full", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "test-to", children: "Send test to" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "test-to", type: "email", value: testTo, onChange: (e) => setTestTo(e.target.value), placeholder: "you@example.com" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", onClick: onTest, disabled: testing, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "h-4 w-4 mr-2" }),
            " ",
            testing ? "Sending…" : "Send Test Email"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: onSave, disabled: saving, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4 mr-2" }),
            " ",
            saving ? "Saving…" : "Save Configuration"
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  EmailConfigPage as component
};
