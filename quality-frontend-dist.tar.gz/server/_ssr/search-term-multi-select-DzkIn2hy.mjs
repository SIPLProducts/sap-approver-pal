import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useServerFn, c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { C as Checkbox } from "./checkbox-mmp_duDa.mjs";
import { B as Button } from "./button-vZ1dO6Qq.mjs";
import { P as Popover, a as PopoverTrigger, b as PopoverContent, C as Command, c as CommandInput, d as CommandList, f as CommandGroup, g as CommandItem } from "./command-i9zWGkU5.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { r as runSapApi } from "./sap.functions-oOi__-nP.mjs";
import { n as ChevronsUpDown, a3 as LoaderCircle } from "../_libs/lucide-react.mjs";
const getSearchTermConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("9032204eb35b34de05ff6c56419bf9ae7686d91dc7f3e6a54d7109b2318638db"));
function parseJsonIfPossible(value) {
  if (typeof value !== "string") return value;
  const trimmed = value.trim();
  if (!trimmed || !(trimmed.startsWith("[") || trimmed.startsWith("{"))) return value;
  try {
    return JSON.parse(trimmed);
  } catch {
    return value;
  }
}
function collectRows(value, depth = 0) {
  if (depth > 6 || value == null) return [];
  const parsed = parseJsonIfPossible(value);
  if (Array.isArray(parsed)) return parsed;
  if (!parsed || typeof parsed !== "object") return [];
  if ("SEARCH_TERM" in parsed) return [parsed];
  const candidates = [
    parsed.DATA,
    parsed.data?.DATA,
    parsed.data?.data,
    parsed.data,
    parsed.ITEMS,
    parsed.items,
    parsed.RESULTS,
    parsed.results,
    parsed.SEARCH_TERMS,
    parsed.SEARCH_TERM_LIST
  ];
  for (const candidate of candidates) {
    const rows = collectRows(candidate, depth + 1);
    if (rows.length) return rows;
  }
  for (const child of Object.values(parsed)) {
    const rows = collectRows(child, depth + 1);
    if (rows.length) return rows;
  }
  return [];
}
function extractSearchTermOptions(resp) {
  const rows = collectRows(resp);
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const row of rows) {
    if (row == null) continue;
    const parsedRow = parseJsonIfPossible(row);
    if (!parsedRow || typeof parsedRow !== "object" || Array.isArray(parsedRow)) continue;
    const raw = parsedRow.SEARCH_TERM;
    if (raw == null) continue;
    const code = String(raw).trim();
    if (!code || seen.has(code)) continue;
    seen.add(code);
    out.push({ code, text: "" });
  }
  return out;
}
function getSearchTermParseError(resp) {
  const parsed = parseJsonIfPossible(resp);
  if (!parsed || typeof parsed !== "object") return null;
  const direct = parsed.__parse_error;
  if (typeof direct === "string" && direct.trim()) return direct.trim();
  const candidates = [parsed.data, parsed.DATA, parsed.body, parsed.result];
  for (const candidate of candidates) {
    const nested = getSearchTermParseError(candidate);
    if (nested) return nested;
  }
  return null;
}
function SearchTermMultiSelect({
  value,
  onChange,
  plants,
  placeholder = "Select search term…",
  disabled,
  className
}) {
  const [open, setOpen] = reactExports.useState(false);
  const [search, setSearch] = reactExports.useState("");
  const [debouncedSearch, setDebouncedSearch] = reactExports.useState("");
  const PAGE_SIZE = 50;
  const [visibleCount, setVisibleCount] = reactExports.useState(PAGE_SIZE);
  const loadMoreRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 250);
    return () => clearTimeout(t);
  }, [search]);
  reactExports.useEffect(() => {
    if (!open) {
      setSearch("");
      setDebouncedSearch("");
      setVisibleCount(PAGE_SIZE);
    }
  }, [open]);
  const getCfg = useServerFn(getSearchTermConfig);
  const runApi = useServerFn(runSapApi);
  const cfgQuery = useQuery({
    queryKey: ["sap-search-term-config"],
    queryFn: () => getCfg(),
    staleTime: 10 * 60 * 1e3
  });
  const configId = cfgQuery.data?.configId ?? null;
  const plantKey = (plants ?? []).join(",");
  const hasQuery = debouncedSearch.length >= 2;
  const stQuery = useQuery({
    queryKey: ["sap-search-terms", configId, plantKey],
    enabled: !!configId && open,
    staleTime: 5 * 60 * 1e3,
    queryFn: async () => {
      const inputs = {};
      if (plants && plants.length > 0) {
        inputs.PLANT = plants[0];
        inputs.PLANTS = plants;
        inputs.VKORG = plants[0];
      }
      const resp = await runApi({ data: { configId, inputs } });
      const payload = resp?.data ?? resp;
      const parseError = getSearchTermParseError(payload);
      if (parseError) {
        throw new Error(`SAP returned malformed JSON: ${parseError}`);
      }
      return extractSearchTermOptions(payload);
    }
  });
  const options = reactExports.useMemo(() => stQuery.data ?? [], [stQuery.data]);
  const selected = reactExports.useMemo(() => new Set(value), [value]);
  const triggerLabel = value.length ? value.join(", ") : "";
  const filtered = reactExports.useMemo(() => {
    if (!hasQuery) return options;
    const q = debouncedSearch.toLowerCase();
    return options.filter((o) => o.code.toLowerCase().includes(q));
  }, [options, debouncedSearch, hasQuery]);
  reactExports.useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [debouncedSearch, options]);
  const visible = reactExports.useMemo(() => filtered.slice(0, visibleCount), [filtered, visibleCount]);
  const hasMore = filtered.length > visibleCount;
  reactExports.useEffect(() => {
    if (!hasMore || !loadMoreRef.current) return;
    const el = loadMoreRef.current;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisibleCount((c) => c + PAGE_SIZE);
        }
      },
      { root: el.closest("[cmdk-list]"), threshold: 0.1 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [hasMore, visibleCount, filtered.length]);
  function toggle(code) {
    if (selected.has(code)) {
      onChange(value.filter((c) => c !== code));
    } else {
      onChange([...value, code]);
    }
  }
  function toggleAllFiltered() {
    const codes = filtered.map((o) => o.code);
    const allSelected = codes.length > 0 && codes.every((c) => selected.has(c));
    if (allSelected) {
      onChange(value.filter((c) => !codes.includes(c)));
    } else {
      const merged = /* @__PURE__ */ new Set([...value, ...codes]);
      onChange(Array.from(merged));
    }
  }
  if (!cfgQuery.isLoading && !configId) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "outline",
        disabled: true,
        className: cn("h-9 w-full justify-between text-muted-foreground font-sans", className),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate text-left", children: "Get_Search_Term not configured" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronsUpDown, { className: "ml-2 h-3.5 w-3.5 shrink-0 opacity-50" })
        ]
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "outline",
        role: "combobox",
        "aria-expanded": open,
        disabled: disabled || cfgQuery.isLoading,
        className: cn(
          "h-9 w-full justify-between",
          !value.length && "text-muted-foreground font-sans",
          className
        ),
        children: [
          cfgQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2 font-sans", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Loading…"
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: cn("truncate text-left", value.length && "font-mono"), children: triggerLabel || placeholder }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronsUpDown, { className: "ml-2 h-3.5 w-3.5 shrink-0 opacity-50" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PopoverContent,
      {
        className: "z-[1000] w-[380px] p-0 max-h-[60vh]",
        align: "start",
        side: "bottom",
        sideOffset: 6,
        avoidCollisions: false,
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Command, { shouldFilter: false, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            CommandInput,
            {
              placeholder: "Search… (type 2+ chars to filter)",
              className: "h-9",
              value: search,
              onValueChange: setSearch
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CommandList, { className: "max-h-[calc(60vh-3rem)]", children: stQuery.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 py-6 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
            " Fetching search terms…"
          ] }) : stQuery.isError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-4 text-xs text-destructive space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: "Failed to load search terms." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] opacity-80 break-words", children: stQuery.error?.message ?? "Unknown error" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "underline", onClick: () => stQuery.refetch(), children: "Retry" })
          ] }) : filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-xs text-muted-foreground", children: hasQuery ? `No search terms match "${debouncedSearch}".` : "No search terms available." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            !hasQuery && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-2 text-[11px] text-muted-foreground border-b", children: [
              "Showing first ",
              Math.min(visibleCount, filtered.length),
              " of ",
              filtered.length,
              " — type 2+ characters to filter."
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandGroup, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                CommandItem,
                {
                  value: "__select_all__",
                  onSelect: toggleAllFiltered,
                  className: "font-medium border-b rounded-none",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      Checkbox,
                      {
                        checked: filtered.length > 0 && filtered.every((o) => selected.has(o.code)),
                        tabIndex: -1,
                        className: "pointer-events-none mr-2"
                      }
                    ),
                    filtered.every((o) => selected.has(o.code)) ? `Clear all matching (${filtered.length})` : `Select all matching (${filtered.length})`
                  ]
                }
              ),
              visible.map((o) => {
                const isSel = selected.has(o.code);
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  CommandItem,
                  {
                    value: `${o.code} ${o.text}`,
                    onSelect: () => toggle(o.code),
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        Checkbox,
                        {
                          checked: isSel,
                          tabIndex: -1,
                          className: "pointer-events-none mr-2"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: o.code }),
                      o.text && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 text-muted-foreground truncate", children: [
                        "— ",
                        o.text
                      ] })
                    ]
                  },
                  o.code
                );
              }),
              hasMore && /* @__PURE__ */ jsxRuntimeExports.jsx(
                CommandItem,
                {
                  value: "__load_more__",
                  onSelect: () => setVisibleCount((c) => c + PAGE_SIZE),
                  className: "justify-center text-xs text-muted-foreground",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref: loadMoreRef, className: "w-full text-center", children: [
                    "Load more (showing ",
                    visible.length,
                    " of ",
                    filtered.length,
                    ")"
                  ] })
                }
              )
            ] })
          ] }) })
        ] })
      }
    )
  ] });
}
export {
  SearchTermMultiSelect as S
};
