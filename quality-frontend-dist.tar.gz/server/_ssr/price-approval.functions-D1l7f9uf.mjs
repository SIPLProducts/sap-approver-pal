import { c as createSsrRpc } from "./createSsrRpc-Bx8XQbeC.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";
import { a as objectType, z as stringType, C as arrayType, D as enumType, A as unionType, B as numberType } from "../_libs/zod.mjs";
const getMySapUserId = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("715e000d0382e3f7239a277c6d3f2aa8fc6d648c7b8b6922bcf5b9a76be5a513"));
const fetchPriceApprovals = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().trim().min(1).max(40)).min(1, "At least one plant required"),
  user_id: stringType().trim().max(40).optional()
}).parse(d)).handler(createSsrRpc("5383f3852d157fea104f725b8dc6df79144352f3f3a14f59ef271d29f85bad22"));
const PriceRowSchema = objectType({
  select_flg: stringType().nullable().optional(),
  key_combination: stringType().nullable().optional(),
  condition_type: stringType().nullable().optional(),
  customer: stringType().nullable().optional(),
  price_group: stringType().nullable().optional(),
  plant: stringType().nullable().optional(),
  material: stringType().nullable().optional(),
  new_price: unionType([stringType(), numberType()]).nullable().optional(),
  currency: stringType().nullable().optional(),
  uom: stringType().nullable().optional(),
  calculation_sc: stringType().nullable().optional(),
  valid_from_sc: stringType().nullable().optional(),
  valid_to_sc: stringType().nullable().optional(),
  old_price: unionType([stringType(), numberType()]).nullable().optional(),
  release_code1: stringType().nullable().optional(),
  approval_status: stringType().nullable().optional()
});
const submitPriceDecision = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["accepted", "rejected"]),
  rows: arrayType(PriceRowSchema).min(1, "Select at least one row"),
  user_id: stringType().trim().max(40).optional()
}).parse(d)).handler(createSsrRpc("395e5e8e35398358f77e3d39bbac36aa3d90daa92ea960d33b53c87d6fcc874f"));
export {
  fetchPriceApprovals as f,
  getMySapUserId as g,
  submitPriceDecision as s
};
