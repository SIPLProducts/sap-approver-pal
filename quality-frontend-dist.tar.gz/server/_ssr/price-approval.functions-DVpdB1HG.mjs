import process from "node:process";
import { Buffer } from "node:buffer";
import { c as createServerRpc } from "./createServerRpc-Bm5Y9dpM.mjs";
import { a as createServerFn } from "./server-6SfJ9jtE.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-Drtg4FDX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, z as stringType, C as arrayType, A as unionType, B as numberType, D as enumType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";

import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const CONFIG_NAME = "Price_Approval_Fetch";
function pick(o, k) {
  if (!o || typeof o !== "object") return null;
  const hit = Object.keys(o).find((x) => x.toLowerCase() === k.toLowerCase());
  return hit ? o[hit] ?? null : null;
}
function mapRow(raw) {
  return {
    select_flg: pick(raw, "SELECT_FLG"),
    key_combination: pick(raw, "KEY_COMBINATION"),
    condition_type: pick(raw, "CONDITION_TYPE"),
    customer: pick(raw, "CUSTOMER"),
    price_group: pick(raw, "PRICE_GROUP"),
    plant: pick(raw, "PLANT"),
    material: pick(raw, "MATERIAL"),
    new_price: pick(raw, "NEW_PRICE"),
    currency: pick(raw, "CURRENCY"),
    uom: pick(raw, "UOM"),
    calculation_sc: pick(raw, "CALCULATION_SC"),
    valid_from_sc: pick(raw, "VALID_FROM_SC"),
    valid_to_sc: pick(raw, "VALID_TO_SC"),
    old_price: pick(raw, "OLD_PRICE"),
    release_code1: pick(raw, "RELEASE_CODE1"),
    approval_status: pick(raw, "APPROVAL_STATUS")
  };
}
const getMySapUserId_createServerFn_handler = createServerRpc({
  id: "715e000d0382e3f7239a277c6d3f2aa8fc6d648c7b8b6922bcf5b9a76be5a513",
  name: "getMySapUserId",
  filename: "src/lib/sd/price-approval.functions.ts"
}, (opts) => getMySapUserId.__executeServer(opts));
const getMySapUserId = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMySapUserId_createServerFn_handler, async ({
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data
  } = await supabaseAdmin.from("profiles").select("sap_user_id").eq("id", context.userId).maybeSingle();
  let fallback = null;
  if (!data?.sap_user_id) {
    const {
      data: cfg
    } = await supabaseAdmin.from("sap_api_configs").select("id").eq("name", CONFIG_NAME).maybeSingle();
    if (cfg) {
      const {
        data: f
      } = await supabaseAdmin.from("sap_api_request_fields").select("default_value").eq("config_id", cfg.id).eq("field_name", "USER_ID").maybeSingle();
      fallback = f?.default_value ?? null;
    }
  }
  return {
    sap_user_id: data?.sap_user_id ?? fallback ?? ""
  };
});
const fetchPriceApprovals_createServerFn_handler = createServerRpc({
  id: "5383f3852d157fea104f725b8dc6df79144352f3f3a14f59ef271d29f85bad22",
  name: "fetchPriceApprovals",
  filename: "src/lib/sd/price-approval.functions.ts"
}, (opts) => fetchPriceApprovals.__executeServer(opts));
const fetchPriceApprovals = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  plants: arrayType(stringType().trim().min(1).max(40)).min(1, "At least one plant required"),
  user_id: stringType().trim().max(40).optional()
}).parse(d)).handler(fetchPriceApprovals_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${CONFIG_NAME}" not found. Configure it in Admin → SAP API.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: prof
  }, {
    data: userIdField
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("profiles").select("sap_user_id").eq("id", context.userId).maybeSingle(), supabaseAdmin.from("sap_api_request_fields").select("default_value").eq("config_id", cfg.id).eq("field_name", "USER_ID").maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const userId = data.user_id && data.user_id.trim() || prof?.sap_user_id && prof.sap_user_id.trim() || userIdField?.default_value || "NEOBMWCONS";
  const firstPlant = data.plants[0];
  const plantArray = data.plants.map((p) => ({
    plant: p
  }));
  const join = cfg.endpoint_url.includes("?") ? "&" : "?";
  const qs = `${join}PLANT=${encodeURIComponent(firstPlant)}&USER_ID=${encodeURIComponent(userId)}`;
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "GET";
  let bodyOut;
  const headers = {
    Accept: "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/price_approval/Fetch`;
    method = "POST";
    headers["Content-Type"] = "application/json";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      inputs: {
        PLANT: plantArray,
        USER_ID: userId
      }
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url + qs;
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  let rows = [];
  let message = "";
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
    if (proxied && res.status === 404) {
      const peek = await res.clone().text().catch(() => "");
      if (/Cannot\s+POST/i.test(peek)) {
        const fallback = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
        res = await fetch(fallback, {
          method: "POST",
          headers,
          body: JSON.stringify({
            configId: cfg.id,
            inputs: {
              PLANT: plantArray,
              USER_ID: userId
            }
          })
        });
        target = fallback;
      }
    }
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    const latency_ms2 = Date.now() - t0;
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: latency_ms2,
      message: `price-fetch network: ${errMsg}`
    });
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      user_id: userId,
      error: `Could not reach SAP at ${cfg.endpoint_url.split("?")[0]}. ${errMsg}. The endpoint may be on a private network not accessible from this server.`
    };
  }
  const text = await res.text().catch(() => "");
  message = `${res.status} ${res.statusText}`;
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    if (proxied && res.status === 404 && /Cannot\s+POST/i.test(text)) {
      message = `Middleware is outdated — copy the latest middleware/server.js and restart it (${res.status})`;
    }
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `price-fetch: ${message} ${text.slice(0, 500)}`
    });
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      user_id: userId,
      error: `SAP returned ${message}: ${text.slice(0, 200)}`
    };
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    return {
      rows: [],
      fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
      count: 0,
      user_id: userId,
      error: `Invalid JSON from SAP: ${text.slice(0, 200)}`
    };
  }
  const sapJson = proxied ? json?.data ?? {} : json;
  const arr = Array.isArray(sapJson?.DATA) ? sapJson.DATA : Array.isArray(sapJson?.data) ? sapJson.data : Array.isArray(sapJson) ? sapJson : [];
  rows = arr.map(mapRow);
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: rows.length,
    message: `price-fetch: ${message}`
  });
  return {
    rows,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    count: rows.length,
    user_id: userId,
    error: null
  };
});
const DECISION_CONFIG_NAME = "Price_Approve_Reject";
const PriceRowSchema = objectType({
  select_flg: stringType().nullable().optional(),
  key_combination: stringType().nullable().optional(),
  condition_type: stringType().nullable().optional(),
  customer: stringType().nullable().optional(),
  price_group: stringType().nullable().optional(),
  plant: stringType().nullable().optional(),
  material: stringType().nullable().optional(),
  new_price: unionType([stringType(), numberType()]).nullable().optional(),
  currency: stringType().nullable().optional(),
  uom: stringType().nullable().optional(),
  calculation_sc: stringType().nullable().optional(),
  valid_from_sc: stringType().nullable().optional(),
  valid_to_sc: stringType().nullable().optional(),
  old_price: unionType([stringType(), numberType()]).nullable().optional(),
  release_code1: stringType().nullable().optional(),
  approval_status: stringType().nullable().optional()
});
function toSapRow(r) {
  return {
    SELECT_FLG: "X",
    KEY_COMBINATION: str(r.key_combination),
    CONDITION_TYPE: str(r.condition_type),
    CUSTOMER: padCustomer(r.customer),
    PRICE_GROUP: str(r.price_group),
    PLANT: str(r.plant),
    MATERIAL: str(r.material),
    NEW_PRICE: str(r.new_price),
    CURRENCY: str(r.currency),
    UOM: str(r.uom),
    CALCULATION_SC: str(r.calculation_sc),
    VALID_FROM_SC: str(r.valid_from_sc),
    VALID_TO_SC: str(r.valid_to_sc),
    OLD_PRICE: str(r.old_price)
  };
}
function str(v) {
  return v == null ? "" : String(v);
}
function padCustomer(v) {
  const s = str(v).trim();
  return s && /^\d+$/.test(s) ? s.padStart(10, "0") : s;
}
const submitPriceDecision_createServerFn_handler = createServerRpc({
  id: "395e5e8e35398358f77e3d39bbac36aa3d90daa92ea960d33b53c87d6fcc874f",
  name: "submitPriceDecision",
  filename: "src/lib/sd/price-approval.functions.ts"
}, (opts) => submitPriceDecision.__executeServer(opts));
const submitPriceDecision = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
  action: enumType(["accepted", "rejected"]),
  rows: arrayType(PriceRowSchema).min(1, "Select at least one row"),
  user_id: stringType().trim().max(40).optional()
}).parse(d)).handler(submitPriceDecision_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: cfg
  } = await supabaseAdmin.from("sap_api_configs").select("*").eq("name", DECISION_CONFIG_NAME).maybeSingle();
  if (!cfg) throw new Error(`SAP API config "${DECISION_CONFIG_NAME}" not found.`);
  if (!cfg.is_active) throw new Error(`SAP API config "${DECISION_CONFIG_NAME}" is disabled.`);
  const [{
    data: creds
  }, {
    data: prof
  }, {
    data: userIdField
  }, {
    data: globalSettings
  }, {
    data: globalSecret
  }] = await Promise.all([supabaseAdmin.from("sap_api_credentials").select("*").eq("config_id", cfg.id).maybeSingle(), supabaseAdmin.from("profiles").select("sap_user_id").eq("id", context.userId).maybeSingle(), supabaseAdmin.from("sap_api_request_fields").select("default_value").eq("config_id", cfg.id).eq("field_name", "USER_ID").maybeSingle(), supabaseAdmin.from("sap_global_settings").select("connection_mode, middleware_url").eq("id", "default").maybeSingle(), supabaseAdmin.from("sap_global_secrets").select("proxy_secret").eq("id", "default").maybeSingle()]);
  const resolvedUserId = data.user_id && data.user_id.trim() || prof?.sap_user_id && prof.sap_user_id.trim() || userIdField?.default_value || "NEOBMWCONS";
  const sapPayload = {
    APPROV: data.action === "accepted" ? "X" : "",
    REJ: data.action === "rejected" ? "X" : "",
    USER_ID: resolvedUserId,
    DATA: data.rows.map(toSapRow)
  };
  const globalProxy = globalSettings?.connection_mode === "via_proxy" && !!globalSettings?.middleware_url;
  const useProxy = cfg.auth_type === "proxy" || globalProxy;
  const middlewareUrl = globalSettings?.middleware_url?.trim() || null;
  let target;
  let method = cfg.http_method ?? "PUT";
  let bodyOut;
  const headers = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  let proxied = false;
  if (useProxy) {
    if (!middlewareUrl) throw new Error("Proxy mode is on but no middleware URL is configured.");
    target = `${middlewareUrl.replace(/\/$/, "")}/price_approval/Price_Approve_Reject`;
    method = "POST";
    const secret = (cfg.proxy_secret_ref ? process.env[cfg.proxy_secret_ref] : void 0) || globalSecret?.proxy_secret || process.env.MIDDLEWARE_SHARED_SECRET;
    if (secret) headers["x-shared-secret"] = secret;
    bodyOut = JSON.stringify({
      inputs: sapPayload
    });
    proxied = true;
  } else {
    target = cfg.endpoint_url.trim();
    if (cfg.auth_type === "basic" && creds?.username && creds?.password_encrypted) {
      headers.Authorization = "Basic " + Buffer.from(`${creds.username}:${creds.password_encrypted}`).toString("base64");
    }
    bodyOut = JSON.stringify(sapPayload);
  }
  for (const [k, v] of Object.entries(creds?.extra_headers ?? {})) {
    headers[k] = v;
  }
  const t0 = Date.now();
  console.log("[submitPriceDecision] target=", target, "method=", method, "proxied=", proxied, "payload=", sapPayload);
  let res;
  try {
    res = await fetch(target, {
      method,
      headers,
      body: bodyOut
    });
    if (proxied && res.status === 404) {
      const peek = await res.clone().text().catch(() => "");
      if (/Cannot\s+(POST|PUT)/i.test(peek)) {
        const fallback = `${middlewareUrl.replace(/\/$/, "")}/sap/invoke`;
        res = await fetch(fallback, {
          method: "POST",
          headers,
          body: JSON.stringify({
            configId: cfg.id,
            inputs: sapPayload
          })
        });
        target = fallback;
      }
    }
  } catch (e) {
    const errMsg = e.message || "fetch failed";
    console.error("[submitPriceDecision] network error", errMsg);
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms: Date.now() - t0,
      message: `price-decision ${data.action}: network ${errMsg}`
    });
    throw new Error(`Could not reach SAP: ${errMsg}`);
  }
  const text = await res.text().catch(() => "");
  const latency_ms = Date.now() - t0;
  console.log("[submitPriceDecision] status=", res.status, "latency_ms=", latency_ms, "body=", text.slice(0, 1e3));
  if (!res.ok) {
    let upstream = "";
    try {
      const j = JSON.parse(text);
      if (j?.error) upstream = String(j.error);
      else if (j?.data) upstream = typeof j.data === "string" ? j.data : JSON.stringify(j.data);
    } catch {
    }
    await supabaseAdmin.from("sap_api_sync_log").insert({
      config_id: cfg.id,
      status: "error",
      latency_ms,
      message: `price-decision ${data.action}: ${res.status} ${text.slice(0, 500)}`
    });
    throw new Error(`SAP returned ${res.status} ${res.statusText}: ${upstream || text.slice(0, 300)}`);
  }
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = {
      raw: text
    };
  }
  await supabaseAdmin.from("sap_api_sync_log").insert({
    config_id: cfg.id,
    status: "ok",
    latency_ms,
    rows_processed: data.rows.length,
    message: `price-decision ${data.action}: ${res.status}`
  });
  return {
    ok: true,
    action: data.action,
    count: data.rows.length,
    sap_response: json
  };
});
export {
  fetchPriceApprovals_createServerFn_handler,
  getMySapUserId_createServerFn_handler,
  submitPriceDecision_createServerFn_handler
};
