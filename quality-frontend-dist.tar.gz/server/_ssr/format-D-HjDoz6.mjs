function toNumber(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value !== "string") return null;
  const v = value.trim().replace(/,/g, "");
  if (!v) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}
function formatNumber(value, fallback = "—") {
  const n = toNumber(value);
  if (n === null) return fallback;
  return n.toLocaleString("en-IN", { maximumFractionDigits: 3 });
}
function formatAmount(value, fallback = "—") {
  const n = toNumber(value);
  if (n === null) return fallback;
  return n.toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
function formatCurrency(value, fallback = "—") {
  const n = toNumber(value);
  if (n === null) return fallback;
  return `₹${formatAmount(n)}`;
}
function formatQuantity(value, uom) {
  const q = formatNumber(value);
  if (q === "—") return q;
  return uom ? `${q} ${uom}` : q;
}
function formatDate(value, fallback = "—") {
  if (value == null || value === "") return fallback;
  let d = null;
  if (value instanceof Date) d = value;
  else if (typeof value === "string") {
    const v = value.trim();
    if (/^\d{8}$/.test(v)) {
      d = /* @__PURE__ */ new Date(`${v.slice(0, 4)}-${v.slice(4, 6)}-${v.slice(6, 8)}T00:00:00`);
    } else {
      const parsed = new Date(v);
      d = Number.isNaN(parsed.getTime()) ? null : parsed;
    }
  }
  if (!d || Number.isNaN(d.getTime())) return fallback;
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }).replace(/ /g, "-");
}
function formatDateTime(value, fallback = "—") {
  if (value == null || value === "") return fallback;
  const d = value instanceof Date ? value : new Date(String(value));
  if (Number.isNaN(d.getTime())) return fallback;
  return `${formatDate(d)} ${d.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit"
  })}`;
}
export {
  formatCurrency as a,
  formatDate as b,
  formatQuantity as c,
  formatAmount as d,
  formatDateTime as f
};
