import { r as reactExports, j as jsxRuntimeExports } from "./_libs/react.mjs";
import { R as Route$u, o as oauth } from "./_ssr/router-BdEqF8Cp.mjs";
import { B as Button } from "./_ssr/button-vZ1dO6Qq.mjs";
import { C as Card } from "./_ssr/card-DcbU6Qrh.mjs";
import { B as BrandLogo } from "./_ssr/brand-logo-CzKKMZ3Z.mjs";
import "./_libs/sonner.mjs";
import "./_libs/unenv.mjs";

import "./_libs/lovable.dev__mcp-js.mjs";
import "./_libs/modelcontextprotocol__sdk.mjs";
import "./_libs/zod-to-json-schema.mjs";
import "./_libs/ajv-formats.mjs";
import "./_libs/web-push.mjs";


import "./_libs/tanstack__query-core.mjs";
import "./_libs/tanstack__react-query.mjs";
import "./_libs/tanstack__react-router.mjs";
import "./_libs/tanstack__router-core.mjs";
import "./_libs/tanstack__history.mjs";
import "./_libs/cookie-es.mjs";
import "./_libs/seroval.mjs";
import "./_libs/seroval-plugins.mjs";


import "./_libs/react-dom.mjs";
import "./_libs/isbot.mjs";
import "./_ssr/client-CXnFcWf4.mjs";
import "./_libs/supabase__supabase-js.mjs";
import "./_libs/supabase__postgrest-js.mjs";
import "./_libs/supabase__realtime-js.mjs";
import "./_libs/supabase__phoenix.mjs";
import "./_libs/supabase__storage-js.mjs";
import "./_libs/iceberg-js.mjs";
import "./_libs/supabase__auth-js.mjs";
import "./_libs/tslib.mjs";
import "./_libs/supabase__functions-js.mjs";
import "./_libs/tanstack__zod-adapter.mjs";
import "./_libs/zod.mjs";
import "./_ssr/client.server-D5ro3rAQ.mjs";

import "./_ssr/sap-client.server-CglbxEth.mjs";
import "./_ssr/push.server-Co_uxbPF.mjs";
import "./_libs/jose.mjs";
import "./_libs/ajv.mjs";
import "./_libs/fast-deep-equal.mjs";
import "./_libs/json-schema-traverse.mjs";
import "./_libs/fast-uri.mjs";

import "./_libs/asn1.js.mjs";
import "./_libs/bn.js.mjs";
import "./_libs/inherits.mjs";
import "./_libs/safer-buffer.mjs";
import "./_libs/minimalistic-assert.mjs";
import "./_libs/jws.mjs";

import "./_libs/safe-buffer.mjs";
import "./_libs/jwa.mjs";
import "./_libs/ecdsa-sig-formatter.mjs";
import "./_libs/buffer-equal-constant-time.mjs";
import "./_libs/http_ece.mjs";

import "./_libs/https-proxy-agent.mjs";



import "./_libs/debug.mjs";
import "./_libs/ms.mjs";
import "./_libs/supports-color.mjs";

import "./_libs/has-flag.mjs";
import "./_libs/agent-base.mjs";

import "./_libs/radix-ui__react-slot.mjs";
import "./_libs/radix-ui__react-compose-refs.mjs";
import "./_libs/class-variance-authority.mjs";
import "./_libs/clsx.mjs";
import "./_ssr/utils-H80jjgLf.mjs";
import "./_libs/tailwind-merge.mjs";
function Consent() {
  const details = Route$u.useLoaderData();
  const {
    authorization_id
  } = Route$u.useSearch();
  const [busy, setBusy] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  async function decide(approve) {
    setBusy(true);
    setError(null);
    const {
      data,
      error: error2
    } = approve ? await oauth().approveAuthorization(authorization_id) : await oauth().denyAuthorization(authorization_id);
    if (error2) {
      setBusy(false);
      setError(error2.message);
      return;
    }
    const target = data?.redirect_url ?? data?.redirect_to;
    if (!target) {
      setBusy(false);
      setError("No redirect returned by the authorization server.");
      return;
    }
    window.location.href = target;
  }
  const clientName = details?.client?.name ?? "an app";
  return /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "min-h-screen grid place-items-center p-6 bg-muted/30", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-8 max-w-md w-full space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BrandLogo, { className: "h-10" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-xl font-semibold tracking-tight", children: [
        "Connect ",
        clientName,
        " to Resustainability Approvals"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground mt-2", children: [
        clientName,
        " will be able to call this app's enabled tools while you are signed in. This does not bypass this app's permissions or backend policies."
      ] })
    ] }),
    error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { role: "alert", className: "text-sm text-destructive", children: error }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 justify-end pt-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", disabled: busy, onClick: () => decide(false), children: "Cancel connection" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { disabled: busy, onClick: () => decide(true), children: busy ? "Working…" : "Approve" })
    ] })
  ] }) });
}
export {
  Consent as component
};
